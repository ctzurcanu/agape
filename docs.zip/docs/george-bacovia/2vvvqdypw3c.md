---
id: 2vvvqdypw3c
title: "Decembre - December"
sidebar_label: "Decembre - December"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/2vvvqdypw3c"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Decembre - December

Lyrics: George Bacovia

Te uită cum ninge decembre…  
Spre geamuri, iubito, priveşte –  
Mai spune s-aducă jăratec  
Şi focul s-aud cum trosneşte.

Şi mână fotoliul spre sobă,  
La horn să ascult vijelia,  
Sau zilele mele – totuna –  
Aş vrea să le-nvăţ simfonia.

Mai spune s-aducă şi ceaiul,  
Şi vino şi tu mai aproape, –  
Citeşte-mi ceva de la poluri,  
Şi ningă… zăpada ne-ngroape.

Ce cald e aicea la tine,  
Şi toate din casă mi-s sfinte, –  
Te uită cum ninge decembre…  
Nu râde… citeşte nainte.

E ziuă şi ce întuneric…  
Mai spune s-aducă şi lampa –  
Te uită, zăpada-i cât gardul,  
Şi-a prins promoroacă şi clampa.

Eu nu mă mai duc azi acasă…  
Potop e-napoi şi nainte,  
Te uită cum ninge decembre…  
Nu râde… citeşte nainte.

Potop e-napoi şi nainte,  
Nu râde… citeşte nainte.

English:

He watches you as it snows in December…  
To the windows, my love, look –  
He also says to bring embers  
And I can hear the fire crackling.

And he pushes the armchair towards the stove,  
To the chimney to listen to the storm,  
Or my days – all the same –  
I would like to teach them a symphony.

He also says to bring the tea,  
And you come closer too, –  
Read me something from the poles,  
And it snows… the snow is burying us.

How warm it is here at your place,  
And everything in the house is sacred to me, –  
He watches you as it snows in December…  
Don’t laugh… read on.

It’s daytime and how dark…  
He also says to bring the lamp –  
He also says to bring you, the snow is as thick as the fence,  
And the sleet has caught up with the clamp.

I'm not going home today…  
Flood is back and forth,  
Look at how it snows in December…  
Don't laugh… read on.

Flood is back and forth,  
Don't laugh… read on.
