---
id: PLrZFPVQM38Mcopk5lvAyTvWDZ0CpiDR6e
title: "George Bacovia"
sidebar_label: "George Bacovia"
---

# George Bacovia

This is the landing page for the playlist "George Bacovia".

## Videos in this Playlist

- [Decembre - December](/agape/george-bacovia/2vvvqdypw3c)

