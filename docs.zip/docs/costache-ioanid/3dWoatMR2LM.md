---
id: 3dWoatMR2LM
title: "Giulgiul Gol - The Empty Shroud"
sidebar_label: "Giulgiul Gol - The Empty Shroud"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/3dWoatMR2LM"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Giulgiul Gol - The Empty Shroud

Lyrics: Costache Ioanid

Veghind într-un loc tăinuit,  
apostolii-n freamăt de teamă,  
în zarea de zi s-au trezit  
de-un iute şi viu ciocănit  
în uşa cu drugi de aramă.

Mormântul... femeile-au spus...  
e gol! Pe Domnul luară  
şi nu știm unde L-au pus.

Şi-acolo... pe lespezi... de sus,  
doi îngeri, venind, se-arătară.

Doi îngeri... Dar glasul s-a stins,  
căci toţi le priveau cu-ntristare.

Iar Toma plângea ca învins.  
Dar Petru mijlocul şi-a-ncins.  
Ioan a sărit în picioare!

Şi-ndată, pe drumuri pustii,  
sub cer sângerând ca o rană,  
cei doi străbătură în goană  
livezi îngrădite şi vii.

Şi sus, la mormânt, cu fiori,  
pe pragul cioplit ca o treaptă,  
Ioan... se opreşte... aşteaptă.

Iar Petru curând năvăleşte  
cum cade un înger pe-un trunchi  
şi plin de uimire, priveşte.

Fâşiile-n albe tipare,  
întreaga lor formă păstrând,  
lăsaseră trupul să zboare  
din ele, cum zboară un gând.

În balta de smirnă şi-aloe,  
stau pânzele tainic deşarte  
şi-i strâns obrăzarul deoparte!

În hohot de plâns fără voie,  
cu-ntreaga puterii măsură  
apostolii cred în Scriptură.  
Învinsă e veşnica moarte!  
Isus e stăpân pe natură!

Învinsă e veşnica moarte!  
Isus e stăpân pe natură!
