---
id: F22WTzrDLpY
title: "Piatra pecetluită - The Sealed Stone"
sidebar_label: "Piatra pecetluită - The Sealed Stone"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/F22WTzrDLpY"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Piatra pecetluită - The Sealed Stone

Lyrics: Costache Ioanid

Bătea o aripă de vânt.  
Şi noaptea era ca gheena.

Din vale, cu sufletul frânt,  
o ceată urca spre mormânt…  
Şi-n frunte era Magdalena.

Maria, cea smulsă din iad,  
din şapte otgoane de moarte,  
trecea printre stânci ca prin vad.

Şi toate-i păreau ca o carte...  
Şi-n toate citea lăcrimând  
poemul cel scris de curând  
cu jilave slove de sânge.

Acolo... privirea-ntorcând,  
Isus o văzuse cum plânge.  
Aici... El căzuse-n genunchi.  
Acolo-i vorbeau heruvimii.  
Aici, sprijinit pe un trunchi,  
vorbise cu milă mulţimii.

Maria privea mai departe.  
Şi gându-i zbura spre mormânt.

"Dar piatra din pragul cel sfânt,  
vai, cine-o va da la o parte?"  
Bătea o aripă de vânt  
deasupra cărării deşarte...

"Dar piatra din pragul cel sfânt,  
vai, cine-o va da la o parte?"

English:

A wind blew.  
And the night was like hell.

From the valley, with broken souls,  
a group climbed towards the tomb…  
And at the head was Magdalene.

Mary, the one torn from hell,  
from seven pits of death,  
was passing through the rocks as if through a ford.

And everything seemed to her like a book…  
And in everything she read, weeping  
the poem she had recently written  
with wet, blood-stained letters.

There... looking back,  
Jesus had seen her weeping.  
Here... He had fallen to his knees.  
There the cherubim were speaking to him.  
Here, leaning on a trunk,  
He had spoken with pity to the crowd.

Mary looked further.  
And her thoughts flew towards the tomb.

"But the stone from the holy threshold,  
alas, who will roll it away?"  
A wing of wind was beating  
over the empty path...

"But the stone of the holy threshold,  
alas, who will roll it away?"
