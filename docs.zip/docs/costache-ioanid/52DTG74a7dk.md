---
id: 52DTG74a7dk
title: "Doi îngeri - Two Angels"
sidebar_label: "Doi îngeri - Two Angels"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/52DTG74a7dk"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Doi îngeri - Two Angels

Lyrics: Costache Ioanid

Bătea o aripă de vânt  
cu dulce parfum de narcise.  
Asupra oraşului sfânt  
o geană de zori răsărise.

Maria urca spre mormânt.  
Şi gându-i zbura mai departe...  
"Dar piatra din pragul cel sfânt,  
vai, cine-o va da la o parte?"

Şi ceata se-opreşte acum.  
Şi inima-ncepe să bată.  
Se-adună surorile-n drum.

Acolo... sub stâncă... e fum...  
Şi piatra cea grea-i răsturnată!

Lăsând între pietre povara,  
aleargă femeile-n stol.

Şi toate sunt albe ca ceara:  
Mormântul... mormântul e gol!

Şi plânge în hohot Maria.  
Şi plânge... Vai, unde L-au pus?

Ori n-are un capăt urgia  
ce tot mai loveşte-n Isus?

Cum tremură frunza-n dumbravă  
se-crâncenă carnea de-amar.

Deodată, în haine de slavă,  
alături, doi tineri răsar.  
- De ce căutaţi între morţi  
pe Regele gloriei sfinte?  
Căci iată, negrele porţi  
le-a frânt, cum a spus mai-nainte!

Uimite spre îngeri privesc  
femeile-n rugi fremătăte.  
Şi fără de sine pornesc  
din deal, înspre sfânta cetate.
