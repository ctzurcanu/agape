---
id: Z5ewmb-RnoE
title: "Dar sus la Golgota... - But on Golgotha..."
sidebar_label: "Dar sus la Golgota... - But on Golgotha..."
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Z5ewmb-RnoE"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Dar sus la Golgota... - But on Golgotha...

Lyrics: Costache Ioanid

E plin de miraje pământul,  
de patimi ce-atrag în noroi,  
Muşcăm din păcat tot mai lacomi  
şi tot mai flămânzi şi mai goi.

Dar sus, la Golgota, pe cruce,  
cu pieptul de-o lance străpuns,  
la tainica vremii răscruce,  
ne-aşteaptă cu lacrimi Isus.

În ritm de stridente orchestre,  
perechile lumii petrec,  
crezând că-s mai tari decât moartea,  
spre braţele morţii se-ntrec.

Aleargă maşini pe artere.  
Rachete zvâcnesc printre nori.  
Tresare Selena-n cratere.  
Saturn e cuprins de fiori.

Tu, rege al vremurilor noastre,  
tu, om ce străbaţi prin stihii,  
tu ştii să te-nalţi către astre,  
dar taina supremă n-o ştii.

Tu nu ştii că sus pe Golgota,  
cu pieptul de-o lance străpuns,  
sub norii ce-ntunecă bolta,  
ne-aşteaptă cu lacrimi Isus.

sub norii ce-ntunecă bolta,  
ne-aşteaptă cu lacrimi Isus.

English:

The earth is full of mirages,  
of passions that drag us into the mud,  
We bite from sin more and more greedy  
and more and more hungry and naked.

But up, at Golgotha, on the cross,  
with his chest pierced by a lance,  
at the mystery of the crossroads of time,  
Jesus awaits us with tears.

To the rhythm of shrill orchestras,  
the world's couples pass by,  
believing they are stronger than death,  
towards the arms of death they rush.

Cars run on the arteries.  
Rockets shudder through the clouds.  
Selena trembles in the craters.  
Saturn is gripped by shivers.

You, king of our times,  
you, man who traverses the elements,  
you know how to ascend to the stars,  
but you do not know the supreme secret.

You don't know that up on Golgotha,  
with his chest pierced by a lance,  
under the clouds that darken the vault,  
Jesus awaits us with tears.

under the clouds that darken the vault,  
Jesus awaits us with tears.
