---
id: llavtzhssUc
title: "Biruinţa - Victory"
sidebar_label: "Biruinţa - Victory"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/llavtzhssUc"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Biruinţa - Victory

Lyrics: Costache Ioanid

Isus a înviat din morţi, biruitor,  
din Însăşi viaţa Lui dând viaţă tuturor!  
Şi-acum în rând cu noi, ca frate şi-mpărat,  
trăieşte, trăieşte, e viu cu-adevărat!

Cu mii de flori, cu frunze noi în crîng  
vin primăveri ce iarna iar înfrâng  
Şi toate spun că Cel Crucificat,  
trăieşte, trăieşte, e viu cu-adevărat!

Isus a înviat cu trup de slavă plin,  
aşa cum vom trăi si noi prin har divin.  
De două mii de ani în luptă ne'ncetat,  
trăieşte, trăieşte, e viu cu-adevărat!

Dar dacă-i drept că-nvie frunza iar  
şi florile când din pământ răsar,  
cu-atât mai mult Acel ce le-a creat  
trăieşte, trăieşte, e viu cu-adevărat!

Isus a înviat, puternic şi slăvit.  
Şi sutele de fraţi cu Domnul au vorbit.  
Apoi, în patru zări pornind, ei au strigat:  
trăieşte, trăieşte, e viu cu-adevărat!

Eu n-am văzut cum a-nviat Isus,  
nici mâna-n răni ca Toma nu I-am pus.  
Dar simt mereu că-n viaţa ce mi-a dat  
trăieşte, trăieşte, e viu cu-adevărat!

e viu cu-adevărat!

e viu cu-adevărat!

English: 

Jesus rose from the dead, victorious,  
from His own life giving life to all!  
And now, alongside us, as brother and king,  
He lives, lives, is truly alive!

With thousands of flowers, with new leaves in the grove  
springs come that defeat winter again  
And all say that the Crucified One,  
lives, lives, is truly alive!

Jesus rose with a body full of glory,  
just as we too will live by divine grace.  
For two thousand years in ceaseless struggle,  
He lives, lives, is truly alive!

But if it is true that the leaf lives again  
and the flowers when they sprout from the earth,  
how much more does the One who created them  
lives, lives, is truly alive!

Jesus is risen, powerful and glorious.  
And the hundreds of brothers with the Lord spoke.  
Then, starting in four directions, they shouted:  
He lives, lives, is truly alive!

I did not see how Jesus rose,  
nor did I put my hand in His wounds like Thomas.  
But I always feel that in the life that He gave me  
He lives, lives, is truly alive!
