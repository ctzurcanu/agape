---
id: _8-790muoWw
title: "Caiafa - Caiaphas"
sidebar_label: "Caiafa - Caiaphas"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/_8-790muoWw"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Caiafa - Caiaphas

Lyrics: Costache Ioanid

În zori,  
în falnicu-i palat,  
sări din patul său Caiafa,  
cu chip livid şi turburat,  
golindu-şi în potir carafa.

Apoi aprozii şi-a strigat:  
- Chemaţi acum în zori soborul  
să ţinem un sabat în plus!...  
Căci aşa sfârşim cu-acel ISUS!

În urmă, vom chema poporul.  
Şi-apoi vom merge pe Golgota,  
acolo unde-nşelătorul,  
Acela ce-Și zicea Mesia,  
Îşi doarme-n pânze veşnicia!  
Şi, fiindcă-i ziua învierii...  
chemaţi bătrânii cu podoabe,  
încinşi cu sfinte filacterii!

  
Dar iată... printre robi şi roabe,  
intrară în palat străjerii.

-Ce-i asta? Aţi lăsat mormântul!  
Cu-n glas întretăiat de-un tremur,  
ostaşii au luat cuvântul:

- A fost un înger... un cutremur...  
şi piatra a căzut deodată!  
- Ce-aţi spus? Vă duc la judecată!  
Ostaşi, voi aţi fugit din post!  
- Un înger... coborât pe piatră...  
un înger lângă noi a fost!

Era ca fulgerul pe cer  
când umple de sclipire norul.  
- Sunteţi nebuni. Când eşti străjer,  
mai ştii ce-i spaima şi fiorul?  
Vai, parcă m-a lovit un fier!  
Dar unde e... înşelătorul?  
- Ah, domnule, să-ţi spun curat:  
Înşelătorul a-nviat!  
- A în... vi... at? Ce vorbă-i asta?  
Ah, blestemaţii, ah, nerozii!  
Mi se despică-n două țeasta!  
Să vie înapoi aprozii...  
... Dar poate totuşi... e-o greşeală.  
Un mort e mort fără-ndoială!  
O fi pe-acolo... Cine ştie?  
- Nu-i nimeni. Peştera-i pustie.  
Şi zace-n miruri pânza goală.  
- Veţi merge-n lanţuri la galere!

Ba nu... mai bine... sst!... tăcere!  
Ei, ucenicii l-au furat...  
Aţi înţeles? Din neveghere,  
aţi adormit... puţin!... aseară.

Şi, ei, tâlharii, Îl furară!  
- Dar dregătorul?...  
- Fiţi pe pace!  
Vorbind în taină cu stăpânul,  
noi fără grijă vă vom face...

Şi le-a umplut cu aur sânul.

Şi le-a umplut cu aur sânul.

English:

At dawn,  
in his towering palace,  
Caiaphas jumped from his bed,  
with a livid and troubled face,  
emptying his carafe into his chalice.

Then he shouted to his disciples:  
- Call the council now at dawn  
to keep an extra Sabbath!

Because that's how we end up with that JESUS!

Afterwards, we will call the people.

And then we will go to Golgotha,  
where the deceiver,  
The one who called himself the Messiah,  
Sleeps his eternity in his sheets!  
And, since it is the day of the resurrection...  
call the elders in their ornaments,  
girded with holy phylacteries!

But behold... among the servants and maids,  
the guards entered the palace.

-What is this? You left the tomb!

With a trembling voice,  
the soldiers spoke:

- There was an angel... an earthquake...  
and the stone fell suddenly!  
- What did you say? I'll take you to court!  
Soldiers, you ran away from your post!  
- An angel... descended on the stone...  
an angel was near us!

It was like lightning in the sky  
when it fills the cloud with sparkle.  
- You are crazy. When you are a guard,  
do you know what fear and thrill are?  
Wow, it's like I've been struck by an iron rod!  
But where is... the deceiver?  
- Ah, sir, let me tell you plainly:  
The deceiver has risen!  
- He has... risen? What is this talk?  
- Ah, you damned ones, ah, fools!  
My skull is splitting in two!  
Let the apros come back...  
... But maybe still... it's a mistake.  
A dead man is dead without a doubt!  
He's probably over there... Who knows?  
- There's no one. The cave is deserted.  
And the empty canvas lies in the myrrh.  
- You'll go to the galleys in chains!

No... better... ssh!... silence!  
Well, the disciples stole him...  
Do you understand? Out of carelessness,  
you slept... a little!... last night.

And, they, the robbers, stole him!  
- But the governor?...  
- Be at peace!  
Speaking in secret with the master,  
we will make you...

And he filled their chest with gold.

And he filled their chest with gold.
