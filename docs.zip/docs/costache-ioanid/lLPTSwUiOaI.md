---
id: lLPTSwUiOaI
title: "Ecce homo!"
sidebar_label: "Ecce homo!"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/lLPTSwUiOaI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Ecce homo!

Lyrics: Costache Ioanid

"Ecce homo!" strigă-n Iad Pilat  
Cine iarăşi L-a crucificat?  
Cine-I scoate umbra de sub văl?  
Daţi-mi apă mâinile să-mi spăl!  
Revărsaţi-mi râuri peste pumnii plini!  
Sângele acesta voi l-aţi vrut, rabini!

"Ecce homo!" umbra a răspuns,  
Eu sunt umbra Omului străpuns.  
În zadar în lumea de păcat  
mâinile pătate ţi-ai spălat.  
Cei spălaţi de apă, ca şi apa pier.  
Cei spălaţi de Mine, sunt cu Mine-n cer!

  
"Ecce homo!" strigă-n Iad Pilat.  
Cine iar Îl vrea crucificat?  
Eu am spus întregului popor:  
Pe-mpăratul vostru să-L omor?  
Gândul meu pe cruce lămurit l-am scris.  
Nu sunt eu de vină! Nu eu Te-am ucis!

"Ecce homo!" umbra a răspuns,  
Omul care vede în ascuns.  
Dându-Mi titlul de-mpărat iudeu,  
tu stăteai pe însuşi tronul Meu...  
Şi, scriind pe cruce al domniei semn,  
tu domneai în slavă, Eu muream pe lemn...

  
"Ecce homo!" strigă-n Iad Pilat!  
Ca stăpân, Cezaru-i vinovat.  
Eu eram guvernator roman.  
N-am rostit osânda ca duşman.  
N-am oprit să-Ţi pună trupul în mormânt.  
Nu sunt ucenic, dar nici vrăjmaş nu-Ţi sunt!

"Ecce homo!" umbra a răspuns,  
Omu-n care singur te-ai străpuns.  
Tu ai vrut şi glorie şi-arginţi  
dar s-ajungi la urmă şi-ntre sfinţi.  
Nu-i decât o cale spre Eterna Stea!  
Cine nu-i pe cale, e-mpotriva Mea!
