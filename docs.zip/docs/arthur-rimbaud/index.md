---
id: PLrZFPVQM38MeDPeBhdxy91k63PF-ptATx
title: "Arthur Rimbaud"
sidebar_label: "Arthur Rimbaud"
---

# Arthur Rimbaud

This is the landing page for the playlist "Arthur Rimbaud".

## Videos in this Playlist

- [Première soirée - First Evening](/agape/arthur-rimbaud/-lM_LM4e3x4)

