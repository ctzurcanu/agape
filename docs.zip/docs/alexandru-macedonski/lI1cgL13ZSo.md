---
id: lI1cgL13ZSo
title: "Cântecul ploaiei - The Song of Rain"
sidebar_label: "Cântecul ploaiei - The Song of Rain"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/lI1cgL13ZSo"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Cântecul ploaiei - The Song of Rain

Versuri: Alexandru Macedonski

Plouă, plouă,  
Plouă cât poate să plouă.  
Cu ploaia ce cade, m-apasă  
Durerea cea veche, cea nouă...  
Afară e trist ca şi-n casă, -  
Plouă, plouă.

Plouă, plouă... -  
Plouă cât poate să plouă...  
Zadarnic vor cântece clare  
Ca florile umezi de rouă  
Cei vecinic scutiţi de-ntristare... -  
Plouă, plouă.

Plouă, plouă,  
Plouă cât poate să plouă...  
Fiinţa mea şi simţirea  
Sufăr şi plâng amândouă...  
Viaţa-şi urmează-ndârjirea...  
Plouă, plouă.

Plouă, plouă,  
Plouă cât poate să plouă...  
Rapănă-n geamuri ca-n tobe...  
Spintecă inima-n două  
Cântecul ploaiei de cobe... -  
Plouă, plouă... -

English:
