---
id: MuT2AuM79aA
title: "Pe balta clară - On the clear pond"
sidebar_label: "Pe balta clară - On the clear pond"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/MuT2AuM79aA"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Pe balta clară - On the clear pond

Versuri: Alexandru Macedonski, 1891

Pe balta clară...

Oh! sufletul!

Pe balta clară barca molatică plutea  
Albeţi neprihănite curgeau din cer; — voioase  
Zâmbeau în fundul apei răsfrângeri argintoase;

Oh! albă dimineață, și visul ce șoptea,  
Și norii albi — și crinii suavi — și balta clară,  
Și sufletul — curatul argint de-odinioară —

Oh! sufletul! — curatul argint de-odinioară.

Oh! sufletul!  
de-odinioară...

Oh! sufletul!  
de-odinioară...

Oh! sufletul!  
de-odinioară...

English:

On the clear pond...

Oh! the soul!

On the clear pond the soft boat floated  
Righteous whites flowed from the sky; — cheerful  
Silver reflections smiled at the bottom of the water;

Oh! white morning, and the whispering dream,  
And the white clouds — and the soft lilies — and the clear pond,  
And the soul — the pure silver of old —

Oh! the soul! — the pure silver of old.

Oh! the soul!  
of old...

Oh! the soul!  
of old...

Oh! the soul!  
of old...
