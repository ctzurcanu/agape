---
id: QELBGByv1DU
title: "Perdona a tu pueblo, Señor - Forgive your people, Lord"
sidebar_label: "Perdona a tu pueblo, Señor - Forgive your people, Lord"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/QELBGByv1DU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Perdona a tu pueblo, Señor - Forgive your people, Lord

Lyrics: Joaquín Díaz

Perdona a tu pueblo, Señor,  
perdona a tu pueblo.  
¡Perdónale, Señor!

No estés eternamente enojado,  
no estés eternamente enojado.  
¡Perdónale, Señor!

Por las heridas de pies y manos,  
por los azotes tan inhumanos.  
¡Perdónale, Señor!

Por tus profundas llagas crueles,  
por tus afrentas y por tus hieles.  
¡Perdónale, Señor!

Por los tres clavos que te clavaron  
y las espinas que te punzaron.  
¡Perdónale, Señor!

Perdona a tu pueblo, Señor,  
perdona a tu pueblo.  
¡Perdónale, Señor!

Por la abertura de tu costado  
no estés eternamente enojado.  
¡Perdónale, Señor!

No estés eternamente enojado,  
no estés eternamente enojado.  
¡Perdónale, Señor!

English:

Forgive your people, Lord,  
forgive your people.  
Forgive them, Lord!

Do not be eternally angry,  
do not be eternally angry.  
Forgive them, Lord!

For the wounds on their feet and hands,  
for the inhuman scourgings.  
Forgive them, Lord!

For your deep, cruel wounds,  
for your insults and your bitterness.  
Forgive them, Lord!

For the three nails that drove you  
and the thorns that pierced you.  
Forgive them, Lord!

Forgive your people, Lord,  
forgive your people.  
Forgive them, Lord!

Through the opening in your side,  
do not be eternally angry.  
Forgive them, Lord!

Do not be eternally angry,  
do not be eternally angry.  
Forgive them, Lord!
