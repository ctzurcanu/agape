---
id: GcyUa7s89u8
title: "Ce se întâmplă?"
sidebar_label: "Ce se întâmplă?"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/GcyUa7s89u8"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Ce se întâmplă?

[Urmăritorii]  
Spune-mi ce se întâmplă? Spune-mi ce se petrece.  
Ce se întâmplă? Spune-mi ce se petrece.  
Ce se întâmplă? Spune-mi ce se petrece.

[Iisus]  
De ce vreți să știți?  
Nu vă îngrijorați pentru viitor.  
Nu încercați să știți dinainte.  
Lăsați mâine pentru mâine;  
Gândiți-vă acum doar la ziua de azi.

Aș putea să vă dau date și cifre.  
Chiar să vă dau planuri și previziuni.  
Chiar să vă spun unde merg eu.

[Urmăritorii]  
Ce se întâmplă? Spune-mi ce se petrece.  
Ce se întâmplă? Spune-mi ce se petrece.

[Iisus]  
De ce vreți să știți?  
De ce sunteți obsedați de luptele  
Cu vremurile și soarta pe care nu le puteți sfida?  
Dacă ați ști drumul  înainte,  
L-ați înțelege și mai puțin decât mine.

[Urmăritorii]  
Ce se întâmplă? Spune-mi ce se petrece.  
Ce se întâmplă? Spune-mi ce se petrece.

[Ioana]  
Lasă-mă să încerc să-ți port crucea ta puțin.  
Lasă-mă să încerc să-ți port crucea ta puțin.

[Iisus]  
Ioana mm mm așa e bine,  
În timp ce voi trăncăniți prin thread-uri,  
Unde și când și cine și cum.  
Doar ea a încercat să-mi dea  
Ce am nevoie chiar acum.  
mm mm mm mm
