---
id: LOrvd0x2cNE
title: "Alas! and did my Savior bleed"
sidebar_label: "Alas! and did my Savior bleed"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/LOrvd0x2cNE"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Alas! and did my Savior bleed

Lyrics:  Isaac Watts, 1707

Alas! and did my Savior bleed,  
and did my Sovereign die!  
Would he devote that sacred head  
for sinners such as I?

Was it for crimes that I have done,  
he groaned upon the tree?  
Amazing pity! Grace unknown!  
And love beyond degree!

Well might the sun in darkness hide,  
and shut its glories in,  
when God, the mighty maker, died  
for his own creature's sin.

Thus might I hide my blushing face  
while his dear cross appears;  
dissolve my heart in thankfulness,  
and melt mine eyes to tears.

But drops of tears can ne'er repay  
the debt of love I owe.  
Here, Lord, I give myself away;  
'tis all that I can do.
