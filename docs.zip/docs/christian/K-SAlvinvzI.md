---
id: K-SAlvinvzI
title: "It Will Be Worth It All"
sidebar_label: "It Will Be Worth It All"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/K-SAlvinvzI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## It Will Be Worth It All

Lyrics: Esther K. Rusthoi, 1940

Sometimes the day seems long,  
Our trials hard to bear.  
We´re tempted to complain,  
to murmur and despair.  
But Christ will soon appear  
to catch his bride away!  
All tears forever over  
in God’s eternal day!

It will be worth it all  
when we see Jesus!  
Life’s trials will seem so small  
when we see Christ.  
One glimpse of his dear face,  
all sorrow will erase.  
So, bravely run the race  
till we see Christ.  
 

At times the sky seems dark,  
with not a ray of light;  
We’re tossed and driven on,  
no human help in sight.  
But there is One in heaven,  
Who knows our deepest care;  
Let Jesus solve your problems,  
just go to him in prayer.

It will be worth it all  
when we see Jesus!  
Life’s trials will seem so small  
when we see Christ.  
One glimpse of his dear face,  
all sorrow will erase.  
So, bravely run the race  
till we see Christ.  
 

Life’s day will soon be o’re,  
all storms forever past;  
We’ll cross the great divide  
to Glory, safe at last!  
We’ll share the joys of heaven:  
a harp, a home, a crown;  
The tempter will be banished,  
We’ll lay our burdens down.

It will be worth it all  
when we see Jesus!  
Life’s trials will seem so small  
when we see Christ.  
One glimpse of his dear face,  
all sorrow will erase.  
So, bravely run the race  
till we see Christ.
