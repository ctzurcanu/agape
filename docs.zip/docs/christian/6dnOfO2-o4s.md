---
id: 6dnOfO2-o4s
title: "Hristos a Înviat - Christ is Risen"
sidebar_label: "Hristos a Înviat - Christ is Risen"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/6dnOfO2-o4s"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Hristos a Înviat - Christ is Risen

Lyrics: Adrian Păunescu, 1995

Pe toată valea pământeană,  
E sfântă mama care naște,  
Hristos se naște dintr-o rană  
Cântați, creștinilor, e Paște!

Oricâte i se-ntâmplă lumii,  
Cel sfânt nu pleacă nicăierea  
Din jalea lacrimilor mumii,  
Mereu se-ntâmplă Învierea.

Lumânări la porți,  
Ceru-i luminat,  
Hristos a înviat din morți  
Hristos a înviat  
Hristos a înviat din morți  
Adevărat a-nviat!

  
Pe harta petelor de sânge  
Rătăcitoare este firea,  
Și Dumnezeu în ceruri plânge  
Să întețească-n noi iubirea.

Și învățăm din nou, cu milă  
Cum trece duhul în ființă,  
Că măreția e umilă  
Și totul este suferință.

Lumânări la porți,  
Ceru-i luminat,  
Hristos a înviat din morți  
Hristos a înviat  
Hristos a înviat din morți  
Adevărat a-nviat!

  
Veniți, creștinilor, la Domnul,  
Să vă convingeți că nu moare  
Doar uneori l-încearcă somnul  
Cum ne e dat la fiecare.

Aceasta-i noaptea minunată,  
Când însăși Biblia cuvântă  
Și Dumnezeu ni se arată,  
În foc de lumânare sfântă.

Lumânări la porți,  
Ceru-i luminat,  
Hristos a înviat din morți  
Hristos a înviat  
Hristos a înviat din morți  
Adevărat a-nviat!

English:

Throughout the earthly valley,  
The mother who gives birth is holy,  
Christ is born from a wound  
Sing, Christians, it's Easter!

No matter how much happens to the world,  
The saint does not go anywhere  
From the mourning of the mummy's tears,  
The Resurrection always happens.

Candles at the gates,  
Heaven is illuminated,  
Christ has risen from the dead  
Christ has risen  
Christ has risen from the dead  
Indeed, He is risen!

On the map of blood stains  
Nature is wandering,  
And God in heaven weeps  
To intensify love in us.

And we learn again, with mercy  
How the spirit passes into being,  
That greatness is humble  
And everything is suffering.

Candles at the gates,  
Heaven is illuminated,  
Christ is risen from the dead  
Christ is risen  
Christ is risen from the dead  
Indeed, He is risen!

Come, Christians, to the Lord,  
Convince yourselves that he does not die  
Only sometimes sleep tries him  
As is given to each of us.

This is the wonderful night,  
When the Bible itself speaks  
And God shows himself to us,  
In the fire of a holy candle.

Candles at the gates,  
Heaven is illuminated,  
Christ is risen from the dead  
Christ is risen  
Christ is risen from the dead  
Indeed, He is risen!
