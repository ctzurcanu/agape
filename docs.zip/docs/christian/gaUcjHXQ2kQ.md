---
id: gaUcjHXQ2kQ
title: "How Great Thou Art"
sidebar_label: "How Great Thou Art"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/gaUcjHXQ2kQ"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## How Great Thou Art

O Lord my God, When I in awesome wonder,  
Consider all the worlds Thy Hands have made;  
I see the stars, I hear the rolling thunder,  
Thy power throughout the universe displayed.  
   
Then sings my soul, My Saviour God, to Thee,  
How great Thou art, How great Thou art.  
Then sings my soul, My Saviour God, to Thee,  
How great Thou art, How great Thou art!

When through the woods, and forest glades I wander,  
And hear the birds sing sweetly in the trees.  
When I look down, from lofty mountain grandeur  
And see the brook, and feel the gentle breeze.  
   
Then sings my soul, My Saviour God, to Thee,  
How great Thou art, How great Thou art.  
Then sings my soul, My Saviour God, to Thee,  
How great Thou art, How great Thou art!

And when I think, that God, His Son not sparing;  
Sent Him to die, I scarce can take it in;  
That on the Cross, my burden gladly bearing,  
He bled and died to take away my sin.  
   
Then sings my soul, My Saviour God, to Thee,  
How great Thou art, How great Thou art.  
Then sings my soul, My Saviour God, to Thee,  
How great Thou art, How great Thou art!

When Christ shall come, with shout of acclamation,  
And take me home, what joy shall fill my heart.  
Then I shall bow, in humble adoration,  
And then proclaim: "My God, how great Thou art!"  
   
Then sings my soul, My Saviour God, to Thee,  
How great Thou art, How great Thou art.  
Then sings my soul, My Saviour God, to Thee,  
How great Thou art, How great Thou art!
