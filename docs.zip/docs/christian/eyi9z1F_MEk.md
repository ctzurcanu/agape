---
id: eyi9z1F_MEk
title: "Spune-mi cine a biruit frica - Tell me who overcame fear"
sidebar_label: "Spune-mi cine a biruit frica - Tell me who overcame fear"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/eyi9z1F_MEk"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Spune-mi cine a biruit frica - Tell me who overcame fear

Lyrics: Sunny Tranca

Hai, spune-mi cine a biruit moartea,  
Cine-a călcat peste ea ?  
Cine e Leul din Iuda,  
Scutul, tăria mea ?

Spune-mi cine a biruit frica,  
Cine-a călcat peste ea ?  
Cine e Leul din Iuda,  
Scutul, tăria mea?

Aleluia Aleluia Aleluia, Isus este Domn!  
Aleluia Aleluia Aleluia, Isus este Domn!

Hai spune-mi cine a murit pentru mine,  
Cine-a murit pentru noi ?  
Cine-a murit pentru lume ?  
Glorie doar Regelui !

Spune-mi cine-ntr-o zi se va-ntoarce  
În fruntea oştirii Lui ?  
El va primi închinarea,  
Pământul şi cerul e-al Lui !

Aleluia Aleluia Aleluia, Isus este Domn!  
Aleluia Aleluia Aleluia, Isus este Domn!

English: 

Come, tell me who has conquered death,  
Who has trampled on it?  
Who is the Lion of Judah,  
The shield, my strength?

Tell me who has conquered fear,  
Who has trampled on it?  
Who is the Lion of Judah,  
The shield, my strength?

Hallelujah Hallelujah Hallelujah, Jesus is Lord!

Hallelujah Hallelujah Hallelujah, Jesus is Lord!

Come, tell me who died for me,  
Who died for us?  
Who died for the world?  
Glory to the King alone!

Tell me who will one day return  
At the head of His army?  
He will receive worship,  
Earth and heaven are His!

Hallelujah Hallelujah Hallelujah, Jesus is Lord!  
Hallelujah Hallelujah Hallelujah, Jesus is Lord!
