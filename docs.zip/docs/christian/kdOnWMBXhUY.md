---
id: kdOnWMBXhUY
title: "Jesus Christ, Superstar v3: Act 1: Strange Thing Mystifying"
sidebar_label: "Jesus Christ, Superstar v3: Act 1: Strange Thing Mystifying"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/kdOnWMBXhUY"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Jesus Christ, Superstar v3: Act 1: Strange Thing Mystifying

[JUDAS]

It seems to me a strange thing, mystifying  
That a man like you can waste his time on women of her kind.

[SIMON]

Hey, cool it, man.

[JUDAS]

Yes, I can understand that she amuses,  
But to let her kiss you, stroke your hair, that's hardly in your line.  
It's not that I object to her profession,  
But she doesn't fit in well with what you teach and say.  
It doesn't help us if you're inconsistent.  
They only need a small excuse to put us all away.

[JESUS]

Who are you to criticize her?  
Who are you to despise her?  
Leave her, leave her, let her be now.  
Leave her, leave her, she's with me now.  
If your slate is clean, then you can throw stones.  
If your slate is not, then leave her alone.

I'm amazed that men like you can be so shallow, thick, and slow  
There is not a man among you who knows or cares if I come or go.

[ALL]

No, you're wrong!  
You're very wrong!  
No, you're wrong!  
You're very wrong!

[ALL]

No, you're wrong!  
You're very wrong!  
No, you're wrong!  
You're very wrong!  
How can you say that?  
How can you say that?  
How can you say that?  
How can you say that?

[JESUS]

Not one, not one of you!
