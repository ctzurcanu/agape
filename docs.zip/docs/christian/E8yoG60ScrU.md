---
id: E8yoG60ScrU
title: "Deo gratias Anglia - Give thanks, England"
sidebar_label: "Deo gratias Anglia - Give thanks, England"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/E8yoG60ScrU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Deo gratias Anglia - Give thanks, England

Lyrics: https://en.wikipedia.org/wiki/Agincourt_Carol

Deo gratias Anglia   
redde pro victoria!

Owre Kynge went forth to Normandy  
With grace and myght of chyvalry  
Ther God for hym wrought mervelusly;  
Wherefore Englonde may call and cry

Deo gratias!  
Deo gratias Anglia redde pro victoria!

He sette sege, forsothe to say,  
To Harflu towne with ryal aray;  
That toune he wan and made afray  
That Fraunce shal rewe tyl domesday.

Deo gratias!  
Deo gratias Anglia redde pro victoria!

Then went hym forth, owre king comely,  
In Agincourt feld he faught manly;  
Throw grace of God most marvelously,  
He had both feld and victory.

Deo gratias!  
Deo gratias Anglia redde pro victoria!

Ther lordys, erles and barone  
Were slayne and taken and that full soon,  
Ans summe were broght into Lundone  
With joye and blisse and gret renone.

Deo gratias!  
Deo gratias Anglia redde pro victoria!

Almighty God he keep owre kynge,  
His people, and alle his well-wyllynge,  
And give them grace wythoute endyng;  
Then may we call and savely syng:

Deo gratias!  
Deo gratias Anglia redde pro victoria!
