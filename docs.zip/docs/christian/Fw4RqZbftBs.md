---
id: Fw4RqZbftBs
title: "Psalmul 3 - Psalm 3"
sidebar_label: "Psalmul 3 - Psalm 3"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Fw4RqZbftBs"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Psalmul 3 - Psalm 3

Lyrics: St. Metropolitan Dosoftei, 1673  
https://en.wikipedia.org/wiki/Dosoftei

Doamne, cât se înmulțiră   
cei ce îmi caută vină! 

Asupra-mi mulți se sculară,   
cuvânt mare cuvântară,   
dând inimii lor crezare   
c-o să cad în disperare, 

că n-am sprijin de la Tine,   
Dumnezeul ce-mi faci bine,   
la nevoie îndrăzneală   
și de voie a mea fală! 

Că mi-ai împletit cunună,   
cu podoabă dimpreună,   
de m-ai pus cap peste alţii,   
să bat pe toţi necuraţii!. 

Am strigat cu glasul mare   
către Dumnezeu Cel tare,   
căci m-aude și mi-e scut   
din muntele Său cel sfânt. 

Am dormit somn cu odihnă   
până-n ziuă, de la cină,   
și m-am sculat dimineață,   
căci mi-e Dumnezeu povață. 

De mulțimi multe de gloate   
teamă n-am, și nici nu poate   
vestea rea să mă mâhnească,   
dimprejur să mă-nglodească. 

Scoală, Doamne, de mă scoate,   
din aste-ntristări, din toate,   
și le dă bătăi pe spate   
celor ce-mi fac nedreptate! 

Ca, scrâșnind, să-și frângă dinții,   
în durerea lor, greșiţii!   
Căci Dumnezeu, cu izbândă,   
va da celor buni dobândă. 

va da celor buni dobândă.

English:

Lord, how many have multiplied  
those who seek my fault!

Many have risen up against me,  
they have spoken great words,  
giving their hearts the belief  
that I will fall into despair,

that I have no support from You,  
God who does good to me,  
in need boldness  
and in my free will my boasting!

For you have woven a crown for me,  
with adornment together,  
when you have set me head above others,  
to strike down all the unclean!.

I cried out with a loud voice  
to God the Almighty,  
for he hears me and is my shield  
from his holy mountain.

I slept a sleep of rest  
until day, from dinner,  
and I rose up in the morning,  
for God is my counsel.

I am not afraid of many crowds, of crowds,  
nor can  
bad news grieve me,  
around me to besiege me.

Arise, O Lord, to bring me out,  
from these sorrows, from all,  
and strike on the back  
those who do me wrong!

So that, grinding, they may break their teeth,  
in their pain, the wrongdoers!  
For God, with success,  
will give interest to the good.

He will give interest to the good.
