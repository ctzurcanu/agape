---
id: wPDgQaHG5bg
title: "Psalmul 69 - Psalm 69"
sidebar_label: "Psalmul 69 - Psalm 69"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/wPDgQaHG5bg"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Psalmul 69 - Psalm 69

Lyrics: St. Metropolitan Dosoftei, 1673  
https://en.wikipedia.org/wiki/Dosoftei

Doamne, întru ajutorul meu să iei aminte,   
să m-auzi degrab', Dumnezeule Sfinte! 

Cei ce-mi caută răul, rău să pățească,   
viscolul din față să-i lovească! 

Să se-ntoarcă repede cu ocară   
cei ce mă batjocoresc în țară! 

Iar Drepţii să aibă voie bună,   
să se veselească împreună! 

Și tuturor celor ce, Doamne, Te caută,   
să le vină bucurie deasă cu laudă! 

Și să aibă pururea a zice:   
„Mărit să fii, Doamne, întru cele veșnice!  
Și celor ce iubesc a Ta izbândă,   
să le vină pururea dobândă!"

Iar eu, care sunt sărman și sărac,   
să ies vesel, Doamne, de la Tine, cu leac!   
Că mi-ești ajutor și sprijinire   
și vin, Doamne, fără zăbovire! 

  
Vin, Doamne, fără zăbovire!

English:

Lord, listen to me for my help,  
hear me quickly, Holy God!

Let those who seek my harm, may evil befall them,  
let the blizzard from before strike them!

Let those who mock me in the land be turned back quickly with disgrace!

And let the righteous be happy,  
rejoice together!

And to all who seek You, Lord,  
may joy and praise come to them!

And let them always say:  
“Be exalted, Lord, forever!  
And to those who love Your victory,  
may profit always come to them!”

And I, who am poor and needy,  
may I go joyfully, Lord, from You, with healing!  
For You are my help and support  
and I come, Lord, without delay!

I am coming, Lord, without delay!
