---
id: srhg_Zdw4WQ
title: "Tarantella per la nascita del Verbo - Tarantella for the birth of the Word"
sidebar_label: "Tarantella per la nascita del Verbo - Tarantella for the birth of the Word"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/srhg_Zdw4WQ"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Tarantella per la nascita del Verbo - Tarantella for the birth of the Word

Lyrics: Cristoforo Caresana, 1670

Alle selve, alle valli, alle grotte  
Adorate sì bella notte,  
Alle paglie alla capanna,  
Che ogni fiume già scorre manna.

Alle rupi, alle tane, alle selve  
E mansuete son fatte le belve.  
Ogni pianta nel bosco è fiorita  
Mentre torna nel mondo la vita.

Alle selve, alle valli, alle grotte  
Vagheggiate, riverite, adorate sì bella notte!  
Tarantola d’abisso, empio serpente  
Or ch’è nato l’Agnello innocente  
La tua forza si abbatterà.  
Piangi, trema, singhiozza, sospira  
Nel tuo regno d’oscurità.  
Viva, viva l’Eternità!

Tarantola ch’in Cielo il nido avesti  
Ma per troppo volar cadesti  
Da quel trono di maestà,  
Or che il Verbo dal Cielo è disceso  
Il tuo dente non ferirà.  
La superbia così va!

Tarantola ribelle, fulminata  
Or che in terra la luce è nata  
Nova fiamma ti struggerà!  
Si raddoppino a te le catene  
Or che ha l’huomo la libertà:  
Chi pugna col Cielo mai vincerà!

Or che al bosco fiorisce ogni pianta  
Or che al prato fiorisce ogni stelo  
Or che in Cielo risplende ogni stella  
Replicate la tarantella!

Alle selve, alle valli, alle grotte,  
Adorate sì bella notte,  
Alle balze, alle sponde, ai ruscelli  
Scotono i zefiri gli arboscelli;  
Fa l’erbette fiorire nel prato  
L’Alto Monarca che in terra è nato.  
Ai campi, alla riviera,  
Ride nel verno la primavera.

Alle selve, alle valli, alle grotte,  
Vagheggiate, riverite, adorate sì bella notte!

English: 

To the forests, to the valleys, to the caves,  
Adore the beautiful night,  
To the straw in the stable,  
Where every river now flows with manna.

To the cliffs, to the dens, to the forests,  
The beasts have been tamed.  
Every plant in the woods has blossomed,  
While life returns to the world.

To the forests, to the valleys, to the caves,  
Admire, revere, adore the beautiful night!  
Abyssal tarantula, vile serpent,  
Now that the Innocent Lamb is born,  
Your strength will be shattered.  
Weep, tremble, sob, sigh  
In your realm of darkness.  
Long live Eternity!

Tarantula that once had a nest in Heaven,  
But fell from too much flying  
From that throne of majesty,  
Now that the Word has descended from Heaven,  
Your bite will not harm.  
Thus goes pride!

Rebel tarantula, struck by lightning,  
Now that light has been born on earth,  
A new flame will consume you!  
May your chains be doubled  
Now that man has freedom:  
Who fights with Heaven will never win!

Now that every plant in the woods flourishes,  
Now that every blade of grass in the meadow flourishes,  
Now that every star in the sky shines,  
Replicate the tarantella!

To the forests, to the valleys, to the caves,  
Adore the beautiful night,  
To the cliffs, to the banks, to the streams,  
The zephyrs shake the trees;  
The grass blooms in the meadow  
Thanks to the High Monarch who was born on earth.  
To the fields, to the riverbank,  
Spring laughs in the winter.

To the forests, to the valleys, to the caves,  
Admire, revere, adore the beautiful night!
