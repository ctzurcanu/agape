---
id: KYeooJvfjwk
title: "Jesus Christ, Superstar v3: Act 2: The Crucifixion"
sidebar_label: "Jesus Christ, Superstar v3: Act 2: The Crucifixion"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/KYeooJvfjwk"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Jesus Christ, Superstar v3: Act 2: The Crucifixion

Father, forgive them.  
They don't know what they're doing.  
My God, my God, why have you forgotten me?  
Father, into your hands, I commend my spirit.
