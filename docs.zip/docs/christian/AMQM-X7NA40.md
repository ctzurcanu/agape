---
id: AMQM-X7NA40
title: "Isuse-al meu Prieten scump - Jesus, my dear Friend"
sidebar_label: "Isuse-al meu Prieten scump - Jesus, my dear Friend"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/AMQM-X7NA40"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Isuse-al meu Prieten scump - Jesus, my dear Friend

Lyrics: Traian Dorz

Isuse-al meu Prieten scump  
Din zorii tinereții,  
Cu Tine eu călătoresc  
Pân' la sfârșitul vieții!  
Cu Tine eu călătoresc  
Pân' la sfârșitul vieții!

În zori de zi când mă trezesc,  
Smerit m-aplec sub cruce,  
Că-n toată lumea asta n-am  
Un scut mai bun și dulce!  
Că-n toată lumea asta n-am  
Un scut mai bun și dulce!

Când merg pe-un drum îndepărtat,  
Isuse, ești cu mine,  
Să fie drumul cât de greu,  
E-așa ușor cu Tine!  
Să fie drumul cât de greu,  
E-așa ușor cu Tine!

Când am de suferit un chin,  
Tu, Doamne-mi dai putere,  
Să fie-amarul cât de greu,  
Îmi ești Tu mângâiere!  
Să fie-amarul cât de greu,  
Îmi ești Tu mângâiere!

Și nu mă tem că voi pieri  
În marea de păcate,  
Căci Tu, Preabunul meu, Isus,  
Le-ai biruit pe toate!  
Căci Tu, Preabunul meu, Isus,  
Le-ai biruit pe toate!

Tu ești Comoara care-ai fost  
De mine mult căutată,  
Și-acum eu nu Te-aș mai lăsa,  
Nici pentru lumea toată!  
Și-acum eu nu Te-aș mai lăsa,  
Nici pentru lumea toată!

Căci Tu-mi ești ca un frate bun  
Și-n cânt și în suspine,  
Isuse-al meu prieten drag,  
Ce bine-i lângă Tine!  
Isuse-al meu prieten drag,  
Ce bine-i lângă Tine!

English:

Jesus, my dear Friend  
From the dawn of youth,  
With You I travel  
Until the end of life!  
With You I travel  
Until the end of life!

At dawn when I wake up,  
Humiliatedly I bow beneath the cross,  
Because in all this world I have not  
A better and sweeter shield!  
Because in all this world I have not  
A better and sweeter shield!

When I walk a distant road,  
Jesus, you are with me,  
Let the road be as hard as it is,  
It is so easy with You!  
Let the road be as hard as it is,  
It is so easy with You!

When I have to suffer a torment,  
You, Lord, give me strength,  
Let the bitter be as hard as it is,  
You are my comfort!  
Let the bitter be as hard as it is,  
You are my comfort!

And I am not afraid that I will perish  
In the sea of ​​sins,  
Because You, my Most Good, Jesus,  
You have overcome them all!  
Because You, my Most Good, Jesus,  
You have overcome them all!

You are the Treasure that was  
Long sought by me,  
And now I would not leave You,  
Not even for the whole world!  
And now I would not leave You,  
Not even for the whole world!

Because You are like a good brother to me  
And in song and in sighs,  
My dear Jesus,  
How good it is to be near You!  
My dear Jesus,  
How good it is to be near You!
