---
id: HjLLp5abruo
title: "Palestine song - Palästinalied"
sidebar_label: "Palestine song - Palästinalied"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/HjLLp5abruo"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Palestine song - Palästinalied

Lyrics: Walther von der Vogelweide, 13th century  
Original Old German: https://youtu.be/FiWIFI1AiYw

Now my life has gained its meaning  
Since these sinful eyes behold  
The sacred land with meadows greening  
Whose renown was often told.  
  This was granted me from God:  
  To see the land, the holy sod,  
  Which in human form He trod.  
   
Splendid lands of wealth and power,  
I’ve seen many, far and near,  
Yet of all are you the flower.  
What a wonder happened here!  
  That a maid a child should bear,  
  Lord of all the angels fair,  
  Was not this a wonder rare?  
   
Here was He baptized, the Holy,  
That all people might be pure.  
Here He died, betrayed and lowly,  
That our bonds should not endure.  
  Else our fate had been severe.  
  Hail, O cross, o thorns and spear!  
  Heathens, woe! Your rage is clear.  
   
At the most compass'nate hour  
'Tis the place that he was slain  
The all splendrous in his power  
Gave himself up for our gain  
  To buy out our misery  
  What astounding prodigy  
  None alike shall ever be  
   
Thence to hell the son descended  
From the grave in which he lay  
By the father still attended  
And the spirits ineffable name  
  Like one bolt cut from one tree  
  Three in one and one are three  
  Thus did Abraham once see  
   
When He thence defeated Satan,  
Ne’er has kaiser battled so,  
He returned, our ways to straighten.  
Then the Jews had fear and woe:  
  Watch and stone were both in vain,  
  He appeared in life again,  
  Whom their hands had struck and slain.  
   
Forty days again he wandered  
And was seen all through the land  
Thus he rose but left, oh wonder  
His good ghost, protector, friend  
  He at once us sent back down  
  Bless'd shall be this land and town  
  His illustrous name reknown  
   
To this land, so He has spoken,  
Shall a fearful judgment come.  
Widows’ bonds shall then be broken  
And the orphans’ foe be dumb,  
  And the poor no longer cower  
  Under sad misuse of power.  
  Woe to sinners in that hour!  
   
Verdicts of all earthly trial  
Shall spare none of accusation  
In his hour due judgment's vial  
At last day's annunciation  
  Oh how great one's blame shall be  
  Evry soul shall bow the knee  
  Without pledge or guarantee  
   
Christians, heathen, Jews, contending,  
Claim it as a legacy.  
May God judge with grace unending  
Through his blessed Trinity.  
  Strife is heard on every hand:  
  Ours the only just demand,  
  He will have us rule the land.  
   
Now do not ignore i beg you  
All the things ye heard me say  
I'll expound at last the matter  
Then ye shall be on your way  
  All great deeds of awe and fear  
  That have ever come to ear  
  They began and end right here
