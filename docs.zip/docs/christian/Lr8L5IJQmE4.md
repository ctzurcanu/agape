---
id: Lr8L5IJQmE4
title: "Come, Thou Saviour of our race"
sidebar_label: "Come, Thou Saviour of our race"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Lr8L5IJQmE4"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Come, Thou Saviour of our race

Author: St. Ambrose  
Translator (into German): Martin Luther, 1524  
Translator (into English): William M. Reynolds, 1850

Come, Thou Saviour of our race,  
Choicest Gift of heav'nly grace!  
O Thou blessed Virgin's Son,  
Be Thy race on earth begun,  
Be Thy race on earth begun.

Not of mortal blood or birth,  
He descends from heaven to earth:  
By the Holy Ghost conceived,  
God and man by us believed,  
God and man by us believed.

Wondrous birth! O wondrous Child  
Of the virgin undefiled!  
Though by all the world disowned,  
Still to be in heaven enthroned,  
Still to be in heaven enthroned.

From the Father forth He came,  
And returneth to the same;  
Captive leading death and hell,--  
High the song of triumph swell!  
High the song of triumph swell!

Equal to the Father now,  
Though to dust Thou once didst bow,  
Boundless shall Thy kingdom be;  
When shall we its glories see?  
When shall we its glories see?

Brightly doth Thy manger shine!  
Glorious in its light divine:  
Let not sin o'ercloud this light,  
Ever be our faith thus bright,  
Ever be our faith thus bright.

Amen.
