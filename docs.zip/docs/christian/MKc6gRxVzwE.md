---
id: MKc6gRxVzwE
title: "Această Fecioară trebuie să Ardă"
sidebar_label: "Această Fecioară trebuie să Ardă"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/MKc6gRxVzwE"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Această Fecioară trebuie să Ardă

[Vocea Naratorului]  
Reverend Cauchon, curtea vă așteaptă cu interes.  
Toți teologii sunt prezenți pentru acest proces.

[Vocea lui Cauchon]  
Ah, domnilor, știți sarcina noastră în Rouen,  
Nu avem mult timp, și cereri mari de la Paris, Londra și Roma.

Ascultați această larmă, țăranii pe stradă!  
O fată ridică un steag și ei îi cad la picioare.

Trăiască-ne Ioana!  
Trăiască-ne fecioara!

Ea este periculoasă!  
Ea este periculoasă!

Fata este în turn. Ea va apărea în fața instanței.  
Misiunea ei de a răzvrăti masele noi trebuie să o curmăm.

Trăiască-ne Ioana!  
Trăiască-ne fecioara!

Ea este periculoasă!  
Ea este periculoasă!

Excelența Voastră, ea este chiar în curtea noastră.  
Reverend Cauchon, lăsați garda să o înfățișeze.

[Vocea lui Cauchon]  
Nu, așteptați! Avem nevoie de o soluție mai durabilă pentru orice presupus plebiscit.

Ce să facem cu Ioana d'Arc?  
Fecioara simplă, și eroina prostimii.

Nu vrem nici revolte, nici armate,   
nici noi crezuri, nici noi sfinți.

Un lucru pot spune, această Ioana nu ține oamenii cuminți.

Nu îndrăznim să o lăsăm să-și urmeze parcursul,  
Armatele de țărani vor căstiga concursul.

Dar cum s-o mai oprești? Farmecul ei crește,  
Este top de tendințe; orașe cucerește

Văd lucruri rele ce se apropie.  
Mulțimea o unge regină-profetă,   
Ordinea nostră va ajunge desuetă.

Văd sânge și rebranding,  
Locurile noastre de muncă   
externalizate din cauza unei fete.

Sânge și rebranding din cauza unei fete.

[Vocea Naratorului]  
Din cauza, din cauza, din cauza unei fete.

Locurile noastre de muncă   
externalizate din cauza unei fete.

Din cauza, din cauza, din cauza unei, din cauza unei, din cauza unei fete.

Ce să facem cu această Ioana-manie?  
Cum să gestionăm o regină-păstor?  
Cum rezolvăm cu o Fecioară mai mare  
Decât chiar Carol când Carol era încă mare?

[Vocea lui Cauchon]  
Naivilor, nu aveți nici o percepție!

Miza pe care o jucăm este înfricoșător de mare!  
Trebuie să o ardem complet,

La fel ca și Carol înaintea ei, această Ioana d'Arc trebuie să moară.  
Pentru binele Bisericii, nu lăsați moaște în urmă!

Trebuie să moară, trebuie să ardă, această Ioană trebuie să ardă.

La fel ca și Carol înaintea ei, această Ioana d'Arc trebuie să moară.  
Trebuie să moară, trebuie să ardă, această Ioană trebuie,  
Ioana trebuie, Ioana trebuie să ardă!

[Vocea Naratorului]  
Trebuie să moară, trebuie să ardă, această Ioană trebuie să ardă.

La fel ca și Carol înaintea ei, această Ioana d'Arc trebuie să moară.  
Trebuie să moară, trebuie să ardă, această Ioană trebuie,  
Ioana trebuie, Ioana trebuie să ardă!
