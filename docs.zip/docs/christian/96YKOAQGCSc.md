---
id: 96YKOAQGCSc
title: "Days of Elijah"
sidebar_label: "Days of Elijah"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/96YKOAQGCSc"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Days of Elijah

He who was, and who is, and who is to come

Behold He comes! Riding on the clouds!  
Shining like the sun! At the trumpet call  
Lift your voice! It's the year of Jubilee!  
And out of Zion's hill salvation comes!

These are the days of Elijah  
Declaring the Word of the Lord  
And these are the days of your servant Moses  
Righteousness being restored  
And though these are days of great trials  
Of famine and darkness and sword  
Still we are the voice in the desert crying  
Prepare ye the way of the Lord!  
   
Behold He comes! Riding on the clouds!  
Shining like the sun! At the trumpet call  
Lift your voice! It's the year of Jubilee!  
And out of Zion's hill salvation comes!

These are the days of Elijah  
Declaring the Word of the Lord  
And these are the days of your servant Moses  
Righteousness being restored  
And though these are days of great trials  
Of famine and darkness and sword  
Still we are the voice in the desert crying  
Prepare ye the way of the Lord!  
   
Behold He comes! Riding on the clouds!  
Shining like the sun! At the trumpet call  
Lift your voice! It's the year of Jubilee!  
And out of Zion's hill salvation comes!  
   
And these are the days of Ezekiel  
The dry bones becoming as flesh  
And these are the days of your servant David  
Rebuilding a temple of praise  
And these are the days of the harvest  
The fields are as white in the world  
And we are the labourers in your vineyard  
Declaring the word of the Lord!  
   
Behold He comes! Riding on the clouds!  
Shining like the sun! At the trumpet call  
Lift your voice! It's the year of Jubilee!  
And out of Zion's hill salvation comes!

Behold He comes! Riding on the clouds!  
Shining like the sun! At the trumpet call  
Lift your voice! It's the year of Jubilee!  
And out of Zion's hill salvation comes!

Lift your voice! It's the year of Jubilee!  
And out of Zion's hill salvation comes!

He who was, and who is, and who is to come

He who was, and who is, and who is to come

He who was, and who is, and who is to come
