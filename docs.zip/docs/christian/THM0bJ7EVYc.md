---
id: THM0bJ7EVYc
title: "Jesus Christ, Superstar v3: Act 2: The Last Supper"
sidebar_label: "Jesus Christ, Superstar v3: Act 2: The Last Supper"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/THM0bJ7EVYc"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Jesus Christ, Superstar v3: Act 2: The Last Supper

Jesus Christ, Superstar v3: Act 2: The Last Supper

Lyrics: Tim Rice

[APOSTLES]

Look at all my trials and tribulations  
Sinking in a gentle pool of wine.  
Don't disturb me now, I can see the answers  
'Till this evening is this morning, life is fine.  
Always hoped that I'd be an apostle.  
Knew that I would make it if I tried.  
Then when we retire, we can write the Gospels,  
So they'll still talk about us when we've died.

[JESUS]

The end...is just a little harder, when brought about by friends.  
For all you care, this wine could be my blood.  
For all you care, this bread could be my body.  
The end! This is my blood you drink.  
This is my body you eat.  
If you would remember me when you eat and drink.

I must be mad thinking I'll be remembered.  
Yes, I must be out of my head.  
Look at your blank faces. My name will mean nothing  
Ten minutes after I'm dead.  
One of you denies me.  
One of you betrays me.

[APOSTLES]

No! Who would?! Impossible!

[JESUS]

Peter will deny me in just a few hours.  
Three times will deny me,  
And that's not all I see.  
One of you here dining,  
One of my twelve chosen  
Will leave to betray me.

[JUDAS]

Cut the dramatics!  
You know very well who.

[JESUS]

Why don't you go do it?

[JUDAS]

You want me to do it!

[JESUS]

Hurry, they are waiting.

[JUDAS]

If you knew why I do it

[JESUS]

I don't care why you do it!

[JUDAS]

To think I admired you.  
Well, now I despise you.

[JESUS]

You liar. You Judas.

[JUDAS]

You want me to do it!  
What if I just stayed here  
And ruined your ambition.  
Christ, you deserve it.

[JESUS]

Hurry, you fool. Hurry and go.  
Save me your speeches,  
I don't want to know. Go!

[APOSTLES]

Look at all my trials and tribulations  
Sinking in a gentle pool of wine.  
What's that in the bread? It's gone to my head,  
'Till this morning is this evening, life is fine.  
Always hoped that I'd be an apostle.  
Knew that I would make it if I tried.  
Then when we retire, we can write the Gospels,  
So they'll all talk about us when we've died.

[JUDAS]

You sad, pathetic man, see where you've brought us to,  
Our ideals die around us and all because of you.  
But the saddest cut of all:  
Someone has to turn you in.  
Like a common criminal, like a wounded animal.  
A jaded mandarin,  
A jaded mandarin,  
Like a jaded, faded, faded, jaded, jaded mandarin.

[JESUS]

Get out they're waiting! Get out!  
They're waiting, Oh, they are waiting for you!

[JUDAS]

Every time I look at you I don't understand  
Why you let the things you did get so out of hand.  
You'd have managed better if you had it planned...  
Oh....

[APOSTLES]

Always hoped that I'd be an apostle.  
Knew that I would make it if I tried.  
Then when we retire, we can write the Gospels,  
So they'll still talk about us when we've died.

[JESUS]

Will no one stay awake with me?  
Peter, John, James?  
Will none of you wait with me?  
Peter, John, James?
