---
id: ZBjD8tf0mkk
title: "Inno Cavalieri Templari"
sidebar_label: "Inno Cavalieri Templari"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/ZBjD8tf0mkk"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Inno Cavalieri Templari

Lyrics: Salmo 133

Ecco quanto è buono e quanto è dolce  
che i fratelli vivano insieme!  
E' come olio profumato che sparso sul capo   
scende sulla barba di Aronne,  
che scende fino all'orlo dei suoi vestiti.

E' come rugiada dell'Ermon,  
che scende sui monti di Sion.  
perchè là il Signore ha donato la sua  benedizione  
e la vita per sempre.  
Amen
