---
id: lHjNRgMjdIM
title: "Jesus Christ, Superstar v3: Act 1: Overture"
sidebar_label: "Jesus Christ, Superstar v3: Act 1: Overture"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/lHjNRgMjdIM"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Jesus Christ, Superstar v3: Act 1: Overture

Turn on the subtitles for this opera!

Credits:

For the good news:      Jesus Christ  
Music of Overture:       Andrew Lloyd Webber   
Music of other parts:   AI  
Lyrics:                             Tim Rice  
Idea:                               Jesus Christ, Superstar - the rock opera  
AI Voice Editor:             Christian Tzurcanu  
Re-Orchestration:         Christian Tzurcanu  
All other work:              Christian Tzurcanu

Github repo: https://ctzurcanu.github.io/musical-JCS/
