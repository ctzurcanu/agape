---
id: pqaeY75uveI
title: "The Tyger"
sidebar_label: "The Tyger"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/pqaeY75uveI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## The Tyger

Lyrics: William Blake

Tyger Tyger, burning bright,   
In the forests of the night;   
What immortal hand or eye,   
Could frame thy fearful symmetry?

In what distant deeps or skies.   
Burnt the fire of thine eyes?  
On what wings dare he aspire?  
What the hand, dare seize the fire?

Tyger Tyger, burning bright,   
In the forests of the night; 

And what shoulder, & what art,  
Could twist the sinews of thy heart?  
And when thy heart began to beat.  
What dread hand? & what dread feet?

What the hammer? what the chain,  
In what furnace was thy brain?  
What the anvil? what dread grasp.  
Dare its deadly terrors clasp?

Tyger Tyger, burning bright,   
In the forests of the night; 

When the stars threw down their spears   
And water'd heaven with their tears:  
Did he smile his work to see?  
Did he who made the Lamb make thee?

Tyger Tyger burning bright,  
In the forests of the night:  
What immortal hand or eye,  
Dare frame thy fearful symmetry?

Tyger Tyger, burning bright,   
In the forests of the night;
