---
id: TMqvH2jetAI
title: "Revelation song"
sidebar_label: "Revelation song"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/TMqvH2jetAI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Revelation song

Lyrics: Revelation 4  
https://en.wikipedia.org/wiki/Revelation_Song

Worthy is the... Lamb who was slain  
Holy, holy is He

Sing a new song... to Him who sits on  
Heaven's mercy seat

Worthy is the... Lamb who was slain  
Holy, holy is He

Sing a new song... to Him who sits on  
Heaven's mercy seat  
   
Holy, holy, holy  
Is the Lord God Almighty  
Who was and is and is to come

With all creation I sing  
Praise to the King of Kings  
You are my everything  
And I will... adore you

Yeah! I will adore you

Clothed in rainbows... of living colors  
Flashes of lightening... rolls of thunder

Blessing and honor, strength and  
Glory and power be  
to You the only wise King  
   
Holy, holy, holy  
Is the Lord God Almighty  
Who was and is and is to come

With all creation I sing  
Praise to the King of Kings  
You are my everything  
And I will... adore you

Filled with wonder... awe-struck wonder  
At the mention of your name  
Jesus your name is power  
Breath and living water  
Such a marvelous mystery...   
   
Holy, holy, holy  
Is the Lord God Almighty  
Who was and is and is to come

With all creation I sing  
Praise to the King of Kings  
You are my everything  
And I will... adore you

Holy, holy, holy  
Is the Lord God Almighty  
Who was and is and is to come

With all creation I sing  
Praise to the King of Kings  
You are my everything  
And I will... adore you

Holy, holy, holy  
will... adore you
