---
id: TrQp9WquP-Y
title: "Adoro te devote - I devoutly adore you"
sidebar_label: "Adoro te devote - I devoutly adore you"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/TrQp9WquP-Y"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Adoro te devote - I devoutly adore you

Lyrics: St. Thomas Aquinas

Adóro te devóte, látens Déitas,  
Quæ sub his figúris, vere látitas:  
Tibi se cor meum totum súbjicit,  
Quia, te contémplans, totum déficit.  
   
Visus, tactus, gustus, in te fállitur,  
Sed audítu solo tuto créditur:  
Credo quidquid díxit Dei Fílius;  
Nil hoc verbo veritátis vérius.  
   
In cruce latébat sola Déitas,  
At hic látet simul et humánitas:  
Ambo támen crédens átque cónfitens,  
Peto quod petívit latro pœnitens.  
   
Plagas, sicut Thomas, non intúeor,  
Deum támen meum te confíteor.  
Fac me tibi sémper mágis crédere,  
In te spem habére, te dilígere.  
   
O memoriále mortis Dómini,  
Panis vivus, vitam præstans hómini,  
Præsta meæ menti de te vívere,  
Et te illi semper dulce sápere.  
   
Pie pellicáne, Jesu Dómine,  
Me immúndum munda tuo sánguine,  
Cujus una stilla salvum fácere,  
Totum mundum quit ab ómni scélere.  
   
Jesu, quem velátum nunc aspício,  
Oro fíat illud, quod tam sítio:  
Ut, te reveláta cernens fácie,  
Visu sim beátus tuæ glóriæ. 

Amen.

English:

I devoutly adore you  
I devoutly adore you, O hidden Deity,  
Truly hidden beneath these appearances.  
My whole heart submits to you,  
And in contemplating you, It surrenders itself completely.  
   
Sight, touch, and taste are all deceived in their judgment of you,  
But hearing suffices firmly to believe.  
I believe all that the Son of God has spoken;  
There is nothing truer than this word of truth.  
   
On the cross, only the divinity was hidden,  
But here humanity is also hidden.  
Yet believing and confessing both,  
I ask for what the repentant thief asked.  
   
I do not see the wounds as Thomas did,  
But I confess that you are my God.  
Make me believe more and more in you,  
Hope in you, and love you.  
   
O memorial of our Lord's death!  
Living bread that gives life to man,  
Grant my soul to live on you,  
And always to savor your sweetness.  
   
Lord Jesus, Good Pelican,  
wash my filthiness and clean me with your blood,  
One drop of which can free  
the entire world of all its sins.  
   
Jesus, whom now I see hidden,  
I ask you to fulfill what I so desire:  
That the sight of your face being unveiled  
I may have the happiness of seeing your glory. 

Amen.
