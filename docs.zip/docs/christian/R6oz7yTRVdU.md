---
id: R6oz7yTRVdU
title: "Joan’s Light"
sidebar_label: "Joan’s Light"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/R6oz7yTRVdU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Joan’s Light

Joan’s Light

From Joan of Arc, Supermaid rock opera https://youtu.be/ujWAriq0FT4?si=Iy7MSeQBU4SdVb6E&t=1809

[Joan]

White standard, bearer of light, proof of sun's godly might   
You give the heroes the right to know their reason to fight   
You survived revolutions raised reborn from the pyres   
Woven of deeds and duties moved by cosmic tremors  
How grand is this journey outside my own axes

High havens rolling my heart with one thunder   
Who am I? I live the fever of the storm of neither 

I am in the center of now. Born into being here.   
I was born to do this for ever of forever.  
Weaved the standard of hope. Shining its light whiter than white.  
In God's crystalline sublime, through the corridors of time, the heaven's plans assembled

I now begot the might and the light of the cause of reason to fight   
I alone remain in the right of being my own virgin mother  
the eye of the I 

My dear Christ, I once burned for your Church  
But in your name, good Christ,   
For your light, I forgot to know how to die. 

I now begot the might and the light of the cause of reason to fight   
I alone remain in the right of being my own virgin mother  
the eye of the I
