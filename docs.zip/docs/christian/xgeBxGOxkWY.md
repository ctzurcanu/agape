---
id: xgeBxGOxkWY
title: "Dies Iræ - The Day Of Wrath"
sidebar_label: "Dies Iræ - The Day Of Wrath"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/xgeBxGOxkWY"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Dies Iræ - The Day Of Wrath

Dies iræ, dies illa  
Solvet sæclum in favilla,  
Teste David cum Sibylla.  
   
Quantus tremor est futurus,  
Quando Judex est venturus,  
Cuncta stricte discussurus!  
   
Tuba mirum spargens sonum,  
Per sepulchra regionum,  
Coget omnes ante thronum.  
   
Mors stupebit et natura,  
Cum resurget creatura,  
Judicanti responsura.  
   
Liber scriptus proferetur,  
In quo totum continetur,  
Unde mundus judicetur.  
   
Judex ergo cum sedebit,  
Quidquid latet apparebit:  
Nil inultum remanebit.  
   
Quid sum miser tunc dicturus?  
Quem patronum rogaturus,  
Cum vix justus sit securus?  
   
Rex tremendæ majestatis,  
Qui salvandos salvas gratis,  
Salva me, fons pietatis.  
   
Recordare, Jesu pie,  
Quod sum causa tuæ viæ:  
Ne me perdas illa die.  
   
Quærens me, sedisti lassus:  
Redemisti Crucem passus:  
Tantus labor non sit cassus.  
   
Juste Judex ultionis,  
Donum fac remissionis,  
Ante diem rationis.  
   
Ingemisco, tamquam reus:  
Culpa rubet vultus meus:  
Supplicanti parce, Deus.  
   
Qui Mariam absolvisti,  
Et latronem exaudisti,  
Mihi quoque spem dedisti.  
   
Preces meæ non sunt dignæ;  
Sed tu bonus fac benigne,  
Ne perenni cremer igne.  
   
Inter oves locum præsta.  
Et ab hædis me sequestra,  
Statuens in parte dextra.  
   
Confutatis maledictis,  
Flammis acribus addictis,  
Voca me cum benedictis.  
   
Oro supplex et acclinis,  
Cor contritum quasi cinis,  
Gere curam mei finis.  
   
Lacrimosa dies illa,  
Qua resurget ex favilla,  
Judicandus homo reus.

Huic ergo parce, Deus:  
   
Pie Jesu Domine,  
Dona eis requiem. 

Amen.  
Amen.  
Amen.

English:

The day of wrath, on that day,  
It will dissolve the world into glowing ashes,  
As attested to by David with Sibyl.  
   
What trembling there will be,  
When the Judge shall come,  
To examine all in strict justice.  
   
The trumpet's wondrous call resounding,  
In tombs throughout the world,  
Gathering everyone toward the throne.  
   
Death and nature shall stand amazed,  
When creation rises from the dead again,  
To give an answer to its Judge.  
   
The written book will be brought forth,  
In which everything is contained,  
From which the world shall be judged.  
   
So when the Judge is seated,  
Whatever (sin) is hidden will be made known,  
Nothing shall go unpunished.  
   
What shall I, a wretch, say at that time,  
What advocate shall I ask (to plead for me),  
When even the righteous are not carefree.  
   
King of awesome majesty,  
Who, gives to those to be saved,  
The grace of salvation.  
   
Remember, Holy Jesus,  
That I am the reason for your (mortal) journey:  
Do not cast me aside on that day.  
   
Seeking me, You sat down wearily:  
You redeemed me suffering on The Cross.  
Let such toil not be in vain.  
   
Honored Judge of vengeance,  
Grant me forgiveness,  
Before the day of reckoning.  
   
I moan as one condemned:  
My face blushing for my sins:  
Spare (your) servant, (Oh) God.  
   
You who absolved Mary (Magdalen),  
And heard (the prayer) of the thief,  
(You) have given me hope.  
   
My prayers are not worthy;  
But You, (please) deal kindly with me.  
(So that) I will not burn in the eternal fire.  
   
Give me a place among the sheep,  
And separate me from the goats,  
Setting me on your right side.  
   
When the cursed have been silenced,  
Sentenced to searing flames,  
Call me among the blessed.  
   
Praying humbly and prostrate,  
A penitent heart like cold, heavy ashes,  
Arrange the care of me at my end.  
   
(On) that sorrowful day,  
Those rising from the glowing ashes,  
(The) accused man to be judged.  
Spare them, Oh God:  
   
Holy Jesus, Oh Lord,  
Grant them peace.  
Amen.
