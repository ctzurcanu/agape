---
id: lpDrptp-QvQ
title: "Betrayal"
sidebar_label: "Betrayal"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/lpDrptp-QvQ"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Betrayal

[JOAN]

Sire, must you betray me before I conquer Paris?

[FOLLOWERS]

What's the buzz?  
Tell me what's happening.   
What's the buzz?  
Tell me what's happening.  
What's the buzz?  
Tell me what's happening.  
What's the buzz?  
Tell me what's happening.  
What's the buzz?  
Tell me what's happening.

What's the buzz?  
Tell me what's happening.  
Hang on, Joan,  
We're going to fight for you!  
We're going to fight for you!  
We're going to fight for you!

[JOAN]

Put away your sword  
Don't you know that it's all over?  
It was nice, but now it's gone.  
Why are you obsessed with fighting?  
Stick to treaties from now on.

[FOLLOWERS]

Tell me Joan how you feel tonight.  
Do you plan to put up a fight?  
Do you feel that you've had the breaks?  
What would you say were your big mistakes?  
Do you think that you may retire?  
Did you think you would get much higher?  
How do you view your coming trial?  
Have your men proved at all worthwhile?  
Come with us to see Cauchon.  
You'll just love Rouen's courthouse.  
You'll just love seeing Cauchon.  
You'll just burn in the marketplace.  
Come on Joan this is not like you.  
Let us know what you're going to do.  
You know what you're supporters feel;  
You'll triumph in the final reel.  
Tell me Joan how you feel tonight.  
Do you plan to put up a fight?  
Do you feel that you've had the breaks?  
What would you say were your big mistakes?  
Come with us to see Cauchon.  
You'll just love Rouen's courthouse.  
You'll just love seeing Cauchon.  
You'll just burn in the marketplace.  
Now we have her!  
Now we have got her!  
Now we have her!  
Now we have got her!  
Now we have her!  
Now we have got her!  
Now we have her!  
Now we have got her!  
Now we have her!  
Now we have got her!

[CAUCHON]

Joan, you must realize the serious charges facing you.  
You say you're you hear voices of Saints in all your posts,  
Well, is it true?

[JOAN]

That's what you say, you say that I hear.

[CAUCHON]

There you have it gentlemen.  
What more evidence do we need?  
Sire, thank you for the victim.  
Stay a while and you'll see her bleed!

[FOLLOWERS]

Now we have her!  
Now we've got her!  
Now we have her!  
Now we've got her!  
Now we have her!  
Now we've got her!  
Now we have her!  
Now we've got her!

Take her to Rouen!   
Take her to Rouen!  
Take her to Rouen!  
Take her to Rouen!
