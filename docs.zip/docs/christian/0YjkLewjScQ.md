---
id: 0YjkLewjScQ
title: "Gaudete - Rejoice!"
sidebar_label: "Gaudete - Rejoice!"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/0YjkLewjScQ"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Gaudete - Rejoice!

Gaudete! gaudete! Christus est natus ex Maria Virgine: Gaudete!  
   
Tempus adest gratiae, Hoc quod optabamus;  
Carmina laeticiae Devote redamus.  
   
Gaudete! gaudete! Christus est natus ex Maria Virgine: Gaudete!  
   
Deus homo factus est, Natura mirante;  
Mundus renovatus est, A Christo regnante.  
   
Gaudete! gaudete! Christus est natus ex Maria Virgine: Gaudete!  
   
Ezechiellis porta Clausa pertransitur;  
Unde lux est orta, Salus invenitur.  
   
Gaudete! gaudete! Christus est natus ex Maria Virgine: Gaudete!  
   
Ergo nostra cantio Psallat iam in lustro;  
Benedicat Domino: Salus Regi nostro.  
   
Gaudete! gaudete! Christus est natus ex Maria Virgine: Gaudete!

English:

Rejoice! Rejoice! Christ is born of the Virgin Mary: rejoice!  
   
The time of grace has come, This that we have desired;  
Verses of joy, Let us devoutly return.  
   
Rejoice! Rejoice! Christ is born of the Virgin Mary: rejoice!  
   
God has become man, Nature marveling;  
The world has been renewed, By the reigning Christ.  
   
Rejoice! Rejoice! Christ is born of the Virgin Mary: rejoice!  
   
The closed gate of Ezechiel is passed through;  
Whence the light is born, Salvation is found.  
   
Rejoice! Rejoice! Christ is born of the Virgin Mary: rejoice!  
   
Therefore let our gathering, Now sing in brightness  
Let it give praise to the Lord: Greeting to our King.  
   
Rejoice! Rejoice! Christ is born of the Virgin Mary: rejoice!

Therefore let our gathering, Now sing in brightness  
Let it give praise to the Lord: Greeting to our King.  
   
Rejoice! Rejoice! Christ is born of the Virgin Mary: rejoice!
