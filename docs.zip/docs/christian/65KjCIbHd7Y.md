---
id: 65KjCIbHd7Y
title: "I Wish We'd All Been Ready"
sidebar_label: "I Wish We'd All Been Ready"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/65KjCIbHd7Y"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## I Wish We'd All Been Ready

Lyrics: Larry D. Norman

Life was filled with guns and war  
And all of us got trampled on the floor  
I wish we'd all been ready

Children died the days grew cold  
A piece of bread could buy a bag of gold  
I wish we'd all been ready

There's no time to change your mind  
The Son has come and you've been left behind

A man and wife asleep in bed  
She hears a noise and turns her head he's gone  
I wish we'd all been ready

Two men walking up a hill  
One disappears and one's left standing still  
I wish we'd all been ready

There's no time to change your mind  
The Son has come and you've been left behind

Children died the days grew cold  
A piece of bread could buy a bag of gold  
I wish we'd all been ready

There's no time to change your mind  
The Son has come and you've been left behind  
   
The Father spoke the demons died  
How could you have been so blind  
   
There's no time to change your mind  
The Son has come and you've been left behind

I hope we'll all be ready you've been left behind  
I hope we'll all be ready you've been left behind  
I hope we'll all be ready you've been left behind
