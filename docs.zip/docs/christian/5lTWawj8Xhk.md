---
id: 5lTWawj8Xhk
title: "P149 Die heilige Gemeine - The Holy Congregation"
sidebar_label: "P149 Die heilige Gemeine - The Holy Congregation"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/5lTWawj8Xhk"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## P149 Die heilige Gemeine - The Holy Congregation

Lyrics: Cornelius Becker, Becker Psalter, 1602  
https://en.wikipedia.org/wiki/Becker_Psalter

Die heilige Gemeine,  
Mit fröhlichem Gemüt,  
Singet von Herzen reine  
Dem Herrn ein neues Lied.  
Gott hat Israels Samen  
Zu seinem Volk gemacht,  
Des Königs werter Name  
Zion groß Freude bracht.

Sie sollen an dem Reigen  
Loben des Herren Nam,  
Mit Pauken, Harfen, Geigen  
Spielen lieblich zusamm'n,  
Der Herr hat Wohlgefallen  
An seiner lieben Gmein,  
Will den Elenden allen  
Ihr Gott und Helfer sein.

Die Heiligen mit Freuden  
Preisen Gott unsern Herrn,  
Sein Ehr für allen Leuten  
Rühmen sie herzlich gern  
Und wollen alle Stunden  
In Gottes Dienste stehn,  
Mit Herzen und mit Munde  
Sein Lob und Ehr erhöhn.

Das Wort in ihren Händen  
Ist wie ein scharfes Schwert,  
Groß Ding sie dadurch enden,  
Daß Rach geübet werd  
Unter dem Volk der Heiden,  
Die sie zwingen darmit,  
Bringen zu recht viel Leute,  
Daß sie verderben nicht.

Durch Gottes Wort sie nehmen  
Die König in die Band,  
Die Edlen sich nicht schämen,  
Stelln sich in ihre Hand,  
Daß ihnen widerfahre  
Recht nach dem Wort der Gnad,  
Allein der Heilgen Schare  
Von Gott solch Ehre hat.

Alles, was Odem hat, lobe den Herrn.  
Alleluja, Alleluja, Alleluja.

Alleluja, Alleluja, Alleluja.
