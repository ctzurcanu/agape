---
id: upCIzfQCeu8
title: "Psalm 96"
sidebar_label: "Psalm 96"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/upCIzfQCeu8"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Psalm 96

Lyrics: Psalm 96  
Thomas Williams's Psalmodia Evangelica, 1789

O sing a new song to the Lord,  
sing all the earth and bless His name;  
from day to day His praise record,  
the Lord's redeeming grace proclaim.

Tell all the world God's wondrous ways,  
tell heathen nations far and near;  
great is the Lord, and great His praise;  
the Him alone, let nations fear.

The heathen gods are idols vain;  
the shining heav'ns the Lord supports;  
both light and honor lead His train;  
while strength and beauty fill His courts.

Let every tongue and every tribe  
give to the Lord due praise and sing;  
all glory unto Him ascribe,  
come, throng His courts, and off'rings bring.

O fear and bow, adorned with grace,  
and tell each land that God is King;  
the earth He founded in its place,  
and justice to the world will bring.

Let heav'n be glad, let earth rejoice,  
the teeming sea resound with praise;  
let waving fields lift high their voice,  
and all the trees their anthem raise.

So let them shout before our God,  
for lo, He comes, He comes with might,  
to wield the scepter and the rod,  
to judge the world with truth and right.
