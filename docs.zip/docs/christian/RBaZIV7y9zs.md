---
id: RBaZIV7y9zs
title: "Psalmul 12 - Psalm 12"
sidebar_label: "Psalmul 12 - Psalm 12"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/RBaZIV7y9zs"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Psalmul 12 - Psalm 12

Lyrics: St. Metropolitan Dosoftei, 1673   
https://en.wikipedia.org/wiki/Dosoftei 

Până când, Milostive, nu-Ţi aduci aminte,   
de mă uiţi cu totul, Dumnezeule Sfinte?   
Până când, Milostive, Ți-ascunzi sfânta Ta față,   
de mine ticălosul, cu multă greață? 

Până când îmi voi pune sfaturi în bietul suflet,   
ziua dureri, și noaptea inima-n greu cuget?   
Până când se va înălța vrăjmașul meu cu-nvârtoșare,   
de va voi să suie, să mi se pună-n spinare? 

Ci Te milostivește, o, Dumnezeule Sfinte,   
de-mi auzi sărmana rugă, sărmanele cuvinte!   
Cugetul îmi sfințește, ochii-mi luminează   
dintr-a Ta strălucire de senină rază! 

Să nu adorm în somnul celei de-a doua morți,   
să nu râdă vrăjmașul, să-mi zică: „Nu poţi!”.   
Căci celor ce-mi fac scârbă și grea supărare,   
le-ar face bucurie să fiu în pierzare. 

Însă mila Ta cea sfântă îmi e spre virtute,   
mi-e nădejde și reazim când mă apasă multe.   
Mă voi bucura și-mi voi face inimă bună   
pentru biruința Ta, cântând împreună,   
dintru a Ta bunătate, pe care mi-o vei trimite,   
ca să cânt sfântul nume, Dumnezeule Sfinte! 

  
Dumnezeule Sfinte!
