---
id: O912BdVI2C0
title: "El gran Carlemany - The Great Charlemagne"
sidebar_label: "El gran Carlemany - The Great Charlemagne"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/O912BdVI2C0"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## El gran Carlemany - The Great Charlemagne

Lyrics: Joan Benlloch i Vivó  
https://en.wikipedia.org/wiki/El_gran_Carlemany

El gran Carlemany, mon pare,  
dels alarbs em deslliurà,  
i del cel vida em donà  
de Meritxell, la gran Mare.

Princesa nasquí i pubilla  
entre dos nacions, neutral;  
sols resto l'única filla  
de l'imperi Carlemany.

Creient i lliure onze segles,  
creient i lliure vull ser.  
Siguin els furs mos tutors  
i mos Prínceps defensors!  
i mos Prínceps defensors!

English:

The great Charlemagne, my father,  
liberated me from the Saracens,  
and from heaven he gave me life  
of Meritxell, the great Mother.

I was born a princess and heiress  
between two nations, neutral;  
I am the only remaining daughter  
of the Carolingian empire.

Faithful and free for eleven centuries,  
Faithful and free I want to be.  
May the laws be my tutors  
and my Princes defenders  
and my Princes defenders!
