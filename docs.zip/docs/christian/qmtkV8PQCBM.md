---
id: qmtkV8PQCBM
title: "Savior of the nations, come"
sidebar_label: "Savior of the nations, come"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/qmtkV8PQCBM"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Savior of the nations, come

Lyrics: St. Ambrose  
Translator (into German): Martin Luther, 1523  
Translator: William M. Reynolds, 1860

Savior of the nations, come,  
Virgin's Son, make here your home.  
Marvel now, O Heav'n and Earth,  
That the Lord chose such a birth.

Not by human flesh and blood,  
By the Spirit of our God  
Was the Word of God made flesh:  
Woman's offspring, pure and fresh.

Wondrous birth! O wondrous child  
Of the virgin undefiled!  
Though by all the world disowned,  
Still to be in Heav’n enthroned.

Lo, he comes! The Lord of all  
Leaves his bright and royal hall;  
God and man, with giant force,  
Hastening to run his course.

From the Father forth he came  
And returned hence to the same.  
Captive leading death and hell—  
High the song of triumph swell!

Christ, the Father’s only Son,  
Has o’er sin the vict’ry won.  
Boundless shall your kingdom be;  
When shall we its glories see?

Brightly does your manger shine;  
Glorious is its light divine.  
Let not sin o’ercloud this light;  
Ever be our faith thus bright.

Praise to God the Father sing,  
Praise to God the Son, our King,  
Praise to God the Spirit be  
Ever and eternally.
