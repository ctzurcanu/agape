---
id: EcA9UQzHy1I
title: "Ave Generosa - Hail thee, noble one"
sidebar_label: "Ave Generosa - Hail thee, noble one"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/EcA9UQzHy1I"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Ave Generosa - Hail thee, noble one

Lyrics: Hildegard von Bingen, 12th century

Ave generosa gloriosa et intacta  
puella, tu pupilla castitatis,  
tu materia sanctitatis,  
que Deo placuit.  
   
Nam hec superna infusio in te fuit,  
quod supernum Verbum in te carnem induit.  
   
Tu candidum lilium quod Deus   
ante omnem creaturam inspexit.

O pulcherrima et dulcissima,  
quam valde Deus in te delectabatur,  
cum amplexionem caloris sui in te posuit,  
ita quod Filius eius de te lactatus est.

Venter enim tuus gaudium habuit  
cum omnis celestis symphonia de te sonuit,  
quia virgo Filium Dei portasti,  
ubi castitas tua in Deo claruit.  
   
Nunc omnis ecclesia in gaudio rutilet  
ac in symphonia sonet  
propter dulcissimam Virginem  
et laudabilem Mariam,  
Dei Genitricem. Amen.

English: Hail thee, noble one

Hail, nobly born, hail, honored and inviolated,  
you Maiden are the piercing gaze of chastity,  
you the material of holiness—  
the one who pleasèd God.  
   
For heaven’s flood poured into you  
as heaven’s Word was clothed in flesh in you.  
   
You are the lily, gleaming white, upon which God  
has fixed his gaze before all else created.  
   
O beautiful, O sweet!  
How deep is that delight that God received in you,  
when ‘round you he enwrapped his warm embrace,  
so that his Son was suckled at your breast.  
   
Your womb rejoiced  
as from you sounded forth the whole celestial symphony.  
For as a virgin you have borne the Son of God—  
in God, your chastity shone brightly.  
   
 So now in joy gleams all the Church like dawn,  
resounds in symphony  
because of you, the Virgin sweet  
and worthy of all praise, Maria,  
God’s mother. Amen.
