---
id: HR608HWCEmM
title: "Jesus Christ, Superstar v3: Act 2: Judas' Death"
sidebar_label: "Jesus Christ, Superstar v3: Act 2: Judas' Death"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/HR608HWCEmM"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Jesus Christ, Superstar v3: Act 2: Judas' Death

[JUDAS]

My God! I saw him.  
He looked three-quarters dead!  
And he was so bad I had to turn my head.  
You beat him so hard that he was bent and lame,  
And I know who everybody's going to blame.  
I don't believe he knows I acted for our good.  
I'd save him all this suffering if I could.  
Don't believe...our good...  
And I'd save him if I could...

[ANNAS]

Cut the confessions, forget the excuses.  
I don't understand why you're filled with remorse.  
All that you've said has come true with a vengeance.  
The mob turned against him, you backed the right horse.

[CAIAPHAS]

What you have done will be the saving of everyone.  
You'll be remembered forever for this.  
And not only that, you've been paid for your efforts.  
Pretty good wages for one little kiss.

[JUDAS]

Christ, I know you can't hear me,  
But I only did what you wanted me too.  
Christ, I'd sell out the nation,  
For I have been saddled with the murder of you.  
I have been spattered with innocent blood.  
I shall be dragged through the slime and the mud.  
I have been spattered with innocent blood.  
I shall be dragged through the slime and the mud!  
I don't know how to love him.  
I don't know why he moves me.  
He's a man. He's just a man.  
He is not a king. He is just the same  
As anyone I know.  
He scares me so!  
When he's cold and dead will he let me be?  
Does he love me too? Does he care for me?  
My mind is in darkness.  
God, God I'm sick. I've been used,  
And you knew all the time.  
God, God I'll never ever know why you chose me for your crime.  
You're so bloody, Christ.  
[Instrumental]

[CHOIR]

Poor old Judas. So long Judas.

[JUDAS]

You have murdered me.
