---
id: anoOVAMb3xo
title: "Pater Noster - Our Father"
sidebar_label: "Pater Noster - Our Father"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/anoOVAMb3xo"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Pater Noster - Our Father

Pater Noster

Pater Noster

Pater noster, qui es in cælis,  
Sanctificetur nomen tuum,  
Adveniat regnum tuum,  
Fiat voluntas tua,  
Sicut in cælo et in terra.

Panem nostrum quotidianum  
da nobis hodie,  
Et dimitte nobis debita nostra,

Sicut et nos dimittimus  
debitoribus nostris.

Et ne nos inducas in tentationem,  
Sed libera nos a malo.

Amen  
Amen  
Amen

English:

Our Father, who is in heaven,  
Blessed be Your name,  
Your kingdom come,  
Your will be done,  
As it is in heaven, and on earth.  
Our daily bread  
Give to us this day,  
And forgive us of our debts,  
As we also forgive  
Our debtors.  
And do not lead us into temptation,  
But rather free us from evil.  
Amen.
