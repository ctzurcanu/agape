---
id: xoW1-_JUua4
title: "Jesus, Jesus, I’ll burn!"
sidebar_label: "Jesus, Jesus, I’ll burn!"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/xoW1-_JUua4"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Jesus, Jesus, I’ll burn!

Lyrics: Tim Rice, Jesus Christ Superstar  
slight lyrics modifications: Christian Tzurcanu

Saint JOAN OF ARC:

I only wish to say,  
If there’s a way,  
Keep the flames away from me,  
For I am weaker than this torment.  
Feel it burn me, I have changed.

Once I heard voices, clear and sparkling.  
Then, I was chosen.  
Now, I’m trapped and poisoned.  
Listen, surely I've met Heaven's expectations,  
Fought one long year, seemed like twenty.  
Has Jesus asked as much from any other soul?

But if I burn,  
See my path through and keep my standard true,  
Let them mock me, scorn me, chain me, tie me to the flames.

I want to know, I want to know, dear Jesus,  
Want to know, I want to know, good Jesus,  
Want to see, I want to see, dear Saints,  
Want to see, I want to see, good Saints,  
Why must I burn?

Will my name shine brighter than it ever has before?  
Will all the hearts which moved beat same drum evermore?

I need to know, I need to know, dear Jesus,  
Need to know, I need to know, good Jesus,  
Need to see, I need to see, dear Saints,  
Need to see, I need to see, good Saints,

If I am ash what will then be my crown?  
If I am ash what will then be my crown?  
Need to know, I need to know, dear Jesus,  
I need to know, I need to know, good Jesus,  
Why must I burn? Oh, why must I burn?

Can you tell me now my dust won't be forgotten?  
Show me just a fragment of your grand celestial plane.  
Show me there's a reason for my toils and my pain.

You've chosen me for grilling and tasked Rouen for embers.  
Alright, I'll burn!  
Just watch me burn!  
See how I burn!  
Oh oh oh oh  
Yeah  
See how I burn!

  
Back then I was chosen,  
Now, I'm trapped and poisoned.  
After all, I've tried for one year, seems like always.  
Angel Michael, for The Throne, your white standard I've flown  
In Rouen's fiery dawn, I'll burn for Christ, alone.

Heaven, your purpose is vast,  
But in you, my trust is cast.  
I'll wear your garb, accept my past.  
Take me to your stake, Rouen.

Burn me, light me,  
End me.  
Take me, now!

Before my heart gives up...
