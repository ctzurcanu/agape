---
id: qRjyfYM50xg
title: "A Song to David 1"
sidebar_label: "A Song to David 1"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/qRjyfYM50xg"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## A Song to David 1

Lyrics: Christopher Smart, 1753

Sublime—invention ever young,    
Of vast conception, tow'ring tongue    
   To God th' eternal theme;    
Notes from yon exaltations caught,    
Unrivall'd royalty of thought  
   O'er meaner strains supreme.  

His muse, bright angel of his verse,    
Gives balm for all the thorns that pierce,    
   For all the pangs that rage;    
Blest light still gaining on the gloom,  
The more than Michal of his bloom,    
   Th' Abishag of his age.  

He sang of God—the mighty source    
Of all things—the stupendous force    
   On which all strength depends;  
From whose right arm, beneath whose eyes,    
All period, power, and enterprise    
   Commences, reigns, and ends.  

Tell them, I AM, Jehovah said    
To Moses; while earth heard in dread,  
   And, smitten to the heart,    
At once above, beneath, around,    
All Nature, without voice or sound,    
   Replied, O LORD, THOU ART.  

The world, the clustering spheres, He made;  
The glorious light, the soothing shade,    
   Dale, champaign, grove, and hill;    
The multitudinous abyss,    
Where Secrecy remains in bliss,    
   And Wisdom hides her skill.

The pillars of the Lord are seven,    
Which stand from earth to topmost heaven;    
   His Wisdom drew the plan;    
His Word accomplish'd the design,    
From brightest gem to deepest mine;  
   From Christ enthroned, to Man.  

For Adoration all the ranks    
Of Angels yield eternal thanks,    
   And David in the midst;    
With God's good poor, which, last and least  
In man's esteem, Thou to Thy feast,    
   O blessèd Bridegroom, bidd'st!  

For Adoration, David's Psalms    
Lift up the heart to deeds of alms;    
   And he, who kneels and chants,  
Prevails his passions to control,    
Finds meat and medicine to the soul,    
   Which for translation pants.  

For Adoration, in the dome    
Of Christ, the sparrows find a home,  
   And on His olives perch:    
The swallow also dwells with thee,    
O man of God's humility,    
   Within his Saviour's church.
