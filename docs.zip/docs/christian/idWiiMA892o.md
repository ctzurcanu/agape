---
id: idWiiMA892o
title: "A Song to David 2"
sidebar_label: "A Song to David 2"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/idWiiMA892o"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## A Song to David 2

Lyrics: Christopher Smart, 1753

Sweet is the dew that falls betimes,  
And drops upon the leafy limes;    
   Sweet Hermon's fragrant air:    
Sweet is the lily's silver bell,    
And sweet the wakeful tapers' smell    
   That watch for early prayer.

Sweet the young nurse, with love intense,    
Which smiles o'er sleeping innocence;    
   Sweet, when the lost arrive:    
Sweet the musician's ardour beats,    
While his vague mind's in quest of sweets,  
   The choicest flowers to hive.  

Strong is the horse upon his speed;    
Strong in pursuit the rapid glede,    
   Which makes at once his game:    
Strong the tall ostrich on the ground;  
Strong through the turbulent profound    
   Shoots Xiphias to his aim.  

Strong is the lion—like a coal    
His eyeball,—like a bastion's mole    
   His chest against the foes:  
Strong, the gier-eagle on his sail;    
Strong against tide th' enormous whale    
   Emerges as he goes.  

But stronger still, in earth and air,    
And in the sea, the man of prayer,  
   And far beneath the tide:    
And in the seat to faith assign'd,    
Where ask is have, where seek is find,    
   Where knock is open wide.  

Precious the penitential tear;  
And precious is the sigh sincere,    
   Acceptable to God:    
And precious are the winning flowers,    
In gladsome Israel's feast of bowers    
   Bound on the hallow'd sod.

Glorious the sun in mid career;    
Glorious th' assembled fires appear;    
   Glorious the comet's train:    
Glorious the trumpet and alarm;    
Glorious the Almighty's stretched-out arm;  
   Glorious th' enraptured main:  

Glorious the northern lights astream;    
Glorious the song, when God 's the theme;    
   Glorious the thunder's roar:    
Glorious Hosanna from the den;  
Glorious the catholic Amen;    
   Glorious the martyr's gore:  

Glorious—more glorious—is the crown    
Of Him that brought salvation down,    
   By meekness call'd thy Son:  
Thou that stupendous truth believed;—    
And now the matchless deed 's achieved,    
   Determined, dared, and done!
