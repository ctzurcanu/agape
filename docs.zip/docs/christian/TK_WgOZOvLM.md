---
id: TK_WgOZOvLM
title: "Oratio Vespertina - Evening Prayer"
sidebar_label: "Oratio Vespertina - Evening Prayer"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/TK_WgOZOvLM"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Oratio Vespertina - Evening Prayer

Christe, decus mundi, qui lux es clara diesque  
Noctis tu tenebras illustrans detegis atras.  
Lucifer exoriens lumen de lumine profers,  
Vitam dignanter tribuis sine fine beatis.

Tu nos, omnipotens, clementer, sancte, precamur,  
Hostis ab insidiis defendas nocte dieque.  
Sit nobis in te requies ; tu, conditor alme,  
Instantem fieri noctem largire quietem,

Ne gravis impediat noctis caligine somnus,  
Hostis subrepat nobis ne fraude maligna,  
Ne caro peccando fragilis consentiat illi  
Nosque reos statuat iusto sub iudice Christo.

Gloria magna patri iugiter per saecula cuncta,  
Gloria summa patris nato sit semper in aevum ;  
Spiritui amborum pariter sit gloria perpes,  
Gloria saeclorum per saecula sit trinitati.

English:

Christ, the glory of the world, who art the light of day and night,  
You illuminate the darkness of night and reveal the darkness.  
Lucifer, rising from the light, brings forth light,  
You give life worthily to the blessed without end.

We pray to you, almighty, mercifully, holy,  
Protect us from the snares of the enemy by night and day.  
May we find rest in you; you, the Creator of the soul,  
Give us rest as soon as night comes,

Lest the darkness of night hinder sleep,  
Lest the enemy steal from us with his evil trickery,  
Lest the frail flesh consent to him in sinning,  
And hold us guilty before the just judge Christ.

Great glory to the Father forever and ever,  
Supreme glory to the Son of the Father always for ever;  
To the Spirit of both be eternal glory,  
Glory to the Trinity forever and ever.
