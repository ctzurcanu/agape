---
id: HG1dEerLn4M
title: "A înviat! - He is risen!"
sidebar_label: "A înviat! - He is risen!"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/HG1dEerLn4M"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## A înviat! - He is risen!

Lyrics: Costache Ioanid

De-atunci... în lumea cea largă,  
o, câte Marii au strigat,  
câţi martori de veste au dat:  
E viu Salvatorul! Trăieşte!

De-atunci... în lumea cea largă,  
o, câte Marii au strigat,  
câţi martori de veste au dat:  
E viu Salvatorul! Trăieşte!

Iar noi eram morţi şi vrăjmaşi,  
păziţi ca de tainici ostaşi.

Şi Domnul, din bezna adâncă,  
ne-a scos prin peceţi şi prin stâncă  
să ducem mesajul divin.

E viu Salvatorul! Şi încă,  
din cerul de glorie plin,  
ne cheamă, ne iartă, amin...

E viu Salvatorul! Şi încă,  
din cerul de glorie plin,  
ne cheamă, ne iartă, amin...

ne cheamă, ne iartă, amin...

English:

Since then... in the wide world,  
oh, how many Marys have cried out,  
how many witnesses have given the news:  
The Savior is alive! He lives!

Since then... in the wide world,  
oh, how many Marys have cried out,  
how many witnesses have given the news:  
The Savior is alive! He lives!

And we were dead and enemies,  
guarded as by secret soldiers.

And the Lord, from the deep darkness,  
brought us out through seals and through the rock  
to carry the divine message.

The Savior is alive! And still,  
from the sky full of glory,  
He calls us, forgive us, amen...

The Savior is alive! And still,  
from the sky full of glory,  
He calls us, forgives us, amen...

He calls us, forgives us, amen...
