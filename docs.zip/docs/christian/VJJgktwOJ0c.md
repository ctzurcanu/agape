---
id: VJJgktwOJ0c
title: "Feast of the Ascension"
sidebar_label: "Feast of the Ascension"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/VJJgktwOJ0c"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Feast of the Ascension

Lyrics: Anonymous

O thou eternal King most high,  
Who didst the world redeem;  
And conquering death and hell, receive  
A dignity supreme:

This day beheld thee through the skies  
To thy bright throne ascend;  
Thenceforth to reign in sovereign power,  
And glory without end.

There, seated in thy majesty,  
To thee submissive bow  
The spacious earth, the highest heaven  
The depths of hell below.

With trembling there the angels see  
The chang'd estate of men;  
The flesh which sinn'd by Flesh redeem'd  
And Man o'er seraphs reign.

There, waiting for thy faithful souls,  
Be thou to us, O Lord,  
Our peerless Joy while here we stay.  
In heavn our great reward.
