---
id: KcLnpFp7csw
title: "Awesome God"
sidebar_label: "Awesome God"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/KcLnpFp7csw"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Awesome God

Lyrics: Richard W. Mullins, 1988

When He rolls up His sleeves  
He ain't just puttin' on the ritz  
(our God is an awesome God)  
There is thunder in His footsteps  
And lightning in His fist  
(our God is an awesome God)

Well, the Lord wasn't joking  
When He kicked 'em out of Eden  
It wasn't for no reason that He shed his blood  
His return is very close and so you better be believing  
that our God is an awesome God  
   
Our God (our God) is an awesome God  
He reigns (He reigns) from heaven above  
With wisdom (with wisdom) power and love  
our God is an awesome God  
   
And when the sky was starless in the void of the night  
(our God is an awesome God)  
He spoke into the darkness and created the light  
(our God is an awesome God)  
Judgment and wrath he poured out on Sodom  
Mercy and grace He gave us at the cross  
I hope that we have not too quickly forgotten that  
our God is an awesome God  
   
Our God (our God) is an awesome God  
He reigns (He reigns) from heaven above  
With wisdom (with wisdom) power and love  
our God is an awesome God  
   
Our God (our God) is an awesome God  
He reigns (He reigns) from heaven above  
With wisdom (with wisdom) power and love  
our God is an awesome God  
   
Our God (our God) is an awesome God  
He reigns (He reigns) from heaven above  
With wisdom (with wisdom) power and love  
our God is an awesome God

Our God is an awesome God  
Our God is an awesome God  
(Our God is an awesome God)  
(Our God is an awesome God)
