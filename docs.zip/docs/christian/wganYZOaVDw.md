---
id: wganYZOaVDw
title: "Jesus Christ, Superstar v3: Act 1: Then We Are Decided"
sidebar_label: "Jesus Christ, Superstar v3: Act 1: Then We Are Decided"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/wganYZOaVDw"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Jesus Christ, Superstar v3: Act 1: Then We Are Decided

[CAIAPHAS]

We've been sitting on the fence for far too long.

[ANNAS]

Why let him upset us?  
Caiaphas, let him be.  
All those imbeciles will see,  
He really doesn't matter.

[CAIAPHAS]

Jesus is important,  
We've let him go his way before.  
And while he starts a major war,  
We theorize and chatter.

[ANNAS]

He's just another scripture-thumping hack from Galilee.

[CAIAPHAS]

The difference is they call him King,  
The difference frightens me!  
What about the Romans?  
When they see King Jesus crowned,  
Do you think they'll stand around,  
Cheering, and applauding?  
What about our people?  
If they see we've lost our nerve,  
Don't you think that they deserve,  
Something more rewarding.

[ANNAS]

They've got what they want,  
They think so, anyway.  
If he's what they want,  
Why take their toy away?  
He's a craze!

[CAIAPHAS]

Put yourself in my place,  
I can hardly step aside.  
Can not let my hands be tied.  
I am law and order.  
What about our priesthood?  
Don't you see that we could fall?  
If we are to last at all,  
We can not be divided.

[ANNAS]

Then say so to the council,  
But don't rely on subtlety.  
Frighten them, or they won't see.

[CAIAPHAS]

Then we are decided?

[ANNAS]

Then we are decided.
