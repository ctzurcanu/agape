---
id: w2xmqstgBlI
title: "Psalm XXIII"
sidebar_label: "Psalm XXIII"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/w2xmqstgBlI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Psalm XXIII

Lyrics: Christopher Smart, 1753

The shepherd Christ from heav'n arriv'd,  
My flesh and spirit feeds;  
I shall not therefore be depriv'd  
Of all my nature needs.

As slop'd against the glist'ning beam  
The velvet verdure swells,  
He keeps, and leads me by the stream  
Where consolation dwells.

My soul He shall from sin restore,  
And her free pow'rs awake,  
In paths of heav'nly truth to soar,  
For love and mercy's sake.

Yea, tho' I walk death's gloomy vale,  
The dread I shall disdain;  
For Thou art with me, lest I fail,  
To check me and sustain.

Thou shalt my plenteous board appoint  
Before the braving foe;  
Thine oil and wine my head anoint,  
And make my goblet flow.

But great still Thy love and grace  
Shall all my life attend;  
And in Thine hallow'd dwelling place  
My knees shall ever bend.
