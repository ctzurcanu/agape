---
id: yNOkNANAaQY
title: "Christus Vincit - Christ Conquers"
sidebar_label: "Christus Vincit - Christ Conquers"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/yNOkNANAaQY"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Christus Vincit - Christ Conquers

Lyrics: Psalm 117

Christus vincit,  
Christus regnat,  
Christus, Christus imperat.  
   
Laudate Dominum, omnes gentes  
laudate eum, omnes populi.

Christus vincit,  
Christus regnat,  
Christus, Christus imperat.  
   
Quoniam confirmata est super nos misericordia ejus,  
et veritas Domini manet in aeternum.  
   
Christus vincit,  
Christus regnat,  
Christus, Christus imperat.  
   
Gloria Patri et Filio,  
et Spiritui Sancto.  
   
Christus vincit,  
Christus regnat,  
Christus, Christus imperat.  
   
Sicut erat in principio et nunc, et semper,  
et in saecula saeculorum. Amen.  
   
Christus vincit,  
Christus regnat,  
Christus, Christus imperat.

English:

Christ conquers,  
Christ reigns,  
Christ commands.  
   
O praise the Lord, all ye nations:  
praise ye Him, all ye people.  
   
Christ conquers,  
Christ reigns,  
Christ commands.  
   
For His mercy is confirmed upon us:  
and the truth of the Lord remaineth forever.  
   
Christ conquers,  
Christ reigns,  
Christ commands.  
   
Glory be to the Father and to the Son,  
and to the Holy Spirit.  
   
Christ conquers,  
Christ reigns,  
Christ commands.  
   
As in the beginning, is now and always and ever shall be,  
world without end. Amen.  
   
Christ conquers,  
Christ reigns,  
Christ commands.
