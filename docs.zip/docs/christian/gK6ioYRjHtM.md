---
id: gK6ioYRjHtM
title: "Marche Pontificale - Pontifical Anthem and March"
sidebar_label: "Marche Pontificale - Pontifical Anthem and March"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/gK6ioYRjHtM"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Marche Pontificale - Pontifical Anthem and March

Lyrics: Raffaello Lavagna, 1991  
https://en.wikipedia.org/wiki/Pontifical_Anthem

O felix Roma – o Roma nobilis:  
O felix Roma – o Roma nobilis:

Sedes es Petri, qui Romae effudit sanguinem,  
Petri cui claves datae sunt regni caelorum.  
Pontifex, Tu successor es Petri;  
Pontifex, Tu magister es tuos confirmans fratres;  
Pontifex, Tu qui Servus servorum Dei,  
hominumque piscator, pastor es gregis,  
ligans caelum et terram.  
Petre, Tu Christi es Vicarius super terram,  
rupes inter fluctus, Tu es pharus in tenebris;  
Tu pacis es vindex, Tu es unitatis custos,  
vigil libertatis defensor; in Te potestas.

Tu Pontifex, firma es petra, et super petram  
hanc aedificata est Ecclesia Dei.

Petre, Tu Christi es Vicarius super terram,  
rupes inter fluctus, Tu es pharus in tenebris;  
Tu pacis es vindex, Tu es unitatis custos,  
vigil libertatis defensor; in Te potestas.

O felix Roma – O Roma nobilis.  
O felix Roma – O Roma nobilis.

English:

O happy Rome - O noble Rome  
O happy Rome - O noble Rome

You are the seat of Peter, who shed his blood in Rome,  
Peter, to whom the keys of the kingdom of heaven were given.  
Pontiff, You are the successor of Peter;

Pontiff, You are the teacher, you confirm your brethren;  
Pontiff, You who are the Servant of the servants of God,  
and fisher of men, are the shepherd of the flock,  
linking heaven and earth.

Pontiff, You are the vicar of Christ on earth,  
a rock amidst the waves, You are a beacon in the darkness;  
You are the defender of peace, You are the guardian of unity,  
watchful defender of liberty; in You is the authority.

Pontiff, you are the unshakable rock, and on this rock  
was built the Church of God.

Pontiff, You are the vicar of Christ on earth,  
a rock amidst the waves, You are a beacon in the darkness;  
You are the defender of peace, You are the guardian of unity,  
watchful defender of liberty; in You is the authority.

O happy Rome - O noble Rome  
O happy Rome - O noble Rome
