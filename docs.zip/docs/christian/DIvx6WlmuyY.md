---
id: DIvx6WlmuyY
title: "Adventus Domini - The Coming of the Lord"
sidebar_label: "Adventus Domini - The Coming of the Lord"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/DIvx6WlmuyY"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Adventus Domini - The Coming of the Lord

Astra polorum  
Cuncta chorique,  
Solque sororque,   
Lumina caeli.

Omnipotentem  
Semper adorent  
Et benedicant  
Omne per aevum

  
Sic quoque lymphae  
Quaeque supernae,  
Ros pluviaeque,  
Spiritus omnis.

Omnipotentem  
Semper adorent  
Et benedicant  
Omne per aevum

  
Ignis et aestus,  
Cauma geluque,  
Frigus et ardor  
Atque pruina.

Omnipotentem  
Semper adorent  
Et benedicant  
Omne per aevum

  
Nix glaciesque,  
Noxque diesque,  
Lux tenebraeque,  
Fulgura, nubes.

Omnipotentem  
Semper adorent  
Et benedicant  
Omne per aevum

  
Arida, montes,   
Germina, collcs,  
Flumina, fontes,  
Pontus et undae.

Omnipotentem  
Semper adorent  
Et benedicant  
Omne per aevum

Omnia viva,  
Quae vehit aequor,  
Quae vehit aer,  
Terraque nutrit.

Omnipotentem  
Semper adorent  
Et benedicant  
Omne per aevum

  
Cuncta hominum gens,  
Israel ipse   
Christicolaeque,  
Servuli quique.

Omnipotentem  
Semper adorent  
Et benedicant  
Omne per aevum

  
Sancti humilesque   
Corde benigno,  
Tresque pusilli  
Exsuperantes

Omnipotentem  
Semper adorent  
Et benedicant  
Omne per aevum

  
Rite camini  
Ignei flammas,  
Iussa tyranni  
Temnere prompti.

Omnipotentem  
Semper adorent  
Et benedicant  
Omne per aevum

English:

The stars of the poles  
All their choirs,  
And the sun and sister,  
The lights of heaven.

May the Almighty  
Always adore  
And bless  
All through the ages

So also the lymph  
And the heavenly ones,  
Dew and rain,  
Every spirit.

Fire and heat,  
Frost and frost,  
Cold and hot  
And frost.

Snow and ice,  
Night and day,  
Light and darkness,  
Lightning, clouds.

Dry land, mountains,  
Growths, clusters,  
Rivers, fountains,  
Ponts and waves.

All living things,  
Which the sea carries,  
Which the air carries,  
And the earth nourishes.

The whole race of men,  
Israel itself  
And Christ's servants,  
Every one of them.

Saints and humble,   
with kind hearts,   
Three little ones,   
overcoming the flames of the furnace,   
Ready to obey the tyrant's commands.
