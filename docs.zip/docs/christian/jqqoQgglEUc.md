---
id: jqqoQgglEUc
title: "Jesus Christ, Superstar v3: Act 2: Trial Before Pilate"
sidebar_label: "Jesus Christ, Superstar v3: Act 2: Trial Before Pilate"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/jqqoQgglEUc"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Jesus Christ, Superstar v3: Act 2: Trial Before Pilate

[PILATE]

And so the king is once again my guest.  
And why is this? Was Herod unimpressed?

[MOB]

We turn to Rome to sentence Nazareth.  
We have no law to put a man to death.  
We need him crucified.  
It's all you have to do.  
We need him crucified.  
It's all you have to do.

[PILATE]

Talk to me Jesus Christ.  
You have been brought here  
Manacled, beaten by your own people.  
Do you have the first idea why you deserve it?  
Listen King of the Jews,  
Where is your kingdom?  
Look at me. Am I a Jew?

[JESUS]

I have no kingdom in this world.  
I'm through.  
There may be a kingdom for me somewhere.  
If you only knew.

[PILATE]

Then you are a king?

[JESUS]

It's you that say I am.  
I look for truth and find that I get damned.

[PILATE]

But what is truth?  
Is truth a changing law?  
We both have truths.  
Are mine the same as yours?

[MOB]

Crucify him! Crucify him!

[PILATE]

What do you mean?  
You'd crucify your king?

[MOB]

We have no king but Caesar!

[PILATE]

He's done no wrong.  
No, not the slightest thing.

[MOB]

We have no king but Caesar!  
Crucify him!

[PILATE]

What is this new respect for Caesar?  
'Till now this has been noticeably lacking.  
Who is this Jesus? Why is he different?  
You choose Messiahs by the sackfull.

[MOB]

We need him crucified,  
It's all you have to do.  
We need him crucified,  
It's all you have to do.

[PILATE]

Talk to me, Jesus Christ.  
Look at your Jesus Christ.  
I'll agree he's mad.  
Ought to be locked up,  
But that is not a reason to destroy him.  
He's a sad little man.  
Not a King or God.  
Not a thief,  
I need a crime!

[MOB]

Crucify him!

[PILATE]

Behold a man,  
Behold your shattered King.

[MOB]

We have no King but Caesar.

[PILATE]

You hypocrites,  
You hate us more than him.

[MOB]

We have no King but Caesar,  
Crucify him!

[PILATE]

I see no reason. I find no evil.  
This man is harmless, so why does he upset you?  
He's just misguided, thinks he's important,  
But to keep you vultures happy I shall flog him.

[MOB]

Crucify him! Crucify him!

[PILATE]

Where are you from, Jesus?  
What do you want, Jesus?  
Tell me.  
You've got to be careful.  
You could be dead soon,  
Could well be.  
Why do you not speak when  
I hold your life in my hands?  
How can you stay quiet?  
I don't believe you understand.

[JESUS]

You have nothing in your hands.  
Any power you have, comes to you from far beyond.  
Everything is fixed, and you can't change it.

[PILATE]

You're a fool Jesus Christ.  
How can I help you?

[MOB]

Pilate, Crucify him!

Remember Caesar.  
You have a duty  
To keep the peace, so crucify him!

Remember Caesar.  
You have a duty  
To keep the peace, so crucify him!

[PILATE]

Don't let me stop your great self-destruction.  
Die if you want to, you misguided martyr.  
I wash my hands of your demolition.  
Die if you want to you innocent puppet!
