---
id: xPWeD-1xKGs
title: "Psalmul 1 - Psalm 1"
sidebar_label: "Psalmul 1 - Psalm 1"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/xPWeD-1xKGs"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Psalmul 1 - Psalm 1

Lyrics: St. Metropolitan Dosoftei, 1673   
https://en.wikipedia.org/wiki/Dosoftei

Fericit este omul care nu merge   
în sfatul celor fărădelege   
Și cu cei răi nu stă în cărare,   
nici nu șade-n scaun de pierzare, 

ci voia lui va fi tot cu Domnul   
și-n legea Lui își va petrece somnul,   
încât se va învăţa zi și noapte   
să-I cunoască poruncile toate?. 

Și va fi ca pomul lângă apă,   
care tot timpul va da roadă,   
și frunza sa încă nu-și va pierde,   
ci în toată vremea va sta verde. 

Și cu cât lucrează sporește,   
iar bogăţia lui va crește.   
iar voi, necuraţilor, ca pleava,   
degrabă vă veţi cunoaște isprava. 

Când se va vântura din arie snopul,   
vă veţi duce cum se duce colbul,   
și cu grâul nu veţi cădea-n hambare,   
ci veţi fi suflați cu spulberare. 

La Judecată nu vi se va afla locul,   
să vă înălțați, ci veţi pieri cu totul.   
Nici păcătoșii nu vor fi în dreapta,   
ca să își ia cu cei Drepţi plata, 

căci celor Drepţi toată calea le-o vede   
Domnul, din scaunul în care El șade.   
Și calea păgânilor cea strâmbă   
va pieri, și vor cădea-n grea osândă. 

și vor cădea-n osândă...

English:

Blessed is the man who does not walk  
in the counsel of the wicked,  
nor stand in the way of sinners,  
nor sit in the seat of mockers,

But his delight is in the law of the Lord,  
and on His law he meditates day and night.  
He is like a tree planted by streams of water,  
which yields its fruit in season  
and whose leaf does not wither—  
whatever he does prospers.

Not so the wicked!  
They are like chaff  
that the wind blows away.  
Therefore the wicked will not stand in the judgment,  
nor sinners in the assembly of the righteous.

For the Lord watches over the way of the righteous,  
but the way of the wicked leads to destruction.  
And the wicked will fall into condemnation...
