---
id: mAyfW1XuPdw
title: "Gloria In Excelsis Deo - Glory To God In The Highest"
sidebar_label: "Gloria In Excelsis Deo - Glory To God In The Highest"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/mAyfW1XuPdw"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Gloria In Excelsis Deo - Glory To God In The Highest

Lyrics:  Hilary of Poitiers, 4th century  
https://en.wikipedia.org/wiki/Gloria_in_excelsis_Deo

Glória in excélsis Deo  
Glória in excélsis Deo

Glória in excélsis Deo  
et in terra pax homínibus   
bonae voluntátis.

Laudámus te,  
benedícimus te,  
adorámus te,  
glorificámus te.

Grátias ágimus tibi   
propter magnam glóriam tuam,  
Dómine Deus, Rex cæléstis,  
Deus Pater omnípotens.

Dómine Fili Unigénite,   
Iesu Christe,  
Dómine Deus, Agnus Dei,   
Fílius Patris,  
Qui tollis peccáta mundi,   
miserére nobis;  
Qui tollis peccáta mundi,   
súscipe deprecatiónem nostram.  
Qui sedes ad déxteram Patris,   
miserére nobis.

Quóniam tu solus Sanctus,   
tu solus Dóminus,   
tu solus Altíssimus,  
Iesu Christe,   
cum Sancto Spíritu:   
in glória Dei Patris. 

Amen

English:

Glory To God In The Highest  
Glory To God In The Highest

Glory to God in the highest  
and peace on earth to all men of goodwill  
we praise you  
we bless you  
we adore you  
we glorify you  
we thank you, for your great glory  
Lord God, king of the heavens  
God almighty Father  
Lord, begotten son, Jesus Christ  
Lord God, lamb of God, son of the father  
take all sins from the world, have mercy on us  
take all sins from the world, receive our invocation  
you who are seated at the right of the Father, have mercy on us  
because only you are Holy, only you are Lord, only you are Highest  
Jesus Christ, with the Holy Spirit, in the glory of God the Father,   
Amen.
