---
id: RpV_6leFhoI
title: "Σκηνή 32"
sidebar_label: "Σκηνή 32"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/RpV_6leFhoI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 32

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Ένα απόσπασμα της επιτέθηκε.

«Παραδώσου!» της φώναξαν. «Έχω ορκιστεί και έχω δεσμεύσει την πίστη μου σε κάποιον άλλον εκτός από εσάς», απάντησε η γενναία κοπέλα, «και θα τηρήσω τον όρκο μου!»

Αλλά μάταια αντιστάθηκε. Τραβηγμένη από τα μακριά της ρούχα, ρίχτηκε από το άλογό της και αιχμαλωτίστηκε. Από την κορυφή των προμαχών της πόλης, ο Λόρδος του Φλαβί, διοικητής της Κομπιένης, ήταν μάρτυρας της σύλληψής της. Δεν έκανε τίποτα για να τη βοηθήσει.
