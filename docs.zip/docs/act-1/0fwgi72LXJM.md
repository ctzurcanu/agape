---
id: 0fwgi72LXJM
title: "Σκηνή 17"
sidebar_label: "Σκηνή 17"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/0fwgi72LXJM"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 17

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Ωστόσο, ήταν ζήτημα να αποφασιστεί πώς θα συνεχιζόταν αυτή η επίθεση που είχε αρχίσει τόσο ευτυχώς εναντίον των Άγγλων.

Οι αρχηγοί, απρόθυμοι να καθοδηγηθούν από ένα κορίτσι του χωριού ή να μοιραστούν μαζί της τη δόξα της επιτυχίας, συναντήθηκαν κρυφά για να συζητήσουν το σχέδιο που θα υιοθετούσαν.

Η Ιωάννα παρουσιάστηκε στο συμβούλιο· και καθώς ο καγκελάριος του Δούκα της Ορλεάνης προσπάθησε να κρύψει από αυτήν τις αποφάσεις που είχαν ληφθεί:

“Πείτε τι έχετε συμπεράνει και πείτε,” φώναξε, αγανακτισμένη από αυτές τις παρακάμψεις· “μπορώ να κρύψω κάτι μεγαλύτερο!” πρόσθεσε:

“Ήσασταν στο συμβούλιό σας και εγώ ήμουν στο δικό μου, και πιστέψτε ότι το συμβούλιο του Θεού θα εκπληρωθεί και θα παραμείνει σταθερό, και ότι το δικό σας θα καταρρεύσει. Ξυπνήστε νωρίς αύριο το πρωί, γιατί θα έχω πολλά να κάνω, περισσότερα από όσα είχα ποτέ.”
