---
id: 1clgS_jEdac
title: "Σκηνή 34"
sidebar_label: "Σκηνή 34"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/1clgS_jEdac"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 34

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Η Ιωάννα κλειδώθηκε στο Κάστρο του Μποβρουάρ. Αλλά γνωρίζοντας ότι οι Άγγλοι ήθελαν να την αγοράσουν από τον Λόρδο του Λουξεμβούργου και επίσης ότι η πολιορκία της Κομπιένης προχωρούσε και ότι η πόλη επρόκειτο να υποκύψει, μια νύχτα γλίστρησε από την κορυφή του πύργου, χρησιμοποιώντας λουριά που έσπασαν. Έπεσε στη βάση του τοίχου και έμεινε εκεί σαν νεκρή.

Η Ιωάννα, ωστόσο, συνήλθε από την πτώση της. Μια σκληρότερη μοίρα την περίμενε.

Στα τέλη Νοεμβρίου, παραδόθηκε στους Άγγλους για ένα ποσό δέκα χιλιάδων τουρνουά λιρών.
