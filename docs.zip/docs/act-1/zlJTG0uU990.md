---
id: zlJTG0uU990
title: "Σκηνή 16"
sidebar_label: "Σκηνή 16"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/zlJTG0uU990"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 16

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Η Ιωάννα επέστρεψε νικηφόρα στην Ορλεάνη. Αλλά καθώς, μέσα στη χαρά της επιτυχίας της, επέστρεφε προς την πόλη, διασχίζοντας το πεδίο της μάχης, ένιωσε την καρδιά της να λιώνει από οίκτο στη θέα των τραυματισμένων και των νεκρών, και άρχισε να κλαίει, σκεπτόμενη ότι είχαν πεθάνει χωρίς εξομολόγηση. Και είπε “ότι ποτέ πριν δεν είχε δει το αίμα της Γαλλίας να χύνεται. Τα μαλλιά της σηκώθηκαν όρθια.”
