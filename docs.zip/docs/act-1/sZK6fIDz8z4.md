---
id: sZK6fIDz8z4
title: "Σκηνή 28"
sidebar_label: "Σκηνή 28"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/sZK6fIDz8z4"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 28

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Μετά τη στέψη της Ρεμς, η Ιωάννα ήθελε να προχωρήσει δυναμικά προς το Παρίσι και να ανακτήσει την πρωτεύουσα του βασιλείου. Η αναποφασιστικότητα του Βασιλιά έδωσε στους Άγγλους χρόνο να κάνουν τις αμυντικές τους προετοιμασίες. Η επίθεση αποκρούστηκε· η Ιωάννα τραυματίστηκε από ένα βέλος στο μηρό.

Αναγκάστηκε να μεταφερθεί με τη βία από τους πρόποδες των προμαχών για να σταματήσει τη μάχη. Την επόμενη μέρα, ο Βασιλιάς αντιτάχθηκε στην επανέναρξη της επίθεσης· η Ιωάννα, ωστόσο, ήταν υπεύθυνη για την έλλειψη επιτυχίας.

Για αρκετό καιρό ο Κάρολος σέρνονταν στους δρόμους· ανυπομονούσε να ξαναρχίσει την αδιάφορη ζωή του στα κάστρα του στην Τουραίν.
