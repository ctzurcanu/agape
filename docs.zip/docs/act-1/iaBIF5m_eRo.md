---
id: iaBIF5m_eRo
title: "Σκηνή 2"
sidebar_label: "Σκηνή 2"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/iaBIF5m_eRo"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 2

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Μια καλοκαιρινή μέρα, όταν ήταν δεκατριών ετών, καθώς ήταν μεσημέρι, άκουσε μια φωνή στον κήπο του πατέρα της· ένα μεγάλο φως ξέσπασε, και ο αρχάγγελος Άγιος Μιχαήλ της εμφανίστηκε. Της είπε να είναι καλή και να πηγαίνει στην εκκλησία. Στη συνέχεια, λέγοντάς της για τη μεγάλη λύπη που υπήρχε στο βασίλειο της Γαλλίας, της ανακοίνωσε ότι θα πήγαινε σε βοήθεια του Δελφίνου και ότι θα τον οδηγούσε στη Ρεμς για τη στέψη του.

“Κύριε, είμαι μόνο ένα φτωχό κορίτσι, δεν μπορώ να ιππεύσω ή να οδηγήσω άνδρες στα όπλα.”

“Ο Θεός θα σε βοηθήσει”, απάντησε ο αρχάγγελος.

Και το ταραγμένο παιδί έμεινε κλαίγοντας.
