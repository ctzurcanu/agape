---
id: 820_YxiWA4E
title: "Σκηνή 20"
sidebar_label: "Σκηνή 20"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/820_YxiWA4E"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 20

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Τα νέα της απελευθέρωσης της Ορλεάνης διαδόθηκαν παντού, επιβεβαιώνοντας τη θεότητα της αποστολής της Ιωάννας.

Η αγία κοπέλα, αποφεύγοντας την αναγνώριση των Ορλεανών, επέστρεψε βιαστικά στο Σινόν. Ήθελε, εκμεταλλευόμενη τον ενθουσιασμό που ξεσήκωσε γύρω της, να φύγει αμέσως για τη Ρεμς, παίρνοντας τον Βασιλιά μαζί της για να τον στεφθεί. Ο Βασιλιάς την υποδέχθηκε με μεγάλες τιμές, αλλά αρνήθηκε να την ακολουθήσει. Δέχθηκε την αφοσίωση αυτής της ηρωικής κοπέλας, αλλά καταλάβαινε ότι οι γενναιόδωρες προσπάθειές της δεν θα διατάρασσαν σε καμία περίπτωση την δειλή αδράνεια της βασιλικής της ύπαρξης.

Αποφασίστηκε ότι η Ιωάννα θα επιτεθεί στα μέρη που οι Άγγλοι ακόμα κρατούσαν στις όχθες του Λίγηρα.
