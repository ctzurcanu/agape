---
id: cI76l3nq62I
title: "Σκηνή 37"
sidebar_label: "Σκηνή 37"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/cI76l3nq62I"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 37

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Μια μέρα, ο Στάφορντ και ο Γουόρικ ήρθαν να τη δουν με τον Ιωάννη του Λουξεμβούργου. Και καθώς αυτός, χλευαστικά, της είπε ότι ερχόταν να την αγοράσει πίσω αν υποσχόταν να μην οπλιστεί ξανά εναντίον της Αγγλίας:

«Στο όνομα του Θεού», απάντησε, «με κοροϊδεύετε, γιατί ξέρω πολύ καλά ότι δεν έχετε ούτε τη θέληση ούτε τη δύναμη· ξέρω πολύ καλά ότι οι Άγγλοι θα με σκοτώσουν, πιστεύοντας ότι μετά το θάνατό μου θα αποκτήσουν το βασίλειο της Γαλλίας· αλλά ακόμα κι αν ήταν εκατό χιλιάδες περισσότεροι, δεν θα αποκτούσαν το βασίλειο.»

Οργισμένος, ο Κόμης του Στάφορντ όρμησε κατά πάνω της.

Θα την είχε σκοτώσει χωρίς την παρέμβαση των βοηθών.
