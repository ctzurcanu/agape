---
id: E4nzWM0PYh8
title: "Σκηνή 14"
sidebar_label: "Σκηνή 14"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/E4nzWM0PYh8"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 14

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Την ίδια μέρα, καθώς η Ιωάννα αναπαυόταν, ξύπνησε ξαφνικά.

“Ω! Θεέ μου,” φώναξε, “το αίμα του λαού μας χύνεται στο έδαφος!… Είναι λάθος! Γιατί δεν με ξύπνησαν; Γρήγορα, τα όπλα μου, το άλογό μου!”

Βοηθούμενη από τις γυναίκες του σπιτιού, οπλίστηκε γρήγορα και, πηδώντας στη σέλα, έφυγε καλπάζοντας, με το σταντάρ της στο χέρι, τρέχοντας κατευθείαν προς την Πύλη της Βουργουνδίας, τόσο γρήγορα που πετάγονταν σπινθήρες από το πλακόστρωτο.
