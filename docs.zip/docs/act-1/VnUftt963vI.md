---
id: VnUftt963vI
title: "Σκηνή 33"
sidebar_label: "Σκηνή 33"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/VnUftt963vI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 33

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Η Ιωάννα μεταφέρθηκε στο Μαρνί ανάμεσα σε κραυγές χαράς των εχθρών της. Οι Άγγλοι και οι Βουργουνδοί αρχηγοί και ο ίδιος ο Δούκας της Βουργουνδίας έτρεξαν να δουν τη μάγισσα. Βρέθηκαν αντιμέτωποι με ένα δεκαοχτάχρονο κορίτσι. Η Ιωάννα ήταν η αιχμάλωτη του Ιωάννη του Λουξεμβούργου, ενός κυρίου χωρίς περιουσία, που ήθελε μόνο να επωφεληθεί από τη σύλληψή της. Ο βασιλιάς της Γαλλίας δεν έκανε καμία προσφορά για λύτρα της αιχμαλώτου.
