---
id: PxO-yq1IN_k
title: "Σκηνή 24"
sidebar_label: "Σκηνή 24"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/PxO-yq1IN_k"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 24

Οι στρατιώτες, Άγγλοι και Βουργουνδοί, που φρουρούσαν την Τρουά, μπόρεσαν να φύγουν από την πόλη με όλα τα υπάρχοντά τους. Αυτό που είχαν ήταν κυρίως αιχμάλωτοι, Γάλλοι. Κατά τη σύνταξη της συνθηκολόγησης, τίποτα δεν είχε προβλεφθεί υπέρ αυτών των άτυχων ανθρώπων. Αλλά όταν οι Άγγλοι έφυγαν από την πόλη με τους δεμένους αιχμαλώτους τους, η Ιωάννα ρίχτηκε στο δρόμο τους.

«Στο όνομα του Θεού, δεν θα τους πάρετε!» φώναξε.

Ζήτησε να της παραδοθούν οι αιχμάλωτοι και να πληρωθούν τα λύτρα τους από τον Βασιλιά.
