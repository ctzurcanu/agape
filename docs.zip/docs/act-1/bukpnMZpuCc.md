---
id: bukpnMZpuCc
title: "Σκηνή 39"
sidebar_label: "Σκηνή 39"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/bukpnMZpuCc"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 39

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Ωστόσο, η δίκη προχωρούσε πολύ αργά για τους Άγγλους.

«Δικαστές, δεν αξίζετε τα χρήματά σας!» φώναζαν στα μέλη του δικαστηρίου.

«Ήρθα στον Βασιλιά της Γαλλίας», είπε η Ιωάννα, «από τον Θεό, από την Παναγία, τους Αγίους και την νικήτρια Εκκλησία άνωθεν· σε εκείνη την Εκκλησία υποβάλλομαι, τα έργα μου, ό,τι έχω κάνει ή πρόκειται να κάνω. Λέτε ότι είστε οι δικαστές μου, προσέχετε τι κάνετε, γιατί αλήθεια, είμαι σταλμένη από τον Θεό και εσείς βάζετε τον εαυτό σας σε μεγάλο κίνδυνο!»

Η αγία ηρωίδα καταδικάστηκε, ως αιρετική, αναθεωρημένη, αποστάτης και ειδωλολάτρης, να καεί ζωντανή στην πλατεία του Παλιού Παζαριού στη Ρουέν.

«Επίσκοπε, πεθαίνω εξαιτίας σου!» είπε, απευθυνόμενη στον Καουσόν.
