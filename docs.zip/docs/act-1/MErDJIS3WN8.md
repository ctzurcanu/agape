---
id: MErDJIS3WN8
title: "Σκηνή 38"
sidebar_label: "Σκηνή 38"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/MErDJIS3WN8"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 38

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Η Ιωάννα, θεωρούμενη αιρετική, στερήθηκε τη βοήθεια της θρησκείας. Τα μυστήρια της απαγορεύτηκαν.

Επιστρέφοντας από την ανάκριση και περνώντας με την συνοδεία της μπροστά από ένα παρεκκλήσι του οποίου η πόρτα ήταν κλειστή, ρώτησε τον μοναχό που την συνόδευε αν το σώμα του Ιησού Χριστού ήταν εκεί, ζητώντας να της επιτραπεί να γονατίσει για λίγο μπροστά από την πόρτα για να προσευχηθεί. Το οποίο έκανε. Τώρα, ο Καουσόν, όταν το έμαθε αυτό, απείλησε τον μοναχό με τις πιο αυστηρές τιμωρίες αν συνέβαινε ξανά κάτι τέτοιο.
