---
id: EN8JtWxeVqY
title: "Σκηνή 31"
sidebar_label: "Σκηνή 31"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/EN8JtWxeVqY"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 31

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Στις 23 Μαΐου, ενώ βρισκόταν στο Κρεσπί, έμαθε ότι η πόλη της Κομπιένης πολιορκούνταν στενά από τους Άγγλους και τους Βουργουνδούς.

Πήγε εκεί με τετρακόσιους μαχητές και εισήλθε στην πόλη στις 24, την αυγή. Τότε, παίρνοντας μέρος της φρουράς μαζί της, επιτέθηκε στους Βουργουνδούς. Αλλά οι Άγγλοι ήρθαν να της επιτεθούν. Οι Γάλλοι υποχώρησαν.

«Μην σκέφτεστε τίποτα άλλο παρά να τους πυροβολείτε», φώναξε η Ιωάννα, «είναι στο χέρι σας να τους αποδιοργανώσετε!»

Αλλά η Ιωάννα παρασύρθηκε από την υποχώρηση των ανθρώπων της. Φέρθηκε πίσω κάτω από τα προμαχώνα του Κομπιένης, οι Γάλλοι βρήκαν τη γέφυρα ανεβασμένη και την πύλη κατεβασμένη. Ωστόσο, η Ιωάννα, εξαναγκασμένη στα χαντάκια, εξακολουθούσε να αμύνεται.
