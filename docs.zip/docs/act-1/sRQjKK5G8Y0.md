---
id: sRQjKK5G8Y0
title: "Σκηνή 13"
sidebar_label: "Σκηνή 13"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/sRQjKK5G8Y0"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 13

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Ωστόσο, δεν λάβαμε νέα από το Μπλουά. Ο Ντουνουά, ανήσυχος, έφυγε για να επισπεύσει την άφιξη της βοήθειας. Ήταν καιρός. Ο αρχιεπίσκοπος της Ρεμς, Ρενώλντ ντε Σαρτρ, καγκελάριος του βασιλιά, αναθεωρώντας τις ληφθείσες αποφάσεις, επρόκειτο να στείλει τα στρατεύματα πίσω στις φρουρές τους. Ο Ντουνουά κατάφερε να τα πάει στην Ορλεάνη.

Την Τετάρτη, 4 Μαΐου, το πρωί, η Ιωάννα, περιβαλλόμενη από όλον τον κλήρο της πόλης και ακολουθούμενη από μεγάλο μέρος του πληθυσμού, έφυγε από την Ορλεάνη· μέσα από τα αγγλικά φρούρια, προχώρησε σε μια μεγαλοπρεπή πομπή για να συναντήσει τον μικρό στρατό του Ντουνουά, ο οποίος πέρασε υπό την προστασία των ιερέων και ενός κοριτσιού, χωρίς οι Άγγλοι να τολμήσουν να τον επιτεθούν.
