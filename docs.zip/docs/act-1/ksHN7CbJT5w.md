---
id: ksHN7CbJT5w
title: "Σκηνή 5"
sidebar_label: "Σκηνή 5"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/ksHN7CbJT5w"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 5

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Αλλά αυτή τη φορά έμεινε στο Βωκουλέρ.

Σύντομα, ο μόνος θόρυβος στη χώρα ήταν για αυτή τη νεαρή κοπέλα, που γύριζε λέγοντας δυνατά ότι θα έσωζε το βασίλειο, ότι πρέπει να την πάρουν στον Δελφίνο, ότι ο Θεός το ήθελε.

“Θα πάω,” είπε, “ακόμα κι αν φθείρω τα πόδια μου μέχρι τα γόνατα.”

Οι άνθρωποι, με απλές καρδιές, συγκινημένοι από την πίστη της, την πίστεψαν. Ένας ιππότης, ο Ζαν ντε Μετς, κερδισμένος από την εμπιστοσύνη του πλήθους, προσφέρθηκε να την πάει στο Σινόν, όπου ήταν ο Κάρολος Ζ’. Οι φτωχοί, ενώνοντας τις δυστυχίες τους, ενώθηκαν για να ντύσουν και να οπλίσουν το μικρό κορίτσι του χωριού. Της αγόρασαν ένα άλογο, και την ορισμένη ημέρα αναχώρησε με τη μικρή συνοδεία της.

“Πήγαινε. Και ό,τι γίνει!” της πέταξε ο Μποδρικόρ.

“Ο Θεός να σε ευλογίσει!” φώναξαν οι φτωχοί άνθρωποι, και οι γυναίκες έκλαιγαν καθώς την έβλεπαν να φεύγει.
