---
id: elCJZbfK3iw
title: "Σκηνή 10"
sidebar_label: "Σκηνή 10"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/elCJZbfK3iw"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 10

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Ο στρατός και το κομβόι έφτασαν μπροστά από το Σέσι, δύο λεύγες πάνω από την Ορλεάνη.

Ήταν θέμα να διασχίσουν τον Λίγηρα· έλειπαν τα σκάφη. Η Ιωάννα μεταφέρθηκε στην άλλη όχθη με μέρος της συνοδείας της και το κομβόι των προμηθειών. Τα υπόλοιπα στρατεύματα έπρεπε να επιστρέψουν στο Μπλουά, για να επιστρέψουν στην Ορλεάνη μέσω της δεξιάς όχθης του Λίγηρα, μέσω της Μποσέ.
