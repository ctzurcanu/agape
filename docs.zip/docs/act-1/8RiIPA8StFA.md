---
id: 8RiIPA8StFA
title: "Σκηνή 15"
sidebar_label: "Σκηνή 15"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/8RiIPA8StFA"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 15

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Στην πραγματικότητα, χωρίς να την ειδοποιήσουν, είχε επιτεθεί το φρούριο του Αγίου Λουπ. Η επίθεση είχε αποτύχει· οι Γάλλοι υποχωρούσαν ατακτοποίητα. Η Ιωάννα έτρεξε να τους συγκεντρώσει και, επιστρέφοντας τους στον εχθρό, επανέλαβε την επίθεση. Ο Ταλομπότ προσπάθησε μάταια να βοηθήσει τους ανθρώπους του. Η Ιωάννα, στέκοντας στους πρόποδες των τειχών, ενθάρρυνε τον λαό της. Για τρεις ώρες οι Άγγλοι αντιστάθηκαν. Παρά την απελπισμένη τους άμυνα, το φρούριο καταλήφθηκε.
