---
id: 0qr5jn2_Ojw
title: "Σκηνή 36"
sidebar_label: "Σκηνή 36"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/0qr5jn2_Ojw"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 36

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Ωστόσο, της έμενε μία βοήθεια: αυτή των αγίων της. Μόνο αυτοί δεν την είχαν εγκαταλείψει. Η Ιωάννα λάμβανε πάντα συμβουλές από τις ουράνιες φωνές της· η Αγία Μαργαρίτα και η Αγία Αικατερίνη εμφανίζονταν σε αυτήν στη σιωπή της νύχτας, την παρηγορούσαν με καλές λέξεις. Και καθώς ο επίσκοπος Καουσόν ρώτησε την Ιωάννα τι της είπαν:

«Με ξύπνησαν», απάντησε, «έσφιξα τα χέρια μου και ζήτησα να μου δώσουν συμβουλές· μου είπαν: ‘Ρώτησε τον Κύριό μας.’»

«Και τι άλλο σου είπαν;»

«Να σου απαντήσω θαρρετά.»

Και καθώς ο επίσκοπος την πίεζε με ερωτήσεις:

«Δεν μπορώ να πω τα πάντα· φοβάμαι περισσότερο μήπως πω κάτι που τους δυσαρεστεί παρά να μην σου απαντήσω.»
