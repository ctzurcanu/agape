---
id: 9dfNxg3XbHo
title: "Σκηνή 9"
sidebar_label: "Σκηνή 9"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/9dfNxg3XbHo"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 9

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Τα στρατεύματα συγκεντρώθηκαν στο Μπλουά. Η Ιωάννα έφτασε εκεί συνοδευόμενη από τον Δούκα του Αλανσόν, τον Στρατάρχη του Μπουσάκ, τον Άρχοντα του Ρε, τον Λα Ιρ και τον Ζαντραγί.

Στο λευκό της σταντάρ είχε την εικόνα του Θεού και τα ονόματα Ιησούς και Μαρία κεντημένα. Συμβούλευε τους στρατιώτες της να εξετάσουν τη συνείδησή τους και να εξομολογηθούν πριν βγουν να πολεμήσουν. Την Πέμπτη, 28 Απριλίου, ο μικρός στρατός αναχώρησε. Η Ιωάννα ηγείτο, το σταντάρ της στον άνεμο, με το τραγούδι “Veni, Creator”.

Ήθελε να βαδίσει κατευθείαν προς την Ορλεάνη· οι αρχηγοί σκέφτηκαν ότι ήταν πιο συνετό να πάνε μέσω της αριστερής όχθης του Λίγηρα.
