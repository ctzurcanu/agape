---
id: Az9TUvyruT4
title: "Σκηνή 23"
sidebar_label: "Σκηνή 23"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Az9TUvyruT4"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 23

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Οι Άγγλοι έχασαν τέσσερις χιλιάδες νεκρούς. Δύο εκατοντάδες αιχμάλωτοι συνελήφθησαν. Μόνο εκείνοι που μπορούσαν να πληρώσουν λύτρα κρατήθηκαν, οι άλλοι σκοτώθηκαν χωρίς έλεος.

Ένας από αυτούς ξυλοκοπήθηκε τόσο βάναυσα μπροστά στην Ιωάννα που κατέβηκε από το άλογό της για να τον βοηθήσει. Σήκωσε το κεφάλι του φτωχού ανθρώπου, έφερε έναν ιερέα σε αυτόν, τον παρηγόρησε και τον βοήθησε να πεθάνει.

Η καρδιά της ήταν εξίσου συμπονετική για τους τραυματισμένους Άγγλους όσο και για τους δικούς της.

Επιπλέον, αψηφούσε τα χτυπήματα και τραυματιζόταν συχνά, αλλά ποτέ δεν ήθελε να χρησιμοποιήσει το σπαθί της· το λευκό της λάβαρο ήταν το μόνο όπλο της.
