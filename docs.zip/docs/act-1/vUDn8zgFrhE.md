---
id: vUDn8zgFrhE
title: "Σκηνή 8"
sidebar_label: "Σκηνή 8"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/vUDn8zgFrhE"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 8

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Για τρεις εβδομάδες τη βασάνιζαν με δόλιες ερωτήσεις.

“Υπάρχουν περισσότερα στο βιβλίο του Θεού από ό,τι στο δικό σας,” απάντησε· “δεν ξέρω ούτε το Α ούτε το Β, αλλά έρχομαι από τον Βασιλιά των Ουρανών.”

Όταν της αντέτειναν ότι ο Θεός, για να ελευθερώσει τη Γαλλία, δεν χρειαζόταν ένοπλους άνδρες, σηκώθηκε ξαφνικά:

“Οι άνδρες θα πολεμήσουν, ο Θεός θα δώσει τη νίκη.”

Εκεί, όπως και στο Βωκουλέρ, οι άνθρωποι δήλωσαν τον εαυτό τους υπέρ της, τη θεωρούσαν αγία και εμπνευσμένη. Οι γιατροί και οι ισχυροί αναγκάστηκαν να υποκύψουν στον ενθουσιασμό του πλήθους.
