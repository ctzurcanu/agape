---
id: rLAS1JZ65HI
title: "Σκηνή 29"
sidebar_label: "Σκηνή 29"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/rLAS1JZ65HI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 29

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Αυτή η υποχώρηση που επιβλήθηκε από τη δειλία του Καρόλου VII και τη ζήλια των αυλικών ήταν μια τρομερή επίθεση στο κύρος της Ιωάννας.

Από τώρα και στο εξής, στα μάτια όλων, έπαψε να είναι ανίκητη.

Η αγία κοπέλα φαίνεται να το κατάλαβε αυτό, γιατί, πριν φύγει από το Παρίσι, πήγε να τοποθετήσει ως προσφορά, στον βωμό του Αγίου Διονυσίου, τα μέχρι τότε νικηφόρα όπλα της. Προσευχήθηκε για πολύ ώρα. Ίσως εκείνη τη στιγμή είχε την προαίσθηση ότι η ένδοξη αποστολή της είχε τελειώσει και ότι την περίμεναν επώδυνες δοκιμασίες. Ωστόσο, υποτάχθηκε και, με τον θάνατο στην ψυχή της, ακολούθησε τον Βασιλιά στο Ζιέν. Ο στρατός διαλύθηκε. Οι άνθρωποι της αυλής πίστευαν ότι είχαμε πολεμήσει αρκετά. Ήταν σημαντικό, άλλωστε, για τη ζήλια τους να τερματίσουν τις επιτυχίες της Ιωάννας.
