---
id: kOu1DqlF47A
title: "Σκηνή 18"
sidebar_label: "Σκηνή 18"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/kOu1DqlF47A"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 18

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Την επόμενη μέρα, 6 Μαΐου, κατέλαβε το φρούριο των Αυγουστινών. Το Σάββατο 7, νωρίς το πρωί, άρχισε η επίθεση στο φρούριο των Τουρνέλ. Η Ιωάννα, κατεβασμένη στη τάφρο, ανέβαζε μια σκάλα στο στηθαίο, όταν μια βολή τόξου την τρύπησε ανάμεσα στο λαιμό και τον ώμο. Αφαίρεσε το σίδερο από την πληγή· της προσφέρθηκε τότε να μαγέψει την πληγή, αρνήθηκε, λέγοντας “ότι θα προτιμούσε να πεθάνει παρά να κάνει κάτι που ήταν αντίθετο με το θέλημα του Θεού”. Εξομολογήθηκε και προσευχήθηκε για πολύ ώρα ενώ τα στρατεύματά της ξεκουράζονταν. Στη συνέχεια, δίνοντας εντολή να ξαναρχίσει η επίθεση, έπεσε στη μάχη, φωνάζοντας στους επιτιθέμενους:

“Είναι δικό σας, μπείτε!”

Το φρούριο καταλήφθηκε και όλοι οι υπερασπιστές χάθηκαν. Δεν υπήρχε πια Άγγλος στην αριστερή όχθη του Λίγηρα.
