---
id: cpU2FldVVUE
title: "Σκηνή 4"
sidebar_label: "Σκηνή 4"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/cpU2FldVVUE"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 4

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Η υποδοχή του Μποδρικόρ ήταν βάναυση. Η Ιωάννα του είπε “ότι ένα μήνυμα ήρθε από τον Θεό, ότι ο Θεός θα διέταζε τον Δελφίνο να φερθεί καλά γιατί ο Κύριος θα του δώσει βοήθεια πριν από τη μέση της Σαρακοστής”· πρόσθεσε “ότι ο Θεός ήθελε ο Δελφίνος να γίνει βασιλιάς· ότι θα το έκανε παρά τους εχθρούς του, και ότι η ίδια θα τον οδηγούσε στη στέψη”.

“Αυτή η κοπέλα είναι τρελή, είπε ο Μποδρικόρ, ας την πάμε πίσω στον πατέρα της για να της δώσει μερικές καλές σφαλιάρες.”

Η Ιωάννα επέστρεψε στο Ντομρεμί. Αλλά, πιεζόμενη ξανά από τις φωνές της, επέστρεψε στο Βωκουλέρ και είδε ξανά τον Άρχοντα του Μποδρικόρ χωρίς να λάβει μία καλύτερη υποδοχή.
