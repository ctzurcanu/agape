---
id: FWBfmQwnn84
title: "Σκηνή 21"
sidebar_label: "Σκηνή 21"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/FWBfmQwnn84"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 21

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Στις 11 Ιουνίου, οι Γάλλοι κατέλαβαν τα προάστια του Ζαρζό. Την επόμενη μέρα, νωρίς το πρωί, η Ιωάννα έδωσε το σήμα για μάχη. Ο Δούκας του Αλενσόν ήθελε να καθυστερήσει την επίθεση:

“Προχωρήστε, ευγενή δούκα, στην επίθεση! Μην αμφιβάλλετε, είναι η ώρα που ευχαριστεί τον Θεό. Εργαστείτε, και ο Θεός θα εργαστεί.”

Η ίδια ανέβηκε τη σκάλα. Ένα πέτρινο χτύπημα στο κεφάλι την έριξε κάτω. Αλλά σηκώθηκε, φωνάζοντας στους ανθρώπους της:

“Φίλοι, ανεβείτε! ανεβείτε! Ο Άρχοντάς μας έχει καταδικάσει τους Άγγλους. Είναι δικοί μας αυτή την ώρα. Έχετε θάρρος!”

Τα τείχη κατακτήθηκαν. Οι Άγγλοι, κυνηγημένοι μέχρι τη γέφυρα της πόλης, πιάστηκαν και σκοτώθηκαν. Ο Σάφολκ αιχμαλωτίστηκε.

Στις 15, οι Γάλλοι πήραν τον έλεγχο της γέφυρας του Μεν·

στις 16, πολιόρκησαν το Μποζενσύ·

στις 17, η πόλη παραδόθηκε.
