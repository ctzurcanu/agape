---
id: XmaEc1oZNZw
title: "Σκηνή 12"
sidebar_label: "Σκηνή 12"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/XmaEc1oZNZw"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 12

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Ζήτησε να την πάνε σε μια εκκλησία, θέλοντας πάνω απ’ όλα να ευχαριστήσει τον Θεό.

Όταν ένας ηλικιωμένος άνδρας είπε στην Ιωάννα, μιλώντας για τους Άγγλους:

“Κόρη μου, είναι δυνατοί και καλά οχυρωμένοι, και θα είναι μεγάλο πράγμα να τους βγάλουμε από τη μέση,” απάντησε: “Δεν υπάρχει τίποτα αδύνατο στη δύναμη του Θεού.”

Και, στην πραγματικότητα, η εμπιστοσύνη της κέρδισε όλους γύρω της. Οι Ορλεανείς, τόσο φοβισμένοι και αποθαρρυμένοι την προηγούμενη μέρα, τώρα φανατισμένοι από την παρουσία της, ήθελαν να επιτεθούν στον εχθρό και να αφαιρέσουν τις βάσεις τους. Ο Ντουνουά, φοβούμενος την αποτυχία, αποφάσισε να περιμένουν την άφιξη του στρατού ανακούφισης για να ξεκινήσουν την επίθεση. Στο μεταξύ, η Ιωάννα κάλεσε τους Άγγλους να αποσυρθούν και να επιστρέψουν στη χώρα τους. Αυτοί απάντησαν με προσβολές.
