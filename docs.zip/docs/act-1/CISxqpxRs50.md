---
id: CISxqpxRs50
title: "Σκηνή 19"
sidebar_label: "Σκηνή 19"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/CISxqpxRs50"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 19

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Την Κυριακή, οι Άγγλοι παρατάχθηκαν σε μάχη στη δεξιά όχθη του Λίγηρα. Η Ιωάννα απαγόρευσε να τους επιτεθούν. Είχε ένα βωμό ανεγερμένο, και Θεία λειτουργία τελέστηκε παρουσία του συναθροισμένου στρατού. Η τελετή τελείωσε, είπε στους γύρω της:

“Δείτε αν οι Άγγλοι έχουν τα πρόσωπά τους στραμμένα προς εμάς ή τις πλάτες τους!” Και καθώς της είπαν ότι υποχωρούσαν προς την κατεύθυνση του Μεν:

“Στο όνομα του Θεού, αν φεύγουν, αφήστε τους να φύγουν· δεν ευχαριστεί τον Κύριο Θεό να τους πολεμήσουμε σήμερα, θα τους έχουμε κάποια άλλη φορά.”

Η Ορλεάνη, πολιορκημένη για οκτώ μήνες, παραδόθηκε σε τέσσερις μέρες.
