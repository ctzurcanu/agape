---
id: Jb1Xm2VL2H0
title: "Σκηνή 35"
sidebar_label: "Σκηνή 35"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Jb1Xm2VL2H0"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Σκηνή 35

Η Ηρωική Μάρτυς για την Αλήθεια  
Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeUPzfWQnmSq3ShkER7pdSA&si=1nS7zi_Nm_u6HsZW 

Κλειδωμένη στη φυλακή του Κάστρου της Ρουέν, φρουρούνταν μέρα και νύχτα από στρατιώτες, από τους οποίους έπρεπε να υποστεί προσβολές και ακόμη και βιαιότητες, τα δεσμά της δεν της επέτρεπαν να αμυνθεί.

Εν τω μεταξύ, ένα δικαστήριο, κατά την κρίση του αγγλικού κόμματος και προεδρευόμενο από τον Καουσόν, επίσκοπο του Μποβέ, διερευνούσε τη δίκη της. Στις ύπουλες ερωτήσεις των δικαστών της, η φτωχή και άγια κοπέλα, χωρίς υποστήριξη και χωρίς συμβουλές, μπορούσε μόνο να αντιτάξει τη δικαιοσύνη και την απλότητα της καρδιάς της, μόνο την καθαρότητα των προθέσεών της.

«Έρχομαι από τον Θεό», είπε· «δεν έχω καμία χρησιμότητα εδώ· στείλτε με πίσω στον Θεό από τον οποίο ήρθα».
