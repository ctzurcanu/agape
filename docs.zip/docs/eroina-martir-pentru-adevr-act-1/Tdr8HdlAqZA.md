---
id: Tdr8HdlAqZA
title: "Scena 40"
sidebar_label: "Scena 40"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Tdr8HdlAqZA"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 40

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Pe 30 mai, Ioana s-a spovedit și a primit sfânta împărtășanie. Apoi a fost dusă la locul execuției. Când era la picioarele schelei, a îngenuncheat, invocând pe Dumnezeu, pe Fecioara și pe Sfinți; apoi, întorcându-se către episcop, către judecători, către dușmanii ei, i-a rugat cu evlavie să facă liturghii pentru sufletul ei. Ea S-a urcat pe rug, a cerut o cruce și a murit în flăcări în timp ce pronunța numele lui Isus. Toată lumea plângea, călăii înșiși și judecătorii.

„Suntem pierduți, am ars un sfânt!” spuneau englezii în timp ce se împrăștiau.

O JOAN, WITHOUT SEPULCHER AND WITHOUT PORTRAIT, YOU WHO KNEW THAT THE TOMB OF HEROES IS THE HEART OF THE LIVING... André MALRAUX

ONLY PROVABLE VOLUNTEERS CAN RAISE JOAN AND OTHER HEROES BACK FROM THEIR GRAVES Anon
