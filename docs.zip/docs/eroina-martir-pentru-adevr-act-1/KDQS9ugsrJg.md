---
id: KDQS9ugsrJg
title: "Scena 2"
sidebar_label: "Scena 2"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/KDQS9ugsrJg"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 2

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Într-o zi de vară, când avea treisprezece ani, la amiază, a auzit un glas în grădina tatălui ei; a izbucnit o mare lumină și i s-a arătat arhanghelul Sfântul Mihail. El i-a spus să fie bună și să meargă des la biserică. Apoi, spunându-i de marea jale care era în regatul Franței, el a anunțat-o că va merge în ajutorul Delfinului și că îl va duce la Reims pentru încoronare.  
„Domnule, sunt doar o sărmană fată, nu pot călări sau conduce ostași”.  
„Dumnezeu te va ajuta”, a răspuns arhanghelul.  
Iar copilul necăjit a rămas plângând.
