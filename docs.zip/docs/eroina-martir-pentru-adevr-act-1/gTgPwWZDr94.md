---
id: gTgPwWZDr94
title: "Scena 33"
sidebar_label: "Scena 33"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/gTgPwWZDr94"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 33

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Ioana a fost dusă la Margny în mijlocul strigătelor de bucurie ale dușmanilor ei. Sefii englezi si burgunzi si insusi ducele de Burgundia au venit in fuga sa o vada pe vrajitoare. S-au trezit față în față cu o fată de optsprezece ani. Ioana era prizonierul lui Ioan de Luxemburg, un domn fără avere, care nu dorea decât să profite de pe urma capturării ei. Regele Franței nu a făcut nici o ofertă de răscumpărare a captivei.
