---
id: _IGRgvvaPu0
title: "Scena 6"
sidebar_label: "Scena 6"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/_IGRgvvaPu0"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 6

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Chinon era departe, iar călătoria era periculoasă. Partizanii englezi și burgunzi stăpâneau țara, iar trupa mică a fost obligată să treacă peste anumite poduri pe care inamicul le ocupa. Trebuiau să înainteze noaptea și să se ascundă ziua. Tovarășii Ioanei, speriați, planuiau deja întoarcerea la Vaucouleurs.  
„Nu vă temeți de nimic, le-a spus ea, Dumnezeu îmi arată drumul, frații mei din ceruri îmi spun ce trebuie să fac”.  
În a douăsprezecea zi, Ioana a ajuns la Chinon împreună cu tovarășii ei. Din cătunul Sfânta Ecaterina, ea trimisese regelui o scrisoare prin care îi anunța sosirea.  
Curtea lui Carol al VII-lea a fost departe de a fi unanimă cu privire la primirea care ar trebui să i se facă. La Trémouille, favoritul zilei, invidios pe ascendența pe care Ioana o câștigase asupra stăpânului său, era hotărât să înlăture orice influență capabilă să-l smulgă pe Charles din toropeala lui. Timp de două zile, consiliul a discutat dacă Delfinul o va primi pe tânăra inspirată.
