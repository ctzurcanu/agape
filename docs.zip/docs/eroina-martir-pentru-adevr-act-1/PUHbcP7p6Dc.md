---
id: PUHbcP7p6Dc
title: "Scena 38"
sidebar_label: "Scena 38"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/PUHbcP7p6Dc"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 38

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Ioana, tratată ca o eretică, a fost lipsită de ajutorul religiei. Sacramentele i-au fost interzise.  
Întorcându-se de la interogatoriu și trecând cu escorta ei în fața unei capele a cărei ușă era închisă, ea l-a întrebat pe călugărul care o însoțea dacă se află acolo trupul lui Iisus Hristos, cerând să i se permită să îngenuncheze o clipă în fața ușii, pentru a se ruga. Ceea ce a și făcut. Acum, Cauchon, aflând acest lucru, l-a amenințat pe călugăr cu cele mai riguroase pedepse dacă așa ceva s-ar întâmpla din nou.
