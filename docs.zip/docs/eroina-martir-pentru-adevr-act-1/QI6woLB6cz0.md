---
id: QI6woLB6cz0
title: "Scena 29"
sidebar_label: "Scena 29"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/QI6woLB6cz0"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 29

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Această retragere impusă de lașitatea lui Carol al VII-lea și gelozia curtenilor a fost un atac teribil asupra prestigiului Ioanei.  
De acum înainte, în ochii tuturor, ea a încetat să mai fie invincibilă.  
Sfânta fată pare să fi înțeles acest lucru, pentru că, înainte de a părăsi Parisul, s-a dus să așeze ca ofrandă, pe altarul din Saint-Denis, armele ei biruitoare de până atunci. S-a rugat mult timp. Poate că în acel moment a avut un presentiment că misiunea ei glorioasă s-a încheiat și că urmau încercări dureroase. Cu toate acestea, ea s-a supus și, cu moartea în suflet, l-a urmat pe Rege până la Gien. Armata a fost desființată. Curtenii au crezut că s-au luptat destul. Mai mult, era important ca, în gelozia lor, să pună capăt succesului Ioanei.
