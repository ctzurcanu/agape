---
id: 9iE1NS3QAvM
title: "Scena 25"
sidebar_label: "Scena 25"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/9iE1NS3QAvM"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 25

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Pe 16 iulie, Regele a intrat în orașul Reims în fruntea trupelor sale. A doua zi, ceremonia de încoronare a avut loc în catedrală, în mijlocul unui mare adunare de domni și oameni. Ioana stătea în spatele regelui, cu stindardul ei în mână;  
„Stindardul acesta a avut de suferit, este corect să fie în centrul atenției”.  
Când Carol al VII-lea a primit ungerea sacră și coroana de la arhiepiscopul Regnault de Chartres, Ioana s-a aruncat la picioarele lui, sărutându-i genunchii și vărsând lacrimi fierbinți.  
„O, bunule Sire”, a spus ea, „acum s-a împlinit voia lui Dumnezeu care a vrut să vă aduc în orașul vostru Reims pentru a primi sfânta voastră încoronare, arătând că sunteți adevăratul rege și că regatul Franței trebuie să vă aparțină!"  
„Toți cei care au văzut-o în acel moment”, spune vechea cronică, „au crezut mai mult ca niciodată că este de la Dumnezeu”.  
„O, oameni buni și devotați”, a strigat sfânta fată, văzând entuziasmul mulțimii din jurul regelui, „dacă trebuie să mor, aș fi foarte fericită dacă m-ar îngropa aici!”
