---
id: wwL6LuIPqaU
title: "Scena 4"
sidebar_label: "Scena 4"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/wwL6LuIPqaU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 4

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Primirea lui Baudricourt a fost brutală. Ioana i-a spus „că a venit cu solie de la Dumnezeu, că Dumnezeu îi va porunci Delfinului să se poarte bine pentru că Domnul îi va da ajutor înainte de mijlocul Postului Mare”; ea a adăugat „că Dumnezeu a vrut ca Delfinul să devină Rege; că el va face acest lucru în ciuda dușmanilor săi și că ea însăși îl va conduce la încoronare”.  
„Fata asta e nebună”, a spus Baudricourt, să o ducem înapoi la tatăl ei să-i dea o pereche de palme bune.”  
Ioana s-a întors la Domrémy. Dar apăsată din nou de vocile ei, s-a întors la Vaucouleurs și l-a revăzut pe Lordul Baudricourt, insă fără să obțină o primire mai bună.
