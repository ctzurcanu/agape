---
id: 76EclCW7ENk
title: "Scena 22"
sidebar_label: "Scena 22"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/76EclCW7ENk"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 22

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Pe 18 iunie, Ioana a ajuns, lângă Patay, armata engleză condusă de Talbot și Fastolf.  
„În numele lui Dumnezeu trebuie să luptăm cu ei”, a spus ea; "Chiar dacă se agață de nori, ii vom invinge, pentru că Dumnezeu ni-i trimite ca să-i pedepsim. Regele nostru bun va avea astăzi cea mai mare victorie pe care a avut-o vreodată."  
Ea a vrut să meargă în avangarda, dar a fost reținută, iar La Hire a fost însărcinat să-i atace pe englezi pentru a-i obliga să se întoarcă, pentru a le da timp trupelor franceze să sosească. Dar atacul lui La Hire a fost atât de impetuos încât totul a cedat înaintea lui. Când Ioana a venit cu armata ei, englezii se retrăgeau în dezordine. Retragerea lor a devenit o debandadă.  
Talbot a fost luat prizonier.  
„Nu credeai în această dimineață că ți se va întâmpla asta”, a spus ducele de Alençon.  
"Este un noroc specific războiului", răspunse Talbot.
