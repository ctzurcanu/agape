---
id: SB66ZZcuZiw
title: "Scena 27"
sidebar_label: "Scena 27"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/SB66ZZcuZiw"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 27

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Nimica nu era ca nerăbdarea oamenilor de a o atinge pe Ioana. Era vorba despre cine să-i sărute mâinile sau hainele, cine să o atingă. Copiii mici i-au fost prezentați pentru a-i binecuvânta, mătăniile, imaginile sfinte pentru a le sfinți atingându-le cu mâna. Iar fata umilă a respins cu grație aceste semne de adorație, glumând cu blândețe cu bieții oameni despre credulitatea lor în puterea ei. Dar ea a întrebat în ce zi și la ce oră se împărtășesc copiii săracilor, să meargă să fie in comuniune cu ei.  
Mila ei a fost pentru toți cei care au suferit, dar tandrețea ei a fost toată pentru cei mici și umili. Se simțea ca sora lor, știind că s-a născut dintr-unul dintre ei. Când mai târziu a fost criticată pentru că a tolerat această adorație a mulțimii, Ioana va răspunde pur și simplu:  
„Mulți oameni m-au căutat de bunăvoie și mi-au sărutat mâinile fără permisiunea mea, dar săracii au venit de bunăvoie la mine pentru că nu le-am displăcut”.
