---
id: KqazRDybjxo
title: "Scena 34"
sidebar_label: "Scena 34"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/KqazRDybjxo"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 34

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Ioana a fost închisă în castelul de Beaurevoir. Dar, știind că englezii voiau să o cumpere de la Lordul Luxemburgului, și, de asemenea, că asediul cetății Compiègne înainta și că orașul urma să cedeze, într-o noapte ea s-a lăsat să alunece din vârful donjonului, folosind niște curele care s-au rupt. Ea a căzut la picioarele zidului și a rămas acolo aproape moartă.  
Ioana, însă, își revine din cădere.   
Un final mai crud îi era pregătit.  
La sfârșitul lunii noiembrie, a fost predată englezilor pentru o sumă de zece mii de lire.
