---
id: XfYmaIJRKpE
title: "Scena 3"
sidebar_label: "Scena 3"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/XfYmaIJRKpE"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 3

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Din acea zi, evlavia Ioanei a devenit și mai arzătoare; Copilul s-a despărțit de bunăvoie de tovarășii săi pentru a medita și auzea voci cerești care îi vorbeau despre misiunea ei. Ele erau, spunea ea, vocile sfinților ei. Adesea aceste voci erau însoțite de viziuni; I s-au arătat Sfânta Ecaterina și Sfânta Margareta.  
„I-am văzut cu ochii trupului”, le-a spus ea mai târziu judecătorilor ei, „și când m-au părăsit, am plâns; Doream să mă ia cu ei.”  
Copilul a crescut, spiritul ei exaltat de viziunile lui și păstrând adânc în inima ei secretul conversațiilor ei celeste. Nimeni nu bănuia ce se întâmplă în interiorul ei, nici măcar preotul la care se spovedea.  
La începutul anului 1428, Ioana avea optsprezece ani, iar vocile au devenit mai urgente.  
„Pericolul este mare, Ioana trebuie să plece pentru a-l ajuta pe rege și a salva regatul.”  
Sfinții ei i-au poruncit să meargă să-l găsească pe Lordul Baudricourt, Lordul de Vaucouleurs și să-i ceară o escortă care să o ducă la Delfin.  
Neîndrăznind să-și împărtășească cu părinții planul, Ioana s-a dus la Burey să-și găsească unchiul Laxart și l-a implorat să o ducă la Vaucouleurs. Ardoarea rugăminților ei a zguduit timiditatea țăranului; a promis că o va însoți.
