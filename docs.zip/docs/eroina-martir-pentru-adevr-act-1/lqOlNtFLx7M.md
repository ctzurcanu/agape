---
id: lqOlNtFLx7M
title: "Scena 15"
sidebar_label: "Scena 15"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/lqOlNtFLx7M"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 15

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

De fapt, fără a o avertiza, bastida Saint-Loup fusese atacată. Atacul eșuase; francezii s-au retras în dezordine. Ioana a alergat să-i adune și, aducându-i înapoi în fața inamicului, a reînceput asaltul. Degeaba a încercat Talbot să-și ajute oamenii. Ioana, stând la poalele meterezelor, și-a încurajat oamenii. Timp de trei ore englezii au rezistat. În ciuda apărării lor disperate, bastida a fost luată.
