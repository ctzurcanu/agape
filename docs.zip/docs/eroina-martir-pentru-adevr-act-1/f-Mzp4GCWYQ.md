---
id: f-Mzp4GCWYQ
title: "Scena 36"
sidebar_label: "Scena 36"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/f-Mzp4GCWYQ"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 36

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Totuși, a rămas un ajutor pentru ea: cel al sfinților ei. Numai ei nu o abandonaseră. Ioana a primit întotdeauna sfaturi de la vocile ei cerești; Sfânta Margareta și Sfânta Ecaterina i s-au arătat în liniștea nopții, mângâindu-o cu cuvinte bune. Și când episcopul Cauchon a întrebat-o pe Ioana ce i-au spus:  
„M-au trezit”, a răspuns ea, „mi-am încrucișat mâinile și i-am rugat să-mi dea un sfat; mi-au zis: „Întreabă-l pe Domnul nostru”.  
„Și ce au mai spus?”  
„Să vă răspund cu îndrăzneală.”  
Și în timp ce episcopul o apăsa cu întrebări:  
„Nu pot să spun totul; mi-e mai frică să spun ceva care îi nemulțumește pe Sfinți decât să nu vă răspund.”
