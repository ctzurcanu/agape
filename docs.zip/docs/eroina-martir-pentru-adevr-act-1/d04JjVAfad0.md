---
id: d04JjVAfad0
title: "Scena 14"
sidebar_label: "Scena 14"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/d04JjVAfad0"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 14

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

În aceeași zi, când Ioana se odihnea, s-a trezit cu o tresărire.  
"Ah! Doamne, strigă ea, sângele poporului nostru este vărsat pe pământ!... E greșit! De ce nu m-am trezit? Iute, armele mele, calul meu!"  
Ajutată de femeile casei, s-a înarmat repede și, sărind în șa, a pornit în galop, cu stindardul în mână, alergând drept spre Poarta Bourgogne, atât de repede încât scântei au zburat de pe trotuar.
