---
id: plZIuxwYb-Y
title: "Scena 5"
sidebar_label: "Scena 5"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/plZIuxwYb-Y"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 5

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Dar de data aceasta a rămas în Vaucouleurs.  
Curând, singura tulburare din cetate a fost despre această tânără, care se plimba, spunând cu voce tare că va salva împărăția, că trebuie dusă la Delfin, că Dumnezeu asta vrea.  
„Voi merge”, a spus ea, „chiar dacă ar fi să îmi tocesc picioarele până la genunchi”.  
Oamenii, cu inimi simple, mișcați de credința ei, au crezut în ea. Un scutier, Jean de Metz, câștigat de mulțime, s-a oferit să o ducă la Chinon, unde se afla Carol al VII-lea. Bieții oameni, unindu-și sărăcia, au contribuit pentru a îmbrăca si înarma micuța țărancă. I-au cumpărat un cal și, în ziua stabilită, ea a pornit cu slaba ei escortă.  
"Mergi! Și întâmplă-se orice!” i-a strigat Baudricourt.  
"Fii binecuvântată!" au strigat săracii oameni, iar femeile au plâns când au văzut-o plecând.
