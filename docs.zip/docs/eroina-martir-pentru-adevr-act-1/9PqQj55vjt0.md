---
id: 9PqQj55vjt0
title: "Scena 31"
sidebar_label: "Scena 31"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/9PqQj55vjt0"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 31

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Pe 23 mai, pe când se afla în Crespy, a aflat că orașul Compiègne era aproape încercuit de englezi și de burgunzi.  
S-a dus acolo cu patru sute de luptători și a intrat în oraș pe 24, la răsărit. Apoi, luând cu ea o parte din garnizoană, i-a atacat pe burgunzi. Dar când englezii au venit să o atace, francezii s-au retras.  
„Nu va gândiți la nimic altceva decât cum să trageți în ei”, a strigat Ioana, „de voi depinde ca ei să se descurajeze!”  
Dar Ioana a fost târâtă de retragerea oștenilor ei. Aduși înapoi sub meterezele cetății Compiègne, francezii au găsit podul ridicat și grila coborâtă. Totuși, Ioana, forțată în șanț, s-a apărat în continuare.
