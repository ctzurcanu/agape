---
id: TmOHJEplR24
title: "Scena 19"
sidebar_label: "Scena 19"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/TmOHJEplR24"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 19

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Duminică, englezii s-au aliniat pentru luptă pe malul drept al Loarei. Ioana a interzis să fie atacați. Ea a ridicat un altar, iar liturghia a fost celebrată în prezența armatei adunate. Ceremonia fiind încheiată, ea le-a spus celor din jur:  
„Vedeți dacă englezii au fețele întoarse spre noi sau spatele!” Și când i s-a spus că se retrag în direcția Meung:  
„În numele lui Dumnezeu, dacă se duc, lăsați-i să plece; nu-i place Domnului Dumnezeu să luptăm cu ei astăzi, îi veți bate altă dată.”  
Orléans, asediat timp de opt luni, a fost eliberat în patru zile.
