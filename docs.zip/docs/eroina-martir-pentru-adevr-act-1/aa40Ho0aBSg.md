---
id: aa40Ho0aBSg
title: "Scena 21"
sidebar_label: "Scena 21"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/aa40Ho0aBSg"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 21

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Pe 11 iunie, francezii au ocupat suburbia Jargeau. A doua zi, la prima oră dimineață, Ioana a dat semnalul de luptă. Ducele de Alençon a vrut să amâne asaltul:  
"Înainte, bunule duce, la atac! Nu te îndoi, este ceasul plăcut lui Dumnezeu; lucrează și Dumnezeu va lucra."  
Ea însăși a urcat pe scară; a fost doborâtă de o piatră care a lovit-o în cap. Dar ea s-a ridicat, strigând poporului ei:  
"Prieteni, sus! Sus! Tatăl nostru i-a condamnat pe englezi; ei sunt ai noștri la ora asta; aveți curaj!"  
Meterezele au fost urcate. Englezii, urmăriți până la podul orașului, au fost prinși și uciși. Suffolk a fost luat prizonier.  
Pe 15, francezii au preluat controlul asupra podului Meung;  
pe 16, au asediat Beaugency;  
pe 17 orasul a capitulat.
