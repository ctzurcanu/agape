---
id: NlO5ARSgSWA
title: "Scena 12"
sidebar_label: "Scena 12"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/NlO5ARSgSWA"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 12

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Ea a cerut să fie dusă la o biserică, dorind mai presus de toate să-i mulțumească lui Dumnezeu.  
După cum i-a spus un bătrân lui Ioana, vorbind despre englezi:  
„Fiica mea, sunt puternici și bine întăriți și va fi un lucru grozav să-i înlături.”  
ea a răspuns: „Nu este nimic imposibil pentru puterea lui Dumnezeu”.  
Și, de fapt, încrederea ei a cucerit pe toți cei din jurul ei. Orleanienii, atât de înfricoșați și descurajați cu o zi înainte, acum fanatizați de prezența ei, au vrut să se arunce asupra inamicului și să-și înlăture bastioanele. Dunois, temându-se de eșec, a decis că vor aștepta sosirea restului armatei pentru a începe atacul. Între timp, Ioana i-a invitat pe englezi să se retragă și să se întoarcă în țara lor. Au răspuns cu insulte.
