---
id: RQkn6gM1-8k
title: "Scena 23"
sidebar_label: "Scena 23"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/RQkn6gM1-8k"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 23

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Englezii au pierdut patru mii de morți. Două sute de prizonieri au fost luați. Numai cei care puteau plăti o răscumpărare erau cruțați; ceilalţi au fost ucişi fără milă.  
Unul dintre ei a fost bătut atât de brutal în fața Ioanei, încât ea a sărit de pe cal să-l ajute. Ea a ridicat capul bietului om, i-a adus un preot, l-a consolat și l-a ajutat să moară.  
Inima ei era la fel de îndurerată pentru englezii răniți ca și pentru cei din neamul ei.  
În plus, ea a sfidat loviturile și a fost adesea rănită, dar nu a vrut niciodată să-și folosească sabia; stindardul ei era singura ei armă.
