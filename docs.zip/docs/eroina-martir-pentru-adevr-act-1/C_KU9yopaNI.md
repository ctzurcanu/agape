---
id: C_KU9yopaNI
title: "Scena 39"
sidebar_label: "Scena 39"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/C_KU9yopaNI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 39

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Cu toate acestea, procesul se mișca prea încet pentru englezi.  
„Judecători, voi nu vă câștigați banii!” strigau ei către membrii tribunalului.  
„Am venit la regele Franței”, a spus Ioana, „de la Dumnezeu, de la Fecioara Maria, sfinții și Biserica Biruitoare de sus; acelei Biserici mă supun pe mine, lucrările mele, ceea ce am făcut sau trebuie să fac. Ziceți că sunteți judecătorii mei, aveți grijă la ceea ce faceți, pentru că sunt trimisă de Dumnezeu și vă puneți sufletele în mare primejdie!”  
Sfânta eroină a fost condamnată, ca eretică, recidivistă, apostată și idolatrică, să fie arsă de vie in Piața Veche din Rouen.  
„Episcope, mor din cauza ta!” spuse ea adresându-se lui Cauchon.
