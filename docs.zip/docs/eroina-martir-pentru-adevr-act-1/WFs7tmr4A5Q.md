---
id: WFs7tmr4A5Q
title: "Scena 20"
sidebar_label: "Scena 20"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/WFs7tmr4A5Q"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 20

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Vestea eliberării Orléansului s-a răspândit în toată lumea, atestând divinitatea misiunii lui Ioana.  
Fata sfântă, evitând recunoașterea orleanilor, s-a întors în grabă la Chinon. Ea a vrut, profitând de entuziasmul suscitat în jurul ei, să plece imediat la Reims, luându-l cu ea pe Delfin pentru a-l încorona. Charles a primit-o cu mari onoruri, dar a refuzat să o urmeze. A acceptat devotamentul acestei fete eroice, dar a înțeles că eforturile ei generoase nu vor tulbura în niciun fel inerția lașă a vieții lui luxoase.  
S-a hotărât ca Ioana să atace locurile pe care englezii le mai dețineau pe malurile Loarei.
