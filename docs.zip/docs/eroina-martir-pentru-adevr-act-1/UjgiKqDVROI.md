---
id: UjgiKqDVROI
title: "Scena 30"
sidebar_label: "Scena 30"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/UjgiKqDVROI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 30

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Dar Ioana nu se putea resemna cu inacțiunea pe care doreau să i-o impună. Abandonată, fără ajutor în timpul asediului La Charité, ea a înțeles că acum nu mai avea nici o speranță de ajutor din partea lui Carol al VII-lea. La sfârșitul lunii martie (1430), fără să acordul regelui, ea a plecat să se alăture partizanilor francezi care se luptau împotriva englezilor la Lagny.  
Acum, în săptămâna Paștelui, pe când tocmai auzise slujba și se împărtășise în biserica Saint-Jacques de Compiègne, ea s-a retras lângă un stâlp al bisericii și a început să plângă. Oamenii și copiii o înconjurau - ea le-a spus:  
„Copiii mei și dragii mei prieteni, vă spun că am fost vândută și trădată și că în curând voi fi dată morții. Vă rog să vă rugați pentru mine, pentru că nu voi mai avea puterea de a fi de folos pentru Regele și Regatul Franței”.
