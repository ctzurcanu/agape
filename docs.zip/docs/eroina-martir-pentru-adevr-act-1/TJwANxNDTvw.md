---
id: TJwANxNDTvw
title: "Scena 8"
sidebar_label: "Scena 8"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/TJwANxNDTvw"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 8

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Timp de trei săptămâni a fost torturată cu întrebări insidioase.  
„Este mai mult în cartea lui Dumnezeu decât în ​​a voastră”, a răspuns ea; „Nu cunosc nici A, nici B, dar vin de la Regele Cerurilor.”  
Întrucât i s-a obiectat că Dumnezeu, pentru a elibera Franța, nu are nevoie de oameni înarmați, ea s-a ridicat deodată:  
„Oamenii vor lupta, Dumnezeu va da victoria.”  
Acolo, ca la Vaucouleurs, oamenii s-au declarat în favoarea ei, au considerat-o sfântă și inspirată. Doctorii bisericii și cei puternici au fost nevoiți să cedeze entuziasmului mulțimii.
