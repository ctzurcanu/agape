---
id: M9dVuPUXu5Y
title: "Scena 16"
sidebar_label: "Scena 16"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/M9dVuPUXu5Y"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 16

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Ioana s-a întors învingătoare la Orléans. Dar pe când, în bucuria succesului ei, s-a întors spre cetate, trecând câmpul de luptă, și-a simțit inima topindu-se de durere la vederea răniților și a celor uciși și a început să plângă, crezând că au murit fără mărturisire. Și ea a spus „că nu mai văzuse niciodată sângele Franței vărsat înainte. I s-a ridicat părul pe cap.”
