---
id: Wv0DWmhWL6I
title: "Scena 9"
sidebar_label: "Scena 9"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Wv0DWmhWL6I"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 9

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Trupele s-au adunat la Blois. Ioana a sosit acolo, urmată de Ducele de Alençon, Mareșalul de Boussac, Lordul de Rais, La Hire și Xaintrailles.  
Pe steagul ei avea brodate chipul lui Dumnezeu și numele lui Isus și Maria. Ea și-a sfătuit soldații să-și împace conștiința și să se spovedească înainte de a ieși la luptă. Joi, 28 aprilie, armata mică a pornit. Ioana a condus drumul, cu stindardul ei în vânt, pe cântecul „Veni, Creator”.  
Voia să meargă drept spre Orléans; conducătorii au considerat că este mai prudent să treacă pe malul stâng al Loarei.
