---
id: hKjkHmiXyms
title: "Scena 37"
sidebar_label: "Scena 37"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/hKjkHmiXyms"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 37

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Într-o zi, Stafford și Warwick au venit să o vadă cu Ioan de Luxembourg. Și în timp ce el, batjocoritor, îi spunea că vine s-o răscumpere dacă promite să nu se mai înarmeze împotriva Angliei:  
„În numele lui Dumnezeu”, a răspuns ea, „nu râde de mine, căci știu foarte bine că nu ai nici voință, nici putere; Știu foarte bine că englezii mă vor omorî, crezând, după moartea mea, că vor câștiga regatul Franței; dar chiar dacă ar mai fi o sută de mii, nu ar cuceri împărăția”.  
Furios, contele de Stafford s-a aruncat asupra ei.  
Ar fi ucis-o fără intervenția asistenților.
