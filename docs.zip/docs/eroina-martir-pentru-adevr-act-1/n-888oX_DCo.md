---
id: n-888oX_DCo
title: "Scena 18"
sidebar_label: "Scena 18"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/n-888oX_DCo"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 18

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

A doua zi, 6 mai, au capturat bastilia augustiniană. Sâmbătă 7, dis-de-dimineață, a început atacul asupra bastiliei Tournelles. Ioana, coborâtă în șanț, ridica o scară pe parapet, când o săgeată de arbaletă a străpuns-o chiar între gât și umăr. Ea a smuls fierul din rană; i s-a oferit apoi să farmece rana, ea a refuzat, spunând „că preferă să moară decât să facă orice este împotriva voinței lui Dumnezeu”. S-a mărturisit și s-a rugat mult timp în timp ce trupele ei se odihneau. Apoi, dând ordin de reluare a asaltului, ea s-a aruncat în focul luptei, strigând atacatorilor:  
„Bastionul este al tău, intră!”  
Bastionul a fost cucerit și toți apărătorii au pierit. Pe malul stâng al Loarei nu a mai rămas nici un englez.
