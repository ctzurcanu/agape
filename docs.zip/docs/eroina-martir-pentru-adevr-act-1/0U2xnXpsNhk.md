---
id: 0U2xnXpsNhk
title: "Scena 7"
sidebar_label: "Scena 7"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/0U2xnXpsNhk"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 7

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

În acel moment, din Orléans au sosit vești atât de tulburătoare, încât susținătorii Ioanei au reușit să se asigure că această șansă ultimă de salvare nu rămâne exclusă. Seara, la lumina a cincizeci de torțe, în sala mare a castelului, unde se înghesuiau toți domnii curții, a fost prezentată Ioana. Nu-l văzuse niciodată pe Rege. Carol al VII-lea, pentru a nu-i atrage atenția, a purtat un costum mai puțin luxos decât cel al curtenilor săi. La prima vedere, ea l-a distins printre toți și, îngenunchiind în fața lui:  
„Dumnezeu să te binecuvânteze, bunule Delfin!” spuse ea  
„Eu nu sunt Regele”, a răspuns el, „acesta este Regele”. Și i-a desemnat un alt domn.  
„Tu ești, bunule prinț, și nimeni altul; Regele Cerurilor îți trimite cuvântul prin mine că vei fi încoronat”.  
Și apropiindu-se de obiectul misiunii ei, ea i-a spus că Dumnezeu a trimis-o să îl ajute; ea a cerut să-i dea o armată, promițându-i că va ridica asediul Orléansului și că îl va duce la Reims.  
Delfinul a rămas ezitant. Fata asta ar putea fi o vrăjitoare. A trimis-o la Poitiers pentru a se supune examenului doctorilor și eclesiasticilor.
