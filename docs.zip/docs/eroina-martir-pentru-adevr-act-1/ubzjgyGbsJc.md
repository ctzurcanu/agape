---
id: ubzjgyGbsJc
title: "Scena 35"
sidebar_label: "Scena 35"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/ubzjgyGbsJc"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 35

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Închisă în închisoarea castelului Rouen, a fost păzită zi și noapte de soldați, de la care a trebuit să îndure insulte și chiar brutalitate, lanțurile ei nepermițându-i să se apere.  
Între timp, un tribunal, la discreția englezilor și prezidat de Cauchon, episcopul de Beauvais, investiga procesul ei. La întrebările insidioase ale judecătorilor ei, săraca și sfânta fată, fără sprijin și fără avocat, nu putea să se apere decât conform dreptății și simplității inimii ei și purității intențiilor ei.  
„Vin de la Dumnezeu”, a spus ea; „Nu sunt de folos aici; trimite-ți-mă înapoi la Dumnezeu de la care am venit”.
