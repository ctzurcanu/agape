---
id: ooQKD5qQNmI
title: "Scena 32"
sidebar_label: "Scena 32"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/ooQKD5qQNmI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 32

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

O trupă o atacase.  
"Predă-te singură!" i-au strigat ei. „Am jurat și mi-am jurat credința altcuiva decât vouă”, a răspuns fata curajoasă, „și îmi voi ține jurământul!”  
Dar degeaba a rezistat. Trasă de hainele ei lungi, a fost doborâtă de pe cal și luată. Din vârful meterezelor orașului, Lordul Flavy, guvernatorul Compiègne, a asistat la capturarea sa. Nu a făcut nimic pentru a o ajuta.
