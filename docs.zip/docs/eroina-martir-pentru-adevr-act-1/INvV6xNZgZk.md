---
id: INvV6xNZgZk
title: "Scena 24"
sidebar_label: "Scena 24"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/INvV6xNZgZk"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 24

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Soldații, englezi și burgunzi, care formau garnizoana în Troyes au putut părăsi orașul cu tot ce aveau. Ceea ce aveau erau în principal prizonieri, francezi. La întocmirea capitulării nu se stipulase nimic în favoarea acestor nefericiţi. Dar când englezii au părăsit orașul cu prizonierii lor legati de gat, Ioana s-a aruncat in drum.  
„În numele lui Dumnezeu, nu îi vei lua!” a strigat ea.  
Ea a cerut ca prizonierii să-i fie predați și ca răscumpărarea lor să fie plătită de Rege.
