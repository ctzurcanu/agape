---
id: jahHrA32bo8
title: "Scena 28"
sidebar_label: "Scena 28"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/jahHrA32bo8"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 28

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

După încoronarea din Reims, Ioana a vrut să se îndrepte puternic spre Paris și să recupereze capitala regatului. Nehotărârea regelui a dat timp englezilor să-și facă pregătirile de apărare. Asaltul a fost respins; Ioana a fost rănită de o arbaletă la coapsă.  
A trebuit să fie luată cu forța de la poalele meterezelor pentru a o obliga să oprească lupta. A doua zi, Regele s-a opus reluării atacului; Ioana, însă, a fost responsabilă pentru lipsa succesului.  
De prea mult timp Charles fusese târât pe drumuri; era nerăbdător să-și reia viața indolentă în castelele sale din Touraine.
