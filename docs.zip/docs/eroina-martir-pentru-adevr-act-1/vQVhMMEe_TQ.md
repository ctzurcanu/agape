---
id: vQVhMMEe_TQ
title: "Scena 17"
sidebar_label: "Scena 17"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/vQVhMMEe_TQ"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 17

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Totuși, era necesară o decizie despre cum va fi continuat acest atac care a început atât de fericit împotriva englezilor.  
Șefii, nedorind să se lase conduși de o fată de la țară sau să împartă cu ea gloria succesului, s-au întâlnit în secret pentru a discuta planul de adoptat.  
Ioana s-a prezentat la consiliu; iar cancelarul ducelui de Orléans a căutat să-i ascundă deciziile care fuseseră luate:  
„Spuneți care este decizia și ce ați vorbit”, strigă ea, indignată de aceste subterfugii; „Eu pot ascunde ceva mai măreț!” ea a adăugat:  
„Voi ai fost în sfatul vostru, iar eu am fost în al meu, și cred că sfatul lui Dumnezeu se va împlini și va rămâne ferm și al vostru va pieri. Treziți-vă devreme mâine dimineață, căci vom avea multe de făcut, mai mult decât am avut vreodată”.
