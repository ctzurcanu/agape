---
id: DhEui7HODvQ
title: "Scena 1"
sidebar_label: "Scena 1"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/DhEui7HODvQ"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 1

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Ioana s-a născut la 6 ianuarie 1412, în Domrémy, un mic sat din Lorena, dependent de județul Chaumont, sub coroana Franței.  
Numele tatălui ei era Jacques d'Arc, iar mama ei era Isabelle Romée; erau oameni cinstiți, simpli muncitori care trăiau din munca lor.  
Ioana a fost crescută împreună cu frații ei și cu sora ei într-o căsuță care încă mai poate fi văzută în Domrémy, atât de aproape de biserică încât grădina ei are gard cu cimitirul.  
Copilul crește acolo sub ochii lui Dumnezeu.  
Era dulce, simplă și dreaptă. Toți o iubeau pentru că știau că este caritabilă și cea mai bună fată din satul ei. Harnică la muncă, își ajuta familia în sarcinile lor, în timpul zilei conducând animalele la pășune, sau participând la munca grea a tatălui ei, seara petrecând timp cu mama ei și asistând-o în îngrijirea gospodăriei.  
Ea Îl iubea pe Dumnezeu și se ruga lui des.
