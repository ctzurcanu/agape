---
id: JqnYtF6h6zY
title: "Scena 13"
sidebar_label: "Scena 13"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/JqnYtF6h6zY"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scena 13

Eroina Martiră pentru Adevăr. Act 1   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38Mc0XPvHtuN-fwsZhukWGOSQ 

Cu toate acestea, nu au primit nicio veste de la Blois. Dunois, îngrijorat, a plecat pentru a grăbi sosirea ajutorului. Era timpul. Arhiepiscopul de Reims, Regnault de Chartres, cancelarul regelui, reconsiderând deciziile luate, urma să trimită trupele înapoi în garnizoanele lor. Dunois a reușit să-i ducă la Orléans.  
Miercuri, 4 mai, dimineața, Ioana, înconjurată de tot clerul orașului și urmată de o mare parte a populației, a părăsit Orléans; printre bastioanele engleze, ea a înaintat într-un mare cortegiu pentru a întâlni mica armată a lui Dunois, care a trecut sub protecția preoților și a unei fete, fără ca englezii să îndrăznească să o atace.
