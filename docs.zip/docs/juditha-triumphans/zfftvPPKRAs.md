---
id: zfftvPPKRAs
title: "Juditha triumphans 3"
sidebar_label: "Juditha triumphans 3"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/zfftvPPKRAs"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Juditha triumphans 3

Lyrics: Iacopo Cassetti, 1716

[HOLOFERNES]  
Felix per te,  
magisque felix ero,  
si dum sepulta manet  
lux Apollinis unda,  
me te dignum  
in convivio tu reddas,  
ut melius pacis nostræ amatæ, et caræ,  
solemnia tecum possim celebrare.

[JUDITHA]  
Inter convivia, et dapes  
torpescent labia mea  
in jeiunio assueta:  
tristis, nec unquam læta  
in eduliis astricta  
nescia est delitiæ tantæ anima afflicta.

Agitata infido flatu  
diu volatu  
vagabundo  
mæsta hirundo  
it plorando  
boni ignara.

Sed impulsu auræ serenæ  
tantæ cito oblita pœnæ  
in dilecta  
dulcia tecta  
gaudii ridet haud avara.

[HOLOFERNES]  
In tentorio supernæ  
sint in ordine cœnæ.  
Quid, quid natat in Ponto,  
quid, quid in cælo,  
et terra nutrit  
ne sit legere grave.  
Hinc nostræ Reginæ,  
cui Vagæ, tu deservies,  
sit cretensis Lyei donum suave.

[VAGAUS]  
O servi volate,  
et Domino meo  
vos mensas parate  
si proxima nox.  
Invicto Holoferni  
cantemus alterni,  
honoris, amoris  
sit consona nox.

[CHORUS]  
Honoris, amoris,  
sit consona vox.

[VAGAUS]  
Tu quoque hebraica ancilla  
in nostro gaudio tanto  
eris in corde tuo læta, et tranquilla.

[ABRA]  
Quam audacter discurrit  
non minus servus suo Domino nequam.  
Properemus Juditha: ubique semper  
tecum sperans in cælis  
ero Dominæ meæ socia fidelis.

[JUDITHA]  
Veni, veni, me sequere fida  
Abra amata,  
sponso orbata.  
Turtur gemo ac spiro in te.  
Diræ sortis tu socia confida  
debellata  
sorte ingrata,  
sociam lætæ habebis me.

[ABRA]  
Venio Juditha, venio: animo fave,  
amori crede tuo nil erit grave.

Fulgeat sol frontis decoræ,  
et afflictæ abeat Auroræ  
rosa vaga tua pupilla.  
Ama, langue, finge ardere  
nostræ sorti si favore  
potest una tua favilla.  
In Urbe interim pia  
incertas audi voces, aura levis  
fert murmur voti  
et gloriæ, credo, tuæ.  
Gemunt et orant una  
virgines Juda, incertæ sortis suæ.

[CHORUS virginum psalentium in Bethulia]

Mundi Rector de cælo micanti  
audi preces, et suscipe vota  
quæ de corde pro te dimicanti  
sunt pietatis in sinu devota.  
In Juditha tuæ legi dicata  
flammas dulcis tui amoris accende  
feritatis sic hostis domata  
in Bethuliæ spem pacis intende.  
Redi, redi iam Victrix pugnando  
in cilicio in prece revive  
de Holoferne sic hodie triumphando  
pia Juditha per sæcula vive.

Mundi Rector de cælo micanti  
audi preces, et suscipe vota  
quæ de corde pro te dimicanti  
sunt pietatis in sinu devota.  
In Juditha tuæ legi dicata  
flammas dulcis tui amoris accende  
feritatis sic hostis domata  
in Bethuliæ spem pacis intende.  
Redi, redi iam Victrix pugnando  
in cilicio in prece revive  
de Holoferne sic hodie triumphando  
pia Juditha per sæcula vive.
