---
id: -tcqNPBjMjs
title: "Juditha triumphans 2"
sidebar_label: "Juditha triumphans 2"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/-tcqNPBjMjs"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Juditha triumphans 2

Lyrics: Iacopo Cassetti, 1716

[VAGAUS et CHORUS]  
O quam vaga, venusta, o quam decora,  
ospes nostræ victoriæ unica, et vera.

Tentoria vultu tuo ducis honora  
et cuncta ab Holoferne attende, et spera.

[VAGAUS]  
Quem vides prope, aspectu  
terribili, et suavi,  
quem quæris, ipse hic est: amore, et fide,  
in ipso pulchra Sion spera, et confide.

Quamvis ferro, et ense gravis  
dulcis tamen et suavis  
pro te Dux erit, o bella.

Tibi tua tu sors et fatum,  
nec per te fremit iratum,  
tua pupilla fit tua stella.

[HOLOFERNES]  
Quid cerno! Oculi mei  
stupidi quid videtis!  
solis, an cæli splendor!  
ah summæ prolis  
vincunt lumina sua lumina solis.

Sistite, viatrici!  
preparate trophea, spargite flores,  
et obvient Divæ suæ teneri Amores.

[JUDITHA]  
Summe Rex, strenue miles,  
nabuc Regis cor, cuius in manu  
stat suprema potestas, nutui cuius  
fortuna, et sors obedit,  
et cuncta iura sua gloria concedit.

[HOLOFERNES]  
O quam pulchrior in pulchro  
virtus est ore sonans! Quidnam petis,  
suavissima supplex?

[JUDITHA]  
Non mihi, patriæ meæ  
spem salutis exoro,  
et sic Bethuliæ a te pacem imploro.  
Quanto magis generosa,  
plus victori gloriosa  
venia victo magis cara.  
O quam pulchra tua potentia  
illustrata tua clementia!  
parce Dux, ac tolle amara.

[HOLOFERNES]  
Magna, o fœmina petis,  
quæ maxima, si dentur!  
majora sed a me tibi debentur.  
O timpana silete,  
recedite o Phalanges,  
cedite amori meo, cedite invictæ  
faces, tela, sagittæ,  
et vos bellica in campo impia tormenta  
estote in gaudio meo nova contenta.  
Hic sede amica mea.

Sic jubeo, et volo.

Sede, o cara,  
dilecta speciosa  
mea vivida rosa,  
mea fulgida fax.  
Tu Marti triumphanti,  
tu bellico amanti  
pulcherrima Pax.

[JUDITHA]  
Tu Judex es, tu Dominus, tu potens  
in exercitu tanto, et tuæ dextræ victrici  
semper aspectu sint astra felici.
