---
id: v0eT-Zdqd_k
title: "Juditha triumphans 1"
sidebar_label: "Juditha triumphans 1"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/v0eT-Zdqd_k"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Juditha triumphans 1

Lyrics: Iacopo Cassetti, 1716

Arma, cædes, vindictæ, furores,  
angustiæ, timores  
precedite nos.  
Rotate,  
pugnate  
O bellicæ sortes,  
mille plagas,  
mille mortes  
adducite vos.

Felix et fausta dies  
o magnanimi eroes et fortunati:  
prospera vobis sors, sydera, cælum:  
et post sæcula tandem  
venit optata lux, lux suspirata,  
qua magni in vestro Duce,  
qua Dux Magnus in vobis:  
cunctis æqua  
erit tandem Victoria,  
et vestro invicto Regi  
honor, et gloria.  
Nil arma, nil bella,  
nil fiamma furoris  
si cor bellatoris  
est cadens in se.  
Si pugnat sperando,  
iam virtus pugnando  
vigescit in spe.

[ABRA]  
Matrona inimica  
te quærit ad arma  
dux magne Holofernes.  
Et cito deh, credas,  
tibi erit amica  
si lumina cernes.

Huc accedat Matrona,  
et sit armorum Marti ebrea Bellona.  
In Bethulia vilescunt  
hostes miseri geni: undique luctus  
sævus undique clamor.  
Hic anhelat,  
hic gemit, ille plorat,  
dolent omnes;  
nil nisi timor, nil nisi mærentium  
ignavia, desperatio, afflictio, inopia,  
et lacrimarum copia.

[ABRA]  
Veni fœmina illustris,  
pulchra bellatrix huc,  
lumine, et pede  
videntes feri,  
et generosa accede.

[JUDITHA]  
Quocum patriæ me ducit amore  
libertatis dulcissima spes,  
summo ductus a cæli fulgore  
tuto pergat per classica pes.

[ABRA]  
Ne timeas non, lætare  
casta Vidua dilecta  
certa virtutis tuæ munera expecta.

Vultus tui vago splendori  
cedit ira ridet amor.  
Ac tui numinis honori  
lætus plaudit omnium clamor;  
vide, humilis prostrata  
in vultus tui nitore,  
quam estatica sit gens tanta armata.

[JUDITHA]  
Nil moræ. Ad Holofernem  
me ducite benigni  
duces bellici honoris,  
pacis en nuntia venio, et non furoris.
