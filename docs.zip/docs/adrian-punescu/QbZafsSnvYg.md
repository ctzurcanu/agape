---
id: QbZafsSnvYg
title: "Dacii liberi v2 - Free Dacians v2"
sidebar_label: "Dacii liberi v2 - Free Dacians v2"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/QbZafsSnvYg"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Dacii liberi v2 - Free Dacians v2

Lyrics: Adrian Păunescu

N-avem cui să-i cerem voie să cântăm pe dacii liberi,  
Nu există comitete cu caracter mondial,  
Ca să aibă-n atribuții a cânta pe dacii liberi,  
Noi din noi și-a noastră fire îi cântăm pe dacii liberi,  
Nu dăm nimănui plocoane să ni-l dea pe Decebal.

Mulți și-au luat obrăznicia de-a jigni pe dacii liberi,  
Mulți și-au luat încredințarea cum că dacii nu mai sunt,  
Dar din haos până-n haos, căutați pe dacii liberi,  
Ei sunt neamul ce nu moare, sunt o țară — dacii liberi,  
Ei au cerul dacă alții le luară din pământ.

Niciodată dacii liberi, niciodată dacii liberi  
Nu vor suporta, pe umeri, lanț și laț și epoleți,  
Nimenea să nu-și permită vreun joc de-a dacii liberi,  
Nici nu vând, nici nu trădează, niciodată dacii liberi,  
Dacă nu-i simțiți înseamnă că ei sunt, voi nu sunteți.

Dacă viața vă întreabă, întrebați pe dacii liberi,  
Căutați-i jos, în sânge, și-n ulcele și în grai,  
Osul vostru blând sticlește, că e os din dacii liberi,  
Glasul vostru e un cântec repetat de dacii liberi,  
Dacii liberi dorm sub verbe, dacii liberi dorm sub plai.

Nu vom cere la UNESCO voie pentru dacii liberi,  
Nu ne vom iubi părinții când vor marile puteri,  
Unde-a fost Burebista nu muriră dacii liberi,  
Când le schimbă alfabetul, ei rămân tot dacii liberi,  
Ce e azi nu va fi mâine, mâine e mai mult ca ieri.

Și Ardealul și Banatul pline sunt de dacii liberi,  
Nu sunt păci s-arunce Țara în comerțul mondial,  
Dobrogea e , toată, vie până-n țărm de dacii liberi,  
Maramureșul, Moldova ard secret de dacii liberi,  
Curge-n Prut și curge-n Tisa sângele lui Decebal.

Au tăcut două milenii blânzii oameni, dacii liberi,  
Au tăcut în așteptare, în speranță și în mit,  
Fii ai lor, luați aminte, sunteți neam din dacii liberi,  
Ave, Dacie ferice, și trăiască dacii liberi!  
Ține minte, Europă, dacii liberi n-au murit.

Ei aruncă grâul țării de din brazdă, dacii liberi,  
Ei la graniță veghează fără liniște și somn,  
Ei l-au susținut pe Mircea și pe Ștefan, dacii liberi,  
Pe Mihai, pe-Avram, pe Tudor, pe Bălcescu, dacii liberi  
Dacii liberi poartă sceptrul și sunt gardă pentru domn.

Vin în noi cum vine noaptea peste ziuă, dacii liberi,  
Îi putem citi de-a-ntregul în legende și-n urmași,  
Ca un fenomen al lumii și-al naturii, dacii liberi,  
Interziși din vreme-n vreme, vin mai tare, dacii liberi,  
Nu au teamă de invazii și-și bat joc de uriași.

Fibra noastră e-ncărcată, ca un pod, de dacii liberi,  
Trebuie să-i trecem veacul cum și ei ne-au dus pe noi,  
S-arătăm viitorimii ce înseamnă dacii liberi,  
S-arătăm că suntem fiii care-și poartă dacii liberi,  
Ca să-i dăm eternității pe de-a-ntregul înapoi.

Ca să-i dăm eternității   
pe de-a-ntregul   
înapoi...

English:

We have no one to ask permission to sing about the free Dacians,  
There are no committees with a global character,  
To have the task of singing about the free Dacians,  
We, from ourselves and our nature, sing about the free Dacians,  
We don't give anyone the chance to give us Decebal.

Many have had the audacity to insult the free Dacians,  
Many have taken it upon themselves to believe that the Dacians are no more,  
But from chaos to chaos, look for the free Dacians,  
They are the nation that does not die, they are a country — the free Dacians,  
They have the sky if others took them from the earth.

Never free Dacians, never free Dacians  
They will not bear, on their shoulders, chain and noose and epaulettes,  
Let no one allow themselves any game of being free Dacians,  
Neither sell, nor betray, never free Dacians,  
If you don't feel them, it means that they are, you are not.

If life asks you, ask the free Dacians,  
Search for them below, in the blood, and in the jugs and in the language,  
Your soft bone crystallizes, because it is bone of free Dacians,  
Your voice is a repeated song of free Dacians,  
Free Dacians sleep under verbs, free Dacians sleep under the sheets.

We will not ask UNESCO for permission for the free Dacians,  
We will not love our parents when the great powers want,  
Where Burebista was, the free Dacians did not die,  
When they change their alphabet, they remain free Dacians,  
What is today will not be tomorrow, tomorrow is more than yesterday.

And Transylvania and Banat are full of free Dacians,  
There is no peace to throw the country into world trade,  
Dobrogea is, all of it, alive to the shore with free Dacians,  
Maramureș, Moldova are secretly burning with free Dacians,  
The blood of Decebal flows in the Prut and flows in the Tisa.

The gentle people, the free Dacians, have been silent for two millennia,  
They have been silent in expectation, in hope and in myth,  
Their sons, take note, you are a nation of free Dacians,  
Hail, happy Dacia, and long live the free Dacians!  
Remember, Europe, the free Dacians did not die.

They throw the country's wheat from the furrow, the free Dacians,  
They keep watch at the border without peace or sleep,  
They supported Mircea and Ștefan, the free Dacians,  
Mihai, Avram, Tudor, Bălcescu, the free Dacians  
The free Dacians carry the scepter and are the guard for the lord.
