---
id: 8-3XnTU66mQ
title: "Dacii liberi - The Free Dacians"
sidebar_label: "Dacii liberi - The Free Dacians"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/8-3XnTU66mQ"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Dacii liberi - The Free Dacians

Lyrics: Adrian Păunescu

Noi n-am avut nevoie  
Să luăm adeverințe  
Că vieţuim acasă,  
În patrie la noi,  
Am fost și vom rămâne  
De-a pururi dacii liberi  
Și iubitori de pace,  
Și vrednici de război.

La Sarmisegetuza,  
La focuri, cu Zamolxe,  
Şi stelele din ceruri  
Din sânge ni se rup.  
Nu ne-au învins Romanii  
Şi-am râs de toţi barbarii  
Strigând la ei cu steagul  
Făcut din cap de lup.

Aceasta dăm de ştire,  
De sub pământul nostru,  
Urmaşilor în care  
Reinviem acum.  
Femeile iubindu-şi  
Să nască dacii liberi  
Spre răzbunarea noastră  
Pe cel din urmă drum.

Numiţi şi ţara noastră  
Cu numele ei dacic,  
Iubiţi pe nou veniţii  
După atâţia ani,  
Dar veşnic ţineţi minte  
Că peste dacii liberi  
Au tot călcat invazii  
Şi altfel de romani.

Noi am rămas în glie  
Şi devenim pădure,  
Şi devenim recolte,  
Să vă hrănim pe voi,  
Şi temelia ţării  
S-o întărim cu oase,  
Şi iubitori de pace,  
Şi vrednici de război.

Cu tot ce năzăreşte  
Din firea noastră veche,  
Dăm Romelor de ştire,  
Prin ierburi murmurând,  
Că numai oboseala  
Ne-a aşezat sub scoarţă,  
Dar dacă e nevoie  
Ne vom scula oricând.

Dar dacă e nevoie  
Ne vom scula oricând!

English:

We didn't need  
To get certificates  
That we live at home,  
In our homeland,  
We were and will remain  
Forever free Dacians  
And lovers of peace,  
And worthy of war.

At Sarmisegetuza,  
At the fires, with Zamolxe,  
And the stars in the sky  
They break from our blood.  
The Romans did not defeat us  
And we laughed at all the barbarians  
Shouting at them with the flag  
Made of a wolf's head.

This we give news,  
From under our land,  
To the descendants in whom  
We are now resurrected.  
Women loving each other  
Let free Dacians give birth  
To our revenge  
On the last road.

Call our country  
By its Dacian name,  
Love the newcomers  
After so many years,  
But always remember  
That the free Dacians  
Have been trampled by invasions  
And by other Romans.

We stayed in the forest  
And we become a forest,  
And we become crops,  
To feed you,  
And the foundation of the country  
To strengthen it with bones,  
And lovers of peace,  
And worthy of war.

With everything that can be seen  
Of our old nature,  
We give the Romans news,  
Through the murmuring herbs,  
That only fatigue  
Has placed us under the bark,  
But if necessary  
We will rise at any time.

But if necessary  
We will rise at any time!
