---
id: JY7Kcj6AvD4
title: "Nebun de Alb - White Bishop"
sidebar_label: "Nebun de Alb - White Bishop"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/JY7Kcj6AvD4"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Nebun de Alb - White Bishop

Lyrics: Adrian Păunescu

Acum sunt mai pustiu ca totdeauna  
De când mă simt tot mai bogat de tine  
Şi-mi stau pe tâmple soarele şi luna,  
Acum mi-e cel mai rău şi cel mai bine.

M-aş jelui în fel de fel de jalbe  
În care nici n-aş spune cum te cheamă,  
Pătrate negre şi pătrate albe  
Îmi covârşesc grădina şi mi-e teamă.

Şi uite n-are cine să ne-ajute  
Abia-şi mai ţine lumea ale sale  
Şi-ntr-un perete alb de muze mute  
Nebunii negri caută o cale.

Şi te iubesc cu milă şi cu groază  
Tot ce-i al tău mi se cuvine mie,  
Ca un nebun de alb ce capturează  
Regina neagră pentru-o veşnicie.

Prin gări descreierate accidente,  
Mărfare triste vin în miezul verii,  
Iar eu sunt plin de gesturi imprudente  
Ca să te apropii şi ca să te sperii.

Jur împrejur privelişti aberante:  
Copii fragili ducând părinţi în spate,  
Bătrâni cu sănii gri de os pe pante  
Şi albatroşi venind spre zări uscate.

Mi-e dor de tine şi îţi caut chipul  
În fiecare margine a firii,  
În podul palmei dacă iau nisipul  
Simt un inel jucându-se de-a mirii.

I-aud prin bătălii din vreme-n vreme,  
Ostaşii gărzii tale ţi se-nchină,  
Iubita mea cu foarte mari probleme,  
Cu chip slavon şi nume de regină.

Şi te iubesc cu milă şi cu groază  
Tot ce-i al tău mi se cuvine mie,  
Ca un nebun de alb ce capturează  
Regina neagră pentru-o veşnicie.

Ca un nebun de alb ce capturează  
Regina neagră pentru-o veşnicie.

English:

I’ve never been so hollow ever  
Since you have gifted me  
On my temples, the sun and moon are seated  
It's the downfall and the prime of our time

And look, there's no one there to help us  
The world is barely thriving  
And in a white wall of mute muses  
Black bishops are searching for a path to leave

And I love you with empathy and dismay  
All that's yours has an affinity with me  
Like a white bishop that takes away  
The black queen for eternity

In a railroad station, colliding, mindless  
Sad freight trains bust in the middle of Summer  
I'm full of unwise gestures  
To bring you closer and to chase you away in fear.

Around me nothing more but futile perspectives  
Fragile infants hauling heavy parents  
Elders with grey bone sleights on slopes  
And albatrosses coming towards dry horizons

And I love you with empathy and dismay  
All that's yours has an affinity with me  
Like a white bishop that takes away  
The black queen for eternity

I miss you and I’m looking for your semblance  
Amid the limits of my selfdom  
If I take a pinch of sand into my hands  
I feel a ring playing bride-and-groom

I hear you in random battles  
The soldiers of your guard will bow before you  
Beloved.. but with quite a deal of issues,  
Slavonic face and name of a Queen, though……

And I love you with empathy and dismay  
All that's yours has an affinity with me  
Like a white bishop that takes away  
The black queen for eternity

Like a white bishop that takes away  
The black queen for eternity
