---
id: UVdnp93UL6k
title: "Bieți Lampagii - Poor lamplighters"
sidebar_label: "Bieți Lampagii - Poor lamplighters"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/UVdnp93UL6k"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Bieți Lampagii - Poor lamplighters

Lyrics: Adrian Paunescu

Într-un veac cu noapte mare  
Noi aprindem felinare  
Ca să nu fiți triști.  
Ca să nu fiți triști.

Voi le stingeți către ziuă,  
Iar noi ne luăm adio,  
Sărmani artiști.  
Sărmani artiști.

Bieți lampagii, prin veacul greu  
Oriunde-am fi, lucrăm din greu  
Dăm foc, dăm foc, felinarelor.  
Dăm foc, dăm foc, felinarelor.

  
Vine noaptea următoare,  
Noi aprindem felinare  
Spre a fi frumos.  
Spre a fi frumos.

Voi le stingeți dușmănește,  
Vouă noaptea vă priește,  
Vai, ce folos.  
Vai, ce folos.

Bieți lampagii, prin veacul greu  
Oriunde-am fi, lucrăm din greu  
Dăm foc, dăm foc, felinarelor.  
Dăm foc, dăm foc, felinarelor.

  
Cineva mereu ne ceartă  
Că urmăm această artă  
Fără de tumult.  
Fără de tumult.

Într-o noapte fără lună  
Vă vom spune „Noapte bună",  
Umiliți prea mult.  
Umiliți prea mult.

Bieți lampagii, prin veacul greu  
Oriunde-am fi, lucrăm din greu  
Dăm foc, dăm foc, felinarelor.  
Dăm foc, dăm foc, felinarelor.

  
Dar ni se va face milă,  
Vom da foc chiar la feștilă,  
Nu vom rezista.  
Nu vom rezista.

Căci flacăra alb-albastră  
Este meseria noastră,  
Ea și numai ea.  
Ea și numai ea.

Bieți lampagii, prin veacul greu  
Oriunde-am fi, lucrăm din greu  
Dăm foc, dăm foc, felinarelor.  
Dăm foc, dăm foc, felinarelor.

  
Contra nopții tutelare  
Noi aprindem felinare  
Până veți simți  
Până veți simți

Că în beznele profunde  
Azi lumina se ascunde  
În lampagii.  
În lampagii.

Bieți lampagii, prin veacul greu  
Oriunde-am fi, lucrăm din greu  
Dăm foc, dăm foc, felinarelor.  
Dăm foc, dăm foc, felinarelor.

English:

In an age of great night  
We light lanterns  
So that you won't be sad.  
So that you won't be sad.

You turn them off at daybreak,  
And we say goodbye,  
Poor artists.  
Poor artists.

Poor lamplighters, through the hard age  
Wherever we are, we work hard  
We light, we light, the lanterns.  
We light, we light, the lanterns.  
The next night comes,  
We light lanterns  
To be beautiful.  
To be beautiful.

You put them out in hostility,  
You night is yours,  
Alas, what use.  
Alas, what use.

Poor lamplighters, through the hard age  
Wherever we are, we work hard  
We light, we light, the lanterns.  
We light, we light, the lanterns.

Someone always scolds us  
That we follow this art  
Without a fuss.  
Without a fuss.

On a moonless night  
We will say "Good night",  
You humiliate too much.  
You humiliate too much.

Poor lamplighters, through the hard age  
Wherever we are, we work hard  
We light, we light, the lanterns.  
We light, we light, the lanterns.

But we will be pitied,  
We will light the very torch,  
We will not resist.  
We will not resist.

For the blue-white flame  
Is our job,  
It and only it.  
It and only it.

Poor lamplighters, through the hard age  
Wherever we are, we work hard  
We light, we light, the lanterns.  
We light, we light, the lanterns.

Against the tutelary night  
We light the lanterns  
Until you feel  
Until you feel  
That in the deep darkness  
Today the light hides  
In the lanterns.  
In the lanterns.

Poor lanterns, through the hard age  
Wherever we are, we work hard  
We light, we light, the lanterns.  
We light, we light, the lanterns.
