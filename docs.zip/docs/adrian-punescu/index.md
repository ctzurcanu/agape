---
id: PLrZFPVQM38Md-HgJtBRh7e5Holmi1d21E
title: "Adrian Păunescu"
sidebar_label: "Adrian Păunescu"
---

# Adrian Păunescu

This is the landing page for the playlist "Adrian Păunescu".

## Videos in this Playlist

- [Nebun de Alb - White Bishop](/agape/adrian-punescu/JY7Kcj6AvD4)
- [Marşul Ardealului - The Transylvanian Song](/agape/adrian-punescu/20dEpWunk6Y)
- [Actorul - The Actor](/agape/adrian-punescu/BpyxXSM9-g)
- [Colindul colindelor - The Carol of Carols](/agape/adrian-punescu/n1UdNovpOGU)
- [Charlie Chaplin](/agape/adrian-punescu/mP5E8pS7cac)
- [Bătrân Ceasornicar - Old Watchmaker](/agape/adrian-punescu/KVwYvB6FF4o)
- [Cu noi este Dumnezeu - With us is God](/agape/adrian-punescu/T49HlSGvzjw)
- [Dacii liberi - The Free Dacians](/agape/adrian-punescu/8-3XnTU66mQ)
- [Mama Tata - Mother Father](/agape/adrian-punescu/rQZe94kaQuk)
- [Impozite, Biruri şi Taxe - Taxes, Duties and Fees](/agape/adrian-punescu/TZ5du8sNUs0)
- [Dacii liberi v2 - Free Dacians v2](/agape/adrian-punescu/QbZafsSnvYg)
- [Bieți Lampagii - Poor lamplighters](/agape/adrian-punescu/UVdnp93UL6k)
- [Dor de Eminescu - Longing for Eminescu](/agape/adrian-punescu/nimgbtmg5nk)

