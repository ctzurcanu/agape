---
id: T49HlSGvzjw
title: "Cu noi este Dumnezeu - With us is God"
sidebar_label: "Cu noi este Dumnezeu - With us is God"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/T49HlSGvzjw"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Cu noi este Dumnezeu - With us is God

Lyrics: Adrian Păunescu

Azi lumina din lumină,  
Pământu-n trupuri ne e greu,  
Dar e ușor când se închină:  
Cu noi e Dumnezeu.

Am ostenit de-atâta noapte,  
Dar vom ieși din defileu  
Pentru lumina sfintei șoapte:  
Cu noi e Dumnezeu.

Nu suntem niște animale  
Cu suflet amânat mereu,  
În noi e milă și e jale  
Cu noi, cu noi e Dumnezeu.

Luați lumina din lumină,  
Paharuri curg din minereu,  
Credința noastră e creștină,  
Cu noi e Dumnezeu.

Cu noi, cu noi e Dumnezeu.

English:

Today the light from the light,  
The earth in our bodies is hard,  
But it is easy when they worship:  
With us is God.

We have been tired for so long a night,  
But we will come out of the gorge  
For the light of the holy whisper:  
With us is God.

We are not animals  
With souls always postponed,  
In us is pity and there is grief  
With us, with us is God.

Take the light from the light,  
Glasses flow from the ore,  
Our faith is Christian,  
With us is God.

With us, with us is God.
