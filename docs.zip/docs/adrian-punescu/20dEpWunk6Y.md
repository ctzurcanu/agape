---
id: 20dEpWunk6Y
title: "Marşul Ardealului - The Transylvanian Song"
sidebar_label: "Marşul Ardealului - The Transylvanian Song"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/20dEpWunk6Y"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Marşul Ardealului - The Transylvanian Song

Lyrics: Adrian Păunescu

Nu-i român cel ce nu simte  
Ca pe propriul crez moral  
Cele trei cuvinte sfinte:  
Mamă, tată şi Ardeal.

Nu-i român cel ce nu simte  
Ca pe propriul crez moral  
Cele trei cuvinte sfinte:  
Mamă, tată şi Ardeal.

Dac-avem în vine sânge  
Îi suntem datori total  
Maica Horii încă plânge  
Creşte iarba în Ardeal.  
Creşte iarba în Ardeal.

O clopotniţă se-ngână  
Cu un nechezat de cal  
Țipă stelele-n fântână  
Nasc româncele-n Ardeal.  
Nasc româncele-n Ardeal.

Nu-i român cel ce nu simte  
Ca pe propriul crez moral  
Cele trei cuvinte sfinte:  
Mamă, tată şi Ardeal.

Primăvară, zi de Paşte  
Ce-i real e ireal  
Fiul Sfânt aici se naşte  
Dumnezeu e în Ardeal.  
Dumnezeu e în Ardeal.

Prin Viteazul întregirii  
Urcă-n calendar fatal  
Ziua mare a Unirii  
România-e-n Ardeal.  
România-e-n Ardeal.

Nu-i român cel ce nu simte  
Ca pe propriul crez moral  
Cele trei cuvinte sfinte:  
Mamă, tată şi Ardeal.

Ţară iar în nedreptate  
Şi ce-i drept e ilegal,  
Ca soluţie la toate  
Trece Iancu prin Ardeal  
Trece Iancu prin Ardeal

Se-mpreună cer cu peșteri  
Pe-un pământ monumental,  
Ca din tabere de meșteri,  
Ninge marmură-n Ardeal.  
Ninge marmură-n Ardeal.

Nu-i român cel ce nu simte  
Ca pe propriul crez moral  
Cele trei cuvinte sfinte:  
Mamă, tată şi Ardeal.

Nu-i român cel ce nu simte  
Ca pe propriul crez moral  
Cele trei cuvinte sfinte:  
Mamă, tată şi Ardeal.

Nu-i român cel ce nu simte  
Ca pe propriul crez moral  
Cele trei cuvinte sfinte:  
Mamă, tată şi Ardeal.

English:

He is not Romanian who does not feel  
As if by his own moral creed  
The three holy words:  
Mother, father and Transylvania.

He is not Romanian who does not feel  
As if by his own moral creed  
The three holy words:  
Mother, father and Transylvania.

If we have blood in our veins  
We are totally indebted to her  
Mother Horii still cries  
The grass grows in Transylvania.  
The grass grows in Transylvania.

A bell tower is shaking  
With a horse's neigh  
The stars scream in the fountain  
I give birth to Romanians in Transylvania.  
I give birth to Romanians in Transylvania.

He is not Romanian who does not feel  
As if by his own moral creed  
The three holy words:  
Mother, father and Transylvania.

Spring, Easter Day  
What is real is unreal  
The Holy Son is born here  
God is in Transylvania.  
God is in Transylvania.

By the Brave of Wholeness  
Get on the fatal calendar  
The great day of the Union  
Romania is in Transylvania.  
Romania is in Transylvania.

He is not Romanian who does not feel  
As if by his own moral creed  
The three holy words:  
Mother, father and Transylvania.

Country again in injustice  
And what is right is illegal,  
As a solution to everything  
Iancu passes through Transylvania  
Iancu passes through Transylvania

Sky and caves come together  
On a monumental land,  
As if from craftsmen's camps,  
Marble snows in Transylvania.  
Marble snows in Transylvania.

He is not Romanian who does not feel  
As if by his own moral creed  
The three holy words:  
Mother, father and Transylvania.

He is not Romanian who does not feel  
As if by his own moral creed  
The three holy words:  
Mother, father and Transylvania.

He is not Romanian who does not feel  
As his own moral creed  
The three holy words:  
Mother, father and Transylvania.
