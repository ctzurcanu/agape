---
id: rQZe94kaQuk
title: "Mama Tata - Mother Father"
sidebar_label: "Mama Tata - Mother Father"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/rQZe94kaQuk"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Mama Tata - Mother Father

Haide, Mamă, Haide, Tată

Haide, mamă, haide, mamă, hai,  
Nişte linişte să-mi dai,  
Haide, tată, haide, tată, hai,  
Nişte linişte să-mi dai.

Haide, mamă, haide, tată,  
Mai priviţi-vă o dată  
Şi, pe urmă, dacă-i bine,  
Să mă faceţi tot pe mine.

Mi-aţi dat suflet, mi-aţi dat nume,  
De când sunt şi eu pe lume  
Mi-aţi dat multe şi de toate,  
Dar şi zbucium peste poate.

Bună ziua, noapte bună,  
Separat şi împreună,  
Dar şi bună dimineaţa,  
Dragii mei, mai dragi ca viaţa.

Când mi-e jale, când mi-e teamă,  
Mă gândesc la tine, mamă,  
Cand mi-e viaţa tulburată,  
Mă gândesc la tine, tată.

Haide, mamă, haide, tată,  
Mai clădiţi-mă o dată,  
Fără nume şi avere –  
Numai linişte v-aş cere.

Nu-mi ajunge tot ce este,  
Caut veşnic o poveste,  
Un ochi râde, altul plânge,  
Pe-amândoi vă port pe sânge.

Că nici unul n-avem parte  
De la naştere la moarte  
De o viaţă liniştită –  
Frunza-n plop mereu se-agită.

Înapoi la tine ia-mă  
Să mă ştergi de lacrimi, mamă,  
Lasă-ţi mâna să mă bată,  
Să mă–nveţi cu viaţa, tată.

Bune, rele-amestecate,  
V-aţi obişnuit cu toate.  
Creşte noapte, creşte iască  
Pe iubirea pământească.

Bate vântul dinspre viaţă  
Şi eu lacrimi simt pe faţă,  
Dinspre moarte bate vântul,  
Lăcrimează şi cuvântul.

Dinspre moarte bate vântul,  
Lăcrimează şi cuvântul.

English:

Come on, Mom, Come on, Dad

Come on, Mom, come on, Mom, come on,   
Give me some peace,  
Come on, Dad, come on,   
Give me some peace.

Come on, Mom, come on, Dad,  
Look at yourselves one more time  
And then, if you like,  
Make me all the same.

You gave me a soul, you gave me a name,  
Since I was born  
You gave me a lot and everything,  
But also a lot of trouble.

Good afternoon, good night,  
Apart and together,  
But also good morning,  
My dears, dearer than life.

When I am sad, when I am afraid,  
I think of you, Mom,  
When my life is troubled,  
I think of you, Dad.

Come, mother, come, father,  
Build me up once more,  
Without name and wealth –  
Only peace I would ask of you.

Everything that is is not enough for me,  
I am forever searching for a story,  
One eye laughs, the other cries,  
I carry you both in my blood.

Because neither of us has a share  
From birth to death  
Of a peaceful life –  
The leaf on the poplar always shakes.

Take me back to you  
To wipe my tears, mother,  
Let your hand beat me,  
To teach me about life, father.

Goodbye, mixed evils,  
You have become accustomed to everything.  
The night grows, the dawn grows  
On earthly love.

The wind blows from life  
And I feel tears on my face,  
The wind blows from death,  
And the word tears.

The wind blows from death,   
And tears the word.
