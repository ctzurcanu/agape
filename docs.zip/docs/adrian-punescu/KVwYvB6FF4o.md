---
id: KVwYvB6FF4o
title: "Bătrân Ceasornicar - Old Watchmaker"
sidebar_label: "Bătrân Ceasornicar - Old Watchmaker"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/KVwYvB6FF4o"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Bătrân Ceasornicar - Old Watchmaker

Lyrics: Adrian Păunescu

Bătrân ceasornicar, adus de spate,  
Ce vrei să mai repari cu mâna ta,  
Când, nici o oră bună nu mai bate  
Şi secundarul cade pe podea?

Tu nu-nțelegi că s-au făcut contracte  
Să fie ceasuri doar cu baterii?  
Tu nu-nțelegi că orele exacte  
S-au demodat şi nu mai pot veni?

Ce mai repari pendule fără vreme?  
Nu vrei, de tot ce-a fost, să te desparţi?  
Nepoţii tăi învaţă să te cheme,  
Ca din oraş să-ți iei un ceas cu cuarţ.

Ce faci, ceasornicar de modă veche?  
Tot mai repari ce este-n veci de veci  
Ireparabil fără de pereche  
Şi fără sens în veacul douăzeci?

Ireparabil fără de pereche  
Şi fără sens în veacul douăzeci?

English:

Old watchmaker, carried by the back,  
What do you want to fix with your own hands,  
When, not a single good hour beats any more  
And the second hand falls to the floor?

Don't you understand that contracts were made  
To have only battery-powered watches?

Don't you understand that exact hours  
Have gone out of fashion and can no longer come?

Why do you fix clocks without time?  
Don't you want to part with everything that was?  
Your grandchildren are learning to call you,  
Like getting a quartz watch from the city.

What are you doing, old-fashioned watchmaker?  
You keep fixing what is forever and ever  
Irreparable without a peer  
And meaningless in the twentieth century?

Irreparable without a peer  
And meaningless in the twentieth century?
