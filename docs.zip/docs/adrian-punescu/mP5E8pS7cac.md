---
id: mP5E8pS7cac
title: "Charlie Chaplin"
sidebar_label: "Charlie Chaplin"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/mP5E8pS7cac"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Charlie Chaplin

Lyrics: Adrian Păunescu

Râdeți, râdeți, râdeți, râdeți, cu pământ cu tot   
Până când vă mai suportă ultimul Charlot.   
Nu de el când râdeți, râdeți, râdeți voi de voi,   
Că sunteți grăbiți și cinici și inculți și goi. 

Charlie Chaplin calcă-n dodii cu pantofi strâmbați,   
Hohotiți dar n-aveți știre voi ce strâmb călcați.   
Face el cum face rața și e caraghios   
Dar ce cârduri mari de rațe trec în sus și-n jos. 

O, Charlie Chaplin, înger vagabond   
Hai, bătrâne, vino de sub orizont. 

O, Charlie Chaplin, hohot interzis   
Redeschide teatrul ce ni l-au închis! 

Nu mai sunt deloc parale, casierii, triști,   
Astăzi dau autografe, nu bani la artiști.   
S-au născut prea mulți pragmatici, muzică nu pot,   
Hai, Pământ, reamintește-ți că ai fost Charlot! 

Un șofer cu leafă mică și cu mult umor   
Mi te-a readus în minte ca pe-un luptător.   
Că ai fost al celor simpli și al lor rămâi,   
Peste toată lumea veche hohotul dintâi. 

O, Charlie Chaplin, înger vagabond   
Hai, bătrâne, vino de sub orizont. 

O, Charlie Chaplin, hohot interzis   
Redeschide teatrul ce ni l-au închis! 

  
Lăutarii împrumută bani pentru sacâz,   
Cifra noastră de afaceri hohotul de râs.   
Facem bancă mondială și băgăm în ea   
Râsul sărăcimii triste, ca dobânzi să dea. 

Nu există omenie unde nu ești tu,   
Că tu ești curajul nostru de a spune nu!   
Învârtește-te prin Cosmos, spune ce-ai de spus,   
Între-atâtea stele moarte tu Planeta Râs! 

  
O, Charlie Chaplin, înger vagabond   
Hai, bătrâne, vino de sub orizont. 

O, Charlie Chaplin, hohot interzis   
Redeschide teatrul ce ni l-au închis! 

O, Charlie Chaplin, înger vagabond   
Hai, bătrâne, vino de sub orizont. 

O, Charlie Chaplin, hohot interzis   
Redeschide teatrul ce ni l-au închis!
