---
id: n1UdNovpOGU
title: "Colindul colindelor - The Carol of Carols"
sidebar_label: "Colindul colindelor - The Carol of Carols"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/n1UdNovpOGU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Colindul colindelor - The Carol of Carols

Lyrics: Adrian Păunescu

Mai e vreme de colinde,  
Se mai poate, se mai poate,  
Dacă sufletul rămâne  
Cel mai mare dintre toate.

Dar colinda din colinde,  
N-are roluri, n-are mască,  
Şi pe ea tot omul lumii  
E chemat să o rostească.

Steaua, Sorcova şi Capra,  
Pluguşorul şi Ajunul,  
Le vor învăţa copiii,  
Nu le va uita niciunul.

În colindă, cel puternic  
Şi cel sfânt este Cuvântul,  
Cum uneşte într-o noapte  
Omul, cerul şi pământul.

Noi, prea multe ale noastre  
Le-am pierdut la cotitură,  
Prin colindele acestea  
Revenim la starea pură.

Ca-ntr-o stampă din răstimpuri  
Pe la geamuri sunt copiii,  
Şi ies oamenii la ceruri,  
Cu toţi morţii şi toţi viii.

N-am murit ca neam al lumii  
În vreo clipă viforoasă,  
Cât colindele colindă  
Şi copiii sunt acasă.

Cum şi astăzi ne întoarcem  
Şi pe prunci îi vom deprinde  
Să nu uite niciodată  
Oameni, ţară şi colinde.

Vin copiii să dezlege  
Din obraji fantasme roşii,  
Hei, primiţi-i cu colindul,  
Că tresar în ei strămoşii.

Şi-i colindul semn heraldic,  
Şi-i cultură în mişcare,  
Că prin el deschidem firea,  
Şi că spiritul nu moare.

Şi în sufletul prielnic  
Pentru fapte osebite  
Clopoţeii pun ninsoare,  
Cerul, florile-şi trimite.

N-a murit colindul nostru,  
Se mai poate, se mai poate,  
Leru-i ler, florile dalbe,  
La mulţi ani cu sănătate.

English:

There is still time for carols,  
It is still possible, it is still possible,  
If the soul remains  
The greatest of all.

But the carol of carols,  
It has no roles, no mask,  
And every man in the world  
Is called to recite it.

The Star, the Sorcova and the Goat,  
The Little Pig and the Eve,  
They will teach them to the children,  
None of them will forget them.

In the carol, the powerful  
And the holy is the Word,  
How it unites in one night  
Man, heaven and earth.

We, too many of ours  
We have lost them at the turning point,  
Through these carols  
We return to the pure state.

As in a print from the past  
The children are at the windows,  
And people go out to heaven,  
With all the dead and all the living.

We did not die as a nation of the world  
In some stormy moment,  
While the carols are caroling  
And the children are at home.

As we return today  
And we will teach the children  
To never forget  
People, country and carols.

Children come to untie  
From red ghosts cheeks,  
Hey, welcome them with the carol,  
Because the ancestors in them are startled.

And the carol is a heraldic sign,  
And it is culture in motion,  
Because through it we open the nature,  
And because the spirit does not die.

And in the favorable soul  
For special deeds  
The bells put snow,  
The sky, the flowers-sends.

Our carol has not died,  
It can still be, it can still be,  
Let the flowers bloom,  
Happy birthday with health.
