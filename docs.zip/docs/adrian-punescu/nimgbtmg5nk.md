---
id: nimgbtmg5nk
title: "Dor de Eminescu - Longing for Eminescu"
sidebar_label: "Dor de Eminescu - Longing for Eminescu"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/nimgbtmg5nk"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Dor de Eminescu - Longing for Eminescu

Lyrics: Adrian Păunescu

Într-o lume relativă  
Ce-a făcut şi-a desfăcut,  
Eminescu-i remuşcarea  
Dorului de absolut.  
Dacă unu şi cu unu  
Nu mai vor să facă doi,  
Eminescu este chipul  
Infinitului din noi.

Fără el oricare lucru  
Şi-ar urma cărarea sa,  
Fără el chiar steaua noastră  
Dintre stele ar cădea.  
Pe pământul vechii Dacii  
Când mai mare, când mai mic,  
Dacă n-ar fi Eminescu  
Viaţa nu ne-ar fi nimic.

El Moldovei îi e fiul  
Şi Munteniei nepot,  
L-a-nfiat întreg Ardealul,  
Eminescu-i peste tot!  
Într-o lume relativă  
Mai avem un nume sfânt,  
Eminescu-i România  
Tăinuită în cuvânt.

English:

In a relative world  
What he has done and undone,  
Eminescu is the remorse  
Of the longing for the absolute.  
If one and one  
They no longer want to make two,  
Eminescu is the face  
of the Infinite within us.

Without him, every thing  
Would follow its path,  
Without him, even our star  
Would fall from among the stars.  
On the land of ancient Dacia  
Sometimes bigger, sometimes smaller,  
If it weren't for Eminescu  
Life would be nothing to us.

He is Moldavia's son  
And Wallachia's grandson,  
The whole of Transylvania adopted him,  
Eminescu is everywhere!

In a relative world  
We still have a holy name,  
Eminescu is Romania  
Hidden in the word.
