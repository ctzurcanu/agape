---
id: _BpyxXSM9-g
title: "Actorul - The Actor"
sidebar_label: "Actorul - The Actor"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/_BpyxXSM9-g"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Actorul - The Actor

Lyrics: Adrian Păunescu

Actorul a ieșit în stradă  
Să-și cumpere ceva salam,  
Era în haine de paradă,  
Ca Voievod peste un neam.  
Printre mașini, printre tramvaie  
Actorul se grăbea firesc,  
Urma să vină-un nor de ploaie,  
Perucile se dezlipesc.

O, biet actor,  
O, biet artist,  
Rolurile mor  
Viața e un teatru trist.  
O, biet actor,  
O, biet artist,  
Rolurile mor  
Viața e un teatru trist.  
   
Și când s-a așezat la coadă  
Cu paloș, mantie și scut,  
Deodată, oamenii din stradă  
Ca Voievod l-au cunoscut.  
S-au dat deoparte cu sfială,  
Mulțimea toată murmura  
Văzându-i hainele de gală,  
Să ne trăiești, Măria-Ta!

O, biet actor,  
O, biet artist,  
Rolurile mor  
Viața e un teatru trist.  
O, biet actor,  
O, biet artist,  
Rolurile mor  
Viața e un teatru trist.  
   
Republicani, mă rog, cu toții  
Descoperiseră alt mod  
De-a da cuvânt la noi emoții  
și se-nchinau la Voievod.  
Dar ploaia a venit deodată  
Și ei văzând cu ochii lor  
Întreaga-i față demachiată  
I-au aruncat un fel de plată:  
Lăsați-l dracu', e-un actor.

O, biet actor,  
O, biet artist,  
Rolurile mor  
Viața e un teatru trist.  
O, biet actor,  
O, biet artist,  
Rolurile mor  
Viața e un teatru trist.

O, biet actor,  
O, biet artist,  
Rolurile mor,  
Viața e un teatru trist.

English:

The actor went out into the street  
To buy some salami,  
He was in full regalia,  
Like a Voivode over a nation.  
Among cars, among trams  
The actor was naturally in a hurry,  
A rain cloud was about to come,  
The wigs are coming off.

Oh, poor actor,  
Oh, poor artist,  
The roles die  
Life is a sad theater.  
Oh, poor actor,  
Oh, poor artist,  
The roles die  
Life is a sad theater.

And when he sat down in line  
With broadsword, cloak and shield,  
Suddenly, the people in the street  
Recognized him as a Voivode.  
They shyly stepped aside,  
The whole crowd murmured  
Seeing his gala clothes,  
Long live us, Your Majesty!

Oh, poor actor,  
Oh, poor artist,  
The roles die  
Life is a sad theater.  
Oh, poor actor,  
Oh, poor artist,  
The roles die  
Life is a sad theater.

Republicans, I pray, all  
They had discovered another way  
To give voice to new emotions  
And they were bowing to the Voivode.  
But the rain came suddenly  
And they seeing with their own eyes  
His entire face stripped of makeup  
They threw him a kind of payment:  
Leave him alone, he's an actor.

Oh, poor actor,  
Oh, poor artist,  
The roles die  
Life is a sad theater.  
Oh, poor actor,  
Oh, poor artist,  
The roles die  
Life is a sad theater.

Oh, poor actor,  
Oh, poor artist,  
The roles die  
Life is a sad theater.
