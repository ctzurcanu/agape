---
id: TZ5du8sNUs0
title: "Impozite, Biruri şi Taxe - Taxes, Duties and Fees"
sidebar_label: "Impozite, Biruri şi Taxe - Taxes, Duties and Fees"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/TZ5du8sNUs0"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Impozite, Biruri şi Taxe - Taxes, Duties and Fees

Lyrics: Adrian Păunescu

De ce nu puneţi şi pe râs impozit  
Şi birul progresiv pe sărăcie?  
De ce nu puneţi taxe pe-ntuneric?  
Impozitaţi şi vântul ce adie!

Ar fi păcat să ezitaţi în crima  
De-a confisca şi sângele din vine,  
Continuaţi prăpădul cu ardoare  
Şi răul ce vă face-atât de bine!

Taxaţi iubirea, somnul, nostalgia,  
Penumbra, deznădejdea şi oftatul  
Şi unghiile care cresc întruna,  
Distrugeţi tot, de-a lungul şi de-a latul.

Nu-i logic să nu puneţi nişte biruri,  
Pe nou născuţi, ce nu ştiu cum îi cheamă,  
Lucraţi neiertător şi echitabil,  
Impozitaţi şi laptele de mamă.

Dar ce fiscalitate este aia  
Din care nu se fură-ntreaga pâine  
Acestui neam ce şi-a luat maidanul  
De-a nu trăi în lesă ca un câine?

Taxaţi sever şi strângerea de mână!  
Impozitaţi total telepatia!  
Luaţi atâtea piei câte vă place  
Şi desfiinţaţi prin taxe România!

Ce e complicitatea asta bleagă  
Cu sărăntocii şi dezmoşteniţii?  
Tot au şi ei ceva să dea ca taxă,  
Treziţi-le revolte şi ambiţii!

Voi nu vedeţi că omul mai respiră?  
Cât amânaţi sentinţa capitală?  
Loviţi la oase naţia întreagă,  
Înduioşarea e un fel de boală.

Adăugaţi impozite şi taxe  
Pe taxe şi impozite, cuminte,  
Impozitaţi şi lacrima şi ploaia!  
Taxaţi adânc şi morţii din morminte!

Impozite pe floarea dăruită,  
Impozite pe cald, ca şi pe rece,  
Impozite pe rouă şi pe lună,  
Impozite pe notele de zece.

Cafeaua, ceaiul, apa de fântână,  
Fereastra, uşa, merită accize  
Când, cu o poftă tragică, Guvernul  
Îi dă un nou impuls acestei crize.

Impozite şi taxe pe cuvinte,  
Dar biruri pe ecou şi pe tăcere,  
A jupui poporul este nobil,  
Când nu-i mai laşi nici dreptul să mai spere.

Hei, Românie, parcă răstignită,  
Degeaba vrem să te-ntrebăm „Quo vadis?”,  
Nici să trăim aici, nu-i cu putinţă  
Nici să murim acum nu mai e gratis.

La luptă împotriva tuturora,  
Într-un neomenesc război promiscuu,  
Trăiască lanţul ce ne intră-n oase!  
Trăiască Taxa, Jaful, Moartea, Fiscul!

La luptă împotriva tuturora,  
Într-un neomenesc război promiscuu,  
Trăiască lanţul ce ne intră-n oase!  
Trăiască Taxa, Jaful, Moartea, Fiscul!

English:

Why don't you also put a tax on laughter  
And a progressive tax on poverty?  
Why don't you put taxes on darkness?  
Tax the wind that blows too!

It would be a shame to hesitate in the crime  
Of confiscating the blood in your veins,  
Continue the destruction with ardor  
And the evil that does you so much good!

Tax love, sleep, nostalgia,  
Penumbra, despair and sighing  
And the nails that grow constantly,  
Destroy everything, length and breadth.

It's not logical not to put some taxes,  
On newborns, who don't know their names,  
Work unforgivingly and fairly,  
Tax breast milk too.

But what kind of taxation is that  
From which the whole bread is not stolen  
From this nation that took its own Maidan  
To not live on a leash like a dog?

Tax handshakes severely too!  
Tax telepathy completely!  
Take as many skins as you like  
And abolish Romania through taxes!

What is this bland complicity  
With the poor and the disinherited?  
They still have something to give as tax,  
Awaken their revolts and ambitions!

Don't you see that man is still breathing?  
How long will you postpone the death sentence?  
You are hitting the whole nation in the bones,  
Tenderness is a kind of disease.

Add taxes and taxes  
On taxes and taxes, good people,  
Tax tears and rain too!  
Tax deeply even the dead in the graves!

Taxes on the flower given,  
Taxes on heat, as well as on cold,  
Taxes on dew and on the moon,  
Taxes on ten-dollar bills.

Coffee, tea, well water,  
Window, door, deserve excise taxes  
When, with a tragic appetite, the Government  
Gives a new impetus to this crisis.

Taxes and duties on words,  
But taxes on echo and silence,  
Fleaing the people is noble,  
When you don't even give them the right to hope anymore.

Hey, Romania, as if crucified,  
In vain we want to ask you "Quo vadis?",  
Neither living here is possible  
Neither dying now is free.

In the fight against everyone,  
In an inhuman promiscuous war,  
Long live the chain that enters our bones!  
Long live Tax, Robbery, Death, Tax!

In the fight against all,  
In an inhuman promiscuous war,  
Long live the chain that enters our bones!  
Long live Tax, Robbery, Death, Tax!
