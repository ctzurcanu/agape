---
id: tCAOoeqiv50
title: "Noah"
sidebar_label: "Noah"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/tCAOoeqiv50"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Noah

[Chorus]  
Well it's a-oh, Noah  
Oh, oh, Noah  
Oh-ho, oh, Noah  
My God's gonna ride   
on the wind and tide  
Well, it's a-oh, oh, Noah  
Oh, oh, Noah  
Oh-ho, oh, Noah  
My God’s gonna ride   
on the wind and tide  
Brother Noah  
(God's gonna ride on the wind and tide)  
My God's talkin'  
(My God's gonna ride on the wind and tide)  
Said he would ride  
(God's gonna ride on the wind and tide)  
On the wind and tide  
(My God's gonna ride on the wind and tide)

[Verse 1]  
Hey children, stop, be still and listen to me  
When God walked down to the brandy sea  
He declared that the evil descend from man  
And then he decided to destroy the land  
He spoke to Noah, and Noah stopped  
He said "Noah, I want you to build me an ark  
I want you to build it three cubits long  
I want you to build it big and strong  
I want it thirty high and fifty wide  
So it will stand the wind and tide"

[Chorus]  
Oh, oh, Noah  
Oh, oh, Noah  
Oh-ho, oh, Noah  
My God's gonna ride   
on the wind and tide  
Well, it's a-oh, oh, Noah  
Oh, oh, Noah  
Oh-ho, oh, Noah  
My God's gonna ride   
on the wind and tide  
Mmm, mmm  
(God's gonna ride on the wind and tide)  
Mmm-hmm  
(God's gonna ride on the wind and tide)  
Mmm, mmm-hmm  
(God's gonna ride on the wind and tide)  
Oh-ho, Noah  
(God's gonna ride on the wind and tide)  
Brother Noah  
(My God's gonna ride on the wind and tide)  
My God's talkin'  
(My God's gonna ride on the wind and tide)  
Said he would ride  
(My God's gonna ride on the wind and tide)  
On the wind and tide  
(My God's gonna ride on the wind and tide)

[Verse 2]  
Well, after the foundation was laid  
Then Noah began to hew and build  
The ringin' of the hammer cried judgment  
The hewing of the saw cried sin and repent  
A hundred years, he hammered and sawed  
Buildin' the ark by the grace of God  
When the ark was done, God's voice was heard  
He said "Now Noah, let me tell you what to do  
Call in the animals two by two"  
So he called 'em in the ark, two by two  
He called the birdie, the ox with the kangaroo  
Then he called in Japheth, and Ham, and Shem  
Then God began to flood the land  
He raised his hands to heaven on high  
Shook the stars and moved from the sky  
Shook the mountains, he troubled the sea  
Hitched the wind to his chariot-to-be  
And he stepped on land, stood on the shore  
And declared that time there wouldn't be no more

[Outro]  
Well, it's a-oh, oh, Noah  
Oh-oh, oh, Noah  
Oh-ho, oh, Noah  
My God's gonna ride   
on the wind and tide
