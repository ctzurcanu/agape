---
id: HezAPyNJVPA
title: "Сцена 4"
sidebar_label: "Сцена 4"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/HezAPyNJVPA"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Сцена 4

Героическая Мученица за Истину. Акт 1.  
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38MfSOiBcQHOv8MSo1vfpWHag

Прием Бодрикура был жестоким. Жанна сказала ему: «Что пришло послание от Бога, что Бог повелит дофину вести себя хорошо, потому что Господь окажет ему помощь до середины поста»; она добавила: «что Бог хочет, чтобы дофин стал королем; что он сделает это, несмотря на своих врагов, и что она сама приведет его к коронации».

«Эта девушка сумасшедшая, — сказал Бодрикур, — давайте отвезем её обратно к её отцу, чтобы он дал ей хорошую порку».

Жанна вернулась в Домреми. Но вновь под давлением своих голосов она вернулась в Вокулер и снова увидела господина Бодрикура, не получив лучшего приема.
