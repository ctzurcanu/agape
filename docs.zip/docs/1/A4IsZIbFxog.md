---
id: A4IsZIbFxog
title: "Сцена 8"
sidebar_label: "Сцена 8"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/A4IsZIbFxog"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Сцена 8

Героическая Мученица за Истину. Акт 1.  
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38MfSOiBcQHOv8MSo1vfpWHag

Три недели её мучили коварными вопросами.

«В Божьей книге больше, чем в вашей», — ответила она; «Я не знаю ни А, ни Б, но я пришла от короля небесного».

Когда ей возразили, что Бог для освобождения Франции не нуждается в вооруженных людях, она вдруг встала:

«Люди будут сражаться, Бог даст победу».

Там, как и в Вокулере, народ заявил о своей поддержке, считая её святой и вдохновленной. Врачи и могущественные люди должны были уступить энтузиазму толпы.
