---
id: 93VSxvxTHBQ
title: "Сцена 2"
sidebar_label: "Сцена 2"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/93VSxvxTHBQ"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Сцена 2

Героическая Мученица за Истину. Акт 1.  
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38MfSOiBcQHOv8MSo1vfpWHag

Однажды летом, когда ей было тринадцать лет, в полдень, она услышала голос в саду своего отца; великий свет озарил всё вокруг, и перед ней явился архангел Михаил. Он сказал ей быть доброй и посещать церковь. Затем, рассказывая ей о великом горе, которое было в королевстве Франции, он объявил ей, что она отправится на помощь дофину и приведет его в Реймс для коронации.

«Сэр, я всего лишь бедная девушка, я не умею ездить верхом или вести вооруженных людей».

«Бог поможет тебе», — ответил архангел.

И потрясенная девочка осталась плакать.
