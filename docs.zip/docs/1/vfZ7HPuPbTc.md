---
id: vfZ7HPuPbTc
title: "Сцена 5"
sidebar_label: "Сцена 5"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/vfZ7HPuPbTc"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Сцена 5

Героическая Мученица за Истину. Акт 1.  
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38MfSOiBcQHOv8MSo1vfpWHag

Но на этот раз она осталась в Вокулере.

Вскоре по всей округе заговорили об этой молодой девушке, которая громко заявляла, что она спасет королевство, что её нужно доставить к дофину, что Бог этого хочет.

«Я пойду, — сказала она, — даже если сотру ноги до колен».

Люди с простыми сердцами, тронутые её верой, поверили ей. Один из оруженосцев, Жан де Мец, уверенный в её словах, предложил отвезти её в Шинон, где находился Карл VII. Бедняки, собрав свои последние сбережения, объединились, чтобы одеть и вооружить маленькую крестьянскую девочку. Они купили ей лошадь, и в назначенный день она отправилась со своей слабой охраной.

«Иди. Что будет — то будет!» — сказал ей Бодрикур.

«Бог благословит тебя!» — кричали бедняки, и женщины плакали, глядя, как она уходит.
