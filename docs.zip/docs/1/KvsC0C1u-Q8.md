---
id: KvsC0C1u-Q8
title: "Сцена 1"
sidebar_label: "Сцена 1"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/KvsC0C1u-Q8"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Сцена 1

Героическая Мученица за Истину. Акт 1.  
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38MfSOiBcQHOv8MSo1vfpWHag

Жанна родилась 6 января 1412 года в Домреми, небольшой деревне в Лотарингии, зависимой от шомонского бальяжа, который принадлежал короне Франции.

Её отца звали Жак д'Арк, а мать - Изабель Роме; они были честными людьми, простыми рабочими, жившими за счет своего труда.

Жанна выросла с братьями и сестрой в маленьком доме, который до сих пор можно увидеть в Домреми, так близко к церкви, что её сад соприкасается с кладбищем.

Ребенок рос под оком Бога.

Она была добрая, простая и честная. Все любили её, потому что знали, что она была милосердна и лучшая девушка в своей деревне. Трудолюбивая, она помогала своей семье в их задачах: днём пасла скот или принимала участие в тяжелой работе своего отца, а вечером проводила время с матерью, помогая ей по хозяйству.

Она любила Бога и часто молилась Ему.
