---
id: WBucp0wPTbI
title: "Balada unui greier mic - The Ballad of a Little Cricket"
sidebar_label: "Balada unui greier mic - The Ballad of a Little Cricket"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/WBucp0wPTbI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Balada unui greier mic - The Ballad of a Little Cricket

Versuri: George Topîrceanu

Peste dealuri zgribulite,  
Peste ţarini zdrenţuite,  
A venit aşa, deodată,  
Toamna cea întunecată.

Lungă, slabă şi zăludă,  
Botezând natura udă  
C-un mănunchi de ciumafai, -  
Când se scutură de ciudă,  
Împrejurul ei departe  
Risipeşte-n evantai  
Ploi mărunte,  
Frunze moarte,  
Stropi de tină,  
Guturai...

Şi cum vine de la munte,  
Blestemând  
Şi lăcrimând,  
Toţi ciulinii de pe vale  
Se pitesc prin văgăuni,  
Iar măceşii de pe câmpuri  
O întâmpină în cale  
Cu grăbite plecăciuni...

Doar pe coastă, la urcuş,  
Din căsuţa lui de humă  
A ieşit un greieruş,  
Negru, mic, muiat în tuş  
Şi pe-aripi pudrat cu brumă:

- Cri-cri-cri,  
Toamnă gri,  
Nu credeam c-o să mai vii  
Înainte de Crăciun,  
Că puteam şi eu s-adun  
O grăunţă cât de mică,  
Ca să nu cer împrumut  
La vecina mea furnică,  
Fi'ndcă nu-mi dă niciodată,  
Şi-apoi umple lumea toată  
Că m-am dus şi i-am cerut...

Dar de-acuş,  
Zise el cu glas sfârşit  
Ridicând un picioruş,  
Dar de-acuş s-a isprăvit...  
Cri-cri-cri,  
Toamnă gri,  
Tare-s mic şi necăjit!

Cri-cri-cri,  
Toamnă gri,  
Tare-s mic şi necăjit!

English:

Over the wrinkled hills,  
Over the ragged fields,  
It came so suddenly,  
The dark autumn.

Long, thin and eager,  
Baptizing wet nature  
With a bundle of plague-bugs, -  
When it shakes off its spite,  
Around it far  
It scatters in a fan  
Small rains,  
Dead leaves,  
Splashes of mud,  
Chestnuts...

And as it comes from the mountain,  
Cursing  
And weeping,  
All the thistles in the valley  
Sneeze through the hollows,  
And the rose hips in the fields  
Welcome it on its way  
With hasty bows...

Only on the slope, on the way up,  
From its little house of humus  
A cricket came out,  
Black, small, soaked in ink  
And on its wings powdered with hoarfrost:

- Cri-cri-cri,  
Gray autumn,  
I didn't think you'd come  
Before Christmas,  
That I could I gather  
A grain as small as possible,  
So that I don't ask for a loan  
From my neighbor the ant,  
Because he never gives me,  
And then fills the whole world  
Because I went and asked him...

But now,  
He said in a broken voice  
Raising a little foot,  
But now it's over...  
Cri-cri-cri,  
Gray autumn,  
So small and troubled!

Cri-cri-cri,  
Gray autumn,  
So small and troubled!
