---
id: p0AHtyV4MnI
title: "Noi, nu! - Not us!"
sidebar_label: "Noi, nu! - Not us!"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/p0AHtyV4MnI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Noi, nu! - Not us!

Lyrics: Nicolae Labiş

O parte din noi ne-am învins  
Greșeala, minciuna și groaza,  
Dar e drum, mai e drum necuprins  
Până-n zarea ce-și leagănă oaza.

Generații secate se sting,  
Tinerii râd către stelele reci.

Cine-și va pierde credința-n izbândă  
Pe-aceste mereu mișcătoare poteci?

Ascultă, ascultă, ascultă!  
Noi, nu! Niciodată! Noi, nu!

Cine din noi va muri  
Înainte ca trupu-i să moară?

Ascultă, ascultă, ascultă!  
Noi, nu! Niciodată! Noi, nu!

Cine-o să-și lepede inima-n colb  
Insuportabil de mare povară?

Ascultă, ascultă, ascultă!  
Noi, nu! Niciodată! Noi, nu!

Ca un vânt rău, ori ca o insultă  
Întrebarea prin rânduri trecu.

Ascultă, ascultă, ascultă!  
Noi, nu! Niciodată! Noi, nu!

Noi, nu! Niciodată! Noi, nu!  
Noi, nu! Niciodată! Noi, nu!

English:

Part of us has defeated  
Mistake, lie and horror,  
But there is a road, there is still an unfathomable road  
To the horizon that rocks its oasis.

Dried generations die out,  
The young laugh at the cold stars.

Who will lose faith in victory  
On these ever-moving paths?

Listen, listen, listen!  
We, no! Never! We, no!

Who among us will die  
Before his body dies?

Listen, listen, listen!  
We, no! Never! We, no!

Who will throw his heart into the dust  
Unbearably heavy burden?

Listen, listen, listen!  
We, no! Never! We, no!

Like a bad wind, or like an insult  
The question passed through the ranks.

Listen, listen, listen!  
We, no! Never! We, no!

We, no! Never! We, no!  
We, no! Never! We, no!
