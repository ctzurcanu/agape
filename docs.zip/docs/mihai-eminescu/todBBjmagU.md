---
id: _todBBjmagU
title: "Povestea Dochiei - Dochia's Story    part 1"
sidebar_label: "Povestea Dochiei - Dochia's Story    part 1"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/_todBBjmagU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Povestea Dochiei - Dochia's Story    part 1

Lyrics: Mihai Eminescu

Crește iarba, mări, iară,  
Bătută de vânt de vară  
Unde mi-i pădurea rară.  
Dar în iarba cea frumoasă  
N-a intrat vrodată coasă  
Unde mi-i pădurea deasă.  
De desișul din pădure  
Nu s-atinse vro secure.

Cât de naltu-i, cât de mare,  
Nicăieri nu vezi cărare,  
De și-ar pierde urmele  
Ciobănași cu turmele.  
La temei de codri deși  
Nu-i cărare ca să ieși,  
Ci-i rariște de brazi  
Și un ochi voios de iaz  
Și doi tei ca niște frați,  
La tulpină depărtați,  
La vârfuri amestecați.

Iar la umbra celor tei  
Mi s-arată un bordei,  
Frunza cade de pe ei  
Scuturată, resfirată,  
Pe cărare aruncată.  
Iar pe prispă, singurea,  
Văduvioară tinerea,  
C-un picior îmi legăna  
Copilaș înfășățel,  
Ce îi râde frumușel.

Și cum codrul se frământă,  
Ea își cântă, ea-și descântă,  
Legănând dintr-un picior  
Îi zicea încetișor:  
Nani, nani, puișor,  
Nani, nani, copilaș,  
O poveste spune-ț-aș,  
O poveste drăgălașă,  
Ca să-mi crești voinic în fașă.

Tată-meu era cioban,  
Câte clipe-s într-un an  
Tot atâția baci avea,  
Cu mii turme-alăturea,  
Turme mii de mielușele,  
Ciobănașii după ele,  
Turme mândre și de oi,  
Ciobănașii dinapoi  
Cu fluiere și cimpoi,  
Mai avea de mă pricepi,  
Herghelii de cai sirepi,  
Ce ca vijeliile  
Îi împleau câmpiile,  
Îi pășteau moșiile,  
Și de-a lungul râurilor  
S-așterneau pustiurilor,  
Și în valurile ierbii  
Pășteau ciutele și cerbii,  
Și prin munți pierduți în nouri  
Avea cârduri mari de bouri,  
Ș-avea munți, ș-avea păduri,  
Și cetăți cu-ntărituri,  
Ș-avea sate mii de mii  
Presărate pe câmpii,  
Ș-avea sate mari și mici,  
Pline toate de voinici.

Ce mai freamăt, ce mai zbucium  
Când, sunând voios din bucium,  
Chema țara la hotare,  
De-alergau cu mic cu mare,  
De curgeau ca râurile  
Și-nnegrea pustiurile.

Amar mie,-ntr-un suspin  
Lacrimile vale-mi vin,  
Cu năframa de le șterg,  
Ele tot mai tare merg.

Și frumoasă mai eram,  
Cum n-a mai fost neam de neam.  
De-aur mi-erau pletele  
Și le-mpleteau fetele,  
Rumănă ca un bujor,  
Eram dragă tuturor.  
Au venit, mări,-au venit  
Împărați din Răsărit  
Să mă ceară în pețit,  
Dar s-au dus cum au sosit.  
Veneau crai și veneau soli  
Învățați în multe școli,  
Cu cuvinte așezate  
Mă cerură cu dreptate.

English:

The grass grows, grows, again,  
Whipped by the summer wind  
Where my forest is sparse.  
But in the beautiful grass  
No scythe has ever entered  
Where my forest is dense.  
No axe has ever touched the thicket in the forest.

How high it is, how big,  
Nowhere can you see a path,  
As if the shepherds with their flocks had lost their tracks.  
At the base of the forests, although  
There is no path to get out,  
But there is a clearing of fir trees  
And a cheerful pond  
And two linden trees like brothers,  
Distant at the stem,  
Mixed at the tops.

And in the shade of the linden trees  
A hut appears to me,  
The leaf falls from them  
Shaked, refreshed,  
On the path thrown.  
And on the porch, alone,  
The young widow,  
With one foot she rocked  
My little child in swaddling clothes,  
That laughs beautifully at him.

And as the forest stirred,  
She sang to herself, she enchanted herself,  
Rocking with one foot  
She said softly:  
Nanny, nanny, little child,  
Nanny, nanny, little child,  
A story I would tell you,  
A sweet story,  
So that you might grow strong in my swaddling clothes.

My father was a shepherd,  
How many moments are there in a year  
He had as many sheep,  
With thousands of flocks beside him,  
Herds of thousands of lambs,  
The shepherds behind them,  
Proud flocks of sheep too,  
The shepherds behind  
With whistles and bagpipes,  
You still had to understand me,  
Herds of smooth horses,  
Which like storms  
Wrapped his fields,  
They grazed his estates,  
And along the rivers  
They spread out in the deserts,  
And in the waves of grass  
The deer and the stags grazed,  
And through the mountains lost in the clouds  
He had large herds of oxen,  
He had mountains, and forests,  
And fortified cities,  
And he had thousands of villages  
Scattered across the fields,  
And he had large villages and small,  
All full of strong men.

How much more trembling, how much more turmoil  
When, ringing joyfully from the joy,  
The country called to the border,  
They ran with small and large,  
They flowed like rivers  
And blackened the deserts.

Bitter to me,-in a sigh  
Tears come to my valley,  
With the pain of wiping them away,  
They go stronger and stronger.

And I was beautiful,  
As there has never been a generation after generation.  
My locks were of gold  
And the girls braided them,  
Blushing like a peony,  
I was dear to everyone.  
They came, great,-they came  
Emperors from the East  
To ask me for marriage,  
But they left as they arrived.  
Kings came and messengers came  
Learned in many schools,  
With well-arranged words  
They asked me with justice.
