---
id: Qp1J9CXq3hM
title: "Scrisoarea I - Letter I"
sidebar_label: "Scrisoarea I - Letter I"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Qp1J9CXq3hM"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scrisoarea I - Letter I

Versuri: Mihai Eminescu

Când cu gene ostenite sara suflu-n lumânare,  
Doar ceasornicul urmează lung-a timpului cărare,  
Căci perdelele-ntr-o parte când le dai, şi în odaie  
Luna varsă peste toate voluptoasa ei văpaie,  
Ea din noaptea amintirii o vecie-ntreagă scoate  
De dureri, pe care însă le simţim ca-n vis pe toate.

Lună tu, stăpân-a mării, pe a lumii boltă luneci  
Şi gândirilor dând viaţă, suferinţele întuneci;  
Mii pustiuri scânteiază sub lumina ta fecioară,  
Şi câţi codri-ascund în umbră strălucire de izvoară!  
Peste câte mii de valuri stăpânirea ta străbate,  
Când pluteşti pe mişcătoarea mărilor singurătate!  
Câte ţărmuri înflorite, ce palate şi cetăţi,  
Străbătute de-al tău farmec ţie singură-ţi arăţi!  
Şi în câte mii de case lin pătruns-ai prin fereşti,  
Câte frunţi pline de gânduri, gânditoare le priveşti!  
Vezi pe-un rege ce-mpânzeşte globu-n planuri pe un veac,  
Când la ziua cea de mâine abia cuget-un sărac...  
Deşi trepte osebite le-au ieşit din urna sorţii,  
Deopotrivă-i stăpâneşte raza ta şi geniul morţii;  
La acelaşi şir de patimi deopotrivă fiind robi,  
Fie slabi, fie puternici, fie genii ori neghiobi!  
Unul caută-n oglindă de-şi buclează al său păr,  
Altul caută în lume şi în vreme adevăr,  
De pe galbenele file el adună mii de coji,  
A lor nume trecătoare le însamnă pe răboj;  
Iară altu-mparte lumea de pe scândura tărăbii,  
Socotind cât aur marea poartă-n negrele-i corăbii.  
Iar colo bătrânul dascăl, cu-a lui haină roasă-n coate,  
Într-un calcul fără capăt tot socoate şi socoate  
Şi de frig la piept şi-ncheie tremurând halatul vechi,  
Îşi înfundă gâtu-n guler şi bumbacul în urechi;  
Uscăţiv aşa cum este, gârbovit şi de nimic,  
Universul fără margini e în degetul lui mic,  
Căci sub fruntea-i viitorul şi trecutul se încheagă,  
Noaptea-adânc-a veciniciei el în şiruri o dezleagă;  
Precum Atlas în vechime sprijinea cerul pe umăr  
Aşa el sprijină lumea şi vecia într-un număr.

English:

When with tired eyelashes I blow into the candle,  
Only the clock follows the long path of time,  
Because the curtains are parted when you give them, and in the room  
The moon pours over everything its voluptuous flame,  
She brings out from the night of memory an eternity  
Of pains, which we feel all as if in a dream.

Moon, you, master of the sea, glide over the vault of the world  
And giving life to thoughts, you darken sufferings;  
Thousands of deserts sparkle under your virgin light,  
And how many forests hide in the shadow the brilliance of a spring!  
Over how many thousands of waves your dominion crosses,  
When you float on the moving solitude of the seas!  
How many flowery shores, what palaces and cities,  
Crossed by your charm you show yourself alone!  
And how many thousands of houses have you entered through the windows,  
How many thoughtful, thoughtful faces do you look at!  
You see a king who spreads the globe in plans for a century,  
When a poor man barely thinks about tomorrow...  
Although their special steps have come out of the urn of fate,  
Your ray and the genius of death both rule them;  
To the same series of passions, both being slaves,  
Whether weak, or strong, whether geniuses or fools!  
One searches in the mirror to curl his hair,  
Another searches in the world and in time for truth,  
From the yellow leaves he gathers thousands of shells,  
His fleeting name he assigns to them in battle;  
And another divides the world from the plank of the ship,  
Counting how much gold the sea carries in the black hulls of its ships.  
And there the old teacher, with his coat worn at the elbows,  
In an endless calculation he keeps counting and counting  
And shivering from the cold on his chest, he ties his old robe,  
He stuffs his neck in the collar and the cotton in his ears;  
Dry as he is, hunched and nothing,  
The boundless universe is in his little finger,  
For under his forehead the future and the past are bound,  
He unties the deep night of eternity in strings;  
As Atlas in ancient times supported the sky on his shoulder  
So he supports the world and eternity in a number.
