---
id: 1OBSKmIV290
title: "Gloss"
sidebar_label: "Gloss"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/1OBSKmIV290"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Gloss

Lyrics: Mihai Eminescu

Time is passing, time comes yet,  
All is old, and all is new;  
What for good or ill is set  
You can ponder and construe;  
Do not hope and do not worry,  
What’s a wave, will wave away;  
Though enticing with a flurry,  
Cool remain to all they say.

Many things pass by before us,  
Many things we hear and see,  
Who remembers all their ruckus  
And would listen to their plea?…  
You sit calmly ‘round the edges,  
Find yourself, despite their threat,  
While you hear their noisy pledges,  
Time is passing, time comes yet.

Not inclining in expression  
The cold balance of our thinking  
To a moment, an impression,  
Mask of happiness now sinking,  
Of its own death notwithstanding  
Takes one lonely breath for you;  
But for him who’s understanding  
All is old, and all is new.

Entertained by actors playing  
In this world yourself depict:  
Though four roles one is portraying,  
His true face you can predict;  
If he weeps, or if he’s fighting,  
You just watch him without fret  
And deduce from his inciting  
What for good or ill is set.

Past and future go together,  
The two faces of a coin,  
You can tell tomorrow’s weather,  
Then you learn the two to join;  
All that was and all that follows  
In this moment we see true,  
On their false and empty hollows  
You can ponder and construe

The same means this world is using  
To constrain in all she fashions,  
And for thousand years suﬀusing  
Joy and sadness duly rations;  
Other masks, the same old drama,  
Other mouths, the same old story,  
Discontent at their conformance  
Do not hope and do not worry.

Do not hope because some cretin  
Wrestles to successes steady,  
Idiots will have you beaten,  
Though you’ve shown them oﬀ already;  
Have no fear if when they gather  
Ostentations they display,  
Don’t resemble them, don’t blather:  
What’s a wave, will wave away.

Like some charming siren calling,  
The world’s luring and inviting;  
Other actors when they’re falling,  
It wants you to do their fighting;  
Move aside, it’s just deception,  
Pass them by, away you scurry,  
From your path make no exception,  
Though enticing with a flurry.

Should they touch you, get some distance,  
Should they curse you, keep your polish,  
Why advise and show persistence,  
When you know they just demolish?  
Let them blather on forever,  
Doesn’t matter whom they sway,  
Don’t grow fond of them, be clever,  
Cool remain to all they say.

Cool remain to all they say,  
Though enticing with a flurry;  
What’s a wave, will wave away,  
Do not hope and do not worry;  
You can ponder and construe  
What for good or ill is set;  
All is old, and all is new:  
Times is passing, time comes yet.
