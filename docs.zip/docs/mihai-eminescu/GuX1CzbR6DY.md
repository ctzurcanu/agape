---
id: GuX1CzbR6DY
title: "What is love? - Ce e amorul?"
sidebar_label: "What is love? - Ce e amorul?"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/GuX1CzbR6DY"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## What is love? - Ce e amorul?

Lyrics: Mihai Eminescu  
Translation (from Romanian): Corneliu M. Popescu

What is love? A lifetime spent    
Of days that pain does fill,   
That thousand tears can't content,   
But asks for tears still. 

With but a little glance coquet   
Your soul it knows to tie,   
That of its spell you can't forget   
Until the day you die. 

Upon your threshold does it stand,   
In every nook conspire,   
That you may whisper hand in hand   
Your tale of heart's aspire. 

Till fades the very earth and sky,   
Your heart completely broken,   
And all the world hangs on a sigh,   
A word but partly spoken. 

It follows you for weeks and weeks   
And in your soul assembles   
The memory of blushing cheeks   
And eyelash fair that trembles. 

It comes to you a sudden ray   
As though of starlight's spending,   
How many and many a time each day   
And every night unending. 

For of your life has fate decreed   
That pain shall it enfold,   
As does the clinging water-weed   
About a swimmer hold. 

Romanian:

Ce e amorul? E un lung  
Prilej pentru durere,  
Căci mii de lacrimi nu-i ajung  
Și tot mai multe cere.

De-un semn în treacăt de la ea  
El sufletul ți-l leagă,  
Încât să n-o mai poți uita  
Viața ta întreagă.

Dar încă de te-așteaptă-n prag  
În umbră de unghere,  
De se-ntâlnește drag cu drag  
Cum inima ta cere

Dispar și ceruri și pământ  
Și pieptul tău se bate,  
Și totu-atârnă de-un cuvânt  
Șoptit pe jumătate.

Te urmărește săptămâni  
Un pas făcut alene,  
O dulce strângere de mâni,  
Un tremurat de gene.

Te urmăresc luminători  
Ca soarele și luna,  
Și peste zi de-atâtea ori  
Și noaptea totdeauna.

Căci scris a fost ca viața ta  
De doru-i să nu-ncapă,  
Căci te-a cuprins asemenea  
Lianelor din apă.
