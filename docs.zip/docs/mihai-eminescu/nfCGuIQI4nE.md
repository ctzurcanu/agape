---
id: nfCGuIQI4nE
title: "Somnoroase păsărele - Sleepy birds"
sidebar_label: "Somnoroase păsărele - Sleepy birds"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/nfCGuIQI4nE"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Somnoroase păsărele - Sleepy birds

Lyrics: Mihai Eminescu

Somnoroase păsărele  
Pe la cuiburi se adună,  
Se ascund în rămurele -  
Noapte bună!

Doar izvoarele suspină,  
Pe când codrul negru tace;  
Dorm şi florile-n grădină -  
Dormi în pace!

Trece lebăda pe ape  
Între trestii să se culce -  
Fie-ţi îngerii aproape,  
Somnul dulce!

Peste-a nopţii feerie  
Se ridică mândra lună,  
Totu-i vis şi armonie -  
Noapte bună!

English:

Sleepy birds  
They gather at their nests,  
They hide in the branches -  
Good night!

Only the springs sigh,  
While the black forest is silent;  
The flowers in the garden also sleep -  
Sleep in peace!

The swan crosses the waters  
Among the reeds to sleep -  
May your angels be near,  
Sweet sleep!

Over the enchanting night  
The proud moon rises,  
It is all a dream and harmony -  
Good night!
