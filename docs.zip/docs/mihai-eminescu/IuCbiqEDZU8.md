---
id: IuCbiqEDZU8
title: "Luceafărul - The Evening Star 1"
sidebar_label: "Luceafărul - The Evening Star 1"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/IuCbiqEDZU8"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Luceafărul - The Evening Star 1

Lyrics: Mihai Eminescu

A fost odată ca-n poveşti  
A fost ca niciodată,  
Din rude mari împărăteşti,  
O prea frumoasă fată.  
   
Şi era una la părinţi  
Şi mândră-n toate cele,  
Cum e Fecioara între sfinţi  
Şi luna între stele.  
   
Din umbra falnicelor bolţi  
Ea pasul şi-l îndreaptă  
Lângă fereastră, unde-n colţ  
Luceafărul aşteaptă.  
   
Privea în zare cum pe mări  
Răsare şi străluce,  
Pe mişcătoarele cărări  
Corăbii negre duce,  
   
Îl vede azi, îl vede mâni,  
Astfel dorinţa-i gata;  
El iar, privind de săptămâni,  
Îi cade dragă fata.

Îi cade dragă fata.  
   
Cum ea pe coate-şi răzima  
Visând ale ei tâmple,  
De dorul lui şi inima  
Şi sufletu-i se împle.  
   
Şi cât de viu s-aprinde el  
În orişicare sară,  
Spre umbra negrului castel  
Când ea o să-i apară.

Când ea o să-i apară.

English:

There was, as in the fairy tales,  
As ne'er in the time's raid,  
There was, of famous royal blood  
A most beautiful maid.  
   
She was her parents' only child,  
Bright like the sun at noon,  
Like the Virgin midst the Saints  
And among stars the moon.  
   
From the deep shadow of the vaults  
Her step now she directs  
Toward a window; at its nook  
Bright Evening-star expects.  
   
She looks as in the distant seas  
He rises, darts his rays  
And leads the blackish, loaded ships  
On the wet, moving, ways.  
   
To look at him every night  
Her soul her instincts spur;  
And as he looks at her for weeks  
He falls in love with her.  
   
And as on her elbows she leans  
Her temple and her whim  
She feels in her heart and soul that  
She falls in love with him.  
   
And ev'ry night his stormy flames  
More stormily renew  
When in the shadow of the castle  
She shows to his bright view.
