---
id: TDKtwh7uZLk
title: "Călin Nebunul [IV] A"
sidebar_label: "Călin Nebunul [IV] A"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/TDKtwh7uZLk"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Călin Nebunul [IV] A

Lyrics: Mihai Eminescu

Lângă lacul cel albastru înstelat cu nuferi mari,  
Pintre trestii auroase ce se legăn solitari,  
Vede fata cea cu ochii cuvioşi ca în biseric’  
Faţa-i albă ca zăpada într-un păr de întuneric.  
Ea în haina ei cea verde se înmlădie bogată,  
Cu flori albe-mpodobită, cu diamante presărată.

— Bună vreme, fată mândră de-mpărat! — Mulţam, Căline,  
Mult îţi merge vestea-n lume, multe-am auzit de tine  
Şi prea rău de tine-mi pare c-ai venit să mori aice,  
Căci de vine zmăul numai rău ţi-a merge, măi voinice !  
— Toţi se laudă cu mâncarea. Spune-mi, fată, cât mănâncă  
Zmeul tău, să văd pe-acesta de îl pot învinge încă.  
— Doisprezece boi, antale, tot pe-atâtea, iară pâne,  
Douăsprezece cuptoare abia îi ajung să cine.  
— C-un antal de vin mai tare decât mine, zice cesta,  
Dar va da Dumnezeu sfântul să mă scap şi de acesta.

Vine zmeul, vine iute, mişcând codrii cei de aur,  
Cu cap mare ca cuptorul şi cu aripi de balaur.  
— Hei, Căline, rău de tine! strigă el şi se aruncă  
Pe voinicul care-l prinde, învârtindu-l jos în luncă.

Se luptară rău şi zmeul cît de cât să nu se deie.  
— Hei, nevastă, zice dânsul, dă-mi să beau şi dă-i să beie.

După ce mai odihniră, zise zmeul: — Măi Căline,  
Nu s-alege-ntre noi lupta, ci-ostenim aşa, vezi bine,  
Da’ m-oi face-o pară roşă şi te-i face-o pară verde  
Ş-om lupta pân’ din noi unul se va stinge şi s-a pierde.

Pară roşă este zmeul, pară verde e Călin  
Şi în galbenu-ntuneric ei se luptă cu venin.  
Se-nfăşoară, se desfăşur, mestecând a lor văpaie,  
Fulgerând umbra din codri în a flacărei bătaie,  
Joacă-n juru-le dumbrava când în umbră purpurie,  
Când încremeneşte parcă într-o brum-adînc-verzie,  
Când în dungi înflăcărate, bolţi, cărări în jur se casc  
Sub lumini de curcubeie repezi ce se sting cum nasc,  
Fâlfâiesc ca două candeli, obosiţi se-nvârt, se-ncaier  
Şi aproape-aproape stinse s-urmăresc jucând pin aer,  
Scoţând limbe ascuţite ca să-nghimpe pe cealaltă;  
Ei jucau prin crengi înalte, pintre trestie, pe baltă,  
Balta tremură adâncă, somnoros şi lin sclipeşte,  
Azvârlind, întunecată câte-o muscă, câte-un peşte  
Către flamele-ostenite... Peste ei deodată zboară  
Ca o pată de cerneală-n noaptea aurită-o cioară.

Zice zmeul: — Moaie, cioară, aripa-ţi în apă, stinge  
Flacăra cea verde, care nu-s în stare a o-nvinge.  
— Împărate pre nălţate, moaie-ţi aripa în apă,  
Zice-atunci Călin, şi stinge flacăra roşă — mă scapă.

Iară cioara, cumu-i cioară, cum aude că o urcă,  
Nici una, nici două, iute se coboară, nu se-ncurcă  
Şi lăsând din bot să-i cadă două picături de apă,  
Potoleşte para roşă, ce tresare, fuge, crapă,  
Şi cu botul o ciupeşte, curge sânge ca fier roş,  
Încât lacul cel albastru e-ncruşit ca vinul roş.  
Zmeul a murit... Se face om Călin şi se îndreaptă  
Cu trei fete-mpărătese unde fraţii îl aşteaptă.
