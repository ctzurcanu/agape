---
id: 5Eyu6Vq6-ng
title: "Of all the ships - Dintre sute de catarge"
sidebar_label: "Of all the ships - Dintre sute de catarge"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/5Eyu6Vq6-ng"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Of all the ships - Dintre sute de catarge

Lyrics: Mihai Eminescu  
Translation (from Romanian): Corneliu M. Popescu

Of all the ships the ocean rolls   
   How many find untimely graves   
Piled high by you upon the shoals,   
   O waves and winds, o winds and waves? 

How many a bird that leaves its bower   
   And o'er the sky in autumn draves   
You beat and blindly  overpower,   
   O winds and waves, o waves and winds?    
   
Should easy luck or high endeavour   
   Be our aim it little saves,   
For you pursue our footsteps ever,   
   O waves and winds, o winds and waves. 

Still, it is past our comprehending   
   What design your song enslaves,   
Rolling on until time's ending,   
   O winds and waves, o waves and winds. 

Romanian:

Dintre sute de catarge  
       Care lasă malurile,  
Câte oare le vor sparge  
       Vânturile, valurile?

Dintre pasări călătoare  
       Ce străbat pământurile,  
Câte-o să le-nece oare  
       Valurile, vânturile?

De-i goni fie norocul,  
       Fie idealurile,  
Te urmează în tot locul  
       Vânturile, valurile.

Nențeles rămâne gândul  
       Ce-ți străbate cânturile,  
Zboară vecinic, îngânându-l,  
       Valurile, vânturile.
