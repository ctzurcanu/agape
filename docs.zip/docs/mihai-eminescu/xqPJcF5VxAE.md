---
id: xqPJcF5VxAE
title: "Over the Woods - Peste vârfuri"
sidebar_label: "Over the Woods - Peste vârfuri"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/xqPJcF5VxAE"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Over the Woods - Peste vârfuri

Lyrics: Mihai Eminescu, 1884  
Translation (from Romanian): Corneliu M. Popescu

Over the woods, the moon's afloat,  
Leaves move softly in the breeze,  
Midst the branching alder trees  
Sounds the horn its plaintive note...

Over the woods, the moon's afloat,  
Leaves move softly in the breeze,  
Midst the branching alder trees  
Sounds the horn its plaintive note...

Farther through the forest deep,  
Farther yet, and yet more faint,  
Blows again its sweet complaint,  
Promise of eternal sleep.

While my heart to you is born  
Why does fade away your sound?  
Will you once for me resound  
Melancholic hunter's horn?

Romanian:

Peste vârfuri trece lună,  
Codru-și bate frunza lin,  
Dintre ramuri de arin  
Melancolic cornul sună.

Mai departe, mai departe,  
Mai încet, tot mai încet,  
Sufletu-mi nemângâiet  
Îndulcind cu dor de moarte.

De ce taci, când fermecată  
Inima-mi spre tine-ntorn?  
Mai suna-vei, dulce corn,  
Pentru mine vreodată?
