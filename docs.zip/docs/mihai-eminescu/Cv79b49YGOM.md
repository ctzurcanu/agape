---
id: Cv79b49YGOM
title: "Fair love, our mutual friend - S-a dus amorul..."
sidebar_label: "Fair love, our mutual friend - S-a dus amorul..."
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Cv79b49YGOM"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Fair love, our mutual friend - S-a dus amorul...

Lyrics: Mihai Eminescu, 1883  
Translation (from Romanian): Corneliu M. Popescu

Fair love, our mutual friend, took wing,    
That is the reason why    
My melancholy song must sing   
To all the world goodbye. 

Frail memory's cold fingertips   
Will shut the past away,   
That it no more shall cross my lips,   
Nor trough my spirit stray. 

Now many a murmuring of streams,   
How many starlit flowers,   
How many, many lover's dreams   
I've buried with the hours. 

To what unfathomed depth unknown   
Had they their roots in me;   
And, wetted by my tears, have grown,   
Beloved one, for thee. 

Through what sad torment did they rear,   
Their blossoms to fulfill;   
And o how sorry am I, dear,   
That I don't suffer still. 

But you are now forever gone,   
Death called you very far;   
And those gay eyes that glory shone   
Now full of darkness are. 

Your wistfully enchanted smile   
Did somehow know, it seem,   
To make of dream real life a while,   
And out of life a dream. 

And now I feel that you must dwell   
Where the moon brightly lights   
That country which the legends tell   
Of thousand and one nights. 

Love's mystery was too complete,   
Too gentle and too strong;   
A dream too wonderfully sweet   
That it could last for long. 

Maybe too much an angel you,   
Too little just a girl,   
That this strange ecstasy we knew   
Its wings so soon should furl. 

Too much dear one both you,   
In love's embrace were blind;   
Too much forgot the lord on high,   
Too much forgot mankind. 

Maybe indeed there is no room   
In a world filled with distress,   
Midst so much grief, and so much gloom,   
For so much happiness.

Romanian:

S-a dus amorul, un amic  
       Supus amândurora,  
Deci cânturilor mele zic  
       Adio tuturora.

Uitarea le închide-n scrin  
       Cu mâna ei cea rece,  
Și nici pe buze nu-mi mai vin,  
       Și nici prin gând mi-or trece.

Atâta murmur de izvor,  
       Atât senin de stele,  
Și un atât de trist amor  
       Am îngropat în ele!

Din ce noian îndepărtat  
       Au răsărit în mine!  
Cu câte lacrimi le-am udat,  
       Iubito, pentru tine!

Cum străbăteau atât de greu  
       Din jalea mea adâncă,  
Și cât de mult îmi pare rău  
       Că nu mai sufăr încă!

Că nu mai vrei să te arați  
       Lumină de-ndeparte,  
Cu ochii tăi întunecați  
       Renăscători de moarte!

Și cu acel smerit surâs,  
       Cu acea blândă față,  
Să faci din viața mea un vis,  
       Din visul meu o viață.

Să mi se pară cum că crești  
       De cum răsare luna,  
În umbra dulcilor povești  
       Din nopți o mie una.

Era un vis misterios  
       Și blând din cale-afară,  
Și prea era de tot frumos  
       De-au trebuit să piară.

Prea mult un înger mi-ai părut  
       Și prea puțin femeie,  
Ca fericirea ce-am avut  
       Să fi putut să steie.

Prea ne pierdusem tu și eu  
       În al ei farmec poate,  
Prea am uitat pe Dumnezeu  
       Precum uitarăm toate.

Și poate că nici este loc  
       Pe-o lume de mizerii  
Pentr-un atât de sfânt noroc  
       Străbătător durerii!
