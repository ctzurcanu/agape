---
id: K8lza0YC6YA
title: "Ode (in Sapphic metre) - Odă (în metru antic)"
sidebar_label: "Ode (in Sapphic metre) - Odă (în metru antic)"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/K8lza0YC6YA"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Ode (in Sapphic metre) - Odă (în metru antic)

Lyrics: Mihai Eminescu  
Translator: Petre Grimm

That I’m doomed to die I believed it never;  
Always young and clad in my mantle I wandered,  
Dreaming eyes uplifted for ever fixed on  
Solitude’s starlight.

When so sudden, there on my pathway rising,  
Sorrow, O so painfully sweet, thou camest!  
Then with deep delight to the dregs I drank thy  
Merciless death cup.

And like Nessus burning alive and tortured,  
Poisoned as was Hercules with his garment,  
This great fire that’s blazing in me I cannot  
Quench with an ocean.

My own dream consuming me, sore lamenting,  
On my pyre I die thus to ashes burning…  
Can I from it living arise as bright as  
Phoenix the immortal?

Troubling eyes, go out of my way for ever!  
Back to me indifference dreary come now!  
That I may in quietness die, O give me  
Back my old selfhood!

Romanian:

Nu credeam să-nvăţ a muri vrodată;  
Pururi tânăr, înfăşurat în manta-mi,  
Ochii mei nălţam visători la steaua  
Singurătăţii.

Când deodată tu răsărişi în cale-mi,  
Suferinţă tu, dureros de dulce...  
Pân-în fund băui voluptatea morţii  
Ne'ndurătoare.

Jalnic ard de viu chinuit ca Nessus.  
Ori ca Hercul înveninat de haina-i;  
Focul meu a-l stinge nu pot cu toate  
Apele mării.

De-al meu propriu vis, mistuit mă vaiet,  
Pe-al meu propriu rug, mă topesc în flăcări...  
Pot să mai re'nviu luminos din el ca  
Pasărea Phoenix?

Piară-mi ochii turburători din cale,  
Vino iar în sân, nepăsare tristă;  
Ca să pot muri liniştit, pe mine  
Mie redă-mă!
