---
id: v0BU8I-uZ74
title: "Although the World - De-or trece anii"
sidebar_label: "Although the World - De-or trece anii"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/v0BU8I-uZ74"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Although the World - De-or trece anii

Lyrics: Mihai Eminescu, 1883  
Translation (from Romanian): Corneliu M. Popescu

Although the world would call me free   
Each year the more her slave am I,   
For in her very way to be   
There's I don't know what, I don't know why. 

Already from the day we met   
Was my freedom mortal shot?   
She's but a girl as they, and yet   
There's something more, I don't know what. 

No matter what we speak, or do,   
The moments in sweet silence fly,   
For somehow there is music too   
When she is mute, I don't know why. 

So likely to my dying day   
To follow her will be my lot,   
For in her sweet and candid way   
There's I don't know why, I don't know what. 

Romanian:

De-or trece anii cum trecura,  
Ea tot mai mult îmi va place,  
Pentru ca-n toat-a ei faptura  
E-un "nu stiu cum" s-un "nu stiu ce".

M-a fermecat cu vreo scânteie  
Din clipa-n care ne vazum ?  
Desi nu e decât femeie,  
E totusi altfel, "nu stiu cum".

De-aceea una-mi este mie  
De ar vorbi, de ar tace;  
Dac-al ei glas e armonie,  
E si-n tacere-i "nu stiu ce".

Astfel robit de-aceeasi jale  
Petrec mereu acelasi drum...  
In taina farmecelor sale  
E-un "nu stiu ce" s-un "nu stiu cum".
