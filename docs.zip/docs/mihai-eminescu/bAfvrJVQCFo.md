---
id: bAfvrJVQCFo
title: "Dintre sute de catarge - Among hundreds of masts"
sidebar_label: "Dintre sute de catarge - Among hundreds of masts"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/bAfvrJVQCFo"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Dintre sute de catarge - Among hundreds of masts

Lyrics: Mihai Eminescu

Dintre sute de catarge  
Care lasă malurile,  
Câte oare le vor sparge  
Vânturile, valurile?

Dintre pasări călătoare  
Ce străbat pământurile,  
Câte-o să le-nece oare  
Valurile, vânturile?

De-i goni fie norocul,  
Fie idealurile,  
Te urmează în tot locul  
Vânturile, valurile.

Nențeles rămâne gândul  
Ce-ți străbate cânturile,  
Zboară vecinic, îngânându-l,  
Valurile, vânturile.

Vânturile...

English:

Among the hundreds of masts  
That leave the shores,  
How many will be broken  
By the winds, the waves?

Among the migratory birds  
That traverse the lands,  
How many will be drowned  
By the waves, the winds?

Whether you chase away luck,  
Or ideals,  
Follow you everywhere  
By the winds, the waves.

The thought remains unintelligible  
That traverses your songs,  
Flying eternally, singing it,  
By the waves, the winds.

By the winds...
