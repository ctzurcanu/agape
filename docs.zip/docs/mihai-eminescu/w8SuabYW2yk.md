---
id: w8SuabYW2yk
title: "O, rămâi... - Oh, stay..."
sidebar_label: "O, rămâi... - Oh, stay..."
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/w8SuabYW2yk"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## O, rămâi... - Oh, stay...

Versuri: Mihai Eminescu, 1879

"O, rămâi, rămâi la mine,  
Te iubesc atât de mult!  
Ale tale doruri toate  
Numai eu ştiu să le-ascult;

În al umbrei întuneric  
Te asamăn unui prinţ,  
Ce se uit-adânc în ape  
Cu ochi negri şi cuminţi;

Şi prin vuietul de valuri,  
Prin mişcarea naltei ierbi,  
Eu te fac s-auzi în taină  
Mersul cârdului de cerbi;

Eu te văd răpit de farmec  
Cum îngâni cu glas domol,  
În a apei strălucire  
Întinzând piciorul gol

Şi privind în luna plină  
La văpaia de pe lacuri,  
Anii tăi se par ca clipe,  
Clipe dulci se par ca veacuri."

Astfel zise lin pădurea,  
Bolţi asupră-mi clătinând;  
Şuieram l-a ei chemare  
Ş-am ieşit în câmp râzând.

Astăzi chiar de m-aş întoarce  
A-nţelege n-o mai pot...  
Unde eşti, copilărie,  
Cu pădurea ta cu tot?

Unde eşti, copilărie,  
Cu pădurea ta cu tot?

English:

"Oh, stay, stay with me,  
I love you so much!  
All your longings  
Only I know how to listen to them;

In the darkness of the shadow  
I liken you to a prince,  
Who looks deep into the waters  
With black and gentle eyes;

And through the roar of the waves,  
Through the movement of the tall grass,  
I make you hear in secret  
The gait of the herd of deer;

I see you captivated by charm  
How you hum with a soft voice,  
In the brilliance of the water  
Stretching your bare foot  
And looking in the full moon  
At the flame on the lakes,  
Your years seem like moments,  
Sweet moments seem like centuries."

Thus spoke the forest softly,  
Vaults swaying above me;  
I hissed at its call  
And I went out into the field laughing.

Today even if I were to return  
I can't understand it anymore...  
Where are you, childhood,  
With your forest and everything?

Where are you, childhood,  
With your forest and everything?
