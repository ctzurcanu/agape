---
id: be2363DT2ek
title: "Luceafărul - The Evening Star 2.2"
sidebar_label: "Luceafărul - The Evening Star 2.2"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/be2363DT2ek"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Luceafărul - The Evening Star 2.2

Lyrics: Mihai Eminescu

Uşor el trece ca pe prag  
Pe marginea ferestei  
Şi ţine-n mână un toiag  
Încununat cu trestii.

Părea un tânăr voievod  
Cu păr de aur moale,  
Un vânăt giulgi se-ncheie nod  
Pe umerele goale.

Iar umbra feţei străvezii  
E albă ca de ceară –  
Un mort frumos cu ochii vii  
Ce scânteie-n afară.

– Din sfera mea venii cu greu  
Ca să-ţi urmez chemarea,  
Iar cerul este tatăl meu  
Şi muma-mea e marea.

Ca în cămara ta să vin,  
Să te privesc de-aproape,  
Am coborât cu-al meu senin  
Şi m-am născut din ape.

O, vin’! odorul meu nespus,  
Şi lumea ta o lasă;  
Eu sunt luceafărul de sus,  
Iar tu să-mi fii mireasă.

Iar tu să-mi fii mireasă.

Colo-n palate de mărgean  
Te-oi duce veacuri multe,  
Şi toată lumea-n ocean  
De tine o s-asculte.

– O, eşti frumos, cum numa-n vis  
Un înger se arată,  
Dară pe calea ce-ai deschis  
N-oi merge niciodată;

Străin la vorba şi la port,  
Luceşti fără de viaţă,  
Căci eu sunt vie, tu eşti mort,  
Şi ochiul tău mă-ngheaţă.

Şi ochiul tău mă-ngheaţă.

English:

As on a threshold o'er the sill  
His hasty steps he leads,  
Holds in his hand a staff with, at  
Its top, a crown of reeds!  
   
A young Voivode he seems to be  
With soft and golden hair;  
A blue shroud binds in a knot on  
His naked shoulder fair.  
   
The shade of his face is of wax  
And thou canst see throughout -  
A handsome dead man with live eyes  
That throw their sparkles out.  
   
-"From my sphere hardly I come to  
Follow thy call and thee,  
The heaven is my father and  
My mother is the sea.  
   
So that I could come to thy room  
And look at thee from near  
With my light reborn from waves my  
Fate toward thee I steer.  
   
O come, my treasure wonderful  
And thy world leave aside;  
For I am Evening-star up from  
And thou wouldst be my bride.

And thou wouldst be my bride.  
   
In my palace of coral I'll  
Take thee for evermore  
And the entire world of the sea  
Will kneel before thy door."  
   
-"O thou art beautiful as but  
In dreams an angel shows,  
The way though thou hast oped for me  
For me's for ever close.  
   
Thy port and mien and speech are strange  
Life thy gleams don't impart,  
For I'm alive and thou art dead  
And thy eyes chill my heart."

"And thy eyes chill my heart."
