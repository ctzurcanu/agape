---
id: lH2FrgeM8R4
title: "The Evening Star - Luceafărul 5.1"
sidebar_label: "The Evening Star - Luceafărul 5.1"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/lH2FrgeM8R4"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## The Evening Star - Luceafărul 5.1

Lyrics: Mihai Eminescu

The Evening Star began to rise,  
Its wings grew in the skies,  
Billions light-years would pass  
In a fleeting moments' guise.

Beneath him lay a starry dome,  
Above, the cosmos in a mayhem —  
He seems a flash of timeless eon  
That's wandering through them.

From the valleys ringing hollow,  
Circled by chaoses that follow,  
He saw as if it was day one,  
How lights broke out of them when done.

They surged and circled him around,  
Like seas that swim, in waves —  
He flew, a thought borne in desire,  
Until all vanished, without trace.

For where he reached, no bounds exist,  
No eyes to comprehend,  
And Time attempts in vain to birth  
From voids of no end.

There is no thing, and yet there is,  
A thirst that pulls, devours —  
Abysses that blindly forget,  
Eternity’s last hours.

"Release me, Father, from the weight  
Of this eternal night,  
And ever-praised be your name  
Immersed be worlds in foresight.

Immersed be worlds in foresight.

Oh, Lord, demand of me all cost,  
But grant to me new fate,  
For you’re the source and the exhaust,  
The keeper of the timeless state.

Take back the halo from my forehead,  
The fire in my sight,  
And in return, let me drop dead  
In momentary love’s delight.

From chaos, Lord, I came to be,  
To chaos, I’d descend —  
From restlessness I was conceived,  
In perfect rest I seek my end.

In perfect rest I seek my end."
