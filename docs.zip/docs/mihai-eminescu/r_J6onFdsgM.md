---
id: r_J6onFdsgM
title: "Călin (file din poveste) - Călin (pages from the story) 5"
sidebar_label: "Călin (file din poveste) - Călin (pages from the story) 5"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/r_J6onFdsgM"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Călin (file din poveste) - Călin (pages from the story) 5

Versuri: Mihai Eminescu, 1876

S-au făcut ca ceara albă fața roșă ca un măr  
Și atâta de subțire, să o tai c-un fir de păr.  
Și cosița ta bălaie o aduni la ochi plângând,  
Inimă făr' de nădejde, suflete bătut de gând.  
Toată ziua la fereastră, suspinând, nu spui nimic,  
Ridicând a tale gene, al tău suflet se ridică;  
Urmărind pe ceruri limpezi cum plutește-o ciocârlie,  
Tu ai vrea să spui să ducă cătră dânsul o solie,  
Dar ea zboară... tu cu ochiul plutitor și-ntunecos  
Stai cu buze discleștate de un tremur dureros.  
Nu-ți mai scurge ochii tineri, dulcii cerului fiaștri,  
Nu uita că-n lacrimi este taina ochilor albaștri.  
Stele rare din tărie cad ca picuri de argint,  
Și seninul cer albastru mândru lacrimile-l prind;  
Dar dacă ar cădea toate, el rămâne trist și gol,  
N-ai putea sa faci cu ochii înălțimilor ocol -  
Noaptea stelelor, a lunei, a oglinzilor de râu  
Nu-i ca noaptea cea mocnită și pustie din sicriu;  
Și din când în când vărsate, mândru lacrimele-ți șed,  
Dar de seci întreg isvorul, atunci cum o să te văd?  
Prin ei curge rumenirea, mândră ca de trandafiri,  
Și zăpada viorie din obrajii tăi subțiri -  
Apoi noaptea lor albastră, a lor dulce vecinicie,  
Ce ușor se mistuiește prin plânsorile pustie...  
Cine e nerod să ardă în cărbuni smarandul rar  
Ș-a lui vecinică lucire s-o strivească în zadar?  
Tu-ți arzi ochii și frumseța... Dulce noaptea lor se stânge,  
Și nici știi ce pierde lumea. Nu mai plânge, nu mai plânge!

English:

They became like white wax, the face red as an apple  
And so thin, to cut it with a hair.  
And you gather your blond braid to your eyes, crying,  
Heart without hope, soul beaten by thoughts.  
All day at the window, sighing, you say nothing,  
Raising your eyelashes, your soul rises;  
Watching a lark float in the clear skies,  
You would like to say to bring him a message,  
But she flies... you with your floating and dark eye  
Stand with lips torn by a painful tremor.  
Stop shedding your young eyes, the sweet ones of the clear sky,  
Don't forget that in tears is the secret of blue eyes.  
Rare stars from strength fall like silver drops,  
And the clear blue sky, proud, tears catch it;  
But if all were to fall, it remains sad and empty,  
You could not make a detour with your eyes to the heights -  
The night of the stars, of the moon, of the river mirrors  
It is not like the smoldering and deserted night in the coffin;  
And from time to time, your tears shed, proudly,  
But if the whole spring dries up, then how will I see you?  
Through them flows the blush, proud as roses,  
And the violet snow from your thin cheeks -  
Then their blue night, their sweet eternity,  
How easily it is consumed by deserted tears...  
Who is foolish enough to burn the rare myrrh in coals  
And crush its eternal shine in vain?  
You burn your eyes and beauty... Their sweet night shrinks,  
And you do not know what the world loses. Don't cry anymore, don't cry anymore!
