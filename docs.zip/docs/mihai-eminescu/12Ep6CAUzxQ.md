---
id: 12Ep6CAUzxQ
title: "Stelele-n cer - The stars in the sky"
sidebar_label: "Stelele-n cer - The stars in the sky"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/12Ep6CAUzxQ"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Stelele-n cer - The stars in the sky

Lyrics: Mihai Eminescu

Stelele-n cer  
Deasupra mărilor  
Ard depărtărilor  
       Până ce pier.

După un semn  
Clătind catargele,  
Tremură largele  
       Vase de lemn;

Niște cetăți  
Plutind pe marile  
Și mișcătoarele  
       Pustietăți.

Stol de cocori  
Apucă-ntinsele  
Și necuprinsele  
       Drumuri de nori.

Zboară ce pot  
Și-a lor întrecere,  
Vecinică trecere ­  
       Asta e tot...

Floare de crâng,  
Astfel viețile  
Și tinerețile  
       Trec și se stâng.

Orice noroc  
Și-ntinde-aripele  
Gonit de clipele  
       Stării pe loc.

Până nu mor,  
Pleacă-te, îngere,  
La trista-mi plângere  
       Plină de-amor.

Nu e păcat  
Ca să se lepede  
Clipa cea repede  
       Ce ni s-a dat?

English:

The stars in the sky  
Above the seas  
Burn the distances  
Until they perish.

After a sign  
Shaking the masts,  
The large  
Wooden vessels tremble;

Some cities  
Floating on the great  
And moving  
Deserts.

Flocks of cranes  
Grab the vast  
And the unfathomable  
Roads of clouds.

They fly as much as they can  
And their own competition,  
Eternal passage  
That's all...

Flower of the grove,  
Thus lives  
And youths  
Pass and leave.

Any luck  
And-spreads-their-wings  
Chased by the moments  
Of staying in one place.

Until I die,  
Go, angel,  
To my sad lament  
Full of love.

Isn't it a sin  
To reject  
The quick moment  
What was given to us?
