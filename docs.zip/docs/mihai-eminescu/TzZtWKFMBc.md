---
id: _TzZtWKFMBc
title: "Luceafărul - The Evening Star 4.1"
sidebar_label: "Luceafărul - The Evening Star 4.1"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/_TzZtWKFMBc"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Luceafărul - The Evening Star 4.1

Lyrics: Mihai Eminescu

În vremea asta Cătălin,  
Viclean copil de casă,  
Ce împle cupele cu vin  
Mesenilor la masă,  
   
Un paj ce poartă pas cu pas  
A-mpărătesei rochii,  
Băiat din flori şi de pripas  
Dar îndrăzneţ cu ochii,  
   
Cu obrăjori ca doi bujori  
De rumeni, bată-i vina,  
Se furişeaza pânditor  
Privind la Cătălina.  
   
Dar ce frumoasă se făcu  
Şi mândră, arz-o focul;  
Ei Cătălin, acu i-acu  
Ca să-ţi încerci norocul.  
   
Şi-n treacăt o cuprinse lin  
Într-un ungher degrabă.  
– Da’ ce vrei, mări Cătălin?  
Ia du-t’ de-ţi vezi de treabă.  
   
– Ce voi? Aş vrea să nu mai stai  
Pe gânduri totdeauna,  
Să râzi mai bine şi să-mi dai  
O gură, numai una.  
   
– Dar nici nu ştiu măcar ce-mi ceri,  
Dă-mi pace, fugi departe –  
O, de luceafărul din cer  
M-a prins un dor de moarte.  
   
– Dacă nu ştii, ţi-aş arăta  
Din bob în bob amorul,  
Ci numai nu te mânia,  
Ci stai cu binişorul.

Ci stai cu binişorul.  
   
Cum vânătoru-ntinde-n crâng  
La păsărele laţul,  
Când ţi-oi întinde braţul stâng  
Să mă cuprinzi cu braţul;  
   
Şi ochii tăi nemişcători  
Sub ochii mei rămâie...  
De te înalţ de subsuori  
Te-nalţă din călcâie;  
   
Când faţa mea se pleacă-n jos,  
În sus rămâi cu faţa,  
Să ne privim nesăţios  
Şi dulce toată viaţa;  
   
Şi ca să-ţi fie pe deplin  
Iubirea cunoscută,  
Când sărutându-te mă-nclin,  
Tu iarăşi mă sărută.

Tu iarăşi mă sărută.

English:

Meanwhile, the house-boy, Catalin,  
Sly, and who often jests  
When he's filling with wine the cups  
Of the banqueting guests;  
   
A page that carries step by step  
The trail of the Queen's gown,  
A wandering bastard, but bold  
Like no one in the town;  
   
His little cheek - a peony  
That under the sun stews;  
Watchful, just like a thief, he sneaks  
In Catalina's views.  
   
-"How beautiful she grew" - thinks he -  
"A flower just to pluck!  
Now, Catalin, but now it is  
Thy chance to try thy luck!"  
   
And by the way, hurriedly, he  
Corners that human fay:  
-"What's with thee, Catalin? Let me  
Alone and go thy way!"  
   
-"No! I want thee to stay away  
From thoughts that have no fun  
. I want to see thee only laugh,  
Give me a kiss, just one!"  
   
-"I don't know what it is about  
And, believe me, retire!  
But for one Evening-star up from  
I've kept my strong desire!"  
   
-"If thou dost not know I could show  
Thee all about love's balm!  
Only, don't give way to thy ire  
And listen and be calm.  
   
So as the hunter throws the net  
That many birds would harm,  
When I'll stretch my left arm to thee,  
Enlace me with thy arm.  
   
Under my eyes keep thine and don't  
Let them move on their wheels  
And if I lift thee by the waist  
Thou must lift on thy heels.  
   
When I bend down my face, to hold  
Thine up must be thy strife;  
So, to each other we could throw  
Sweet, eager, looks for life.  
   
And so that thou have about love  
A knowledge true and plain,  
When I stoop to kiss thee, thou must  
Kiss me too and again."
