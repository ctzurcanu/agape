---
id: aWEcF1KqRcs
title: "Mai am un singur dor - I have only one more wish"
sidebar_label: "Mai am un singur dor - I have only one more wish"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/aWEcF1KqRcs"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Mai am un singur dor - I have only one more wish

Lyrics: Mihai Eminescu

Mai am un singur dor:  
În liniştea serii  
Să mă lăsaţi să mor  
La marginea mării;

Să-mi fie somnul lin  
Şi codrul aproape,  
Pe-ntinsele ape  
Să am un cer senin.

Nu-mi trebuie flamuri,  
Nu voi sicriu bogat,  
Ci-mi împletiţi un pat  
Din tinere ramuri.

Şi nime-n urma mea  
Nu-mi plângă la creştet,  
Doar toamna glas să dea  
Frunzişului veşted.

Pe când cu zgomot cad  
Izvoarele-ntruna,  
Alunece luna  
Prin vârfuri lungi de brad.

Pătrunză talanga  
Al serii rece vânt,  
Deasupră-mi teiul sfânt  
Să-şi scuture creanga.

Cum n-oi mai fi pribeag  
De-atunci înainte,  
M-or troieni cu drag  
Aduceri aminte.

Luceferi, ce răsar  
Din umbră de cetini,  
Fiindu-mi prieteni,  
O să-mi zâmbească iar.

Va geme de patemi  
Al mării aspru cânt...  
Ci eu voi fi pământ  
În singurătate-mi.

Ci eu voi fi pământ  
În singurătate-mi.

Ci eu voi fi pământ  
În singurătate-mi.

English:

I have only one more wish:  
In the silence of the evening  
Let me die  
At the edge of the sea;

May my sleep be peaceful  
And the forest near,  
On the vast waters  
Let me have a clear sky.

I don't need flags,  
I don't want a rich coffin,  
But weave me a bed  
From young branches.

And no one after me  
Lets cry at my head,  
Only autumn gives voice  
To the withered foliage.

While the  
everlasting springs fall with a noise,  
The moon glides  
Through the long tops of the fir trees.

The cold wind of the evening penetrates  
The sacred linden tree  
To shake its branch above me.

Since I will no longer be a wanderer  
From then on,  
I will cherish  
My Trojans with fondness  
Remembrances.

The stars, rising  
From the shadow of the mountains,  
Being my friends,  
Will smile at me again.

Will groan with passion  
The harsh sea sings...  
But I will be earth  
In my solitude.

But I will be earth  
In my solitude.

But I will be earth  
In my solitude.
