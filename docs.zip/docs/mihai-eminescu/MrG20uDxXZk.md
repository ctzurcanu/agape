---
id: MrG20uDxXZk
title: "Drowsy Birds - Somnoroase păsărele"
sidebar_label: "Drowsy Birds - Somnoroase păsărele"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/MrG20uDxXZk"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Drowsy Birds - Somnoroase păsărele

Lyrics: Mihai Eminescu  
Translation (from Romanian): Corneliu M. Popescu

Drowsy birds at even gliding,    
Round about their nests alight,   
In among the branches hiding . . .   
  Dear, good night! 

Silence through the forest creeping,   
Lullaby the river sighs;   
In the garden flowers sleeping. . .   
  Shut your eyes! 

Glides the swan among the rushes   
To its rest where moonlight gleams,   
And the angels' whisper hushes. . .   
  Peaceful dreams! 

O'er the sky stars without number,   
On the earth a silver light;   
All is harmony and slumber . . .   
  Dear, good night! 

Romanian:

Somnoroase păsărele  
Pe la cuiburi se adună,  
Se ascund în rămurele -  
  Noapte bună!

Doar isvoarele suspină,  
Pe când codrul negru tace;  
Dorm și florile-n grădină -  
  Dormi în pace!

Trece lebăda pe ape  
Între trestii să se culce -  
Fie-ți îngerii aproape,  
  Somnul dulce!

Peste-a nopții feerie  
Se ridică mândra lună,  
Totu-i vis și armonie -  
  Noapte bună!
