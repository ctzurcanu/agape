---
id: xxktydeHNv4
title: "La steaua - To the star"
sidebar_label: "La steaua - To the star"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/xxktydeHNv4"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La steaua - To the star

Lyrics: Mihai Eminescu

La steaua care-a răsărit  
E-o cale-atât de lungă,  
Că mii de ani i-au trebuit  
Luminii să ne-ajungă.

Poate de mult s-a stins în drum  
În depărtări albastre,  
Iar raza ei abia acum  
Luci vederii noastre.

Icoana stelei ce-a murit  
Încet pe cer se suie :  
Era pe când nu s-a zărit,  
Azi o vedem, și nu e.

Tot astfel când al nostru dor  
Pieri în noapte-adâncă,  
Lumina stinsului amor  
Ne urmărește încă.

English:

To the star that rose  
There is such a long way,  
That it took thousands of years  
For the light to reach us.

Perhaps it has long since faded away  
In the blue distance,  
And its ray only now  
Lights our sight.

The icon of the star that died  
Slowly rises in the sky:  
It was when it was not seen,  
Today we see it, and it is not.

Just like that when our longing  
Lost in the deep night,  
The light of extinguished love  
Still pursues us.
