---
id: bbkDCtnN6KY
title: "Rugăciune - Prayer"
sidebar_label: "Rugăciune - Prayer"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/bbkDCtnN6KY"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Rugăciune - Prayer

Lyrics: Mihai Eminescu

Crăiasă alegându-te  
Îngenunchem rugându-te,  
Înalţă-ne, ne mântuie  
Din valul ce ne bântuie;  
Fii scut de întărire  
Şi zid de mântuire,  
Privirea-ţi adorată  
Asupra-ne coboară,  
O, Maică prea curată  
Şi pururea fecioară,  
Marie!

Noi, cei din mila Sfântului  
Umbră facem pământului,  
Rugămu-ne ndurărilor,  
Luceafărului mărilor;  
Ascultă-a noastre plângeri,  
Regină peste îngeri,  
Din neguri te arată,  
Lumină dulce clară,  
O, Maică prea curată  
Şi pururea fecioară,  
Marie!

English:

Queen choosing you  
We kneel down praying to you,  
Raise us, save us  
From the wave that haunts us;  
Be a shield of strength  
And a wall of salvation,  
Your adored gaze  
Upon us descend,  
O, Mother most pure  
And ever virgin,  
Mary!

We, those in the mercy of the Holy  
We make a shadow to the earth,  
Pray for mercy,  
The Star of the seas;  
Hear our complaints,  
Queen over angels,  
From the mists show you,  
A sweet clear light,  
O, Mother most pure  
And ever virgin,  
Mary!
