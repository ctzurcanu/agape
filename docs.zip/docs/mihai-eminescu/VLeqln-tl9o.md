---
id: VLeqln-tl9o
title: "Călin Nebunul [I] B - Calin the Fool [I] B"
sidebar_label: "Călin Nebunul [I] B - Calin the Fool [I] B"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/VLeqln-tl9o"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Călin Nebunul [I] B - Calin the Fool [I] B

Lyrics: Mihai Eminescu

Mers-au ca vo două zile, ş-au găsit. Cel mijlociu  
Aruncă şi tot pe-atâta, ba ş-oleacă mai târziu.  
Dară când zvârli nebunul, mers-au ei trei luni de-a rând,  
Zi şi noapte, pân’ găsiră-a lui săgeată în pământ.  
Ş-ajungând au scos amnarul, au scos cremene şi iască,  
Ca s-aţâţe foc în codru, să se-ntindă s-odihnească.

Dar întâi se sfătuiră ca pe rând să steie pază  
Şi pe foc să puie vreascuri, a se stinge să nu-l lase,  
Hotărând ca celui care va lăsa să se potoale,  
Va lăsa să-i prindă noaptea, ei să-i puie capu-n poale.

Se culcară doi. Cel mare să păzească au rămas.  
Dară pe la miez de noapte auzi-n văzduh un glas.  
Vine-un zmeu în solzi de criţă cu trei capete, şi lui:  
— Cum de calci moşia tatei făr' de voia nimărui?

Hai la luptă... Se luptară şi-l lovi voinicul rău,  
Făcu trei căpiţi de carne din trei capete de zmeu,  
Şi când cei doi se treziră: — Uite, voi cât aţi dormit,  
Ce mai lupt-avui grozavă şi ce treab-am isprăvit!

A rămas în noapte-a doua ca strejăriu cel mijlociu  
Şi tot pe la miezul nopţii prin văzduh aude-un chiu  
Şi pin vânt văzu cu-aripe sunătoare, fioroase  
Patru capete cumplite pe două umere groase.

— Hai la luptă, măi voinice, cum făcuşi de te văzui,  
Cum de calci moşia tatei făr’ de voia nimărui?  
Dar voinicul îl omoară şi, ca vai de mama lui,  
Patru clăi de carne face el din capetele lui.

Când cei doi iar se treziră, au văzut a lui ispravă,  
Izbândirea strălucită dintr-o lupt-aşa grozavă.  
Şi când iar i-apucă noaptea, lui Călin de grijă-i dară  
Să păzească bine focul de a nopţii crunte fiară.

Când acum în noaptea-a treia străjuia Călin, deodată,  
Auzi un vuiet mare şi-nainte i se-arată  
Cu opt capete cumplite un zmeu mândru năzdrăvan,  
Cu ochi roşii de jeratec şi cu sufletul avan.

— Haide-ha, Călin Nebune! Cum venişi nu te-i întoarce,  
Nici s-a fierbe pentru tine, nici s-a ţese, nici s-a toarce!  
Se luptă Călin Nebunul mai ca sufletul să-i steie,  
Iară zmeul cel puternic cât de cât să nu se deie.

El tăindu-i o ureche, cade-n foc un strop de sânge  
Şi în noaptea cea adâncă tot jeratecul se stinge  
Şi în negrul întuneric într-o luptă oarbă, crudă,  
Mâni de fier în piept i-nfige; zmeul ostenit asudă,  
Gâfâie pe cele-opt gâturi, sub genunchi Călin îl ţine  
Şi cu sabia-i ratează a lui capete păgâne!

English:

They walked for two days, they found it. The middle one  
Threw and threw it, and later they would lie down.  
But when the fool threw it, they walked for three months in a row,  
Day and night, until they found his arrow in the ground.  
And arriving they took out the almshouse, they took out flints and sticks,  
To light a fire in the forest, to lie down to rest.

But first they decided to take turns to stand guard  
And to put sticks on the fire, to not let it go out,  
Deciding that whoever would let it calm down,  
He would let the night catch up with him, they would lay their head in his lap.

The two of them went to bed. The eldest stayed to guard.  
But around midnight they heard a voice in the air.  
A kite with three heads in chalk scales came, and to him:  
— How dare you trample on your father's estate without anyone's will?

Come to the fight... They fought and the evil strongman struck him,  
He made three heads of meat from the three kite heads,  
And when the two woke up: — Look, how long have you slept,  
What a great fight you had and what a job we have done!

The middle one stayed on guard for the second night  
And also at midnight he heard a chirping sound in the air  
And in the wind he saw with ringing, fierce wings  
Four terrible heads on two thick shoulders.

— Come to the fight, mighty one, how did you manage to see yourself,  
How dare you trample on your father's estate without anyone's will?  
But the strong man kills him and, as if he were his mother,  
He makes four meatloafs of his heads.

When the two woke up again, they saw his feat,  
The brilliant victory from such a terrible fight.  
And when night fell again, Călin's care was given  
To guard the fire well from the cruel beast of the night.

When now on the third night Călin was guarding, suddenly,  
He heard a great roar and before him appeared  
With eight terrible heads a proud, fierce dragon,  
With eyes red with fire and with a soul abounding.

— Come on, Călin the Fool! As you came, don't turn back,  
Neither to boil for you, nor to weave, nor to spin!  
Calin the Madman fights as if his soul would die,  
And the mighty kite barely manages not to break.

He cuts off one of its ears, a drop of blood falls into the fire  
And in the deep night all the fire is extinguished  
And in the black darkness in a blind, cruel fight,  
He thrusts iron hands into its chest; the tired kite sweats,  
He gasps on the eight necks, Calin holds it under his knees  
And with his sword he misses its pagan heads!
