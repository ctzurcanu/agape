---
id: W5GPd2lPNfA
title: "Over Treetops - Peste vârfuri"
sidebar_label: "Over Treetops - Peste vârfuri"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/W5GPd2lPNfA"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Over Treetops - Peste vârfuri

Lyrics: Mihai Eminescu, 1884  
Translation (from Romanian): Adrian George Sahlean

Over treetops, white moon wanders,  
Forest boughs shake gentle leaf,  
Sounds a horn with distant grief,  
Alders bow their heads asunder.

Far away and ever farther,  
Softer still, its fading breath  
Soothing with a dream of death  
My soul’s unrequited ardor.

Why your music from me sever  
When I turn to you forlorn—  
Will you sound again sweet horn  
For my soul’s enchantment, ever?

Romanian:

Peste vârfuri trece lună,  
Codru-și bate frunza lin,  
Dintre ramuri de arin  
Melancolic cornul sună.

Mai departe, mai departe,  
Mai încet, tot mai încet,  
Sufletu-mi nemângâiet  
Îndulcind cu dor de moarte.

De ce taci, când fermecată  
Inima-mi spre tine-ntorn?  
Mai suna-vei, dulce corn,  
Pentru mine vreodată?
