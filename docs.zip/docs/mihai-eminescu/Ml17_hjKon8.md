---
id: Ml17_hjKon8
title: "The Murmur of the Forest - Freamăt de codru"
sidebar_label: "The Murmur of the Forest - Freamăt de codru"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Ml17_hjKon8"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## The Murmur of the Forest - Freamăt de codru

Lyrics: Mihai Eminescu  
Translation (from Romanian): Corneliu M. Popescu

On the pond bright sparks are falling,   
Wavelets in the sunlight glisten;   
Gazing on the woods with rapture,   
Do I let my spirit capture   
Drowsiness, and lie and listen...   
Quails are calling.  

All the silent water sleeping   
Of the streams and of the rivers;   
Only where the sun is shining   
Thousand circles there designing   
As with fright its surface shivers,   
Swiftly leaping.  

Pipe the birds midst woods concealing,   
Which of us their language guessing?   
Birds of endless kinds and races   
Chirp amidst its leafy places   
And what wisdom they expressing   
And what feeling.  

Asks the cuckoo: "Who has seen   
Our beloved summer idol ,   
Beautiful beyond all praising   
Through her languid lashes gazing,   
Pur most lovely, tender, bridal,   
Forest queen ?"  

Bends the lime with gentle care   
Her sweet body to embower ;   
In the breeze his branches singing   
Lift her in their arms upswinging,   
While a hundred blossoms shower   
On her hair.  

Asks the brooklet as it flows :   
" Where has gone my lovely lady?    
She, who evening hour beguiling,   
In my silver surface smiling,   
Broke its mirror deep and shady   
With her toes ?"  

I replied:" O forest, she    
Comes no more, no more returning!   
Only you, great oaks, still dreaming   
Violet eyes, like flowers gleaming,   
That the summer through were yearning   
Just for me."  

Happy then, alone we twain,   
Through the forest brush-wood striding!   
Sweet enchanted tale of wonder   
That the darkness broke asunder...   
Dear, wherever you'd be hiding,   
Come again!  

I replied:" O forest, she    
Comes no more, no more returning!   
Only you, great oaks, still dreaming   
Violet eyes, like flowers gleaming,   
That the summer through were yearning   
Just for me."  

Happy then, alone we twain,   
Through the forest brush-wood striding!   
Sweet enchanted tale of wonder   
That the darkness broke asunder...   
Dear, wherever you'd be hiding,   
Come again!  

Romanian:

Tresărind scânteie lacul  
Și se leagănă sub soare;  
Eu, privindu-l din pădure,  
Las aleanul să mă fure  
Și ascult de la răcoare  
                       Pitpalacul.

Din isvoare și din gârle  
Apa sună somnoroasă;  
Unde soarele pătrunde  
Pintre ramuri a ei unde,  
Ea în valuri sperioase  
                       Se azvârle.

Cucul cântă, mierle, presuri -  
Cine știe să le-asculte?  
Ale pasărilor neamuri  
Ciripesc pitite-n ramuri  
Și vorbesc cu-atât de multe  
                       Înțelesuri.

Cucu-ntreabă: - "Unde-i sora  
Viselor noastre de vară?  
Mlădioasă și iubită,  
Cu privirea ostenită,  
Ca o zână să răsară  
                       Tuturora."

Teiul vechi un ram întins-a,  
Ea să poată să-l îndoaie,  
Ramul tânăr vânt să-și deie  
Și de brațe-n sus s-o ieie,  
Iară florile să ploaie  
                       Peste dânsa.

Se întreabă trist isvorul  
– „Unde mi-i crăiasa oare?  
Părul moale despletindu-și,  
Fața-n apa mea privindu-și,  
Să m-atingă visătoare  
                       Cu piciorul?"

Am răspuns: - "Pădure dragă,  
Ea nu vine, nu mai vine!  
Singuri, voi, stejari, rămâneți  
De visați la ochii vineți,  
Ce luciră pentru mine  
                       Vara-ntreagă."

Ce frumos era în crânguri,  
Când cu ea m-am prins tovarăș!  
O poveste încântată  
Care azi e-ntunecată...  
De-unde ești, revino iarăși,  
                       Să fim singuri.
