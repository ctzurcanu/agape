---
id: k4Sx4GN6vMU
title: "What is Love?"
sidebar_label: "What is Love?"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/k4Sx4GN6vMU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## What is Love?

Lyrics: Mihai Eminescu  
Translation (from Romanian): Petre Grimm

O, what is love? It is a cause  
Of pain so long and sore,  
That though thou shedd’st a million tears  
It still will ask for more.

A passing token but from her  
Forever binds thy soul,  
And never wilt forget her now,  
Thy life is hers, the whole.

But when on threshold there for thee,  
Or in the shady nooks,  
Fulfilling all thy hearts desire,  
She waits with longing looks,

Then earth and heavens disappear,  
And throbbing is thy heart,  
All hangs on a half-whispered word,  
New life with it doth start.

A pressure of the hand so sweet,  
An eyelash twinkling, nay,  
A lazy gait, an aimless word,  
Pursues thee night and day.

And eyes pursue thee, light thy way,  
Like sun and moon so bright,  
And wheresoever, night and day  
They are thy only light.

And it was doomed that all thy life  
For her alone shall long,  
For like the water bindweed she  
Has caught thy soul so strong.
