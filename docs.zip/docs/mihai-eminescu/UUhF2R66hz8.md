---
id: UUhF2R66hz8
title: "The Evening Star 6 - Luceafărul 6 v2"
sidebar_label: "The Evening Star 6 - Luceafărul 6 v2"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/UUhF2R66hz8"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## The Evening Star 6 - Luceafărul 6 v2

Lyrics: Mihai Eminescu  
Translator (from Romanian): Octavian Cocoş

And in his place again he stays  
For in the sky returns  
And like in all the other days  
His light in distance burns.

Now it is evening all around  
Soon will begin the night;  
The moon is rising, there's no sound,  
The sea reflects its light.

And with its sparks borne by the breeze  
It fills the forest lands;  
Beneath a row of linden trees  
Two youngsters hold their hands:

– O, baby, let my head to lie  
Upon your breasts with care  
And look at me with your sweet eye,  
Which is so clear and fair;

Then with the charm of the cold light  
Go deep into my brain,  
Pour the deep silence of the night  
Over my pangs of pain.

Don't go away, but stay above  
And stop the sorrow stream,  
You are my first and caring love,  
But also my last dream.

Hyperion sees from the skies  
Amazement on their face:  
When his warm hand on her neck lies  
She gives him an embrace...

The scent of lindens quickly spreads,  
Their blossoms fall like rain  
On top of those two children's heads  
Fair-haired, who there remain.

Intoxicated by this love  
She lifts her eyes and... lo!  
The Evening Star is right above  
She craves now for his glow:

– Climb down, my star, so meek and kind,  
Slide on a ray tonight,  
Pervade the forest and my mind,  
And in my life bring light!

And in my life bring light!

He shivers as it did before  
On hills, in woods and caves,  
While guiding safely to the shore  
The lonely moving waves;

But doesn't fall as did one day  
Into the foamy sea:  
– Why would you care, O, face of clay  
If it is him or me?

If it is him or me?

You live to beg the luck and fate  
Your world is small, controlled,  
But in my sphere I'm feeling great,  
Immortal and so cold.

Immortal and so cold.

Romanian (original):

În locul lui menit din cer  
Hyperion se-ntoarse  
Şi, ca şi-n ziua cea de ieri,  
Lumina şi-o revarsă.

Căci este sara-n asfinţit  
Şi noaptea o să-nceapă;  
Răsare luna liniştit  
Şi tremurând din apă

Şi împle cu-ale ei scântei  
Cărările din crânguri.  
Sub şirul lung de mândri tei  
Şedeau doi tineri singuri.

– O, lasă-mi capul meu pe sân,  
Iubito, să se culce  
Sub raza ochiului senin  
Şi negrăit de dulce;

Cu farmecul luminii reci  
Gândirile străbate-mi,  
Revarsă linişte de veci  
Pe noaptea mea de patimi.

Şi de asupra mea rămâi  
Durerea mea de-o curmă,  
Căci eşti iubirea mea dentâi  
Şi visul meu din urmă.

Hyperion vedea de sus  
Uimirea-n a lor faţă;  
De-abia un braţ pe gât i-a pus  
Şi ea l-a prins în braţă…

Şi ea l-a prins în braţă…

Miroase florile-argintii  
Şi cad, o dulce ploaie,  
Pe creştele a doi copii  
Cu plete lungi, bălaie.

Ea, îmbătată de amor,  
Ridică ochii. Vede  
Luceafărul. Şi-ncetişor  
Dorinţele-i încrede:

– Cobori în jos, luceafăr blând,  
Alunecând pe-o rază,  
Pătrunde-n codru şi în gând,  
Norocu-mi luminează!

Norocu-mi luminează!

El tremură ca-n alte dăţi  
În codri şi pe dealuri,  
Călăuzind singurătăţi  
De mişcătoare valuri;

Dar nu mai cade ca-n trecut  
În mări din tot înaltul:  
– Ce-ţi pasă ţie, chip de lut,  
Dac-oi fi eu sau altul?

Trăind în cercul vostru strâmt  
Norocul vă petrece,  
Ci eu în lumea mea mă simt  
Nemuritor şi rece.

Nemuritor şi rece.
