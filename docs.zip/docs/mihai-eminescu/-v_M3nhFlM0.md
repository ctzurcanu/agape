---
id: -v_M3nhFlM0
title: "Ce te legeni, codrule - Why are you swaying, forest?"
sidebar_label: "Ce te legeni, codrule - Why are you swaying, forest?"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/-v_M3nhFlM0"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Ce te legeni, codrule - Why are you swaying, forest?

Lyrics: Mihai Eminescu

Ce te legeni, codrule,  
Ce te legeni, codrule,  
Fără ploaie, fără vânt,  
Fără ploaie, fără vânt,  
Cu crengile la pământ?

– De ce nu m-aș legăna,  
Dacă trece vremea mea!  
Ziua scade, noaptea crește  
Și frunzișul mi-l rărește.

Bate vântul frunza-n dungă  
Cântăreții mi-i alungă;  
Bate vântul dintr-o parte  
Iarna-i ici, vara-i departe.  
Și de ce să nu mă plec,  
Dacă păsările trec!

  
Peste vârf de rămurele  
Trec în stoluri rândunele,  
Ducând gândurile mele  
Și norocul meu cu ele.

Și se duc pe rând, pe rând,  
Zarea lumii-ntunecând,  
Și se duc ca clipele,  
Scuturând aripele.

  
Și mă lasă pustiit,  
Veștejit și amorțit,  
Și cu doru-mi singurel,  
De mă-ngân numai cu el!

Ce te legeni, codrule,  
Ce te legeni, codrule?

English:

Why are you swaying, forest,  
Why are you swaying, forest,  
Without rain, without wind,  
Without rain, without wind,  
With branches on the ground?

– Why wouldn’t I sway,  
If my time passes!

The day decreases, the night increases  
And my foliage thins out.

The wind blows, the leaves in stripes  
It drives away my singers;  
The wind blows from one side  
Winter is here, summer is far away.  
And why shouldn’t I bow,  
If the birds pass!

Over the tops of the branches  
The swallows pass in flocks,  
Carrying my thoughts  
And my luck with them.

And one by one, one by one,  
The horizon of the world darkening,  
And they pass like moments,  
Shaking their wings.

And leaves me desolate,  
Withered and numb,  
And with my own longing,  
If I only deceive myself with him!

Why are you swaying, forest,  
Why are you swaying, forest?
