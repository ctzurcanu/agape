---
id: QICD_ybAa8s
title: "Longing - Dorința"
sidebar_label: "Longing - Dorința"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/QICD_ybAa8s"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Longing - Dorința

Lyrics: Mihai Eminescu, 1884  
Translation (from Romanian): Corneliu M. Popescu

Come to the forest spring where wavelets   
Trembling o'er the pebbles glide   
And the drooping willow branches   
Its secluded threshold hide. 

Eagerly your arms outstretching,   
Hurry dear to my embrace,   
That the breeze your hair will gather   
And uplift it from your face. 

On my knees you will be seated   
Just we two alone, alone   
While upon your curls disordered   
Are the lime tree's blossoms strewn

Forehead pale and tresses golden   
On my shoulder you incline,   
And your lip's delicious plunder   
Raise up willingly to mine. 

We will dream a dream of fairies   
Rocked by secret lullaby,   
Which the lovely spring is chanting   
And the winds that wander by. 

Midst that harmony thus sleeping   
Woodland tales our thoughts enthrall,   
And upon our bodies softly   
Do the lime trees petal fall. 

Romanian:

Vino-n codru la izvorul,  
Care tremură pe prund,  
Unde prispa cea de brazde  
Crengi plecate o ascund.

Și în brațele-mi întinse  
Să alergi, pe piept să-mi cazi,  
Să-ți desprind din creștet vălul,  
Să-l ridic de pe obraz...

Pe genunchii mei ședea-vei,  
Vom fi singuri-singurei,  
Iar în păr, înfiorate,  
Or să-ți cadă flori de tei.

Fruntea albă-n părul galben  
Pe-al meu braț încet s-o culci,  
Lăsând pradă gurii mele  
Ale tale buze dulci...

Vom visa un vis ferice,  
Îngâna-ne-vor c-un cânt  
Singuratice izvoare,  
Blânda batere de vânt;

Adormind de armonia  
Codrului bătut de gânduri,  
Flori de tei deasupra noastră  
Or să cadă rânduri-rânduri.
