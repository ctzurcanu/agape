---
id: HPdmesZ1I6Y
title: "Și era ploaie cu senin... - And it was rain with clear..."
sidebar_label: "Și era ploaie cu senin... - And it was rain with clear..."
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/HPdmesZ1I6Y"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Și era ploaie cu senin... - And it was rain with clear...

Lyrics: Mihai Eminescu

Și era ploaie cu senin  
Senin cu ploaie,  
Salcâmii ramurile-nclin  
Și le îndoaie.

Acuma toți ei înfloresc  
De primăvară  
Ș-un dulce miros răspândesc  
În dalba sară.

Un mândru soare scânteind  
Pe bolta-albastră  
El bate ploaia șiroind  
Pe-a ta fereastră.

Și-n haină albă tu apari  
Cu pasuri line  
Și numai ochii tăi cei mari  
Privesc la mine.

Atât de dulce și de plin  
C-așa văpaie  
Ah, era ploaie cu senin  
Senin cu ploaie.

English:

And it was rain with clear  
Clear with rain,  
The acacias bend their branches  
And bend them.

Now they all bloom  
In spring  
And a sweet scent spreads  
In the salt marsh.

A proud sun sparkling  
On the blue vault  
He beats the pouring rain  
On your window.

And in a white coat you appear  
With gentle steps  
And only your big eyes  
Look at me.

So sweet and full  
That they burn  
Ah, it was rain with clear  
Clear with rain.
