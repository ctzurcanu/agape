---
id: wKacaQLTop8
title: "O mother... - O, mamă..."
sidebar_label: "O mother... - O, mamă..."
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/wKacaQLTop8"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## O mother... - O, mamă...

Lyrics: Mihai Eminescu  
Translator: Corneliu M. Popescu

O mother, darling mother, lost in time's formless haze   
Amidst the leaves' sweet rustle you call my name always;   
Amidst their fluttering murmur above your sacred grave    
I hear you softly whisper whene'er the branches wave;   
While o'er your tomb the willows their autumn raiment heap...   
For ever wave the branches, and you forever sleep. 

When I shall die, beloved, do not beside me mourn,   
But break a branch of blossom that does the lime adorn,   
And take it very softly, and plant it at my head;   
I'll feel its shadow growing as on the soil it's shed;   
And watered by the tears that you for sorrow weep...   
For ever grow that shadow, and I forever sleep. 

And should it be together that we shall die one day,   
They shall not in some cemet'ry our separate bodies lay,   
But let them dig a grave near where the river flows   
And in a single coffin them both together close;   
That I to time eternal my love beside me keep...   
For ever wail the water, and we forever sleep. 

Romanian:

O, mamă, dulce mamă, din negură de vremi  
Pe freamătul de frunze la tine tu mă chemi;  
Deasupra criptei negre a sfântului mormânt  
Se scutură salcâmii de toamnă şi de vânt,  
Se bat încet din ramuri, îngână glasul tău...  
Mereu se vor tot bate, tu vei dormi mereu.

Când voi muri, iubito, la creştet să nu-mi plângi;  
Din teiul sfânt şi dulce o ramură să frângi,  
La capul meu cu grijă tu ramura s-o-ngropi,  
Asupra ei să cadă a ochilor tăi stropi;  
Simţi-o-voi odată umbrind mormântul meu...  
Mereu va creşte umbra-i, eu voi dormi mereu.

Iar dacă împreună va fi ca să murim,  
Să nu ne ducă-n triste zidiri de ţintirim,  
Mormântul să ni-l sape la margine de râu,  
Ne pună-n încăperea aceluiaşi sicriu;  
De-a pururea aproape vei fi de sânul meu...  
Mereu va plânge apa, noi vom dormi mereu.
