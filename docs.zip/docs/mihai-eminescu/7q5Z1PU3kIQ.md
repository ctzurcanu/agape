---
id: 7q5Z1PU3kIQ
title: "Călin Nebunul [III] A - Calin the Fool [III] A"
sidebar_label: "Călin Nebunul [III] A - Calin the Fool [III] A"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/7q5Z1PU3kIQ"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Călin Nebunul [III] A - Calin the Fool [III] A

Lyrics: Mihai Eminescu

— Măi fărtaţi, Călin li zise, nu-ţi pute trece pin crânguri  
Şi pin codri işti de-aramă, rămâneţi aicea singuri,  
Vă clădiţi ici o colibă, vă săpaţi groapă de vatră,  
Singurel voi merge numai pe cărările de piatră.  
Să vedem ce-a fi cu mine. Ei se pun de îl ascultă  
Şi el trece în pădure făr-a pierde vorbă multă  
Şi la orce pas el face codrul simţitor răsună  
Şi pin mrejile de frunze glasuri trec ca o furtună,  
Căci o strună-i orce creangă şi o limbă-i orce frunză.

Luna doar, trecând pe ceruri, voind codrul să-l pătrunză,  
Împle noaptea-i arămie cu mari dunge de omăt,  
Pe sub cari, răscolite, fulger apele încet.  
Şi deodată-n codrul mândru el aude de departe  
Răsunând un glas de fată, ce venea din lunci deşarte  
Naintează şi o vede lângă apa arămie,  
Culegând flori amorţite de pe maluri cenuşie  
Şi punându-le în poala grea de florile de piatră.  
Luminează luna-n ceruri ca un foc pe-o mare vatră",  
Colţii munţilor ce rupţi-s, uriaşe stânci de cremeni.  
Ce păreţii şi-i ridică îndărătnici, suri asemeni,  
Vântul care trece-n şuier, noaptea sură şi bolnavă,  
Împle cu sălbăticie arămoasa-acea dumbravă.

— Bună vreme, fată mândră de-mpărat, Călin îi zice.  
— Mulţămim, răspunse dânsa, tinerel flăcău voinice!  
Ce caţi tu? Ce vânt te-aduce? Nu ştii că om pământean  
Nu poate călca pădurea de bărbatul meu avan?...  
— Ştiu, fetiţă-mpărătiţă, dar nici frică n-am, nici teamă,  
Că el zmeu e şi puternic, dar şi eu — Călin mă cheamă.

Cum vorbeşte, iată zmeul vine iute ca un vânt,  
Cu o falcă-n cer el vine şi cu una pe pământ.  
— Bună vreme, zmeu de cine! — Mulţumesc, Călin Nebune!  
— Am venit să-ţi iau nevasta. — De-i pute, de ce nu? Bune  
Sunt de zis ce-ţi vine-n minte, dar mai greu e să le faci,  
Zmeul codrilor de-aramă nu te-aşteaptă cu colaci.  
Eu mănânc patru cuptoare, patru boi mi-ajung abia  
Şi de vin patru antaluri abia trag la o măsea.

— Nici că-mi pasă! Şi la luptă în dumbravă ei se scoală,  
Se apucă, de copacii tremurau de-nvălmăşeală,  
Tremură sub ei pământul de-a lor păsuri apăsate,  
Scapără cremenea neagră a stâncimei detunate.

Crunt Călin de mijloc l-îmflă, pin’ la vârf de brazi îl urcă,  
Ca pe-un lemn el îl trânteşte, prin copaci trupul i-ncurcă,  
Şi-n genunchi apoi l-îndoaie ca pe-un vreascur ce îl frânge,  
I se îmflă muşchii vineţi de oţel pe când îl strânge  
Şi lovit, pierzând simţirea, zmeul ca o muscă moare,  
Ce lovită este iarna de-o scânteie de ninsoare.

— Să-mi rămâi cu bine, fată, eu mă duc să cat acum  
Cele două sori a tale... Se porni din nou la drum,  
Trece codri de aramă, de departe vede-albind  
Şi aude glasul mândru al pădurilor de-argint.
