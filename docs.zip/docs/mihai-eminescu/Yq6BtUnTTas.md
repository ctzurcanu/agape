---
id: Yq6BtUnTTas
title: "Călin Nebunul [III] B - Calin the Fool [III] B"
sidebar_label: "Călin Nebunul [III] B - Calin the Fool [III] B"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Yq6BtUnTTas"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Călin Nebunul [III] B - Calin the Fool [III] B

Lyrics: Mihai Eminescu

Noaptea-n rouă e scăldată, lucioli pe lacuri zboară,  
Lumea umbrei, umbra lumei se amestec, se-nfăşoară,  
În pădurea argintoasă iarba pare de omăt,  
Flori albastre tremur ude în văzduhul tămâiet,  
Pare că şi trunchii mândri poartă suflete sub coajă,  
Ce suspină pintre ramuri cu a glasului lor vrajă,  
Crengile sunt ca vioare pintre care vântul trece  
Frunze sun ca clopoţeii, trezind ceasul doisprezece,  
Şi pin albul întuneric al pădurei de argint  
Vezi izvoare zdrumicate peste prund întunecând  
Şi sărind în bulgări fluizi pe pietrişul din răstoace,  
În cuibar rotit de ape peste cari luna zace.  
El aude-un cântec dulce, plin de lacrimi şi de noduri,  
Doină de simţire ruptă ca jelania-n prohoduri,  
Împlând codrul de zăpadă, sufletu-i de-o jale mare,  
Pare-i că din piept de fată cântă o privighetoare...

În văzduhul plin de-a nopţii moale luminoasă ploaie  
El văzu o fată mândră, îmbrăcată-n lunge straie  
De argint, ce sta ca umezi pe-a ei trup care tresare,  
Ca o creangă mlădioasă sub a vântului suflare.  
Naltă e, subţire este, ochii mari adânci ridică,  
Părul ei de aur moale până la călcâie-i pică  
Şi cu poalele ei albe şterge stelele-i senine,  
Lacrimi lungi ce curg pe faţa-i ca şi fire diamantine.  
„Nu uita cum că seninul cerului este în aştri,  
Nu uita că-n lacrimi este taina ochilor albaştri.

E frumos pe când din cerul plin de-o sântă bogăţie  
Cade-o lacrimă frumoasă în adâncă vecinicie —  
Dar de cad rănite toate, ceru-i negru şi pustiu,  
Nu-i nălţime, nu-i albastru, e o noapte de sicriu.

Stea ce cade taie lumea ca o lacrimă de-argint,  
Pe seninul cer albastru frumos lacrimile-l prind,  
Şi din când în când vărsate frumos lacrime te prind  
Dar de seci întreg izvorul, vai de ochiul tău cel blând.

Pin diamanţii tăi se scurge sânge fin de trandafiri  
Şi zăpada viorie din obrajii tăi subţiri —  
Curge noaptea lor albastră, a lor dulce vecinicie,  
Ce uşor se poate stinge pin plânsorile pustie.

Cine e nerod să ardă în cărbune-o piatră rară  
Şi eterna-i strălucire s-o strivească într-o pară?  
Tu-ţi arzi ochii şi frumuseţea — infinitul lor se stinge  
Şi nu ştii ce răpeşti lumii? Ah, nu plânge, ah, nu plânge!"

Astfel el se socoteşte. I-a căzut atât de dragă,  
Cât ar fi îmflat în spate pentru ea lumea întreagă.

— Bună vreme, fată mândră de-mpărat! — Mulţam, voinice,  
Dar ce vânt te bate-ncoace şi ce rău te-aduce-aice?  
Zise ea zâmbind — de multă vreme zâmbi-ntâia dată,  
Căci şi ci îi cade drag el, deşi n-ar vre s-o arate —  
Ştie ea de ce îi place, ca să n-o prindă de veste,  
Ce frumos îl află dânsa, cum îi stă, ce drag îi este?

Dar deodată spăimântată de un sunet, ea îi spune:  
— Fugi! că dac-a veni zmeul, viaţa ta o va răpune!  
— Vie numai! zise dânsul... s-om vedea atunci cum plouă —  
Nu se dă Călin, săracul, nici cu una, nici cu două.  
Şi deodată peste codri de argint vine în zbor  
Zmeul falnic, care mişcă cu aripa vârful lor,  
Peste vârfurile-nalte parcă zborul lui îl simţi,  
Frunzărimea cea mişcată de aripele-i cu zimţi.

— Bună vreme, zmeu de câne! — Mulţămesc, Călin Nebun!  
— Am venit să-ţi iau nevasta. — Ba să vezi ce-oi sta să-ţi spun:  
Opt cuptoare mânc de pâne şi opt boi şi opt antale  
Abia sunt un prânz puternic pentru trupul meu în zale.  
Şi vrei să te baţi cu mine? — Nici că-mi pasă!  
— Aide, dară!  
Sună frunza zgomotoasă, codrul din adânc răsare,  
Tremură mai surd pământul, oasele parcă se rup,  
Când vânjoşi şi-ndoaie dânşii a lor braţe ş-a lor trup,  
Dar Călin în sus l-ardică şi-l trânteşte la pământ,  
De sun oasele ca hârburi şi zbor aripele-n vânt.

Îl omoară. Apoi zice: — Rămîi, fata mea, cu bine!  
Merg să scap pe sora mare şi să auzim de bine.  
Trece selbele-argintoase, trece-o vale, un colcantaur  
Până vede dinainte-i răsărind pădurea de-aur.
