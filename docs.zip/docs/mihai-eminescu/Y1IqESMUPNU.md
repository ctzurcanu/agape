---
id: Y1IqESMUPNU
title: "Gloss"
sidebar_label: "Gloss"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Y1IqESMUPNU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Gloss

Lyrics: Mihai Eminescu  
Translator: Corneliu M. Popescu

"Days go past and days come still   
All is old and all is new,   
What is well and what is ill,   
You imagine and construe;   
Do not hope and do not fear,   
Waves that leap like waves must fall;   
Should they praise or should they jeer,   
Look but coldly on it all".

Things you'll meet of many a kind,   
Sights and sounds, and tales no end,   
But to keep them all in mind   
Who would bother to attend ?...   
Very little does it matter,   
If you can yourself fulfill,   
That with idle, empty chatter   
"Days go past and days come still".

Little heed the lofty ranging   
That cold logic does display   
To explain the endless changing   
Of this pageantry of joy,   
And which out of death is growing   
But to last an hour or two;   
For the mind profoundly knowing   
"All is old and all is new".

As before some troupe of actors,   
You before the world remain;   
Act they Gods, or malefactors,   
'Tis but they dressed up again.   
And their loving and their slaying,   
Sit apart and watch, until   
You will see behind their playing   
"What is well and what is ill".

What has been and what to be   
Are but of a page each part   
Which the world do read is free.   
Yet who knows them off by heart?   
All that was and is to come   
Prospers in the present too,   
But its narrow modicum   
"You imagine and construe".

With the selfsame scales and gauges   
This great universe to weigh,   
Man has been for thousand ages   
Sometimes sad and sometimes gay;   
Other masks, the same old story,   
Players pass and reappear,   
Broken promises of glory;   
"Do not hope and do not fear".

Do not hope when greed is staring   
O'er the bridge that luck has flung,   
These are fools for not despairing,   
On their brows though stars are hung;   
Do not fear if one or other   
Does his comrades deep enthrall,   
Do not let him call you brother   
"Waves that leap like waves must fall".

Like the sirens' silver singing   
Men spread nets to catch their prey,   
Up and down the curtain swinging   
Midst a whirlwind of display.   
Leave them room without resistance,   
Nor their commentaries cheer,   
Hearing only from a distance,   
"Should they praise or should they jeer".

If they touch you, do not tarry,   
Should they curse you, hold your tongue,   
All your counsel must miscarry   
Knowing who you are among.   
Let them muse and let them mingle,   
Let them pass both great and small;   
Unattached and calm and single,   
"Look but coldly on it all".

"Look but coldly on it all,   
Should they praise or should they jeer;   
Waves that leap like waves must fall,   
Do not hope and do not fear.   
You imagine and construe   
What is well and what is ill;   
All is old and all is new,   
Days go past and days come still".
