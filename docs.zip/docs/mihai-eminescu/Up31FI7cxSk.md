---
id: Up31FI7cxSk
title: "Luceafărul - The Evening Star 2.1"
sidebar_label: "Luceafărul - The Evening Star 2.1"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Up31FI7cxSk"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Luceafărul - The Evening Star 2.1

Lyrics: Mihai Eminescu

Şi pas cu pas pe urma ei  
Alunecă-n odaie,  
Ţesând cu recile-i scântei  
O mreajă de văpaie.

Şi când în pat se-ntinde drept  
Copila să se culce,  
I-atinge mânile pe piept,  
I-nchide geana dulce;

Şi din oglindă luminiş  
Pe trupu-i se revarsă,  
Pe ochii mari, bătând închişi  
Pe faţa ei întoarsă.

Ea îl privea cu un surâs,  
El tremura-n oglindă,  
Căci o urma adânc în vis  
De suflet să se prindă.

Iar ea vorbind cu el în somn,  
Oftând din greu suspină:  
– O, dulce-al nopţii mele Domn,  
De ce nu vii tu? Vină!

Cobori în jos, luceafăr blând,  
Alunecând pe-o rază,  
Pătrunde-n casă şi în gând  
Şi viaţa-mi luminează!

Şi viaţa-mi luminează!

El asculta tremurător,  
Se aprindea mai tare  
Şi s-arunca fulgerător,  
Se cufunda în mare;

Şi apa unde-au fost căzut  
În cercuri se roteşte,  
Şi din adânc necunoscut  
Un mândru tânăr creşte.

Un mândru tânăr creşte.

English: 

And to her room with her slow steps  
He bears his steps and aims  
Weaving out of his sparkles cold  
A toil of shaking flames.  
   
And when she throws upon her bed  
Her tired limbs and reposes,  
He glides his light along her hands  
And her sweet eyelash closes.  
   
And from the mirror on her shape  
A beam has spread and burns,  
On her big eyes that beat though closed  
And on her face that turns.  
   
Her smiles view him; the mirror shows  
Him trembling in the nook  
For he is plunging in her dream  
So that their souls may hook.  
   
She speaks with him in sleep and sighs  
While her heart's swelled veins drum:  
-"O sweet Lord of my fairy nights,  
Why comest thou not? Come!  
   
Descend to me, mild Evening-star  
Thou canst glide on a beam,  
Enter my dwelling and my mind  
And over my life gleam!"

And over my life gleam!  
   
And he listens and trembles and  
Still more for her love craves  
And as quick as the lightning he  
Plunges into the waves.  
   
The water in that very spot  
Moves rolling many rings  
And out of the unknown, dark, depth  
A superb young man springs.

A superb young man springs.
