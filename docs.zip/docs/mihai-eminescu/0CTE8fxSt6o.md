---
id: 0CTE8fxSt6o
title: "The Evening Star - Luceafărul 5.2"
sidebar_label: "The Evening Star - Luceafărul 5.2"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/0CTE8fxSt6o"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## The Evening Star - Luceafărul 5.2

Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeABwofUGMJQldnM-A9NE98&si=kYP4dCSfqL_ArNKb  
Lyrics: Mihai Eminescu  
Aum mantra: https://en.wikipedia.org/wiki/Om

"Hyperion, you from the deep  
Arise with your world complete,  
Do not request of me a sign  
Of nameless Forms, of the Divine."

"You wish to count yourself as man,  
To live the mortals' brief lifespan?  
But should all humankind decay,  
New men would rise another day."

"You wish to count yourself as man,  
To live the mortals' brief lifespan?  
But should all humankind decay,  
New men would rise another day."

"They chase ideals that drift like air,  
In futile dreams their hearts ensnare.  
When waves find graves along a shore,  
New waves will follow, as before."

"They have their stars of fleeting grace,  
Their fates to chase, their paths to trace.  
We neither know of time nor space,  
Nor do we meet death’s cold embrace."

"From yesterday’s eternal womb,  
Today is born, and meets its tomb.  
If suns should fade from heaven’s dome,  
Some other suns will light its home."

"Though seeming always to ascend,  
Behind, death stalks them up to their end.  
For all are born so they may die,  
And die so others may arise."

"But you, Hyperion, remain,  
Wherever you may set your flame.  
Ask of me my word, my will—  
Shall I grant you wisdom still?"

"Shall I grant you wisdom still?"

"Do you wish to give voice to a song,  
To move the mountains, forests along?  
And stir the islands in the seas,  
With so high waves the sky they seize?"

"Would you display, in mighty deeds,  
Justice and strength to meet your needs?  
I’d give you lands in broken spans  
To knead empires with your hands."

"I’ll give you ships with masts held high,  
Armies to conquer far and wide.  
The earth’s expanse, the oceans broad—  
But death itself? Z'not for god."

"But death itself? Z'not for god."

"And for whom would you choose to die?  
Turn back, return, and cast your eye  
Upon that wandering earthly sphere—  
See what awaits you, look from here."

"See what awaits you, look here!"

Romanian (original):

– Hyperion, ce din genuni  
Răsai c-o-ntreagă lume,  
Nu-mi cere semne şi minuni  
Ce nu au chip şi nume.

Tu vrei un om să te socoţi,  
Cu ei să te asameni?  
Dar piară oamenii cu toţi  
S-ar naşte iarăşi oameni.

Tu vrei un om să te socoţi,  
Cu ei să te asameni?  
Dar piară oamenii cu toţi  
S-ar naşte iarăşi oameni.

Ei numai doar durează-n vânt  
Deşarte idealuri –  
Când valuri află un mormânt  
Răsar în urmă valuri.

Ei au doar stele cu noroc  
Şi prigoniri de soarte,  
Noi nu avem nici timp, nici loc,  
Şi nu cunoaştem moarte.

Din sânul vecinicului ieri  
Trăieşte azi ce moare,  
Un soare de s-ar stinge-n cer  
S-aprinde iarăşi soare.

Părând în veci a răsări,  
Din urmă moartea-l paşte,  
Căci toţi se nasc spre a muri  
Şi mor spre a se naşte.

Iar tu, Hyperion, rămâi,  
Oriunde ai apune…  
Cere-mi cuvântul meu dentâi –  
Să-ţi dau înţelepciune?

Să-ţi dau înţelepciune?

Vrei să dau glas acelei guri,  
Ca dup-a ei cântare  
Să se ia munţii cu păduri  
Şi insulele-n mare?

Vrei poate-n faptă să arăţi  
Dreptate şi tărie?  
Ţi-aş da pământul în bucăţi  
Să-l faci împărăţie.

Îţi dau catarg lângă catarg,  
Oştiri spre a străbate  
Pământu-n lung şi marea-n larg,  
Dar moartea nu se poate…

Şi pentru cine vrei sa mori?  
Întoarce-te, te-ndreaptă  
Spre-acel pământ rătăcitor  
Şi vezi ce te aşteaptă.

Şi vezi ce te aşteaptă.
