---
id: QqdIXtU0HMI
title: "Luceafărul - The Evening Star 6.2"
sidebar_label: "Luceafărul - The Evening Star 6.2"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/QqdIXtU0HMI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Luceafărul - The Evening Star 6.2

Lyrics: Mihai Eminescu

Miroase florile-argintii  
Şi cad, o dulce ploaie,  
Pe creştele a doi copii  
Cu plete lungi, bălaie.

Ea, îmbătată de amor,  
Ridică ochii. Vede  
Luceafărul. Şi-ncetişor  
Dorinţele-i încrede:

– Cobori în jos, luceafăr blând,  
Alunecând pe-o rază,  
Pătrunde-n codru şi în gând,  
Norocu-mi luminează!

Norocu-mi luminează!

El tremură ca-n alte dăţi  
În codri şi pe dealuri,  
Călăuzind singurătăţi  
De mişcătoare valuri;

Dar nu mai cade ca-n trecut  
În mări din tot înaltul:  
– Ce-ţi pasă ţie, chip de lut,  
Dac-oi fi eu sau altul?

Trăind în cercul vostru strâmt  
Norocul vă petrece,  
Ci eu în lumea mea mă simt  
Nemuritor şi rece.

Nemuritor şi rece.

English:

The silvery blooms spread their smells  
And their soft cascade strokes  
The tops of the heads of both youths  
With long and golden locks.  
   
And all bewitched by love, she lifts  
Her eyes toward the fires  
Of the witnessing Evening-star  
And trusts him her desires:  
   
-"Descend to me, mild Evening-star  
Thou canst glide on a beam,  
Enter my forest and my mind  
And o'er my good luck gleam!"

-"Descend to me, mild Evening-star  
Thou canst glide on a beam,  
Enter my forest and my mind  
And o'er my good luck gleam!"

"And o'er my good luck gleam!"  
   
As he did it once, into the woods,  
On hills, his rays he urges,  
Guiding throughout so many wilds  
The gleaming, moving, surges.  
   
But he falls not as he did once  
From his height into swells:  
-"What matters thee, clod of dust, if  
'Tis me or someone else?  
   
You live in your sphere's narrowness  
And luck rules over you -  
But in my steady world I feel  
Eternal, cold, and true!

Eternal, cold, and true!
