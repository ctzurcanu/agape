---
id: 7o8iZjM5qzA
title: "Ode (in ancient meter) - Odă (în metru antic)"
sidebar_label: "Ode (in ancient meter) - Odă (în metru antic)"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/7o8iZjM5qzA"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Ode (in ancient meter) - Odă (în metru antic)

Lyrics: Mihai Eminescu

I never thought I’d learn to die -- not ever,    
Forever young, wrapped in my cloak’s embrace,    
My eyes were raised, dream-filled, unto the eye of    
Singularity.  

Then suddenly, you rose upon my journey,    
You, suffering, so painfully sweet...    
To the depths, I drank the bitter nectar    
of deadly defeat.  

Wretched, I burn alive, like a tortured Nessus,    
Or like Hercules, poisoned by his garment;    
No ocean’s waves can quell the fire raging    
In my veins.  

Consumed by my own dream, I cry in anguish,    
Upon my own pyre, in flames I dissolve...    
Can I rise anew, a bright, reborn soul,    
Like a Phoenix of light?  

Let all waves be banished from my path,    
Come again, edge of indifference,   
cold at heart,    
So that I may die in your peace — return me    
To myself.

return me    
To myself...

Romanian (original): Odă (în metru antic)

Nu credeam să-nvăţ a muri vrodată;  
Pururi tânăr, înfăşurat în manta-mi,  
Ochii mei nălţam visători la steaua  
Singurătăţii.

Când deodată tu răsărişi în cale-mi,  
Suferinţă tu, dureros de dulce...  
Pân-în fund băui voluptatea morţii  
Ne'ndurătoare.

Jalnic ard de viu chinuit ca Nessus.  
Ori ca Hercul înveninat de haina-i;  
Focul meu a-l stinge nu pot cu toate  
Apele mării.

De-al meu propriu vis, mistuit mă vaiet,  
Pe-al meu propriu rug, mă topesc în flăcări...  
Pot să mai re'nviu luminos din el ca  
Pasărea Phoenix?

Piară-mi ochii turburători din cale,  
Vino iar în sân, nepăsare tristă;  
Ca să pot muri liniştit, pe mine  
Mie redă-mă!
