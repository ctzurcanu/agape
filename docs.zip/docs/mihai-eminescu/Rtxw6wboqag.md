---
id: Rtxw6wboqag
title: "Legendary Queen - Crăiasa din poveşti"
sidebar_label: "Legendary Queen - Crăiasa din poveşti"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Rtxw6wboqag"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Legendary Queen - Crăiasa din poveşti

Lyrics: Mihai Eminescu  
Translation: Corneliu M. Popescu

Sparkling haze, across the heavens   
Rising slow the sliver moon,   
She has gathered from the water   
And upon the pastures strewn. 

In the valley many flowers   
On the cobwebs jewels strung,   
Countless gems, of countless colours,   
On the cloak of evening hung. 

O'er the lake the clouds in passing   
Cast a soft transparent shade,   
Which the ripples rolling boulders   
With their radiance invade. 

Came at night a little maiden   
Silently the reeds among,   
And a rose of flaming scarlet   
On the water surface flung. 

For her own sweet image gazing,   
Marvelled how the ripples stirred...   
Ay, that lake is long enchanted   
By the Saint Wednesday's word. 

Flung a rose of flaming scarlet   
That the water's mirror blurred...   
Scarlet roses are enchanted   
By the Saint Friday's word. 

Long she gazes. Hair soft golden,   
O'er her face the moon's pale light,   
While within her eyes of violet   
All times fairy-tales unite. 

Romanian:

Neguri albe, strălucite  
Naşte luna argintie,  
Ea le scoate peste ape,  
Le întinde pe câmpie;

S-adun flori în şezătoare  
De painjen tort să rumpă,  
Şi anină-n haina nopţii  
Boabe mari de piatră scumpă.

Lângă lac, pe care norii  
Au urzit o umbră fină,  
Ruptă de mişcări de valuri  
Ca de bulgări de lumină,

Dându-şi trestia-ntr-o parte,  
Stă copila lin plecată,  
Trandafiri aruncă roşii  
Peste unda fermecată.

Ca să vad-un chip, se uită  
Cum aleargă apa-n cercuri,  
Căci vrăjit de mult e lacul  
De-un cuvânt al sfintei Miercuri;

Ca să iasă chipu-n faţă,  
Trandafiri aruncă tineri,  
Căci vrăjiţi sunt trandafirii  
De-un cuvânt al sfintei Vineri.

Ea se uită... Păru-i galben,  
Faţa ei lucesc în lună,  
Iar în ochii ei albaştri  
Toate basmele s-adună.
