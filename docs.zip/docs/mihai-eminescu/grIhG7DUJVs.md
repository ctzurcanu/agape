---
id: grIhG7DUJVs
title: "Lucifer 1"
sidebar_label: "Lucifer 1"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/grIhG7DUJVs"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Lucifer 1

Lyrics: Mihai Eminescu  
Translation (from Romanian): Corneliu M. Popescu

Once on a time, as poets sing    
High tales with fancy laden,    
Born of a very noble king    
There lived a wondrous maiden.  

An only child, her kinsfolk boon,    
So fair, imagination faints ;    
As though amidst the stars the moon,    
Or Mary amidst the saints.  

From 'neath the castle's dark retreat,    
Her silent way she wended    
Each evening to the window-seat    
Where Lucifer attended.  

And secretly, with never fail,    
She watched his double race,    
Where vessels drew their pathless trail    
Across the ocean's face.  

And as intent she drank his light,    
Desire was quickly there ;    
While he who saw her every night    
Soon fell in love with her.  

And sitting thus with rested head,    
Her elbows on the sill,    
Her heart by youthful fancy led    
Did with deep longing fill.  

While he, a brilliant shining spark,    
Glowed always yet more clear    
Towards the castle tall and dark    
Where she would soon appear.  

Towards the castle tall and dark    
Where she would soon appear.
