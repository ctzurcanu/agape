---
id: lJUg_La_iQE
title: "The Evening Star - Luceafărul 5.1"
sidebar_label: "The Evening Star - Luceafărul 5.1"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/lJUg_La_iQE"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## The Evening Star - Luceafărul 5.1

Lyrics: Mihai Eminescu, 1884  
Translation (from Romanian): Octavian Cocoş

The Evening Star moved in the sky  
With his impressive wings  
And many thousand years went by  
In just as many winks.

A starry sky there was below,  
Above a starry sky –  
He seemed a streak, a constant glow  
That wandered there on high.

And from the chaos, from the bay,  
And from his frozen sight,  
As in that first and holy day  
Flowed lights ablaze and bright.

And they surrounded him in haste  
As water waves, how weird...  
Driven by longing then he raced  
Until they disappeared;

For where he went there was no bound  
Or eyes to look about,  
And time fought hard and moved around  
From hollows to get out.

So, there was nothing, yet there was  
A thirst, more like a threat,  
A deep dark chasm, just because  
It lured him to forget.

– Untie me, Father, from the chains  
Of an eternal life,  
May you be praised on all domains  
And may your years be rife;

O, Lord, ask anything from me,  
But listen my demands,  
A spring of life you'll always be  
And death is in your hands.

Remove the aura from my head  
And the immortal dove,  
Be good and offer me instead  
An hour of true love...

From chaos I was born, no doubt,  
In chaos I'd return,  
And from the stillness I came out  
For stillness now I yearn.

Romanian (original):

Porni luceafărul. Creşteau  
În cer a lui aripe,  
Şi căi de mii de ani treceau  
În tot atâtea clipe.

Un cer de stele dedesubt  
Deasupra-i cer de stele –  
Părea un fulger nentrerupt  
Rătăcitor prin ele.

Şi din a chaosului văi,  
Jur împrejur de sine,  
Vedea ca-n ziua cea dentâi  
Cum izvorau lumine.

Cum izvorând îl înconjor  
Ca nişte mări de-a-notul …  
El zboară, gând purtat de dor,  
Pân’ piere totul, totul.

Căci unde-ajunge nu-i hotar,  
Nici ochi spre a cunoaşte,  
Şi vremea-ncearcă în zadar  
Din goluri a se naşte.

Nu e nimic şi totusi e  
O sete care-l soarbe,  
E un adânc asemene  
Uitării celei oarbe.

– De greul negrei vecinicii  
Părinte, mă dezleagă  
Şi lăudat pe veci să fii  
Pe-a lumii scară-ntreagă.

Pe-a lumii scară-ntreagă.

O, cere-mi, Doamne, orice preţ,  
Dar dă-mi o altă soarte,  
Căci tu izvor eşti de vieţi  
Şi dătător de moarte.

Reia-mi al nemuririi nimb  
Şi focul din privire  
Şi pentru toate dă-mi în schimb  
O oră de iubire.

Din chaos, Doamne-am apărut  
Şi m-aş întoarce-n chaos…  
Şi din repaos m-am născut  
Mi-e sete de repaos.

Mi-e sete de repaos.
