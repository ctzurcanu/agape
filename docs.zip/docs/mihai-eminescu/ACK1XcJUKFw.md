---
id: ACK1XcJUKFw
title: "Doina - Song"
sidebar_label: "Doina - Song"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/ACK1XcJUKFw"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Doina - Song

Lyrics: Mihai Eminescu

De la Nistru pân' la Tissa  
Tot românul plânsu-mi-s-a,  
Că nu mai poate străbate  
De-atâta străinătate.

Din Hotin şi pân' la mare  
Vin muscalii de-a călare,  
De la mare la Hotin  
Mereu calea ne-o aţin;

Din Boian la Vatra-Dornii  
Au umplut omida cornii,  
Şi străinul te tot paşte  
De nu te mai poţi cunoaşte.

Sus la munte, jos pe vale  
Şi-au făcut duşmanii cale,  
Din Sătmar pân' în Săcele  
Numai vaduri ca acele.

Vai de biet român săracul!  
Îndărăt tot dă ca racul,  
Nici îi merge, nici se-ndeamnă,  
Nici îi este toamna toamnă,  
Nici e vară vara lui,  
Şi-i străin în ţara lui.

De la Turnu-n Dorohoi  
Curg duşmanii în puhoi  
Şi s-aşează pe la noi;  
Şi cum vin cu drum de fier  
Toate cântecele pier,  
Zboară păsările toate  
De neagra străinătate;  
Numai umbra spinului  
La uşa creştinului.

Îşi dezbracă ţara sânul,  
Codrul - frate cu românul -  
De secure se tot pleacă  
Şi izvoarele îi seacă -  
Sărac în ţară săracă!

  
Cine-au îndrăgit străinii,  
Mâncă-i-ar inima câinii,  
Mânca-i-ar casa pustia,  
Şi neamul nemernicia!

Ştefane, Măria ta,  
Tu la Putna nu mai sta,  
Las' arhimandritului  
Toată grija schitului,  
Lasă grija sfinţilor  
În sama părinţilor,  
Clopotele să le tragă  
Ziua-ntreagă, noaptea-ntreagă,  
Doar s-a-ndura Dumnezeu,  
Ca să-ţi mântui neamul tău!  
Tu te-nalţă din mormânt,  
Să te-aud din corn sunând  
Şi Moldova adunând.

De-i suna din corn o dată,  
Ai s-aduni Moldova toată,  
De-i suna de două ori,  
Îţi vin codri-n ajutor,  
De-i suna a treia oară  
Toţi duşmanii or să piară  
Din hotară în hotară -  
Îndrăgi-i-ar ciorile  
Şi spânzurătorile!

English:

From the Dniester to the Tissa  
All Romanians have cried to me,  
Because they can no longer cross  
Because of so much foreignness.

From Hotin and to the sea  
The Muscovites come on horseback,  
From the sea to Hotin  
They always keep our way;

From Boian to Vatra-Dornii  
They have filled the hornet's nest,  
And the stranger keeps grazing you  
Until you can no longer recognize yourself.

Up in the mountains, down in the valley  
The enemies have made their way,  
From Satu Mare to Săcele  
Only fords like those.

Woe to the poor Romanian!  
He keeps going back like a crab,  
Neither goes for him, nor does he dare,  
Neither is his autumn autumn,  
Nor is his summer summer,  
And he is a stranger in his own land.

From Turnu-n Dorohoi  
The enemies flow in torrents  
And settle among us;  
And as they come with an iron road  
All the songs perish,  
All the birds fly  
From the black foreign land;  
Only the shadow of the thorn  
At the door of the Christian.

The country strips its bosom,  
The forest - brother to the Romanian -  
Keeps bending over to the axe  
And its springs dry up -  
Poor in a poor country!

Whoever has loved foreigners,  
The dogs would eat his heart,  
The desert would eat his house,  
And the nation would be wretched!

Stefan, your Maria,  
Don't stay at Putna anymore,  
Leave the archimandrite  
All the care of the hermitage,  
Leave the care of the saints  
In the sama of the fathers,  
Let the bells ring  
All day, all night,  
Only may God have mercy,  
So that I may save your people!  
Rise from the grave,  
Let me hear you sounding the horn  
And gathering Moldova.

If he sounded the horn once,  
All Moldova would gather,  
If he sounded it twice,  
The forests would come to your aid,  
If he sounded it a third time  
All your enemies would perish  
From one decision to another -  
The crows would love them  
And the gallows!

The crows would love them  
And the gallows!
