---
id: 4JJtwdE3ZlM
title: "#EveningStar - #eminescu #romania #romantic #english fragment"
sidebar_label: "#EveningStar - #eminescu #romania #romantic #english fragment"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/4JJtwdE3ZlM"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## #EveningStar - #eminescu #romania #romantic #english fragment

Lyrics: Mihai Eminescu

"Do you wish to give voice to a song,  
To move the mountains, forests along?  
And stir the islands in the seas,  
With so high waves the sky they seize?"

"Would you display, in mighty deeds,  
Justice and strength to meet your needs?  
I’d give you lands in broken spans  
To knead empires with your hands."

"I’ll give you ships with masts held high,  
Armies to conquer far and wide.  
The earth’s expanse, the oceans broad—  
But death itself? Is not for god."

But death itself?   
Is not for god!
