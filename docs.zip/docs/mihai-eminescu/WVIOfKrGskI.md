---
id: WVIOfKrGskI
title: "Azi e zi întâi de mai - Today is the First of May"
sidebar_label: "Azi e zi întâi de mai - Today is the First of May"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/WVIOfKrGskI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Azi e zi întâi de mai - Today is the First of May

Lyrics: Mihai Eminescu  
Dedication: Casandra Elena Alupului, the first love of Eminescu

Azi e zi întâi de mai,  
Azi e ziua de Armindeni:  
Eu te cat, drăguța mea,  
Eu te caut pretutindeni.

Eu te cer de la izvor,  
De la codrul cel de brazi,  
De la vântul ce lovi  
Bălsămând al meu obraz.

Întreb munții cei înalți,  
De la râuri eu te cer:  
De-au văzut cumva ascuns  
Al vieții-mi giuvaer.

Cu-al tău zâmbet răsfățat  
Și cu dulcile cusururi,  
Te-am iubit, copil drăguț,  
Te-oi iubi de-acum și pururi.

Te iubesc făr- de-mputări,  
Fără urmă de căire ­  
Dară, vai, nu te găsesc  
Nicăire, nicăire.

English:

Today is the first of May,  
Today is Armindeni's day:  
I caught you, my dear,  
I look for you everywhere.

I ask you from the spring,  
From the fir forest,  
From the wind that blows  
Balsamming my cheek.

I ask the high mountains,  
From the rivers I ask you:  
If they have somehow seen the hidden  
Jewel of my life.

With your spoiled smile  
And with your sweet flaws,  
I loved you, dear child,  
I will love you from now on and forever.

I love you without regrets,  
Without a trace of regret  
But, alas, I can't find you  
Nowhere, nowhere.
