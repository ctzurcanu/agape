---
id: tjg26PdW3eA
title: "Ode (in ancient meter) - Odă (în metru antic) v2"
sidebar_label: "Ode (in ancient meter) - Odă (în metru antic) v2"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/tjg26PdW3eA"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Ode (in ancient meter) - Odă (în metru antic) v2

Lyrics: Mihai Eminescu

I never thought I’d learn to die -- not once,    
Forever young, wrapped in my cloak’s embrace,    
My eyes were raised, dream-filled, unto the eye of    
Singularity.  

Then suddenly, you rose upon my journey,    
You, suffering, so painfully sweet...    
To the depths, I drank the bitter nectar    
of deadly defeat.  

Wretched, I burn alive, like a tortured Nessus,    
Or like a Hercules, poisoned by his garment;    
No ocean’s waves can quell the fire raging    
Through my own veins.  

Consumed by my own dream, I cry in anguish,    
Upon my own pyre, in flames I dissolve...    
Can I rise anew, a bright, reborn soul,    
A Phoenix in flight?  

Let all waves be banished from my path,    
Come again, edge of indifference,   
coldness of heart,    
So that I may lay within your peace — return me    
To myself.

return me    
To myself...

Romanian (original): Odă (în metru antic)

Nu credeam să-nvăţ a muri vrodată;  
Pururi tânăr, înfăşurat în manta-mi,  
Ochii mei nălţam visători la steaua  
Singurătăţii.

Când deodată tu răsărişi în cale-mi,  
Suferinţă tu, dureros de dulce...  
Pân-în fund băui voluptatea morţii  
Ne'ndurătoare.

Jalnic ard de viu chinuit ca Nessus.  
Ori ca Hercul înveninat de haina-i;  
Focul meu a-l stinge nu pot cu toate  
Apele mării.

De-al meu propriu vis, mistuit mă vaiet,  
Pe-al meu propriu rug, mă topesc în flăcări...  
Pot să mai re'nviu luminos din el ca  
Pasărea Phoenix?

Piară-mi ochii turburători din cale,  
Vino iar în sân, nepăsare tristă;  
Ca să pot muri liniştit, pe mine  
Mie redă-mă!
