---
id: u2HSYbmDwqU
title: "The Evening Star - Luceafărul 5.2 v3"
sidebar_label: "The Evening Star - Luceafărul 5.2 v3"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/u2HSYbmDwqU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## The Evening Star - Luceafărul 5.2 v3

Lyrics: Mihai Eminescu  
Translator (from Romanian): Octavian Cocoş

– Hyperion, who from abyss  
Rise in the world in flames,  
Don't ask for marvels, signs and bliss,  
Which have no face, no names;

You wish to be a man, but how  
To be like other men?  
If all the people died right now  
They would be born again.

And their ideals, right and clear,  
Seem lofty, but are dumb,  
When many ripples disappear  
More ripples quickly come.

They look for lucky stars in space  
And fate stops short their breath,  
We do not have a time and place  
And we don't know what's death.

From the eternal yesterday  
Rise all and then decline,  
If a bright sun now died away  
Another one would shine;

But though it seems to stay alive  
Death treats it with deep scorn,  
For all will die after they thrive  
And then again are born.

– But you, Hyperion, will last  
Whenever you decline...  
This thing I promised in the past –  
My wisdom is divine.

How could I let that mouth to speak  
And sing and to be free?  
It would collapse the mountain peak  
Deep down into the sea.

Or do you wish to show your worth  
Your justice and your reign?  
I'd give you every piece of earth  
To make it your domain.

And all the masts I'll give to thee  
And armies and much wealth,  
To cross the earth and the wide sea,  
But I can't give you death...

Tell me, for whom you want to die?  
Go back now, turn around,  
Look at that planet from on high  
And see what's on the ground.

Romanian (original):

– Hyperion, ce din genuni  
Răsai c-o-ntreagă lume,  
Nu-mi cere semne şi minuni  
Ce nu au chip şi nume.

Tu vrei un om să te socoţi,  
Cu ei să te asameni?  
Dar piară oamenii cu toţi  
S-ar naşte iarăşi oameni.

Tu vrei un om să te socoţi,  
Cu ei să te asameni?  
Dar piară oamenii cu toţi  
S-ar naşte iarăşi oameni.

Ei numai doar durează-n vânt  
Deşarte idealuri –  
Când valuri află un mormânt  
Răsar în urmă valuri.

Ei au doar stele cu noroc  
Şi prigoniri de soarte,  
Noi nu avem nici timp, nici loc,  
Şi nu cunoaştem moarte.

Din sânul vecinicului ieri  
Trăieşte azi ce moare,  
Un soare de s-ar stinge-n cer  
S-aprinde iarăşi soare.

Părând în veci a răsări,  
Din urmă moartea-l paşte,  
Căci toţi se nasc spre a muri  
Şi mor spre a se naşte.

Iar tu, Hyperion, rămâi,  
Oriunde ai apune…  
Cere-mi cuvântul meu dentâi –  
Să-ţi dau înţelepciune?

Să-ţi dau înţelepciune?

Vrei să dau glas acelei guri,  
Ca dup-a ei cântare  
Să se ia munţii cu păduri  
Şi insulele-n mare?

Vrei poate-n faptă să arăţi  
Dreptate şi tărie?  
Ţi-aş da pământul în bucăţi  
Să-l faci împărăţie.

Îţi dau catarg lângă catarg,  
Oştiri spre a străbate  
Pământu-n lung şi marea-n larg,  
Dar moartea nu se poate…

Şi pentru cine vrei sa mori?  
Întoarce-te, te-ndreaptă  
Spre-acel pământ rătăcitor  
Şi vezi ce te aşteaptă.

Şi vezi ce te aşteaptă.
