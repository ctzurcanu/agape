---
id: eH3X0zbf-3s
title: "The Evening Star 4 - Luceafărul 4 v2"
sidebar_label: "The Evening Star 4 - Luceafărul 4 v2"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/eH3X0zbf-3s"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## The Evening Star 4 - Luceafărul 4 v2

Lyrics: Mihai Eminescu  
Translator (from Romanian): Octavian Cocoş

But in the meantime, Catalyne,  
A buttons shrewd and neat,  
Who fills the goblets with red wine  
When people drink and eat.

A page who walks behind the queen  
Her wondrous gowns to hold,  
A bastard child, a stray sweet teen,  
With glances keen and bold,

With cheeks like roses, eyebrows raised  
And with a blushing face,  
At Catalyna looks amazed  
Tucked in a hiding place.

He sees her beauty and her stance  
And on the spot he's struck;  
Well, Catalyne, this is your chance  
To go and try your luck.

And thus he hugs her from behind  
But in a gentle way,  
– Hey, Catalyne, what's on your mind?  
You'd better go away.

– What's on my mind? I think you guess,  
I want to feel the bliss,  
So, I won't let you go unless  
You give me a sweet kiss.

– I do not know what you request,  
Please leave and stay afar,  
My heart is pounding in my chest  
And craves the Evening Star.

– If you don't know, then I'd be glad  
To teach you lovers game,  
Only don't fuss and don't get mad,  
Be lenient and tame.

As does the lonely hunter who  
Lays traps and catches birds,  
The moment I reach out to you  
Embrace me, trust my words;

And let your eyes, so pure and chaste,  
To readily submit  
And when I gently grab your waist  
On tiptoe rise a bit;

Then, when you see my face is bent  
Raise yours and don't be shy,  
We shall remain embraced, content,  
Until it's time to die.

To understand then fully how  
The lovers' hearts do burn,  
When kissing you, I'll slightly bow,  
You'll kiss me in your turn.

She listens to the playful child  
Amazed and ill at ease,  
Now she is shy, now she is mild,  
Now wants, now disagrees,

And says: – I've known you for so long,  
A child astute and fair  
And talkative and good and strong,  
We two could make a pair...

However, came an Evening Star  
And I did not foresee  
That he would give a charm bizarre  
To the secluded sea;

I keep my lashes lowered now  
The teardrops fill my face,  
Because I see the ripples how  
They go towards his place;

He glows with a tremendous love  
And watches me with care,  
But he remains so far above  
That I can't touch him there.

To light the world he is all set,  
Like a majestic star...  
For ever I shall love him, yet  
For ever he'll stay far...

That's why my days do not seem right  
And I want them to end,  
But all the nights have a delight  
That I can't comprehend.

– You're just a child, let's run away  
In the wide world, my dear,  
They will forget our names one day  
And so we'll disappear.

We'll be secure and we'll be glad,  
Our souls will have no scars,  
You will forget your mom and dad  
And all the Evening Stars.

  
Romanian (original):

În vremea asta Cătălin,  
Viclean copil de casă,  
Ce împle cupele cu vin  
Mesenilor la masă,  
   
Un paj ce poartă pas cu pas  
A-mpărătesei rochii,  
Băiat din flori şi de pripas  
Dar îndrăzneţ cu ochii,  
   
Cu obrăjori ca doi bujori  
De rumeni, bată-i vina,  
Se furişeaza pânditor  
Privind la Cătălina.  
   
Dar ce frumoasă se făcu  
Şi mândră, arz-o focul;  
Ei Cătălin, acu i-acu  
Ca să-ţi încerci norocul.  
   
Şi-n treacăt o cuprinse lin  
Într-un ungher degrabă.  
– Da’ ce vrei, mări Cătălin?  
Ia du-t’ de-ţi vezi de treabă.  
   
– Ce voi? Aş vrea să nu mai stai  
Pe gânduri totdeauna,  
Să râzi mai bine şi să-mi dai  
O gură, numai una.  
   
– Dar nici nu ştiu măcar ce-mi ceri,  
Dă-mi pace, fugi departe –  
O, de luceafărul din cer  
M-a prins un dor de moarte.  
   
– Dacă nu ştii, ţi-aş arăta  
Din bob în bob amorul,  
Ci numai nu te mânia,  
Ci stai cu binişorul.

Ci stai cu binişorul.  
   
Cum vânătoru-ntinde-n crâng  
La păsărele laţul,  
Când ţi-oi întinde braţul stâng  
Să mă cuprinzi cu braţul;  
   
Şi ochii tăi nemişcători  
Sub ochii mei rămâie...  
De te înalţ de subsuori  
Te-nalţă din călcâie;  
   
Când faţa mea se pleacă-n jos,  
În sus rămâi cu faţa,  
Să ne privim nesăţios  
Şi dulce toată viaţa;  
   
Şi ca să-ţi fie pe deplin  
Iubirea cunoscută,  
Când sărutându-te mă-nclin,  
Tu iarăşi mă sărută.

Tu iarăşi mă sărută.

Ea-l asculta pe copilaş  
Uimită şi distrasă,  
Şi ruşinos şi drăgălaş,  
Mai nu vrea, mai se lasă,

Şi-i zise-ncet: – Încă de mic  
Te cunoşteam pe tine,  
Şi guraliv şi de nimic,  
Te-ai potrivi cu mine...

Dar un luceafăr, răsărit  
Din liniştea uitării,  
Dă orizon nemărginit  
Singurătăţii mării;

Şi tainic genele le plec,  
Căci mi le împle plânsul,  
Când ale apei valuri trec  
Călătorind spre dânsul;

Luceşte cu-n amor nespus  
Durerea să-mi alunge,  
Dar se înalţă tot mai sus,  
Ca să nu-l pot ajunge.

Pătrunde trist cu raze reci  
Din lumea ce-l desparte...  
În veci îl voi iubi şi-n veci  
Va rămânea departe...

Va rămânea departe...

De-aceea zilele îmi sunt  
Pustii ca nişte stepe,  
Dar nopţile-s de-un farmec sfânt  
Ce nu-l mai pot pricepe.

– Tu esti copilă, asta e...  
Hai ş-om fugi în lume,  
Doar ni s-or pierde urmele  
Şi nu ne-or şti de nume,

Căci amândoi vom fi cuminţi,  
Vom fi voioşi şi teferi,  
Vei pierde dorul de părinţi  
Şi visul de luceferi.

Şi visul de luceferi.
