---
id: EydkzR500ow
title: "La Moarte - To Death"
sidebar_label: "La Moarte - To Death"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/EydkzR500ow"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La Moarte - To Death

Lyrics: Mihai Eminescu

Lăsați clopotul să plângă cu-a lui voce de aramă,  
Lăsați turnul ca să miște a lui inimă de fier,  
Căci de stele mai aproape el le dă acuma samă  
Că un suflet bun și nobil se îndreaptă cătră cer.

Clopote, tu simți durerea și urmezi cu-a ta cântare,  
Când din stea în stea se suie sufletul într-un avânt,  
Pe când noi urmăm cu pasul cel rărit de întristare  
Lutul palid, fără suflet, să-l depunem în pământ.

Ochii? Câte dulci imagini au sorbit a lor lumine!  
Capul? O, de câte gânduri el a fost împopulat!  
Inima? Câtă simțire frământat-a ea în sine?  
Sufletul? Câte speranțe, câte visuri a păstrat?

Ș-azi nimic. Lumea gândirei e o lume sfărâmată  
De lemnoasa mân-a morții inima e stoars-acum,  
Și imaginele-s șterse, ce prin el treceau odată,  
Sufletul (dacă esistă) printre nori își face drum.

Ai știut tu, scumpe frate, că pământu-i o ruină?  
Că-i o sarcină viața? Că-i martiriu să trăiești?  
Ai știut tu cum că moartea e un caos de lumină,  
Că la finea veciniciei te-aștept stelele cerești?

De-a vieții grea enigmă ție-acuma nu-ți mai pasă,  
Căci problema ei cea mare la nimic o ai redus.  
Pe când nouă-ncă viața e o cifră nențeleasă  
Și-n zădar cătăm răspunsul la-ntrebarea ce ne-am pus.

În zădar ne batem capul, triste firi vizionare,  
Să citim din cartea lumei semne ce noi nu le-am scris.  
Potrivim șirul de gânduri pe-o sistemă oarecare,  
Măsurăm mașina lumei cu acea măsurătoare  
Și gândirile-s fantome, și viața este vis.

Și gândirile-s fantome, iară viața este vis.

English:

Let the bell cry with its brass voice,  
Let the tower move its iron heart,  
For closer to the stars it now gives them the same  
That a good and noble soul is heading for heaven.

Bells, you feel the pain and follow with your song,  
When from star to star the soul rises in a rush,  
While we follow with the rarefied step of sorrow  
The pale, soulless clay, to lay it in the ground.

The eyes? How many sweet images have absorbed their light!  
The head? Oh, with how many thoughts has it been populated!  
The heart? How much feeling has it stirred within itself?  
The soul? How many hopes, how many dreams has it kept?

Nothing today. The world of thought is a broken world  
By the wooden hand of death the heart is now squeezed,  
And the images are erased, that once passed through it,  
The soul (if it exists) makes its way through the clouds.

Did you know, dear brother, that the earth is a ruin?  
That life is a burden? That it is martyrdom to live?  
Did you know that death is a chaos of light,  
That at the end of eternity the heavenly stars await you?

You no longer care about life's heavy enigma,  
For you have reduced its great problem to nothing.  
While life is still an incomprehensible number  
And in vain we seek the answer to the question we have asked ourselves.

In vain we rack our brains, sad visionary natures,  
To read from the book of the world signs that we did not write.  
We fit the string of thoughts to some system,  
We measure the machine of the world with that measurement  
And thoughts are ghosts, and life is a dream.

And thoughts are ghosts, and life is a dream.
