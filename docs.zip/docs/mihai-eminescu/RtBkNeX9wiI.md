---
id: RtBkNeX9wiI
title: "Luceafărul - The Evening Star 4.2"
sidebar_label: "Luceafărul - The Evening Star 4.2"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/RtBkNeX9wiI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Luceafărul - The Evening Star 4.2

Lyrics: Mihai Eminescu

Ea-l asculta pe copilaş  
Uimită şi distrasă,  
Şi ruşinos şi drăgălaş,  
Mai nu vrea, mai se lasă,

Şi-i zise-ncet: – Încă de mic  
Te cunoşteam pe tine,  
Şi guraliv şi de nimic,  
Te-ai potrivi cu mine...

Dar un luceafăr, răsărit  
Din liniştea uitării,  
Dă orizon nemărginit  
Singurătăţii mării;

Şi tainic genele le plec,  
Căci mi le împle plânsul,  
Când ale apei valuri trec  
Călătorind spre dânsul;

Luceşte cu-n amor nespus  
Durerea să-mi alunge,  
Dar se înalţă tot mai sus,  
Ca să nu-l pot ajunge.

Pătrunde trist cu raze reci  
Din lumea ce-l desparte...  
În veci îl voi iubi şi-n veci  
Va rămânea departe...

Va rămânea departe...

De-aceea zilele îmi sunt  
Pustii ca nişte stepe,  
Dar nopţile-s de-un farmec sfânt  
Ce nu-l mai pot pricepe.

– Tu esti copilă, asta e...  
Hai ş-om fugi în lume,  
Doar ni s-or pierde urmele  
Şi nu ne-or şti de nume,

Căci amândoi vom fi cuminţi,  
Vom fi voioşi şi teferi,  
Vei pierde dorul de părinţi  
Şi visul de luceferi.

Şi visul de luceferi.

English:

With much bewilderment her mind  
The little boy's word fills,  
And shyly and nicely now she  
Wills not, and now she wills.  
   
And slowly she tells him:- "Since thy  
Childhood I've known thy wit,  
And as thou art and glib and small  
My temper thou wouldst fit.  
   
But Evening-star sprung from the calm  
Of the oblivion,  
Though, gives horizon limitless  
To the sea lone and dun.  
   
And secretly, I close my eyes  
For my eyelash tears dim  
When the waves of the sea go on  
Traveling toward him.  
   
He shines with love unspeakable  
So that my pains he'd leach,  
But higher and higher soars, so  
That his hand I'd ne'er reach.  
   
Sadly thrusts from the worlds which from  
My soul his cold ray bar...  
I shall love him forever and  
Forever he'll rove far.

Forever he'll rove far.  
   
Like the unmeasured steppes my days  
Are deaf and wild, therefore,  
But my nights spread a holy charm  
I understand no more!"  
   
-"Thou art a child! Let's go! Through new  
Lands our own fate let's frame!  
Soon they shall have lost our trace and  
Forgot even our name!  
   
We shall be both wise, glad and whole  
As my judgement infers  
And thou wouldst not long for thy kin  
Nor yearn for Evening-stars!"

"Nor yearn for Evening-stars!"
