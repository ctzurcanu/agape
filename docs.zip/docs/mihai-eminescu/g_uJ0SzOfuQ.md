---
id: g_uJ0SzOfuQ
title: "The Evening Star - Luceafărul 1"
sidebar_label: "The Evening Star - Luceafărul 1"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/g_uJ0SzOfuQ"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## The Evening Star - Luceafărul 1

Lyrics: Mihai Eminescu  
Translator (from Romanian): Octavian Cocoş

There was, as in the fairy tales,  
Back in the distant time,  
Of royal blood, which still prevails,  
A girl sweet and sublime.

The only child, with no constraints,  
And fair and full of charms,  
Shining like Mary among saints  
And moon among the stars.

She glides through the majestic halls  
As if she slowly skates,  
Goes to the window where befalls  
That Evening Star awaits.

Above the sea he always stays  
For rises and shines bright,  
Along the moving water trails  
Guides all the ships at night.

And seeing him, wish burns her cheeks,  
She's thrilled from head to toe;  
He watches her for many weeks,  
And love begins to grow.

And love begins to grow.

While musing happy at her goal  
And resting on her arm,  
Deep in her heart and in her soul  
She's longing for his charm.

How bright he then begins to burn  
Night after night, with grace,  
Above the palace black and stern,  
Where she will show her face.

Where she will show her face.

Romanian (original):

A fost odată ca-n poveşti  
A fost ca niciodată,  
Din rude mari împărăteşti,  
O prea frumoasă fată.  
   
Şi era una la părinţi  
Şi mândră-n toate cele,  
Cum e Fecioara între sfinţi  
Şi luna între stele.  
   
Din umbra falnicelor bolţi  
Ea pasul şi-l îndreaptă  
Lângă fereastră, unde-n colţ  
Luceafărul aşteaptă.  
   
Privea în zare cum pe mări  
Răsare şi străluce,  
Pe mişcătoarele cărări  
Corăbii negre duce,  
   
Îl vede azi, îl vede mâni,  
Astfel dorinţa-i gata;  
El iar, privind de săptămâni,  
Îi cade dragă fata.

Îi cade dragă fata.  
   
Cum ea pe coate-şi răzima  
Visând ale ei tâmple,  
De dorul lui şi inima  
Şi sufletu-i se împle.  
   
Şi cât de viu s-aprinde el  
În orişicare sară,  
Spre umbra negrului castel  
Când ea o să-i apară.

Când ea o să-i apară.
