---
id: QW69FdVarUQ
title: "Călin Nebunul [I] A - Calin the Fool [I] A"
sidebar_label: "Călin Nebunul [I] A - Calin the Fool [I] A"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/QW69FdVarUQ"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Călin Nebunul [I] A - Calin the Fool [I] A

Lyrics: Mihai Eminescu

Fost-a împărat odată şi trei fete el avea  
Cât puteai privi la soare, da’ la ele ca mai ba.  
Nicio vorbă de poveste, cer cu stele presărat  
Nu ajung la frumuseţa astor fete de-mpărat.

Dar deşi nu-ţi poţi da vorba despre ele și cuvântul,  
Mintea tot le – atinge umbra, ochii lor i-ajunge gândul,  
Dar de cea mai mijlocie niciun gând să n-o măsoare,  
E o floare de pe mare, cine-i cată-n faţă moare.

Mulţi feciori de împăraţi, de războinici lăudaţi  
Le-au cerut ca s-o li-o dee, ca cu chipul de femee  
Să-mpodoabe c-o icoană viaţa lor cea năzdrăvană,  
Da-mpăratul nici gândeşte să li dee–aşa comoară,  
Ale casei lui mai mândre şi mai trainice odoară.  
Da-ntr-o sară-n drum de ţară cine dealul mi-l coboară?

Trei feciori voinici de frunte ca trei şoimi voinici de munte,  
Vin în zale îmbrăcaţi, pe cai negri–ncălicaţi,  
Spiţelaţi, uşori ca vântul, de-o frumseţă–ntunecoasă,  
Au venit să-i ceară, Doamne, fetele cele frumoase.

Dar mai bine – ar fi să-i ceară tot bielşugul de pe ţară!  
Şi ce nu se pun de-i cer trei luceferi de pe cer!  
De-ar pute, de n-ar putea, trei luceferi el li-ar da,  
Dară fetele lui ba. Unu – atunci din ei s-a dus  
Şi în noaptea cea senină ca să fluere s-a pus,  
Vine-un nour, ce-i un nour? Vine-un vânt — da ce-i un vânt?  
Vine-o ploaie de şivoaie şi furtună pe pământ,  
Şi în nori hrăniţi de fulger, şi prin râuri de scântei  
Zboară fetele răpite duse-n lume de cei trei.

Scrie carte împăratul, scoate veste-n ţara toată,  
Cine s-ar găsi pe fete de la zmei să i le scoată,  
Să le ieie de neveste şi cine s-ar ispiti  
Toată-mpărăţia mândră între ei va împărţi...

Nu-şi mai pieptăna nici capul de atâta supărare  
Şi lăsase ca să-i crească peste piept o barbă mare,  
Care cade jos în noduri, ca şi câlţii ce nu-i perii,  
Stă să crească iarbă-ntr-însa, s-îmble gâze ca puzderii.  
Nu mai iese sara-n prispă să stea cu ţara de vorbă.  
Ca un pomătuf de jalnic şi tăcut ca o cociorbă,  
Ş-a uitat de mult luleaua şi cloceşte tot pe gânduri.  
Doară plosca-l mai ocheşte de pe-a policioarei scânduri.

Dar în satu cela-n care şedea împăratul dornic  
Era şi un om de seamă, un fruntaş... fusese vornic;  
Avea trei feciori, din cari doi or fost cum or fi fost,  
Oameni harnici şi ca lumea, da’ cel mic era un prost.

Câtu-i ziua şade-n vatră şi se joacă în cenuşă,  
Prost ca gardul de răchită, şui ca clanţa de la uşă.  
De vorbeşte, cine-ascultă? Ştie că nu-i de vo samă,  
Toţi îi zic: „Ne-aude Tontul", da’ pe el Călin îl cheamă.

Cei doi fraţi se ispitiră şi au zis: — Haidem şi noi,  
Dulce măr e-mpărăţia, de ne-a-ntoarce înapoi  
Dumnezeu din calea lungă. Cine-a fi să le găsească,  
Tot voinic din astă lume, de viţă pământească!

Deci, cum vrură să se ducă, zice prostul: — Hai şi eu!  
— Hai! că tot n-are ce face, ş-aşa îmbla teleleu,  
Ne-a ţine de-urât uitucul ş-a păzi la noapte focul.  
Deci făcur-un arc puternic şi vorbiră ca-n tot locul  
Unde va cade săgeata, ei să steie de popas.  
Repezi atunci cel mare o săgeată din pârleaz.

English:

There was once an emperor and he had three daughters  
As much as you could look at the sun, but at them as if they were more.  
No tale, a sky sprinkled with stars  
Cannot reach the beauty of these emperor's daughters.

But although you can't talk about them and the word,  
The mind still touches their shadow, their eyes reach the thought,  
But no thought can measure the middle one,  
She is a flower from the sea, whoever looks at her dies.

Many sons of emperors, of praised warriors  
They asked them to give her to them, as if with the face of women  
To adorn their carefree life with an icon,  
But the emperor doesn't even think of giving them such a treasure,  
Of his prouder and more enduring house it smells.  
But in a country road, who will bring down the hill for me?

Three strong young men, like three strong mountain falcons,  
Come dressed in mail, on black horses,  
Spiked, light as the wind, of a dark beauty,  
They came to ask him, Lord, for the beautiful girls.

But better – they would ask him for all the wealth in the country!  
And why don't they ask him for three stars from the sky!  
If he could, if he couldn't, he would give them three stars,  
But his daughters. One – then one of them went  
And in the clear night, to whistle, he set,  
A cloud is coming, what is a cloud? A wind is coming — what is a wind?  
A torrential rain and storm come upon the earth,  
And in clouds nourished by lightning, and through rivers of sparks  
Fly the kidnapped girls taken into the world by the three.

The emperor writes a book, spreads news throughout the land,  
Whoever finds the girls from the dragons should take them away,  
Let them be his wives and whoever is tempted  
The whole proud kingdom will be divided between them...

He no longer combed his head from such anger  
And had let a large beard grow over his chest,  
Which falls down in knots, like unbrushed toupees,  
But grass grows inside, and worms grow like worms.  
...
