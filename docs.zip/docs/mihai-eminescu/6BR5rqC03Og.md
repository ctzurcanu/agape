---
id: 6BR5rqC03Og
title: "Pe lângă plopii fără soț - Where the lonely poplars grow"
sidebar_label: "Pe lângă plopii fără soț - Where the lonely poplars grow"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/6BR5rqC03Og"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Pe lângă plopii fără soț - Where the lonely poplars grow

Lyrics: Mihai Eminescu

Pe lângă plopii fără soț  
Adesea am trecut;  
Mă cunoșteau vecinii toți –  
Tu nu m-ai cunoscut.

La geamul tău ce strălucea  
Privii atât de des;  
O lume toată-nțelegea –  
Tu nu m-ai înțeles.

De câte ori am așteptat  
O șoaptă de răspuns!  
O zi din viață să-mi fi dat,  
O zi mi-era de-ajuns;

O oră să fi fost amici,  
Să ne iubim cu dor,  
S-ascult de glasul gurii mici  
O oră, și să mor.

Dându-mi din ochiul tău senin  
O rază dinadins,  
În calea timpilor ce vin  
O stea s-ar fi aprins;

Ai fi trăit în veci de veci  
Și rânduri de vieți,  
Cu ale tale brațe reci  
Înmărmureai măreț,

Un chip de-a pururi adorat  
Cum nu mai au perechi  
Acele zâne ce străbat  
Din timpurile vechi.

Căci te iubeam cu ochi păgâni  
Și plini de suferinți,  
Ce mi-i lăsară din bătrâni  
Părinții din părinți.

Azi nici măcar îmi pare rău  
Că trec cu mult mai rar,  
Că cu tristeță capul tău  
Se-ntoarce în zadar,

Căci azi le semeni tuturor  
La umblet și la port,  
Și te privesc nepăsător  
C-un rece ochi de mort.

Tu trebuia să te cuprinzi  
De acel farmec sfânt,  
Și noaptea candelă s-aprinzi  
Iubirii pe pământ.

Și noaptea candelă s-aprinzi  
Iubirii pe pământ.

English (by Corneliu M. Popescu):

Down where the lonely poplars grow   
How often have I erred;   
My steps that all the neighbors know   
You only have not heard. 

Towards your window lighted through   
How oft my gaze has flown;   
A world entire my secret knew   
You only have not known. 

A word, a murmur of reply   
How often did I pray!   
What matters then if I should die,   
Enough to live that day; 

To know one hour of tenderness,   
One hour of lovers' night;   
To hear you whisper's soft caress   
One hour, then come what might! 

Had you but granted me a glance   
That was not filled with scorn,   
Out of its shinning radiance   
A new star has been born. 

You would have lived through lives untold   
Beyond the ends of time;   
O deity with arms so cold,   
O marble form sublime! 

An idol of some pagan lore   
As now no more is seen,   
Come down to us from times yore,   
From times that long have been. 

My worship was of ages gone,   
Sad eyes by faith beguiled,   
Each generation handed on   
From father unto child.

But now I very little care   
To walk along that lane,   
Nor heed the face I found so fair   
Looks out for me in vain; 

For you are like them today   
In bearing and in guise,   
And I but look on your display   
With cold and lifeless eyes. 

You should have known to value right   
With wondering intent,   
And lit your candela at night   
To Love that God had sent.

And lit your candela at night   
To Love that God had sent.
