---
id: vY4rOgncFIw
title: "One wish alone have I - Mai am un singur dor"
sidebar_label: "One wish alone have I - Mai am un singur dor"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/vY4rOgncFIw"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## One wish alone have I - Mai am un singur dor

Lyrics: Mihai Eminescu, 1884  
Translation (from Romanian): Corneliu M. Popescu

One wish alone have I:   
In some calm land   
Beside the sea to die;   
Upon its strand   
That I forever sleep,   
The forest near,   
A heaven clear   
Stretched o'er the peaceful deep.   
No candles shine,   
Nor tomb I need, instead   
Let them for me a bed   
Of twigs entwine. 

That no one weeps my end,   
Nor for me grieves,   
But let the autumn lend   
Tongues to the leaves,   
When brooklet ripples fall   
With murmuring sound,   
And moon is found   
Among the pine-trees tall,   
While softly rings   
The wind its trembling chime   
And over me the lime   
Its blossom flings. 

As I will then no more   
A wanderer be,   
Let them with fondness store   
My memory.   
And Lucifer the while,   
Above the pine,   
Good comrade mine,   
Will on me gently smile;   
In mournful mood,   
The sea sing sad refrain. . .   
And I be earth again   
In solitude. 

Romanian:

Mai am un singur dor  
În liniștea serii  
Să mă lăsați să mor  
La marginea mării;  
Să-mi fie somnul lin  
Și codrul aproape,  
Pe-ntinsele ape  
Să am un cer senin.  
Nu-mi trebuie flamuri,  
Nu voi sicriu bogat,  
Ci-mi împletiți un pat  
Din tinere ramuri.

Și nime-n urma mea  
Nu-mi plângă la creștet,  
Doar toamna glas să dea  
Frunzișului veșted.  
Pe când cu zgomot cad  
Isvoarele-ntr-una,  
Alunece luna  
Prin vârfuri lungi de brad.  
Pătrunză talanga  
Al serii rece vânt,  
Deasupră-mi teiul sfânt,  
Să-și scuture creanga.

Cum n-oi mai fi pribeag  
De-atunci înainte,  
M-or troieni cu drag  
Aduceri aminte.  
Luceferi, ce răsar  
Din umbră de cetini,  
Fiindu-mi prietini,  
O să-mi zâmbească iar.  
Va geme de patemi  
Al mării aspru cânt...  
Ci eu voi fi pământ  
În singurătate-mi.
