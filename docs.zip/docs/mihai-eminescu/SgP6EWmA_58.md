---
id: SgP6EWmA_58
title: "Floare-albastră - Blue-Flower"
sidebar_label: "Floare-albastră - Blue-Flower"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/SgP6EWmA_58"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Floare-albastră - Blue-Flower

Versuri: Mihai Eminescu, 1873  
Dedicaţie: Casandra Elena Alupului, prima iubire a lui Eminescu

- Iar te-ai cufundat în stele  
Şi în nori şi-n ceruri nalte?  
De nu m-ai uita încalte,  
Sufletul vieţii mele.

În zadar râuri în soare  
Grămădeşti-n a ta gândire  
Şi câmpiile asire  
Şi întunecata mare;

Piramidele-nvechite  
Urcă-n cer vârful lor mare -  
Nu căta în depărtare  
Fericirea ta, iubite!

Astfel zise mititica,  
Dulce netezindu-mi părul.  
Ah! ea spuse adevărul;  
Eu am râs, n-am zis nimica.

- Hai în codrul cu verdeaţă,  
Und-izvoare plâng în vale,  
Stânca stă să se prăvale  
În prăpastia măreaţă.

Acolo-n ochi de pădure,  
Lângă balta cea senină  
Şi sub trestia cea lină  
Vom şedea în foi de mure.

Şi mi-i spune-atunci poveşti  
Şi minciuni cu-a ta guriţă,  
Eu pe-un fir de romaniţă  
Voi cerca de mă iubeşti.

Şi de-a soarelui căldură  
Voi fi roşie ca mărul,  
Mi-oi desface de-aur părul,  
Să-ţi astup cu dânsul gura.

De mi-i da o sărutare,  
Nime-n lume n-a s-o ştie,  
Căci va fi sub pălărie -  
Ş-apoi cine treabă are!

Când prin crengi s-a fi ivit  
Luna-n noaptea cea de vară,  
Mi-i ţinea de subsuoară,  
Te-oi ţinea de după gât.

Pe cărare-n bolţi de frunze,  
Apucând spre sat în vale,  
Ne-om da sărutări pe cale,  
Dulci ca florile ascunse.

Şi sosind l-al porţii prag,  
Vom vorbi-n întunecime:  
Grija noastră n-aib-o nime,  
Cui ce-i pasă că-mi eşti drag?

Înc-o gură - şi dispare...  
Ca un stâlp eu stam în lună!  
Ce frumoasă, ce nebună  
E albastra-mi, dulce floare!

. . . . . . . . . . . . . .

Şi te-ai dus, dulce minune,  
Ş-a murit iubirea noastră -  
Floare-albastră! floare-albastră!...  
Totuşi este trist în lume!

English:

- Have you sunk into the stars again  
And into the clouds and into the high heavens?  
If you would not forget me,  
Soul of my life.

In vain rivers in the sun  
You pile up in your thoughts  
And the plains of Assyria  
And the dark sea;

The old pyramids  
Ascend to the sky their great peak -  
Do not seek in the distance  
Your happiness, my beloved!

Thus said the little girl,  
Sweetly smoothing my hair.  
Ah! she spoke the truth;  
I laughed, I said nothing.

- Come to the green forest,  
Where springs cry in the valley,  
The rock stands ready to collapse  
Into the majestic abyss.

There in the eyes of the forest,  
By the serene pond  
And under the smooth reed  
We will sit in blackberry leaves.

And then tell me stories  
And lies with your little mouth,  
I, on a chamomile thread  
I will try to make you love me.

And with the sun's warmth  
I will be red as an apple,  
I will untie my golden hair,  
To cover your mouth with it.

If he gives me a kiss,  
No one in the world will know,  
Because it will be under the hat -  
And then who cares!

When the moon has appeared through   
the branches on that summer night,  
He held my armpit,  
He would hold you by the neck.

On the path in the arches of leaves,  
Taking hold of the village in the valley,  
We will give each other kisses on the way,  
Sweet as the hidden flowers.

And arriving at the gate threshold,  
We will speak in the darkness:  
Our care is of no one,  
Who cares that I love you?

Another mouth - and it disappears...  
Like a pillar I stand under the moon!  
How beautiful, how crazy  
Is my blue, sweet flower!

. . . . . . . . . . . . . . . .

And you are gone, sweet wonder,  
Our love has died -  
Blue flower! blue flower!...  
However, it is sad in the world!
