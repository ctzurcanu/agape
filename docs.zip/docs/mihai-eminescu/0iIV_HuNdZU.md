---
id: 0iIV_HuNdZU
title: "Copii eram noi amândoi - We were both children"
sidebar_label: "Copii eram noi amândoi - We were both children"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/0iIV_HuNdZU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Copii eram noi amândoi - We were both children

Lyrics: Mihai Eminescu

Copii eram noi amândoi,  
Frate-meu şi cu mine.  
Din coji de nucă car cu boi  
Făceam şi înhămam la el  
Culbeci bătrâni cu coarne.

Şi el citea pe Robinson,  
Mi-l povestea şi mie;  
Eu zideam Turnul-Vavilon  
Din cărţi de joc şi mai spuneam  
Şi eu câte-o prostie.

Adesea la scăldat mergeam  
În ochiul de pădure,  
La balta mare ajungeam  
Şi l-al ei mijloc înotam  
La insula cea verde.

Din lut acolo am zidit,  
Din stuful des şi mare,  
Cetate mândră la privit,  
Cu turnuri mari de tinichea,  
Cu zid împreşurată.

Şi frate-meu ca împărat  
Mi-a dat mie solie,  
Să merg la broaşte nempăcat,  
Să-i chem în bătălie -  
Să vedem cine-i mai tare.

Şi împăratul broaştelor,  
C-un oacacŕ de fală,  
Primi - porunce oştirilor  
Ca balta s-o răscoale.  
Şi am pornit război.

Vai! multe broaşte noi am prins  
- Îmi pare chiar pe rege -  
Şi-n turnul negru le-am închis,  
Din insula cea verde.  
Spre sar-am făcut pace.

Şi drumul broaştelor le-am dat.  
Săltau cu bucurie,  
În balt-adânc s-au cufundat  
Ca să nu mai revie.  
Noi am pornit spre casă.

Atunci răsplata am cerut  
Pentru a mele fapte -  
Şi frate-meu m-a desemnat  
De rege-n miazănoapte  
Peste popoare-ndiane.

Motanul alb cel vistier,  
Mânzac cel chior ministru -  
Când de la el eu leafa-mi cer,  
El miaună sinistru.  
Cordial i-am strâns eu laba.

Şi împăratul milostiv  
Mi-a dat şi de soţie,  
Pe fiica lui cu râs lasciv  
Şi ţapănă, nurlie,  
Pe Tlantaqu-caputli.

Am mulţămit cu umil semn,  
- Drept mantie-o prostire -  
M-am dus l-amanta mea de lemn,  
În sfânta mânăstire,  
Într-un cotlon de sobă.

Şi ah! şi dragă-mi mai era!  
Vorbeam blând cu dânsa,  
Dară ea nu-mi răspundea  
Şi de ciudă eu atunci  
Am aruncat-o-n foc.

Şi pe şură ne primblam  
Peste stuf şi paie  
Şi pe munţi ne-nchipuiam.  
Cu fiece bătaie  
Mărşileam alături.

Şi pe cap mi se îmfla  
Casca de hârtie.  
O batistă într-un băţ.  
Steag de bătălie.  
Cântam: Trararah!

Ah! v-aţi dus visuri, v-aţi dus!  
Mort e al meu frate.  
Nimeni ochii-i n-a închis  
În străinătate -  
Poate-s deschişi şi-n groapă!

Dar ades într-al meu vis  
Ochii mari albaştri  
Luminează - un surâs  
Din doi vineţi aştri  
Sufletu-mi trezeşte.

Eu?   
Mai este inima-mi  
Din copilărie?
