---
id: loNdbFk8pyo
title: "Colinde, colinde! - Carols, carols!"
sidebar_label: "Colinde, colinde! - Carols, carols!"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/loNdbFk8pyo"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Colinde, colinde! - Carols, carols!

Lyrics: Mihai Eminescu

Colinde, colinde!  
E vremea colindelor  
Căci gheața se’ntinde  
Asemeni oglinzilor.  
Și tremură brazii  
Mișcând ramurelele  
Căci noaptea de azi-i  
Când scântee stelele.

Se bucur copii  
Copiii și fetele  
De dragul Mariei  
Își peptenă pletele,  
De dragul Mariii  
Ș’a Mântuitorului  
Lucește pe ceruri  
O stea călătorului…

English:

Carols, carols!  
It's carol time  
Because the ice is spreading  
Like mirrors.  
And the fir trees are trembling  
Moving their branches  
Because tonight is the night  
When the stars sparkle.

Children rejoice  
Children and girls  
For the sake of Mary  
They comb their hair,  
For the sake of Mary  
And of the Savior  
Shine in the heavens  
A star for the traveler...
