---
id: uQPzL70pKfQ
title: "Revedere - Return"
sidebar_label: "Revedere - Return"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/uQPzL70pKfQ"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Revedere - Return

Lyrics: Mihai Eminescu, 1879

­ - Codrule, codruțule,  
Ce mai faci, drăguțule,  
Că de când nu ne-am văzut  
Multă vreme au trecut  
Și de când m-am depărtat,  
Multă lume am îmblat.

­ - Ia, eu fac ce fac de mult,  
Iarna viscolu-l ascult,  
Crengile-mi rupându-le,  
Apele-astupându-le,  
Troienind cărările  
Și gonind cântările;

Și mai fac ce fac demult,  
Vara doina mi-o ascult  
Pe cărarea spre izvor  
Ce le-am dat-o tuturor,  
Împlându-și cofeile,  
Mi-o cântă femeile.

­- Codrule cu râuri line,  
Vreme trece, vreme vine,  
Tu din tânăr precum ești  
Tot mereu întinerești.

­ - Ce mi-i vremea, când de veacuri  
Stele-mi scânteie pe lacuri,  
Că de-i vremea rea sau bună,  
Vântu-mi bate, frunza-mi sună;

Și de-i vremea bună, rea,  
Mie-mi curge Dunărea,  
Numai omu-i schimbător,  
Pe pământ rătăcitor,  
Iar noi locului ne ținem,  
Cum am fost așa rămânem:

Marea și cu râurile,  
Lumea cu pustiurile,  
Luna și cu soarele,  
Codrul cu izvoarele.

Iar noi locului ne ținem,  
Cum am fost așa rămânem:

Marea și cu râurile,  
Lumea cu pustiurile,  
Luna și cu soarele,  
Codrul cu izvoarele.

English (by Corneliu M. Popescu):

"Forest, trusted friend and true,   
Forest dear, how do you do?   
Since the day i saw you last   
Many, many years have passed   
And though you still steadfast stand   
I have travelled many a land." 

"Yea, and I, what have I done?   
Watched the years their seasons run;   
Heard the squalls that through me groan   
Ere my singing birds have flown;   
Heard the creaking of my boughg   
Neath the mounted winter snows.   
Yea indeed, what have I done?   
Done as I have always done;   
Felt my summer leaves re-growing,   
Heard the village girls who going   
By the path that meets the spring   
Melancholy doina sing." 

"Forest, though the tempests blow,   
The years come and the years go,   
And the seasons wax and wane,   
You are ever young again." 

"What of seasons, when for ages   
All the sky my lake engages;   
What of years ill or good,   
When the sap mounts in the wood;   
What of years or ill,   
When the Danube rolls on still.   
Only man is always changing,   
O'er the world forever ranging;   
We each do our place retain,   
As we were, so we remain;   
Oceans, rivers, mountains high   
And the stars that light the sky,   
Saturn with its whirling rings,   
And the forest with its springs."
