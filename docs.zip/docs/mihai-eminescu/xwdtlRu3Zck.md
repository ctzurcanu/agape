---
id: xwdtlRu3Zck
title: "Lucifer 5.1"
sidebar_label: "Lucifer 5.1"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/xwdtlRu3Zck"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Lucifer 5.1

Lyrics: Mihai Eminescu  
Translation (from Romanian): Corneliu M. Popescu

Lucifer set out and o'er    
The sky his wings extended,    
And million years flew past before    
As many moments ended.  

A sky of stars above his way,    
A sky of stars below;    
As lightning flash midst them astray    
In one continuous flow.  

Till round his primal chaos hurled    
When out of causeless night    
The first, upflaming dawn unfurled    
Its miracle of light.    
[Instrumental]

Still further flew he ere the start    
Of things of form devoid,    
Spurred by the yearning of his heart,    
Far back into the void.  

Yet where he reach'd is not yet born    
Nor yet where eye to see;    
Beyond where struggling time was torn    
Out of eternity.  

Around him there was naught... And still,    
Strange yearning there was yet,    
A yearning that all space did fill,    
As when the blind forget.  

"O, Father God, this knot untie    
Of my celestial birth,    
And praised you will be on high    
And on the rolling earth.  

And praised you will be on high    
And on the rolling earth.  

The price you ask is little count,    
Give fate another course,    
For you are of fair life the fount    
And of calm death the source.  

Take back this halo from my head,    
Take back my starry lour,    
And give to me, o God, instead    
Of human love one hour.  

Out of the chaos was I wrought,    
In chaos would I be dispersed,    
Out of the empty darkness brought,    
For darkness do I thirst..."  

Out of the empty darkness brought,    
For darkness do I thirst..."
