---
id: 9jL_Gz9uUxs
title: "The Battle of Rovine"
sidebar_label: "The Battle of Rovine"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/9jL_Gz9uUxs"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## The Battle of Rovine

Lyrics: Mihai Eminescu  
Translator: Corneliu M. Popescu  
https://en.wikipedia.org/wiki/Battle_of_Rovine

No sooner had he gone than mighty the commotion!    
The forest rang with arms, and rumbled like the ocean,   
Amidst the greenwood thousand heads with long and plaited hair,    
And sev'ral thousands more besides that did bright helmets wear.  

While wave on wave of cavalry over the plain did flood   
Astride high-prancing chargers, their stirrups carved of wood.   
Thundering over the battered earth an avalanche they went,   
Lances levelled to the charge and bows near double-bent; 

Till like a shower of shivering light that whistled through the air,    
A storm of arrows leapt and sang and flew from everywhere:    
A din of blows on armour dealt like rattling of hail,    
The noise of hoof and sword and lance, the roar of battle gale.    
Unheeded was the Emperor's fury, lion-like his rage,    
For hotter still about his troops the fight did deadly wage; 

Unheeded did the green flame flutter o'er his stricken ranks    
For mightily assailed in front, attacked on both their flanks,   
The East's entire battle host was scattered in the fray   
And line on line of infantry mown down like summer hay. 

A steady rain of arrows fell and sword blows did resound,   
While riders dropped on every hand and dead bestrewed the ground.   
Till, onset from all sides at once, helpless to fight or fly,   
It seemed the very earth was doomed and fallen was the sky... 

Mircea himself led on his men midst storm of battle lust   
That came, and came, and came, that trod all in the dust;   
Their cavalry undaunted, a wall of lances proud   
Which through that pagan army streets of daylight ploughed   
And laid to earth their thousands like sheafs of ripened corn,   
High in the van of conquest Wallachia's banner borne; 

As deluge flung from heaven that burst upon the seas,   
Till in an hour the heathen were chaff before the breeze   
And from that hail of iron fast towards the Danube fled,   
While gloriously behind them th'Romanian army spread. 

And from that hail of iron fast towards the Danube fled,   
While gloriously behind them th'Romanian army spread.
