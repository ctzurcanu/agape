---
id: UqovW2cd15M
title: "Luceafărul - The Evening Star 3.1"
sidebar_label: "Luceafărul - The Evening Star 3.1"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/UqovW2cd15M"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Luceafărul - The Evening Star 3.1

Lyrics: Mihai Eminescu

Trecu o zi, trecură trei  
Şi iarăşi, noaptea, vine  
Luceafărul deasupra ei  
Cu razele senine.

Ea trebui de el în somn  
Aminte să-şi aducă  
Şi dor de-al valurilor Domn  
De inim-o apucă:

– Cobori în jos, luceafăr blând  
Alunecând pe-o rază,  
Pătrunde-n casă şi în gând,  
Şi viaţa-mi luminează.

Cum el din cer o auzi,  
Se stinse cu durere,  
Iar ceru-ncepe a roti  
În locul unde piere;

În aer rumene văpăi  
Se-ntind pe lumea-ntreagă,  
Şi din a chaosului văi  
Un mândru chip se-ncheagă;

Pe negre viţele-i de păr  
Coroana-i arde pare,  
Venea plutind în adevăr  
Scăldat în foc de soare.

Din negru giulgi se desfăşor  
Marmoreele braţă,  
El vine trist şi gânditor  
Şi palid e la faţă;

Şi palid e la faţă;

Dar ochii mari şi minunaţi  
Lucesc adânc himeric,  
Ca două patimi fără saţ  
Şi pline de-ntuneric.

– Din sfera mea venii cu greu  
Ca să te-ascult ş-acuma,  
Şi soarele e tatăl meu,  
Iar noaptea-mi este muma;

O, vin’, odorul meu nespus,  
Şi lumea ta o lasă;  
Eu sunt luceafărul de sus,  
Iar tu să-mi fii mireasă.

Iar tu să-mi fii mireasă.

English:

Days have past since: but Evening-star  
Comes up againd and stays  
Just as before, spreading o'er her  
His clear, translucent rays.  
   
In sleep she would remember him  
And, as before, her whole  
Wish for the Master of the waves  
Is clinching now her soul.  
   
-"Descend to me, mild Evening-star  
Thou canst glide on a beam,  
Enter my dwelling and my mind  
And over my life gleam!"  
   
He hears: and from the dire despair  
Of such an woeful weird  
He dies, and the heavens revolve  
Where he has disappeared.  
   
Soon in the air flames ruddy spread,  
The world in their grip hold;  
A superb form the spasms of the  
Chaotic valleys mold.  
   
On his locks of black hair he bears  
His crown a fierce fire frames;  
He floats as he really comes  
Swimming in the sun's flames.  
   
His black shroud lets develop out  
His arms marbly and hale;  
He pensively and sadly brings  
His face awfully pale.

His face awfully pale.  
   
But his big wonderful eyes' gleam,  
Chimerically deep,  
Shows two unsatiated spasms  
That but into dark peep.  
   
-"From my sphere hardly I come to  
Follow thy voice, thy sight;  
The bright sun is my father and  
My mother is the night.  
   
O come, my treasure wonderful  
And thy world leave aside  
For I am Evening-star from up  
And thou wouldst be my bride.

And thou wouldst be my bride.
