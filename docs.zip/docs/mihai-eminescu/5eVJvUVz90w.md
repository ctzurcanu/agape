---
id: 5eVJvUVz90w
title: "Why do you wail, o forest trees? - Ce te legeni, codrule?"
sidebar_label: "Why do you wail, o forest trees? - Ce te legeni, codrule?"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/5eVJvUVz90w"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Why do you wail, o forest trees? - Ce te legeni, codrule?

Lyrics: Mihai Eminescu  
Translation (from Romanian): Corneliu M. Popescu

Why do you wail, o forest trees,   
Forest, without rain or breeze,   
Your branches ill at ease?

How indeed should I not wail   
When the hours of summer fail!   
Nights grow longer, days get short,   
On my branches few leaves caught, 

And the winds with bitter sword   
Drive my chorister abroad ;   
Autumn winds that forest flay,   
Winter near, spring far away. 

How indeed should I not groan    
When my singing birds have flown,   
And across the frozen sky   
Flocks of swallows hurry by,   
And with them my fancies fly   
Leaving me alone to sigh; 

Hurry on as time in flight   
Turning day half into night,   
Time that o'er the forest rings   
With a fluttering of wings... 

And they pass and leave me cold,   
Nude and shivering and old;   
For my thoughts with them have flown,   
And with them my gladness gone!

Why do you wail, o forest trees,   
Your branches ill at ease?

And they pass and leave me cold,   
Nude and shivering and old;

Romanian original:

– „Ce te legeni, codrule,  
Fără ploaie, fără vânt,  
Cu crengile la pământ?"  
– „De ce nu m-aș legăna,  
Dacă trece vremea mea!  
Ziua scade, noaptea crește  
Și frunzișul mi-l rărește.  
Bate vântul frunza-n dungă -  
Cântăreții mi-i alungă;  
Bate vântul dintr-o parte -  
Iarna-i ici, vara-i departe.  
Și de ce să nu mă plec,  
Dacă păsările trec!  
Peste vârf de rămurele  
Trec în stoluri rândunele,  
Ducând gândurile mele  
Și norocul meu cu ele.  
Și se duc pe rând pe rând,  
Zarea lumii-ntunecând,  
Și se duc ca clipele,  
Scuturând aripele,  
Și mă lasă pustiit,  
Veștejit și amorțit  
Și cu doru-mi singurel,  
De mă-ngân numai cu el!"
