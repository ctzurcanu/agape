---
id: 4CdvGYwwOmA
title: "Călin Nebunul - Calin the Fool [V] A"
sidebar_label: "Călin Nebunul - Calin the Fool [V] A"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/4CdvGYwwOmA"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Călin Nebunul - Calin the Fool [V] A

Lyrics: Mihai Eminescu

— Tată, uite-inelul care într-o noapte mi-a perit  
Făr’ să ştiu nici cum, nici unde. — Cine dară l-a găsit?  
Cine a adus alunele-astea? Logofeţii spun că baba.  
O strigară de la poartă să s-urnească mai degrabă.  
Când, în locu-i, cine vine? Un voinic, strein. El spune:  
— Împărate prenălţate, eu vi l-am pus în alune.  
Zice-atuncea împăratul: — Cum, voinice, şi cu cale  
A ajuns inelul fetei în mânile dumitale?  
— Împărate, prenălţate, iaca cum şi iaca cum.  
Da’ ţiganul nici mai ştie, faţa lui îi numai scrum:  
— Împărate luminate, cum poţi ca să-mi strici hatârul?  
Eu am omorât toţi zmeii. — Cum, ţigane? — Cu satârul;  
Mă înec dacă l-aţi crede... dar la feţe tot îmi schimbă.  
— Să se cate zmeii, doamne, dacă au vârfuri de limbă.  
Îi cătară şi, ce-i dreptul, nici la unul nu era  
Şi Călin atunci le scoate şi le-arată în basma,  
Împăratul porunceşte ca s-aduc-un armăsar  
Şi de coada lui să lege pe ţiganul bucătar  
Şi de coadă-i mai legară lângă el un sac de nuci.  
Cade-o nucă — o bucăţică, astfel îl făcu hăbuci.  
— Ş-acum tu, voinice, zise, mi-i fi ginere — Ba nu  
Altă fată, împărate, tare dragă îmi căzu.  
Am un frate-nsă de cruce, tot fecior de împărat,  
Şi de mult ţi-era s-o ceară, deşi nu s-a cutezat.  
Uite-l ice. Dară fata se cam uită vrând-nevrând,  
Că tot pe Călin Nebunul l-ar fi vrut ea mai curând.  
Ci-ndure că cu feciorul era mai de o potrivă.  
La a ochilor lui jele s-a muiet mai milostivă.  
Deci făcur-o nuntă mare ş-a ţinut trei luni de rând.  
Lăutari, benchet, halaiuri, tot ce-ţi poate trece-n gând.  
Ce nu era? Dragă Doamne, era nuntă-mpărătească.  
— Dar acum mă duc, le zice. Pe-a mea Domnul s-o păzească.  
Nici nu ştiu cum e, cum nu e. Geaba fratele-i de cruce,  
Geaba tânăra mireasă îl mai ţin cu vorbă dulce,  
Dor i-i, Doamne, şi nici ştie cum l-apucă-un dor avan,  
Că de când n-o mai văzuse se scursese şapte ani.  
Când ajunse locul unde casa tatălui său fuse,  
El văzu palate mândre în livezi măreţe puse.  
Şi pe o câmpie goală el văzu de vite-o ciurdă,  
După ea copil călare c-un ciomag în mină zburdă.  
Şi părea că are şase ani şi-ncă ceva mai bine.  
— Bună vreme, măi băiete! — Mulţămim, voinic streine!  
— Nu-mi ştii spune cine şade-n aste rânduri de palat?  
— Doi voinici ce-au scos odată pe trei fete de-mpărat  
Din a zmeilor prinsoare... — Ş-au luat care pe care?  
Mijlociul pe cea mică şi cel mare pe cea mare.  
— Da’ ce-i cu cea mijlocie? — La găini au pus-o ei  
Şi să vezi, voinic străine, că eu sunt feciorul ei.  
Mama-mi spune câteodată, de-o întreb a cui îs eu,  
Că-s a lui Călin Nebunul. Cine-o mai fi, nu ştiu, zău!  
Când aude... numai dânsul îşi ştia inima lui,  
Că, să iertaţi dumneavoastră, de... era băietul lui.  
— Da’ mă rog, bade, ajută-mi să dau vitele-n ocol.  
Înserează... Stele împlu tot seninul lin şi gol...  
Cu băiatu-n bordei intră şi pe capătu-unei laiţi  
Lumina mucos şi negru într-un hârb un roş opaiţ,  
Se coceau pe vatra sură două turte în cenuşă,  
Un papuc e într-o grindă, celălalt e după uşă,  
Pin gunoi se primbla iute legănată o răţuşcă  
Şi pe-un ţol orăcăieşte un cucoş închis în cuşcă  
Hârâie-n colţ colbăită noduros râşniţa veche,  
În cotlon toarce motanul, pieptănându-şi o ureche  
Sub icoana afumată unui sfînt cu comanac  
Arde-n candelă-o lumină cît un sâmbure de mac,  
Pe-a icoanei policioară, busuioc uscat şi mintă  
Împlu casa de-o mireasmă pipărată şi prea sfântă.  
O beşică-n loc de sticlă e lipită-n ferăstruie,  
Pintre care trece-o dungă mohorâtă şi gălbuie,  
Cofa-i albă cu flori negre şi a brad miroase apa,  
De lut plină, rezimată, stă pe coada ei o sapă.  
Pe cuptorul uns cu humă Călinaş cel mititel  
Zugrăvise c-un cărbune un clapon şi un purcel,  
Cu codiţa ca un sfredel şi cu fuse-n loc de labă  
Cum i se şedea mai bine purceluşului de treabă.  
Pe un pat cu paie numai doarme tânăra-i nevastă,  
În mocnitul întuneric faţa ei lîngă fereastră...  
Şi tot sufletul dintr-însul pare-atunci că şi-l înhoalbă  
Şi-l adună-n ochi de trece peste faţa ei cea albă.  
El s-aşază lângă dânsa, faţa ei o netezeşte,  
O dezmiardă cu durere, o sărut,-o drăgosteşte,  
Pleacă gura la ureche-i, blând pe nume el o cheamă  
Ea deschide somnoroasă lunge gene de aramă  
Şi adânc la el se uită, i se pare că visează,  
Ar zâmbi şi nu se-ncrede, ar striga şi nu cutează,  
El din patu-i o ridică şi pe pieptul lui o pune,  
Toată viaţa-i se adună-n al ei sân rotund şi june.  
Ea se uită şi se uită... mută... un cuvânt nu spune,  
Doară râde c-ochi-n lacrimi, speriată de-o minune,  
Ş-apoi îi suceşte părul’n-a ei degete subţire  
Şi-şi ascunde faţa roşă pe-al lui piept duios de mire.  
El ştergarul i-l desprinde şi-l împinge lin la vale,  
Drept în creştet o sărută pe-al ei păr de aur moale  
Şi bărbia ei ridică, s-uită-n ochii plini de apă  
Şi pe sânu-i o desmeardă şi din gură-i se adapă.  
Dar a doua zi voinicul mânios intră-n ogradă;  
Fraţii lui, cum îl văzură la genunchi veneau să-i cadă:  
...
