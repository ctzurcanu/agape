---
id: PhujnO45Svg
title: "Mușatin și Codrul - Mușatin and the Deep Forest p5"
sidebar_label: "Mușatin și Codrul - Mușatin and the Deep Forest p5"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/PhujnO45Svg"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Mușatin și Codrul - Mușatin and the Deep Forest p5

Lyrics: Mihai Eminescu

Și spre mal se-ndreaptă iară  
Luntrea mică și ușoară,  
Iar Mușatin se coboară,  
Calea muntelui apucă  
Până-n vârfuri să se ducă,  
Pân-ce noaptea l-au ajuns  
În cel codru nepătruns.

Dar cu noaptea-n cap pornește,  
Se tot urcă voinicește,  
Doară culmea va sui-o  
Pe când s-o miji de ziuă.

Pe culmea cea înălțată  
El ajunge deodată  
Și făcându-și ochii roată  
El privește lumea toată;  
Vede cerul sfântului  
Și fața pământului:  
Că departe se-ntind șesuri,  
Ce cu ochii nu le măsuri,  
Unde soarele cel sfânt  
Parcă iese din pământ;

Colo-n zarea depărtată  
Nistrul mare i s-arată  
Dinspre țările tătare  
Și departe curge-n mare  
La Liman ca și o salbă  
Se-nșira Cetatea Albă.

Iar pe fața mării line  
Trec corăbiile pline,  
Trec departe de pământ,  
Pânzele umflate-n vânt.

Iar privind spre miazăzi  
Dunărea el o zări  
Într-un arc spre mare-ntoarsă  
Și pe șapte guri se varsă.

De la Nistru pân-la ea  
Țară mândră se-ntindea  
Vede șesuri fumegând,  
Dealuri mândre înverzind,  
Vede codri cum coboară,  
Deal cu deal, scară cu scară,  
Răsfirându-se pe șes,  
Unde râurile ies,  
Și pe vârfuri de păduri,  
Mânăstiri cu-ntărituri,  
Vede târguri, vaduri, sate  
Pe câmpie presărate,  
Vede mândrele cetăți  
Stăpânind pustietăți,  
Vede turmele de oi  
Cu ciobanii dinapoi,  
Cu fluiere și cimpoi,

Iară hergheliile  
Petreceau câmpiile  
Și s-așterneau vântului  
Ca umbra pământului  
Și de-a lungul râurior  
S-așterneau pustiurilor.

Iară șoimul tinerel  
Pe deasupra-i zboară el  
Și din gură-i cuvinta:  
­ Să trăiești, Măria-Ta!  
Câtă lume câtă zare  
De la Nistru pân-la mare:  
Fă-ți odată ochii roată  
C-aceasta-i Moldova toată.

English:

And towards the shore again   
the small and light boat heads,   
And Mușatin descends,   
Taking the mountain path   
To the peaks to go   
Until the night has overtaken him   
In the impenetrable forest.   
But with the night in his head he sets off,   
Still climbing bravely,   
Only the summit will he reach   
When the day breaks.   
He reaches the lofty summit suddenly   
And rolling his eyes   
He looks at the whole world;   
He sees the holy sky   
And the face of the earth:   
How far the plains stretch,   
That the eyes cannot measure   
Where the holy sun   
As if it were emerging from the earth. 

In the distant horizon  
The great Dniester appears to him  
From the Tatar lands  
And far away it flows into the sea  
At the Liman like a necklace  
The White Fortress was lined up.

And on the smooth face of the sea  
The full ships pass,  
They pass far from the land,  
The sails swollen in the wind.

And looking to the south  
He saw the Danube  
In an arc towards the sea  
And it flows into seven mouths.

From the Dniester to her  
A proud land stretched  
Sees smoking plains,  
Proud hills turning green,  
Sees forests descending,  
Hill by hill, ladder by ladder,  
Spreading out on the plain,  
Where rivers emerge,  
And on forest peaks,  
Monasteries with fortifications,  
Sees fairs, fords, villages  
On the scattered plains,  
Sees proud fortresses  
Dominating the wastelands,  
Sees flocks of sheep  
With shepherds behind,  
With whistles and bagpipes,  
And the studs  
Spread the plains  
And spread out to the wind  
Like the shadow of the earth  
And along the rivers  
They spread out to the wastelands.

And the young falcon  
He flies above it  
And from his mouth the word:  
Long live, Your Majesty!  
How many worlds, how many horizons  
From the Dniester to the sea:  
Turn your eyes once  
That this is all of Moldova.
