---
id: L8t5ci8eUZI
title: "Luceafărul - The Evening Star 5.2"
sidebar_label: "Luceafărul - The Evening Star 5.2"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/L8t5ci8eUZI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Luceafărul - The Evening Star 5.2

Lyrics: Mihai Eminescu

Aum mantra: https://en.wikipedia.org/wiki/Om

– Hyperion, ce din genuni  
Răsai c-o-ntreagă lume,  
Nu-mi cere semne şi minuni  
Ce nu au chip şi nume.

Tu vrei un om să te socoţi,  
Cu ei să te asameni?  
Dar piară oamenii cu toţi  
S-ar naşte iarăşi oameni.

Tu vrei un om să te socoţi,  
Cu ei să te asameni?  
Dar piară oamenii cu toţi  
S-ar naşte iarăşi oameni.

Ei numai doar durează-n vânt  
Deşarte idealuri –  
Când valuri află un mormânt  
Răsar în urmă valuri.

Ei au doar stele cu noroc  
Şi prigoniri de soarte,  
Noi nu avem nici timp, nici loc,  
Şi nu cunoaştem moarte.

Din sânul vecinicului ieri  
Trăieşte azi ce moare,  
Un soare de s-ar stinge-n cer  
S-aprinde iarăşi soare.

Părând în veci a răsări,  
Din urmă moartea-l paşte,  
Căci toţi se nasc spre a muri  
Şi mor spre a se naşte.

Iar tu, Hyperion, rămâi,  
Oriunde ai apune…  
Cere-mi cuvântul meu dentâi –  
Să-ţi dau înţelepciune?

Să-ţi dau înţelepciune?

Vrei să dau glas acelei guri,  
Ca dup-a ei cântare  
Să se ia munţii cu păduri  
Şi insulele-n mare?

Vrei poate-n faptă să arăţi  
Dreptate şi tărie?  
Ţi-aş da pământul în bucăţi  
Să-l faci împărăţie.

Îţi dau catarg lângă catarg,  
Oştiri spre a străbate  
Pământu-n lung şi marea-n larg,  
Dar moartea nu se poate…

Şi pentru cine vrei sa mori?  
Întoarce-te, te-ndreaptă  
Spre-acel pământ rătăcitor  
Şi vezi ce te aşteaptă.

Şi vezi ce te aşteaptă.

English:

-"Hyperion, that comest from  
The depths with the world's swarm,  
Do not ask signs and miracles  
That have no name nor form.  
   
Thou wantest to count among men,  
Take their resemblance vain;  
But would now the whole mankind die  
Men will be born again.  
   
But they are building on the wind  
Ideals void and blind;  
When human waves run into graves  
New waves spring from behind.  
   
Fate's persecutions, lucky stars,  
They only are to own;  
Here we know neither time nor space,  
Death we have never known.  
   
From the eternal yesterday  
Drinks what to-day will drain  
And if a sun dies on the sky  
A sun quickens again.  
   
Risen as for ever, death though  
Follows them like a thorn  
For all are born only to die  
And die to be reborn.  
   
But thou remainest wheresoe'er  
Thou wouldst set down or flee.  
Thou art of the prime form and an  
Eternal prodigy.  
   
Thou wilt now hear the wondrous voice  
At whose bewitched singing  
Mounts woody get skipping to skies  
Into sea Island sinking!  
   
Perhaps thou wilt more: show in deeds  
Thy sense of justice, might,  
Out of the earth's lumps make an empire  
And settle on its height!  
   
I can give thee millions of vessels  
And hosts; thou, bear thy breath  
O'er all the lands, o'er all the oceans:  
I cannot give thee death.  
   
For whom thou wantest then to die?  
Just go and see what's worth  
All that is waiting there for thee  
On that wandering earth!"

"Look at that wandering earth!"
