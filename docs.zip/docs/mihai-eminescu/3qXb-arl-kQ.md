---
id: 3qXb-arl-kQ
title: "Calul Troian - The Trojan Horse"
sidebar_label: "Calul Troian - The Trojan Horse"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/3qXb-arl-kQ"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Calul Troian - The Trojan Horse

Lyrics: Mihai Eminescu

Și ascultând așa fel de-al unora îndemn,  
Băgară în cetate pe calul cel de lemn  
Ș-apoi pe veselie, pe chef se așternură  
Pân- ce în miezul nopții pe toții somnu-i fură...  
Din calul acel mare elinii se coboară,  
Cu pază ei prin uliți în pândă se strecoară;  
Cum văd că mic și mare căzuse-n somn ca morți,  
Ei gâtuie străjerii, ce stau lungiți la porți  
Ș-aprind făclii în noapte pe-a zidurilor creste.  
Din Tenedos văzură luminile aceste  
Și-mplătoșați cum fură, armați cu lănci și săbii,  
S-apropie de țărmuri pe negrele corăbii.  
Când peste lumea toată domnea a nopții slavă  
Ei prea cu molcomișul și fără de gâlceavă  
Intrară în cetate... oricare repezi  
Și începur-în toții a da și a snopi.  
Tăiau bătrâni și tineri, din mic până la mare,  
Ostași în floarea vârstei și tinere fecioare...  
Și-s chiote, blesteme din inimă, rărunchi.  
Prin porțile cetății curgeau pân-în genunchi  
Șiroaiele de sânge... pe pruncii cei de țâță  
Îi aruncau în flăcări, să nu rămâie viță  
Și urmă de Troada... Și dând în visterie  
Grămezile de aur răpeau cu lăcomie.  
Trei zile pustiiră cetatea și olatul  
Împlând cu jale țara lui Priam-împăratul.  
Când oamenii-s grămadă uciși în orice loc,  
Elinii atunci dederă cetății mândre foc  
De răsărea din ziduri o mare de jeratec  
Roșind bolta întreagă și crugul singuratec.  
Ard turnurile-n vânturi ­de vaietele mumii  
Nu se vedea de flăcări nici marginile lumii.

English:

And listening to such an exhortation from some,  
They rode into the city on the wooden horse  
And then, on joy, on revelry, they lay down  
Until midnight stole everyone's sleep...  
From that great horse the Greeks dismounted,  
With guard they crept through the streets in ambush;  
When they saw that small and great had fallen asleep like the dead,  
They strangled the guards, who lay stretched out at the gates  
And lit torches in the night on the crests of the walls.  
From Tenedos they saw these lights  
And, armed with spears and swords,  
They approached the shores on the black ships.  
When the glorious night reigned over the whole world  
They too meekly and without quarrel  
Entered the city... whatever rush  
And they all began to give and to shew.  
They cut old and young, from small to large,  
Soldiers in the prime of life and young virgins...  
And there are scoldings, curses from the heart, kidneys.  
Through the gates of the city flowed up to the knees  
Streams of blood... on the suckling babies  
They threw them into the flames, so that no vines would remain  
And no trace of Troas... And giving into the treasury  
The heaps of gold they greedily stole.  
For three days they devastated the city and the pot  
Filling the land of Priam the king with grief.  
When people are killed in droves everywhere,  
The Hellenes then set fire to the proud city  
From the walls rose a sea of ​​embers  
Reddening the entire vault and the lonely circle.  
The towers burn in the winds with the wails of the mummy  
Not even the edges of the world could be seen from the flames.
