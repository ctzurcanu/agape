---
id: sE7IhyIepoQ
title: "Urseala - The Destining"
sidebar_label: "Urseala - The Destining"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/sE7IhyIepoQ"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Urseala - The Destining

Lyrics: Mihai Eminescu

Dar deodată din părete  
Ies ursite ca pe-o poartă,  
Flori albastre au în plete,  
Câte-o stea în frunte poartă.  
Și de-o tainică lumină  
Toată casa este plină  
Ce din ochii lor porni.  
Peste leagănu-i se-nclină  
Și-ncepură a-l meni:

­ Ca și leii să fii tare  
Și frumos ca primăvara,  
Să fii gingaș ca o floare,  
Luminos ca luna sara;  
Și iubit să fii de lume,  
S-ai averi și mare nume,  
Să te faci chiar împărat  
Și să-ți meargă astfel cum e  
La ficiori din basme dat.

Zise-atunci duioasa mamă:  
­ Mulțămesc de câte-ascult,  
Dară mulți i-or fi de samă  
Ș-or avea atât de mult.  
Lui să-i dați ce din mulțime  
N-a putut să aibă nime,  
Și nespus și fără rost ­  
Ș-atunci zâne din nălțime  
Vă sărut piciorul vost.

Zise-atunci, din ele una:  
­ De-a dorești cu dinadinsul,  
Fie-i dat cu totdeuna  
El să simt-adânc într-însul  
Dorul după ce-i mai mare  
N-astă lume trecătoare,  
După ce-i desăvârșit  
Și să-și vadă la picioare  
Acest dar neprețuit.

Ele pier. Iară băietul  
A crescut cum l-a menitu-l,  
Se făcu frumos cu-ncetul,  
Cine-l vede l-a-ndrăgitu-l.  
Și deși ca leul tare,  
Era gingaș ca o floare  
Și isteț era cu duhul,  
Cum a toate-s știutoare  
Doară luna și văzduhul.

English:

But suddenly from the wall  
Come out bears like a gate,  
Blue flowers in their hair,  
Each one carries a star on its forehead.  
And with a mysterious light  
The whole house is filled  
That started from their eyes.  
Over his cradle they bent  
And began to detine for him:

Like lions to be strong  
And beautiful as spring,  
To be gentle as a flower,  
Bright as the rising moon;  
And to be loved by the world,  
That you would have wealth and a great name,  
To become even an emperor  
And may it go as it is  
To the children in fairy tales given.

Then said the tender mother:  
I thank you for what I listen to,  
But many will be equal  
And they will have so much.  
Give him what from the crowd  
No one could have,  
And unspeakable and pointless  
And then fairies from on high  
I kiss your foot.

Then said one of them:  
If you wish with all your heart,  
May it be granted to him at all  
So that he may feel deep within him  
The longing for what is greater  
In this fleeting world,  
After what is perfect  
And see at his feet  
This priceless gift.

They perish. And the boy  
Grew up as he had intended,  
He became beautiful in thought,  
Whoever saw him fell in love with him.  
And although strong as a lion,  
He was delicate as a flower  
And his spirit was clever,  
As only the moon and the sky know everything.
