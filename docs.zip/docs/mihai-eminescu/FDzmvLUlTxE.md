---
id: FDzmvLUlTxE
title: "Când amintirile... - When memories..."
sidebar_label: "Când amintirile... - When memories..."
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/FDzmvLUlTxE"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Când amintirile... - When memories...

Versuri: Mihai Eminescu, 1883

Când amintirile-n trecut  
Încearcă să mă cheme,  
Pe drumul lung și cunoscut  
Mai trec din vreme-n vreme.

Deasupra casei tale ies  
Și azi aceleași stele,  
Ce-au luminat atât de des  
Înduioșării mele.

Și peste arbori răsfirați  
Răsare blânda lună,  
Ce ne găsea îmbrățișați  
Șoptindu-ne-mpreună.

A noastre inimi își jurau  
Credință pe toți vecii,  
Când pe cărări se scuturau  
De floare liliecii.

Putut-au oare-atâta dor  
În noapte să se stingă,  
Când valuri de izvor  
N-au încetat să plângă,

Cum luna trece prin stejari  
Urmând mereu în cale-și  
Când ochii tăi, tot încă mari,  
Se uită dulci și galeși?

Când amintirile-n trecut  
Încearcă să mă cheme,  
Pe drumul lung și cunoscut  
Mai trec din vreme-n vreme.

Iar luna trece prin stejari  
Urmând mereu în cale-și  
Când ochii tăi, tot încă mari,  
Se uită dulci și galeși?

English:

When memories of the past  
Try to call me,  
On the long and familiar road  
I still pass by from time to time.

Above your house,  
And today the same stars come out,  
That have so often illuminated  
My tenderness.

And over the spreading trees  
The gentle moon rises,  
That found us embraced  
Whispering together.

Our hearts swore  
Faith for all eternity,  
When on the paths the bats shook  
From the flower.

Could such longing  
Be extinguished in the night,  
When the waves of spring  
Have not stopped crying,

As the moon passes through the oaks  
Always following in its path  
When your eyes, still large,  
Look sweet and Welsh?

When memories in the past  
Try to call me,  
On the long and familiar road  
I still pass by from time to time.

And the moon passes through the oak trees  
Always following its path  
When your eyes, still wide,  
Look sweet and Welsh?
