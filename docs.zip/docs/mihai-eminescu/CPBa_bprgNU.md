---
id: CPBa_bprgNU
title: "Luceafărul - The Evening Star 5.1 v3"
sidebar_label: "Luceafărul - The Evening Star 5.1 v3"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/CPBa_bprgNU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Luceafărul - The Evening Star 5.1 v3

Lyrics: Mihai Eminescu

Porni luceafărul. Creşteau  
În cer a lui aripe,  
Şi căi de mii de ani treceau  
În tot atâtea clipe.

Un cer de stele dedesubt  
Deasupra-i cer de stele –  
Părea un fulger nentrerupt  
Rătăcitor prin ele.

Şi din a chaosului văi,  
Jur împrejur de sine,  
Vedea ca-n ziua cea dentâi  
Cum izvorau lumine.

Cum izvorând îl înconjor  
Ca nişte mări de-a-notul …  
El zboară, gând purtat de dor,  
Pân’ piere totul, totul.

Căci unde-ajunge nu-i hotar,  
Nici ochi spre a cunoaşte,  
Şi vremea-ncearcă în zadar  
Din goluri a se naşte.

Nu e nimic şi totusi e  
O sete care-l soarbe,  
E un adânc asemene  
Uitării celei oarbe.

– De greul negrei vecinicii  
Părinte, mă dezleagă  
Şi lăudat pe veci să fii  
Pe-a lumii scară-ntreagă.

Pe-a lumii scară-ntreagă.

O, cere-mi, Doamne, orice preţ,  
Dar dă-mi o altă soarte,  
Căci tu izvor eşti de vieţi  
Şi dătător de moarte.

Reia-mi al nemuririi nimb  
Şi focul din privire  
Şi pentru toate dă-mi în schimb  
O oră de iubire.

Din chaos, Doamne-am apărut  
Şi m-aş întoarce-n chaos…  
Şi din repaos m-am născut  
Mi-e sete de repaos.

Mi-e sete de repaos.

English:

Then Evening-star went out. His wings  
Grow, into heavens dash,  
And on his way millenniums  
Flee in less than a flash.  
   
Below, a depth of stars; above,  
The heaven stars begem, -  
He seems an endless lightning that  
Is wandering through them.  
   
And from the Chaos' vales he sees  
How in an immense ring  
Round him, as in the World's first day,  
Lights from their sources spring;  
   
How, springing, they hem him like an  
Ocean that swimming nears...  
He flees carried by his desire  
Until he disappears.  
   
For that region is boundless and  
Searching regards avoids  
And Time strive vainly there to come  
To life from the dark voids.  
   
'Tis nought. 'Tis, though, thirst that sips him  
And which he cannot shun,  
'Tis depth unknown, comparable  
To blind oblivion.  
   
-"From that dark, choking, endlessness  
Into which I am furled,  
Father, undo me, and for e'er  
Be praised in the whole world!

Be praised in the whole world!  
   
Ask anything for this new fate  
For with mine I am through:  
O hear my prayer, O my Lord, for  
Thou gives life and death too.  
   
Take back my endlessness, the fires  
That my being devour  
And in return give me a chance  
To love but for an hour!  
   
I've come from Chaos; I'd return  
To that my former nest...  
And as I have been brought to life  
From rest, I crave for rest!"

"From rest, I crave for rest!"
