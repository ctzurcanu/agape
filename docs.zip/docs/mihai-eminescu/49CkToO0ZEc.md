---
id: 49CkToO0ZEc
title: "Why do you sway, o forest deep?"
sidebar_label: "Why do you sway, o forest deep?"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/49CkToO0ZEc"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Why do you sway, o forest deep?

Lyrics: Mihai Eminescu

Why do you sway, o forest deep,  
(Why do you sway, o forest deep,)  
Without rain or wind’s rough sweep,  
(Without rain or wind’s rough sweep,)  
Branches bowed, as if to weep?

—Why shouldn’t I sway, bend, and sigh,  
When my time is passing by?  
Days grow short and nights stretch wide,  
Leaves grow thin, no place to hide.

Wind stripes leaves in lines so sharp,  
Drives my songbirds from their harp;  
Gusts blow cold from north to south,  
Winter’s here, summer’s drought.  
Why not bow as seasons flee,  
When the birds desert the tree?

Over treetops, high they sail,  
Swallows flock in twilight’s veil,  
Carrying my thoughts away,  
And my luck, they steal, they stray.  
One by one, they fade from sight,  
Darkening the edge of light,  
Swift as moments, wings take flight,  
Shaking off the bonds of night.

Left in solitude, I stand,  
Withered, numb, in barren land,  
With my longing, lone and still,  
Only echoes my heart fill.

Romanian:

Ce te legeni, codrule,  
Ce te legeni, codrule,  
Fără ploaie, fără vânt,  
Fără ploaie, fără vânt,  
Cu crengile la pământ?

– De ce nu m-aș legăna,  
Dacă trece vremea mea!  
Ziua scade, noaptea crește  
Și frunzișul mi-l rărește.

Bate vântul frunza-n dungă  
Cântăreții mi-i alungă;  
Bate vântul dintr-o parte  
Iarna-i ici, vara-i departe.  
Și de ce să nu mă plec,  
Dacă păsările trec!

Peste vârf de rămurele  
Trec în stoluri rândunele,  
Ducând gândurile mele  
Și norocul meu cu ele.

Și se duc pe rând, pe rând,  
Zarea lumii-ntunecând,  
Și se duc ca clipele,  
Scuturând aripele.

Și mă lasă pustiit,  
Veștejit și amorțit,  
Și cu doru-mi singurel,  
De mă-ngân numai cu el!
