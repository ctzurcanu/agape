---
id: 7TCpmRlSHTY
title: "Luceafărul - The Evening Star 3.2"
sidebar_label: "Luceafărul - The Evening Star 3.2"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/7TCpmRlSHTY"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Luceafărul - The Evening Star 3.2

Lyrics: Mihai Eminescu

O, vin’, în părul tău bălai  
S-anin cununi de stele,  
Pe-a mele ceruri să răsai  
Mai mândră decât ele.

– O, eşti frumos, cum numa-n vis  
Un demon se arată,  
Dară pe calea ce-ai deschis  
N-oi merge niciodată!

Mă dor de crudul tău amor  
A pieptului meu coarde,  
Şi ochii mari şi grei mă dor,  
Privirea ta mă arde.

– Dar cum ai vrea să mă cobor?  
Au nu-nţelegi tu oare,  
Cum că eu sunt nemuritor,  
Şi tu eşti muritoare?

– Nu caut vorbe pe ales,  
Nici ştiu cum aş începe –  
Deşi vorbeşti pe înţeles,  
Eu nu te pot pricepe;

Dar dacă vrei cu crezământ  
Să te-ndrăgesc pe tine,  
Tu te coboară pe pământ,  
Fii muritor ca mine.

Fii muritor ca mine.

– Tu-mi cei chiar nemurirea mea  
În schimb pe-o sărutare,  
Dar voi să ştii asemenea  
Cât te iubesc de tare;

Da, mă voi naşte din păcat,  
Primind o altă lege;  
Cu vecinicia sunt legat,  
Ci voi să mă dezlege.

Şi se tot duce... S-a tot dus.  
De dragu-unei copile,  
S-a rupt din locul lui de sus,  
Pierind mai multe zile.

Pierind mai multe zile.

English:

O come, and upon thy blond hair  
Crowns of stars I shall crowd,  
And more that all of them, up there,  
Thou wild look fair and proud."  
   
-"O thou art beautiful as but  
In dreams a demon shows,  
The way though hast oped for me  
For me's for ever close.  
   
The depths of my breast ache from the  
Desire of thy fierce love  
My heavy, big eyes also ache  
When into them thine shove".  
   
-"But how wouldst thou that I come down?  
Know this - for, do I lie? -:  
I am immortal, while thou art  
One of those that must die!"  
   
-"I hate big words, nor do I know  
How to begin my plea;  
And although thy discourse is clear  
I don't understand thee.  
   
But if thou wantest my flamed love  
And that would not be sham,  
Come down on this temporal earth,  
Be mortal as I am!"

"Be mortal as I am!"  
   
-"I'd lose my immortality  
For but one kiss of thine!  
Well, I will show thee how much too  
For thy fierce love I pine!  
   
Yes, I shall be reborn from sin,  
Receive another creed:  
From that endlessness to which I  
Am tied, I shall be freed!"  
   
And out he went, he went, went out,  
Loving a human fay,  
He plucked himself off from the sky,  
Went for many a day.

Went for many a day.
