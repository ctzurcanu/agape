---
id: 7ZNb_I1wWuo
title: "La Bucovina - To Bukovina"
sidebar_label: "La Bucovina - To Bukovina"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/7ZNb_I1wWuo"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La Bucovina - To Bukovina

Lyrics: Mihai Eminescu

N-oi uita vreodată, dulce Bucovină,  
Geniu-ţi romantic, munţii în lumină,  
Văile în flori,  
Râuri resăltânde printre stânce nante,  
Apele lucinde-n dalbe diamante  
Peste câmpii-n zori.

Ale sorţii mele plângeri şi surâse,  
Îngânate-n cânturi, îngânate-n vise  
Tainic şi uşor,  
Toate-mi trec prin gându-mi, trec pe dinainte,  
Inima mi-o fură şi cu dulci cuvinte  
Îmi şoptesc de dor.

Numai lângă sânu-ţi geniile rele,  
Care îmi descântă firul vieţii mele,  
Parcă dormita;  
Mă lăsară-n pace, ca să cânt în lume,  
Să-mi visez o soartă mândră de-al meu nume  
Şi de steaua mea.

Când pe bolta brună tremură Selene,  
Cu un pas melodic, cu un pas alene  
Lin în calea sa,  
Eol pe-a sa arpă blând răsunătoare  
Cânt-a nopţii dulce, mistică cântare,  
Cânt din Valhala.

Atunci ca şi silful, ce n-adoarme-n pace,  
Inima îmi bate, bate, şi nu tace,  
Tremură uşor,  
În fantazii mândre ea îşi face cale,  
Peste munţi cu codri, peste deal şi vale  
Mână al ei dor.

Mână doru-i tainic colo, înspre tine,  
Ochiul îmi sclipeşte, genele-mi sunt pline,  
Inima mi-i grea;  
Astfel totdeauna, când gândesc la tine,  
Sufletul mi-apasă nouri de suspine,  
Bucovina mea!

English:

I will never forget, sweet Bukovina,  
Your romantic genius, the mountains in light,  
Valleys in flowers,  
Rivers rising among the steep rocks,  
Waters shining in white diamonds  
Over the fields at dawn.

My fate's complaints and smiles,  
Laughed at in songs, licked at in dreams  
Secretly and lightly,  
All pass through my thoughts, pass before me,  
They steal my heart and with sweet words  
They whisper to me of longing.

Only near your breast the evil geniuses,  
Which enchant my life's thread,  
Like sleep;  
They left me alone, so that I could sing in the world,  
To dream of a fate proud of my name  
And of my star.

When on the brown vault Selene trembles,  
With a melodious step, with a slow step  
Slowly on her way,  
Aeolus on his softly resounding harp  
Sings the sweet night, mystical song,  
Sings from Valhalla.

Then like the sylph, who does not sleep in peace,  
My heart beats, beats, and does not remain silent,  
Tremble lightly,  
In proud fantasies she makes her way,  
Over mountains with forests, over hill and valley  
Her hand longs.

Her hand longs secretly there, towards you,  
My eye sparkles, my eyelashes are full,  
My heart is heavy;  
Thus always, when I think of you,  
My soul weighs down clouds of sighs,  
My Bukovina!
