---
id: Jm2m9BOZ-64
title: "Odă (în metru antic) - Ode (in ancient meter)"
sidebar_label: "Odă (în metru antic) - Ode (in ancient meter)"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Jm2m9BOZ-64"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Odă (în metru antic) - Ode (in ancient meter)

Versuri: Mihai Eminescu  
https://ro.wikipedia.org/wiki/Mihai_Eminescu

Nu credeam să învăț a muri vrodată;  
Pururi tânăr, înfășurat în manta-mi,  
Ochii mei nălțam visător la steaua  
Singurătății.

Când deodată tu răsăriși în cale-mi,  
Suferință tu, dureros de dulce...  
Pân-în fund băui voluptatea morții  
Nendurătoare.

Jalnic ard de viu chinuit ca Nessus,  
Ori ca Hercul înveninat de haina-i;  
Focul meu a-l stinge nu pot cu toate  
Apele mării.

De-al meu propriu vis, mistuit mă vaiet,  
Pe-al meu propriu rug, mă topesc în flacări...  
Pot să mai renviu luminos din el ca  
Pasărea Phoenix?

Piară-mi ochii turburători din cale,  
Vino iar în sân, nepăsare tristă;  
Ca să pot muri liniștit, pe mine  
Mie redă-mă!

Ca să pot muri liniștit, pe mine  
Mie redă-mă!

pe mine  
Mie redă-mă!

pe mine  
Mie redă-mă!

English:

I never thought I’d learn to die -- not once,  
Forever young, wrapped in my cloak’s embrace,  
My eyes were raised, dream-filled, unto the eye of  
Singularity.

Then suddenly, you rose upon my journey,  
You, Suffering, so painfully sweet...  
To the depths, I drank the bitter nectar  
of deadly defeat.

Wretched, I burn alive, like a tortured Nessus,  
Or like a Hercules, poisoned by his garment;  
No ocean’s waves can quell the fire raging  
through my own veins.  

Consumed by my own dream, I cry in anguish,  
Upon my own pyre, in flames I dissolve...  
Can I rise anew, a bright, reborn soul,  
A Phoenix in flight?

Let all waves be banished from my path,  
Come again, edge of indifference,  
coldness of heart,  
So that I may lay within your peace —- return me  
To myself.

return me  
To myself.
