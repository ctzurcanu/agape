---
id: 5HNF8FX-siM
title: "Dorinţa - The Desire"
sidebar_label: "Dorinţa - The Desire"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/5HNF8FX-siM"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Dorinţa - The Desire

Lyrics: Mihai Eminescu

Vino-n codru la izvorul  
Care tremură pe prund,  
Unde prispa cea de brazde  
Crengi plecate o ascund.

Şi în braţele-mi întinse  
Să alergi, pe piept să-mi cazi,  
Să-ţi desprind din creştet vălul,  
Să-l ridic de pe obraz.

Pe genunchii mei şedea-vei,  
Vom fi singuri-singurei,  
Iar în păr înfiorate  
Or să-ţi cadă flori de tei.

Fruntea albă-n părul galben  
Pe-al meu braţ încet s-o culci,  
Lăsând pradă gurii mele  
Ale tale buze dulci...

Vom visa un vis ferice,  
Îngâna-ne-vor c-un cânt  
Singuratece izvoare,  
Blânda batere de vânt;

Adormind de armonia  
Codrului bătut de gânduri,  
Flori de tei deasupra noastră  
Or să cadă rânduri-rânduri.

English:

Come to the forest to the spring  
Which trembles on the gravel,  
Where the porch of furrows  
Bent branches hide it.

And in my outstretched arms  
You run, fall on my chest,  
So that I may tear off the veil from your head,  
To lift it from your cheek.

You will sit on my knees,  
We will be alone,  
And in your shivering hair  
Linden flowers will fall.

Your white forehead in your yellow hair  
On my arm slowly lie down,  
Leaving prey to my mouth  
Your sweet lips...

We will dream a happy dream,  
They will lull us with a song  
Lonely springs,  
The gentle breeze;

Falling asleep to the harmony of  
The forest, overwhelmed by thoughts,  
Linden blossoms above us  
Will fall row by row.
