---
id: -j2FCfuWL88
title: "Călin Nebunul [II] A - Calin the Fool [II] A"
sidebar_label: "Călin Nebunul [II] A - Calin the Fool [II] A"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/-j2FCfuWL88"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Călin Nebunul [II] A - Calin the Fool [II] A

Lyrics: Mihai Eminescu

Dar acuma-mi stă pe gânduri — ce să facă el — foc nu e,  
Fraţii să se scoale numai şi capul o să-i răpuie.  
S-a luat şi el şi merge supărat înspre pădure  
Cu un hârb plin de funingini, subsuoară c-o săcure,  
Să găsească vun cărbune. Pe-un copac înalt se suie,  
Pe-ntinsori de codri negri aruncând privirea şuie.  
În adâncă depărtare el văzu zare de foc,  
El coboară şi porneşte ca s-ajungă-n acel loc.

El ajunge. Într-o groapă mare arde-un foc avan...  
Pe-o părechi de pirosteie clocoteşte un cazan,  
Doisprezece zmei în juru-i dorm adânc întinşi pe burtă,  
Împrejur de pirosteie se cocea o mare turtă  
Şi-n cazan, notând în zamă, clocoteau vo două vaci.  
„Hei — îşi zise năzdrăvanul — dete badea de colaci!"  
Şi deşi în faţa vetrei dorm şezând zmeoaice mame.  
El, atins de-acea mireasmă a clocotitoarei zame,  
Doi tăciuni luă în hârbu-i, un cărbune în lulea,  
Şi luând o bucăţică din o vacă ce fierbea,  
Iată, curge-un strop fierbinte pe a unui zmeu ureche.  
Ăsta ţipă cu-ngrozire ca un bou împuns de streche.

Toţi treziţi pun pe el mâna, unu-l leagă, altu-l ţine,  
Unu-i ţasălă pădurea, cetluindu-l cole bine.  
Sfătuiesc ca să-l omoare. — Da', mă rog, dumilor-voastre  
Cine şi-ar mai pune mintea cu aşa obrazuri proaste  
Cumu-s eu, măria-voastră! Mă lăsaţi, că-s om sărac,  
De când sunt n-am văz’t turaua, nici măcar de la petac.  
Zise unul cătră dânsul: — Dacă tu ne-i puté face  
Fata-mpăratului Roşu s-o luăm, poţi merge-n pace.

— Ce n-o luaţi domnia-voastră, că sunteţi mai tari, mai mulţi?  
— Ei, pe noi ne simte-ndată, să ne-apropiem desculţi,  
Suntem duhuri necurate şi-mpăratul cela Roş  
Are-n vatră în cenuşă un căţel şi un cucoş;  
Năzdrăvani-s, bată-i naiba, cum ne simt, îi vezi că-n drugă,  
Unul bate, altul cântă... ş-o tulim urât la fugă.  
Să s-apropie nu poate decât omul pământean.  
— De-i aşa, poi las’ pe mine... zice Strolea cel viclean,  
Îl dezleagă şi-l urmează... El văzu atunci legat  
Un voinic care, când vede că zmeii s-au depărtat,  
Se smuci lăsând în urmă a lui mâni şi-n codru piere.

English:

But now I'm thinking - what should he do - there's no fire,  
The brothers should just get up and their heads will be cut off.  
He also got up and went angrily towards the forest  
With a shovel full of soot, a shovel under his arm,  
To find some coal. He climbed a tall tree,  
Through expanses of black forests, casting his gaze.  
In the deep distance he saw a blaze of fire,  
He descended and set off to reach that place.

He arrived. In a large pit a fire was burning brightly...  
On a pair of firewood a cauldron was boiling,  
Twelve kites around it were sleeping soundly, lying on their bellies,  
A large cake was being baked around the firewood  
And in the cauldron, swimming in the mud, two cows were boiling.  
"Hey — said the fool — stop the bunting!"  
And although in front of the hearth, sleeping, sitting mother dragons.  
He, touched by that scent of the boiling broth,  
He took two embers in his fire, a coal in his pipe,  
And taking a piece of a boiling cow,  
Behold, a hot drop flows on a dragon's ear.  
This one screams in horror like an ox gored by a whip.

All awake, they lay hands on him, one ties him, another holds him,  
One chases him through the forest, carefully tying him up.  
I advise them to kill him. — Yes, please, your lords  
Who would put their mind to such stupid faces  
How am I, your majesty! Leave me alone, for I am a poor man,  
Since I have been here I have not seen the tower, not even from the patch.  
One said to him: — If you can make us take  
the Red Emperor's daughter, you can go in peace.

— Why don't you take her, your lordship, since you are stronger, more numerous?  
— Well, feel us right away, let us approach barefoot,  
We are unclean spirits and the Red Emperor  
Has a dog and a cuckoo in the hearth in the ashes;  
They are cheerful, beat the hell out of them, how they feel us, you see they are in a hurry,  
One beats, another sings... and we run away badly.  
Only an earthly man can approach.  
— So, then leave it to me... says the cunning Strolea,  
Untie him and follow him... He then saw a bound  
A strong man who, when he saw that the kites had moved away,  
Took off, leaving his hands behind and perished in the forest.
