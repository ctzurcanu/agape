---
id: 8inOhnxt7_4
title: "Luceafărul - The Evening Star 6.1"
sidebar_label: "Luceafărul - The Evening Star 6.1"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/8inOhnxt7_4"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Luceafărul - The Evening Star 6.1

Lyrics: Mihai Eminescu

În locul lui menit din cer  
Hyperion se-ntoarse  
Şi, ca şi-n ziua cea de ieri,  
Lumina şi-o revarsă.

Căci este sara-n asfinţit  
Şi noaptea o să-nceapă;  
Răsare luna liniştit  
Şi tremurând din apă

Şi împle cu-ale ei scântei  
Cărările din crânguri.  
Sub şirul lung de mândri tei  
Şedeau doi tineri singuri.

– O, lasă-mi capul meu pe sân,  
Iubito, să se culce  
Sub raza ochiului senin  
Şi negrăit de dulce;

Cu farmecul luminii reci  
Gândirile străbate-mi,  
Revarsă linişte de veci  
Pe noaptea mea de patimi.

Şi de asupra mea rămâi  
Durerea mea de-o curmă,  
Căci eşti iubirea mea dentâi  
Şi visul meu din urmă.

Hyperion vedea de sus  
Uimirea-n a lor faţă;  
De-abia un braţ pe gât i-a pus  
Şi ea l-a prins în braţă…

Şi ea l-a prins în braţă…

English: 

His first dominion on the sky  
Hyperion restores  
And like in his first day, his light  
All o'er again he pours.  
   
For it is evening and the night  
Her duty never waives.  
Now the moon rises quietly  
And shaking from the waves,  
   
And upon the paths of the groves  
Her sparkles again drone...  
Under the row of linden-trees  
Two youths sit all alone.  
   
-"O darling, let my blessed ear feel  
How thy heart's pulses beat,  
Under the ray of thy eyes clear  
And unspeakably sweet.  
   
With the charms of their cold light pierce  
My thought's faery glades,  
Pour an eternal quietness  
On my passion's dark shades.  
   
And there, above, remain to stop  
Thy woe's violet stream,  
For thou art my first source of love  
And also my last dream!"  
   
Hyperion beholds how love  
Their eyes equally charms:  
Scarcely his arm touches her neck,  
She takes him in her arms.

She takes him in her arms.
