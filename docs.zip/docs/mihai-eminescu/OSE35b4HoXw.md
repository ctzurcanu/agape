---
id: OSE35b4HoXw
title: "#Luceafarul - The #EveningStar - #eminescu #romania #romantic"
sidebar_label: "#Luceafarul - The #EveningStar - #eminescu #romania #romantic"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/OSE35b4HoXw"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## #Luceafarul - The #EveningStar - #eminescu #romania #romantic

Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MeABwofUGMJQldnM-A9NE98&si=kYP4dCSfqL_ArNKb  
Lyrics: Mihai Eminescu

Vrei să dau glas acelei guri,  
Ca dup-a ei cântare  
Să se ia munţii cu păduri  
Şi insulele-n mare?

Vrei poate-n faptă să arăţi  
Dreptate şi tărie?  
Ţi-aş da pământul în bucăţi  
Să-l faci împărăţie.

Îţi dau catarg lângă catarg,  
Oştiri spre a străbate  
Pământu-n lung şi marea-n larg,  
Dar moartea nu se poate...

Dar moartea nu se poate!

English:

"Do you wish to give voice to a song,  
To move the mountains, forests along?  
And stir the islands in the seas,  
With so high waves the sky they seize?"

"Would you display, in mighty deeds,  
Justice and strength to meet your needs?  
I’d give you lands in broken spans  
To knead empires with your hands."

"I’ll give you ships with masts held high,  
Armies to conquer far and wide.  
The earth’s expanse, the oceans broad—  
But death itself? Is not for god."

"But death itself? Is not for god."
