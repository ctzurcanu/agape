---
id: 7T19TYjnrPU
title: "Călin Nebunul [II] B - Calin the Fool [II] B"
sidebar_label: "Călin Nebunul [II] B - Calin the Fool [II] B"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/7T19TYjnrPU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Călin Nebunul [II] B - Calin the Fool [II] B

Lyrics: Mihai Eminescu

Pe cărări săpate-n stâncă zmeii şi Călin se suie,  
Numai luna îi îmbracă cu lumina ei gălbuie  
Şi pândind trec uriaşii de pe-o stâncă pe-altă stâncă;  
într-o sură depărtare murmură valea adâncă,  
Numai pe păreţii netezi ai stâncimii îndelunge  
Ei arunc umbre gheboase, uriaşe, negre, lunge,  
Ce în şiruri tupilate după ei se mişcă, pare.  
Noaptea-ntinde măreţia-i, lunca doarme, lunca moare,  
Şi călcând încet cu greul lor s-apropie-n tăcere.  
Ei ajung la poarta mare, ferecată cu putere,  
Ce nu-i om s-o poată trece. Dar Călin, suit pe zid:  
— Hai, veniţi, zmeilor, zice, poarta nu pot s-o deschid,  
Dară unul câte unul v-oi lua colea de chică  
Şi pe sus vă trec în curte... Abia-apucă să li-o zică  
Şi ei unul câte unul s-apropie, şi de-a rândul  
El la fiecare-i taie capul de chică ţiindu-l  
Ş-a lor trupuri moarte-aruncă răşchiete în ogradă  
Şi în urmă sare dânsul, ca să vadă, ce-a să vadă?

Împăratul de zid straşnic şi de poartă ce avea,  
Ferestrele stau deschise şi uşile se crăpa.  
Scări bătute-n pietre scumpe, repede voinicul suie,  
Intră-n casele frumoase din înalta cetăţuie,  
Pe covoare moi el calcă, intră în acea odaie,  
Care-i plină de a lunei blândă, tainică bătaie.  
Pe păreţi icoane mândre zugrăvite-n umbră par  
Cum că chipur’le din ele dintre codri mari răsar.  
Pe un pat de flori frumoase, proaspete şi ude încă,  
Doarme fata cea vestită şi-n visarea ei adâncă.  
Ea zâmbind îşi mişcă dulce a ei buze mici, subţiri,  
Înecată de lumină şi miros de trandafiri,  
Iar din pod pân-în podele un paingăn de smarald  
A ţesut pânza subţire, tremurând în aer cald,  
Şi în care luna bate de sclipeşte viorie  
Ş-o încarcă cu o bură, diamantoasă colbărie.  
Şi prin mreaj-asta vrăjită vedeai patul ei de flori,  
Ea cu umeri de zăpadă şi cu părul lucitor  
Şi mai goală este-n somnu-i, numai bolta naltă, sură  
A ferestrei este rece şi simţirea nu o fură,  
Dar de pânz-acoperită-i cu un colb de piatră scumpă.  
S-apropie-ncet voinicul şi cu mâna va s-o rumpă,  
Apoi lin o dă-ntr-o parte, peste fată se înclină,  
Pune gura lui fierbinte pe-a ei buze ce suspină,  
Ia inelul ei cel mândru de pe degetul cel mic...  
Şi se-ntoarce în codreana-i noapte tânărul voinic.

Lângă zmeii morţi când trece, limbile le taie el,  
Le adună sângerânde şi le pune-n testemel,  
Trece zidul şi porneşte iar la drum pân’ce ajunge  
La cazanul care fierbe în mijlocul verzii lunce.  
Pe-o zmeoaică mum-o taie, pe-alta o scăpă în pripă,  
Ia din nou în hârb tăciune ş-un cărbune pune-n pipă,  
Ia cazanul într-un deget şi în altul el ia turtă  
Şi se-ntoarce iar la fraţii, fluierând cu minte scurtă  
Toate cântecele rele ce-n viaţa-i le cântară...

Dezlegă pe Zori-de-ziuă, Miez-de-noapte, De-cu-sară,  
Din cazanul care-l duce dându-le de drum merinde.  
Abia-ajunge-unde dorm fraţii, abia focul îl aprinde,  
Ziua cea întârziată năvăli din răsputeri  
Şi ca repezit în aer soarele se-nalţă-n cer;

Fraţii lui atât dormiră, cât intrase în pământ  
De un stânjin şi-i împluse frunza adunată-n vânt.  
Se treziră. — I! Căline, lungă fu şi noaptea asta,  
Dar nimic el nu le spune ce făcuse-n vremea-aceasta,  
Ci plecând ei mai departe tot Călin arcu-ncordează  
Şi, zburătuind, săgeata trece-n lume ca o rază,  
Vâjâie-n văzduh cumplită; ei urmează unde-i cheamă,  
Pân-ajung în faptul nopţii la pădurea de aramă.

English:

On paths carved into the rock, the kites and Călin climb,  
Only the moon clothes them with its yellowish light  
And lurking, the giants pass from one rock to another;  
In a distant distance, the deep valley murmurs,  
Only on the smooth walls of the long cliff  
They cast hunchbacked, huge, black, long shadows,  
Which in rows of stubby figures move after them, it seems.  
The night spreads its grandeur, the meadow sleeps, the meadow dies,  
And slowly treading with their weight, they approach in silence.  
They reach the great gate, locked with strength,  
Which no man can pass. But Călin, climbing the wall:  
— Come on, come, dragons, he says, I can't open the gate,  
But one by one you will take that chica  
And I will pass you into the yard on top... He barely has time to tell them  
And they one by one approach, and in turn  
He cuts off the chica head of each one while holding it  
And throws their dead bodies into the yard  
And he jumps after, to see, what will he see?

The emperor of the magnificent wall and the gate that he had,  
The windows are open and the doors are cracking.  
Stairs carved in precious stones, the strong man quickly ascends,  
He enters the beautiful houses in the high fortress,  
On soft carpets he steps, enters that room,  
Which is full of the moon's gentle, secret beat.  
On the walls, proud icons painted in shadow seem  
As if their figures from among the great forests rise.  
On a bed of beautiful flowers, fresh and still wet,  
The famous girl sleeps and in her deep reverie.  
...
