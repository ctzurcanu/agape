---
id: 2fGJhw1kIN8
title: "Vis - Dream"
sidebar_label: "Vis - Dream"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/2fGJhw1kIN8"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Vis - Dream

Lyrics: Mihai Eminescu

Pluteam pe un râu. Sclipiri bolnave  
Fantastic trec din val în val,  
În urmă-mi noaptea de dumbrave,  
Nainte-mi domul cel regal.

Căci pe o insulă în farmec  
Se nalță negre, sfinte bolți,  
Și luna murii lungi albește,  
Cu umbră împle orice colț.

Mă urc pe scări, intru-nlăuntru,  
Tăcere-adâncă l-al meu pas.  
Prin întuneric văd înalte  
Chipuri de sfinți p-iconostas.

Sub bolta mare doar străluce  
Un singur sâmbure de foc;  
În dreptul lui s-arat-o cruce  
Și-ntunecime-n orice loc.

Acum de sus din cor apasă  
Un cântec trist pe murii reci  
Ca o cerșire tânguioasă  
Pentru repaosul de veci.

Prin tristul zgomot se arată,  
Încet, sub văl, un chip ca-n somn,  
Cu o făclie-n mâna-i slabă ­  
În albă mantie de domn.

Și ochii mei în cap îngheață  
Și spaima-mi sacă glasul meu.  
Eu îi rup vălul de pe față...  
Tresar ­- încremenesc ­- sunt eu.

De-atunci, ca-n somn eu îmblu ziua  
Și uit ce spun adeseori;  
Șoptesc cuvinte nențelese  
Și parc-aștept ceva - să mor

English:

I was floating on a river. Sick glimmers  
Fantastically pass from wave to wave,  
Behind me the night of the groves,  
Before me the royal dome.

For on an island in enchantment  
Rise black, holy vaults,  
And the moon of the long wall whitens,  
With shadow fills every corner.

I climb the stairs, inside,  
Deep silence my step.  
Through the darkness I see tall  
Faces of saints on the iconostasis.

Under the great vault only shines  
A single core of fire;  
In front of it a cross appears  
And darkness everywhere.

Now from above from the choir presses  
A sad song on the cold walls  
Like a plaintive begging  
For eternal rest.

Through the sad noise,  
Slowly, under the veil, a face as if in sleep,  
With a torch in its weak hand  
In a white gentleman's cloak.

And my eyes in my head freeze  
And fear takes away my voice.  
I tear the veil from its face...  
I start - I freeze - it's me.

Since then, as if in sleep I blur the day  
And I forget what I often say;  
I whisper unintelligible words  
And as if I'm waiting for something - to die
