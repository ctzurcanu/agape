---
id: 4TolQsnIfr8
title: "The Waves of Time - Din valurile vremii..."
sidebar_label: "The Waves of Time - Din valurile vremii..."
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/4TolQsnIfr8"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## The Waves of Time - Din valurile vremii...

Lyrics: Mihai Eminescu  
Translation: Corneliu M. Popescu

Arise again, beloved, out of the waves of time   
With your long golden tresses and marble arms sublime;   
Your face that now transparent and pale as wax is pale   
Is shaded by the shadow of sorrow's clinging veil!   
Your timid smile caressing does rest within my eyes,   
O star amidst fair women, o queen of starry skies;   
Your head upon your shoulder its wealth of beauty lays   
And in your eyes of wonder I'm lost and weeping gaze. 

Out of the void's dark vapours may you once more uprear,   
That to my heart I clasp you, beloved angel dear,   
That I in nameless weeping above your face may bend   
And on your lips forever my burning kisses spend.   
While your cold hand unheeding I clasp against my breast,   
Closer, yet still closer, against my bosom pressed. 

Alas, not thus the darkness gives back its own again;   
Now through its icy vapours I see your shadow wane.   
With hanging arms and helpless once more I am alone   
Before a dream unending of hours that have gone;   
In vain with arms outstretching my soul your shadow craves,   
Dear one, I cannot reach you amidst time's rolling waves. 

In vain with arms outstretching my soul your shadow craves,   
Dear one, I cannot reach you amidst time's rolling waves. 

Romanian:

Din valurile vremii, iubita mea, răsai  
Cu braţele de marmur, cu părul lung, bălai -  
Şi faţa străvezie ca faţa albei ceri  
Slăbită e de umbra duioaselor dureri!  
Cu zâmbetul tău dulce tu mângâi ochii mei,  
Femeie între stele şi stea între femei  
Şi întorcându-ţi faţa spre umărul tău stâng,  
În ochii fericirii mă uit pierdut şi plâng.  
Cum oare din noianul de neguri să te rump,  
Să te ridic la pieptu-mi, iubite înger scump,  
Şi faţa mea în lacrimi pe faţa ta s-o plec,  
Cu sărutări aprinse suflarea să ţi-o-nec  
Şi mâna friguroasă s-o încălzesc la sân,  
Aproape, mai aproape pe inima-mi s-o ţin.

Dar vai, un chip aievea nu eşti, astfel de treci  
Şi umbra ta se pierde în negurile reci,  
De mă găsesc iar singur cu braţele în jos  
În trista amintire a visului frumos...  
Zadarnic după umbra ta dulce le întind:  
Din valurile vremii nu pot să te cuprind.
