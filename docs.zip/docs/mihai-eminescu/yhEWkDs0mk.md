---
id: _yhEWkDs0mk
title: "Renunțare - Renunciation"
sidebar_label: "Renunțare - Renunciation"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/_yhEWkDs0mk"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Renunțare - Renunciation

Lyrics: Mihai Eminescu

Aș vrea să am pământul și marea-n jumătate,  
De mine să asculte corăbii și armate,  
De voi clipi cu ochiul, cu mâna semn de-oi face,  
Să-și miște răsăritul popoarele încoace;  
Sălbatecele oarde să curgă râuri-râuri,  
Din codri răscolite, stârnite din pustiuri;  
Ca undele de fluviu urmeze-ale lor scuturi,  
Întunece-se-n zare pierdutele-nceputuri,  
Un râu de scânteiare lucească lănci și săbii,  
Iar marea se-nspăimânte de negrele-mi corăbii.

Astfel război porni-voi. Voi arunca încalte  
O jumătate-a lumii asupra celeilalte.  
Privească-m-atunci preoți: un monstru ce se-nchină,  
Când oardele-i barbare duc moarte și ruină.  
Ruga-mă-voi cu mâna uscată ținând strana,  
Deasupra mea cu-ntinse aripi va sta Satana;  
Cu tronul meu voi pune alăturea sicriul ,  
Când gloatele-mi în lume ar tot mări pustiul,  
Să simt că nu se poate un Dumnezeu să-mi ierte  
Cetățile în flacări și țările deșerte...  
Astfel doar aș preface durerea-mi fără nume,  
Dezbinul meu din suflet într-un dezbin de lume.

Și tot ce-ncântă ochii cu mii de frumuseți,  
Tot ce pământul are și marea mai de preț,  
Grămezi să steie toate la mine în comori.  
Alăturea cu ele să trec nepăsători,  
Simțindu-mă în mine stăpân al lumii-ntregi,  
Un zeu în omenire, un soare între regi  
Și raze să reverse din frunte-a mea coroană...  
Să-ngenunchez nainte-ți așa ca la icoană  
Și descriindu-ți toată puterea fără seamă  
Să-ți zic: Ia-le pe toate, dar și pe mine ia-mă!

Nu mă iubi! Ca robul să fiu pe lângă tine,  
De-i trece,-n jos pleca-voi a ochilor lumine,  
Dezmoștenit de toate, la viață abdicând,  
Să nu-mi rămână-n minte decât un singur gând:  
C-am apucat un sceptru, cu dânsul lumea-ntreagă,  
Păstrându-mi pentru mine durerea că-mi ești dragă,  
Înamorați de tine, rămână ochii-mi triști  
Și vecinic urmărească cum, marmură, te miști.  
În veci dup-a ta umbră eu brațele să-ntind,  
De-al genei tale tremur nădejdea să mi-o prind,  
Să-mi razim a mea frunte de zidurile goale,  
Atinse de-umbra dulce a frumuseții tale.

English:

I would like to have the earth and the sea in half,  
To me ships and armies would listen,  
If I wink with my eye, with my hand a sign of sheep,  
To move the peoples eastwards;  
The wild hordes would flow rivers-rivers,  
From the forests uprooted, stirred up from the deserts;  
As the waves of the river follow their shields,  
The lost beginnings darken in the horizon,  
A river of sparks shines spears and swords,  
And the sea is terrified of my black ships.

Thus I will start war. I will throw shoes  
One half of the world upon the other.  
Then priests, look at me: a monster that worships,  
When the barbarian hordes bring death and ruin.  
I will pray with a withered hand holding the pew,  
Above me with outstretched wings Satan will stand;  
With my throne I will place the coffin next to me,  
When my crowds in the world would keep increasing the desert,  
To feel that a God cannot forgive me  
The cities in flames and the deserted lands...  
Thus I would only transform my nameless pain,  
My division in my soul into a division in the world.

And everything that delights the eyes with a thousand beauties,  
Everything that the earth and the sea have more precious,  
Heaps may they all remain with me in treasures.  
Let me pass by them carelessly,  
Feeling in myself the master of the whole world,  
A god among humanity, a sun among kings  
And let rays pour from my forehead the crown...  
To kneel before you like an icon  
And describing all your power without measure  
To tell you: Take them all, but take me too!

Do not love me! So that I may be your servant,  
If it passes, I will bow down to your bright eyes,  
Disinherited from everything, abdicating life,  
Let only one thought remain in my mind:  
That I have seized a scepter, with it the whole world,  
Keeping for myself the pain that you are dear to me,  
In love with you, my sad eyes remain  
And forever watch how, marble, you move.  
Forever after your shadow I will stretch my arms,  
From your gene I tremble the hope to catch it,  
Let me shave my forehead against the empty walls,  
Touched by the sweet shadow of your beauty.
