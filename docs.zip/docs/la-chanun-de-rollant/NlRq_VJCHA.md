---
id: _NlRq_VJCHA
title: "La Chançun de Rollant 12"
sidebar_label: "La Chançun de Rollant 12"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/_NlRq_VJCHA"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La Chançun de Rollant 12

[XXXIX]  
« Bel sire Guenes, » ço li ad dit Marsilie,  
« Jo vos ai fait alques de legerie,  
Quant por ferir vus demustrai grant ire.  
Guaz vos en dreit par cez pels sabelines,  
Melz en valt l’or que ne funt cinc cenz livres :  
Einz demain noit en iert bele l’amendise. »  
Guenes respunt : « Jo nel desotrei mie.  
Deus, se lui plaist, a bien le vos mercie » ! 

[XL]  
Ço dist Marsilies : « Guenes, par veir sacez,  
En talant ai que mult vos voeill amer.  
De Carlemagne vos voeill oïr parler.  
Il est mult vielz, si ad sun tens uset ;  
Men escient dous cenz anz ad passet.  
Par tantes teres ad sun cors demened,  
Tanz colps ad pris sur sun escut bucler,  
Tanz riches reis cunduiz a mendisted :  
Quant ert il mais recreanz d’osteier ? »  
Guenes respunt : « Carles n’est mie tels.  
N’est hom kil veit e conuistre le set  
Que ço ne diet que l’emperere est ber.  
Tant nel vos sai ne preiser ne loer  
Que plus n’i ad d’onur e de bontet.  
Sa grant valor, kil purreit acunter ?  
De tel barnage l’ad Deus enluminet  
Meilz voelt murir que guerpir sun barnet. »

[XLI]  
Dist li païens : « Mult me puis merveiller  
De Carlemagne, ki est canuz e vielz !  
Men escientre dous cenz anz ad e mielz.  
Par tantes teres ad sun cors traveillet,  
Tanz cols ad pris de lances e d’espiez,  
Tanz riches reis cunduiz a mendistiet :  
Quant ert il mais recreanz d’osteier ?  
— Ço n’iert, » dist Guenes, « tant cum vivet sis niés :  
N’at tel vassal suz la cape del ciel.  
Mult par est proz sis cumpainz, Oliver ;  
Les douze pers, que Carles ad tant chers,  
Funt les enguardes a vingt milie chevalers.  
Soürs est Carles, que nuls home ne crent. » 

Contemporary French:

XXXIX  
« Beau sire Ganelon, » lui dit Marsile, « je vous ai traité un peu légèrement quand, en ma colère, je faillis vous frapper. Je vous le gage par ces peaux de martre zibeline, dont l’or vaut plus de cinq cents livres : avant demain soir je vous aurai payé une belle amende. » Ganelon répond : « Je ne refuse pas. Que Dieu, s’il lui plaît, vous en récompense ! »

XL  
Marsile dit : « Ganelon, sachez-le, en vérité, j’ai à cœur de beaucoup vous aimer. Je veux vous entendre parler de Charlemagne. Il est très vieux, il a usé son temps ; à mon escient il a deux cents ans passés. Il a par tant de terres mené son corps, il a sur son bouclier pris tant de coups, il a réduit tant de riches rois à mendier : quand sera-t-il las de guerroyer ? » Ganelon répond : « Charles n’est pas celui que vous pensez. Nul homme ne le voit et n’apprend à le connaître qui ne dise : L’empereur est un preux. Je ne saurais le louer et le vanter assez : il y a plus d’honneur en lui et plus de vertus que n’en diraient mes paroles. Sa grande valeur, qui pourrait la décrire ? Dieu fait rayonner de lui tant de noblesse ! Il aimerait mieux la mort que de faillir à ses barons. »

XLI  
Le païen dit : « Je m’émerveille, et j’en ai bien sujet. Charlemagne est vieux et chenu ; à mon escient il a deux cents ans et mieux ; par tant de terres il a mené son corps à la peine, il a pris tant de coups de lances et d’épieux, il a réduit à mendier tant de riches rois : quand sera-t-il recru de mener ses guerres ? — Jamais, » dit Ganelon, « tant que vivra son neveu. Il n’y a si vaillant que Roland sous la chape du ciel. Et c’est un preux aussi qu’Olivier, son compagnon. Et les douze pairs, que Charles aime tant, forment son avant-garde avec vingt mille chevaliers. Charles est en sûreté, il ne craint homme qui vive. »
