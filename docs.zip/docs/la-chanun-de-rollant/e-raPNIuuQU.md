---
id: e-raPNIuuQU
title: "La Chançun de Rollant - Overture"
sidebar_label: "La Chançun de Rollant - Overture"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/e-raPNIuuQU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La Chançun de Rollant - Overture

Il s'agit de la Chanson de Roland. Chantée en vieux français conformément au Manuscrit d'Oxford (présenté à gauche dans les parties suivantes).  
Les sous-titres en français (France) contiendront les paroles originales. Le français contiendra la traduction française contemporaine qui constituera la base de la traduction dans toutes les autres langues.  
Profitez et partagez la joie avec les autres.

English:  
This is the Song of Roland. Sung in Old French in conformance with the Oxford Manuscript (presented on the left side in the following parts).  
The French (France) subtitles will contain the original lyrics. The French will contain the contemporary French translation that will constitute the basis for translation into all other languages.   
Enjoy and spread the joy to others.
