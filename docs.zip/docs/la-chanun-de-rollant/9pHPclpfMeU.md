---
id: 9pHPclpfMeU
title: "La Chançun de Rollant 18"
sidebar_label: "La Chançun de Rollant 18"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/9pHPclpfMeU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La Chançun de Rollant 18

[LXIII]  
Li empereres apelet ses niés Rollant :  
« Bel sire niés, or savez veirement  
Demi mun host vos lerrai en present.  
Retenez les, ço est vostre salvement. »  
Ço dit li quens : « Jo n’en ferai nient.  
Deus me cunfunde, se la geste en desment !  
20 milie Francs retendrai ben vaillanz.  
Passez les porz trestut soürement :  
Ja mar crendrez nul hume a mun vivant ! »

[LXIV]  
Li quens Rollant est muntet el destrer.  
Cuntre lui vient sis cumpainz Oliver.  
Vint i Gerins e li proz quens Gerers,  
E vint i Otes, si i vint Berengers  
E vint i Astors e Anseïs li veillz,  
Vint i Gerart de Rossillon li fiers ;  
Venuz i est li riches dux Gaifiers.  
Dist l’arcevesque : « Jo irai, par mun chef !  
— E jo od vos, » ço dist li quens Gualters ;  
« Hom sui Rollant, jo ne li dei faillir. »  
Entr’els eslisent .XX. milie chevalers.

[LXV]  
Li quens Rollant Gualter de l’Hum apelet :  
« Prenez mil Francs de France, nostre tere,  
Si purprenez les destreiz e les tertres,  
Que l’emperere nis un des soens n’i perdet. »  
Respunt Gualter : « Pur vos le dei ben faire. »  
Od mil Franceis de France, la lur tere,  
Gualter desrenget les destreiz e les tertres :  
N’en descendrat pur malvaises nuveles  
Enceis qu’en seient 700 espees traites.  
Reis Almaris del regne de Belferne  
Une bataille lur livrat le jur pesme.

[LXVI]  
Halt sunt li pui e li val tenebrus,  
Les roches bises, les destreiz merveillus.  
Le jur passerent Franceis a grant dulur.  
De 15 liues en ot hom la rimur.  
Puis que il venent a la Tere Majur,  
Virent Guascuigne, la tere lur seignur ;  
Dunc lur remembret des fius e des honurs,  
E des pulcele e des gentilz oixurs :  
Cel nen i ad ki de pitet ne plurt.  
Sur tuz les altres est Carles anguissus :  
As porz d’Espaigne ad lesset sun nevold.  
Pitet l’en prent, ne poet muer n’en plurt.

Contemporary:

LXIII  
L’empereur dit à son neveu Roland : « Beau sire neveu, vous le savez bien, c’est la moitié de mes armées que je vous offre et vous laisserai. Retenez-les, c’est votre salut. » Le comte dit : « Je n’en ferai rien. Dieu me confonde, si je démens mon lignage ! Je retiendrai vingt mille Français bien vaillants. En toute assurance passez les ports. Vous auriez tort de craindre personne, moi vivant. »

LXIV  
Le comte Roland est monté sur son destrier. Vers lui vient son compagnon, Olivier. Gerin vient et le preux comte Gerier, et Oton vient et Bérengier vient, et Astor vient, et Anseïs le vieux, et Gérard de Roussillon le fier, et le riche duc Gaifier est venu. L’archevêque dit : « Par mon chef, j’irai ! — Et moi avec vous, » dit le comte Gautier ; « je suis homme de Roland, je ne dois pas lui faillir. » Ils choisissent entre eux vingt mille chevaliers.

LXV  
Le comte Roland appelle Gautier de l’Hum : « Prenez mille Français de France, notre terre, et tenez les défilés et les hauteurs, afin que l’empereur ne perde pas un seul des hommes qui sont avec lui. » Gautier répond : « Pour vous je le dois bien faire. » Avec mille Français de France, qui est leur terre, Gautier sort des rangs et va par les défilés et les hauteurs. Pour les pires nouvelles il n’en redescendra pas que des épées sans nombre aient été dégainées. Ce jour-là même, le roi Almaris, du pays de Belferne, leur livra une bataille dure.

LXVI  
Hauts sont les monts et ténébreux les vaux, les roches bises, sinistres les défilés. Ce jour-là même, les Français les passent à grande douleur. De quinze lieues on entend leur marche. Quand ils parviennent à la Terre des Aïeux et voient la Gascogne, domaine de leur seigneur, il leur souvient de leurs fiefs, et des filles de chez eux, et de leurs nobles femmes. Pas un qui n’en pleure de tendresse. Sur tous les autres Charles est plein d’angoisse : aux ports d’Espagne il a laissé son neveu. Pitié lui en prend ; il pleure, il ne peut s’en tenir.
