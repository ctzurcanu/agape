---
id: VI0g2vgUv-g
title: "La Chançun de Rollant 14"
sidebar_label: "La Chançun de Rollant 14"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/VI0g2vgUv-g"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La Chançun de Rollant 14

[XLV]  
Chi purreit faire que Rollant i fust mort,  
Dunc perdreit Carles le destre braz del cors,  
Si remeindreient les merveilluses oz ;  
N’asemblereit jamais Carles si grant esforz ;  
Tere Major remeindreit en repos. »  
Quan l’ot Marsilie, si l’ad baiset el col,  
Puis si cumencet a venir ses tresors. 

[XLVI]  
Ço dist Marsilies : « Qu’en parlereient . . . . .  
Cunseill n’est proz dunt hume . . . . . . .  
La traïsun me jurrez de Rollant.  
Ço respunt Guenes : « Issi seit cum vos plaist ! »  
Sur les reliques de s’espee Murgleis  
La traïsun jurat e si s’en est forsfait.   
[XLVII]  
Un faldestoed i out d’un olifant.  
Marsilies fait porter un livre avant :  
La lei i fut Mahum e Tervagan.  
Ço ad juret li Sarrazins espans,  
Se en rereguarde troevet le cors Rollant,  
Cumbatrat sei a trestute sa gent  
E, se il poet, murrat i veirement.  
Guenes respunt : « Ben seit vostre comant ! » 

[XLVIII]  
Atant i vint uns paiens, Valdabruns.  
Icil en vait al rei Marsiliun.  
Cler en riant l’ad dit a Guenelun :  
« Tenez m’espee, meillur n’en at nuls hom ;  
Entre les helz ad plus de mil manguns.  
Par amistiez, bel sire, la vos duins  
Que nos aidez de Rollant le barun,  
Qu’en rereguarde trover le poüsum.  
— Ben serat fait, » li quens Guenes respunt ;  
Puis se baiserent es vis e es mentuns.

[XLIX]  
Après i vint un paien, Climorins.  
Cler en riant a Guenelun l’ad dit :  
« Tenez mun helme, unches meillor ne vi…,  
Si nos aidez de Rollant li marchis,  
Par quel mesure le poüssum hunir.  
— Ben serat fait, » Guenes respundit ;  
Puis se baiserent es buches e es vis. 

[L]  
Atant i vint la reïne Bramimunde :  
« Jo vos aim mult, sire, » dist ele al cunte,  
« Car mult vos priset mi sire e tuit si hume.  
A vostre femme enveierai dous nusches,  
Bien i ad or, matices e jacunces :  
Eles valent mielz que tut l’aveir de Rume.  
Vostre emperere si bones n’en out unches. »  
Il les ad prises, en sa hoese les butet. 

Contemporary:

XLV  
Qui pourrait faire que Roland y fût tué, Charles perdrait le bras droit de son corps. C’en serait fait des armées merveilleuses. Charles n’assemblerait plus de si grandes levées : la Terre des Aïeux resterait en repos ! » Quand Marsile l’entend, il l’a baisé au cou ; puis.... (?)

XLVI  
Marsile dit : « […] Un accord ne vaut guère, si […] Vous me jurerez de trahir Roland. » Ganelon répond : « Qu’il en soit comme il vous plaît ! » Sur les reliques de son épée Murgleis, il jura la trahison ; et voici qu’il a forfait.

XLVII  
Il y avait là un siège, tout d’ivoire. Marsile fait apporter un livre : la loi de Mahomet et de Tervagan y est écrite. Il jure, le Sarrasin d’Espagne, que, s’il trouve Roland à l’arrière-garde, il combattra avec toute sa gent, et, s’il peut, Roland mourra là. Ganelon répond : « Puisse votre volonté s’accomplir ! «

XLVIII  
Alors vint un païen, Valdabron. Il s’approche du roi Marsile. En riant clair il dit à Ganelon : « Prenez mon épée, nul n’en a de meilleure : la garde, à elle seule, vaut plus de mille mangons. Par amitié, beau sire, je vous la donne, et vous nous aiderez en sorte que nous puissions trouver à l’arrière-garde le preux Roland. — Ce sera fait, » répond le comte Ganelon. Puis ils se baisèrent au visage et au menton.

XLIX  
Après s’en vint un païen, Climorin. En riant clair il dit à Ganelon : « Prenez mon heaume, jamais je ne vis le meilleur […], et aidez-nous contre le marquis Roland, en telle guise que nous puissions le honnir. — Ce sera fait, » répondit Ganelon. Puis ils se baisèrent sur la bouche et au visage.

L  
Alors s’en vint la reine Bramimonde : « Je vous aime fort, sire, » dit-elle à Ganelon, « car mon seigneur vous prise grandement, et tous ses hommes. À votre femme j’enverrai deux colliers : ils sont tout or, améthystes, hyacinthes ; ils valent plus que toutes les richesses de Rome ; votre empereur jamais n’en eut de si beaux. » Il les a pris, il les boute en son houseau.
