---
id: t2tPo-1S67U
title: "La Chançun de Rollant 17"
sidebar_label: "La Chançun de Rollant 17"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/t2tPo-1S67U"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La Chançun de Rollant 17

[LVIII]  
Tresvait la noit e apert la clere albe.  
Par mi cel host. . . . . . . . . . . . . . .  
Li empereres mult fierement chevalchet.  
« Seignurs barons, » dist li emperere Carles,  
« Veez les porz e les destreiz passages !  
Kar me jugez ki ert en la rereguarde. »  
Guenes respunt : « Rollant, cist miens fillastre :  
N’avez baron de si grant vasselage. »  
Quant l’ot li reis, fierement le reguardet,  
Si li ad dit : « Vos estes vifs diables.  
El cors vos est entree mortel rage.  
E ki serat devant mei en l’ansguarde ? »  
Guenes respunt : « Oger de Denemarche :  
N’avez barun ki mielz de lui la facet. »

[LIX]  
Li quens Rollant, quant il s’oït juger,  
Dunc ad parled a lei de chevaler :  
« Sire parastre, mult vos dei aveir cher :  
La rereguarde avez sur mei jugiet !  
N’i perdrat Carles, li reis ki France tient,  
Men escientre palefreid ne destrer,  
Ne mul ne mule que deiet chevalcher,  
Ne n’i perdrat ne runcin ne sumer  
Que as espees ne seit einz eslegiet. »  
Guenes respunt : « Veir dites, jol sai bien. »

[LX]  
Quant ot Rollant qu’il ert en la rereguarde,  
Ireement parlat a sun parastre :  
« Ahi ! culvert, malvais hom de put aire,  
Quias le guant me caïst en la place,  
Cume fist a tei le bastun devant Carle ?

[LXI]  
Dreiz emperere, » dist Rollant le barun,  
« Dunez mei l’arc que vos tenez el poign.  
Men escientre nel me reproverunt  
Que il me chedet cum fist a Guenelun  
De sa main destre, quant reçut le bastun. »  
Li empereres en tint sun chef enbrunc,  
Si duist sa barbe e detoerst sun gernun,  
Ne poet muer que des oilz ne plurt.

[LXII]  
Après iço i est Neimes venud,  
Meillor vassal n’out en la curt de lui,  
E dist al rei : « Ben l’avez entendut ;  
Li quens Rollant, il est mult irascut.  
La rereguarde est jugee sur lui :  
N’avez baron ki jamais la remut.  
Dunez li l’arc que vos avez tendut,  
Si li truvez ki trés bien li aiut ! »  
Li reis li dunet e Rollant l’a reçut.

Contemporary:

LVIII  
La nuit passe toute, l’aube se lève claire. Par les rangs de l’armée, […] l’empereur chevauche fièrement. « Seigneurs barons, » dit l’empereur Charles, « voyez les ports et les étroits passages. Choisissez-moi qui fera l’arrière-garde. » Ganelon répond : « Ce sera Roland, mon fillâtre : vous n’avez baron d’aussi grande vaillance. » Le roi l’entend, le regarde durement. Puis il lui dit : « Vous êtes un démon. Au corps vous est entrée une mortelle frénésie. Et qui donc fera devant moi l’avant-garde ? » Ganelon répond : « Ogier de Danemark ; vous n’avez baron qui mieux que lui la fasse. »

LIX  
Le comte Roland s’est entendu nommer. Alors il parla comme un chevalier doit faire : « Sire parâtre, j’ai bien lieu de vous chérir : vous m’avez élu pour l’arrière-garde. Charles, le roi qui tient la France, n’y perdra, je crois, palefroi ni destrier, mulet ni mule, il n’y perdra cheval de selle ni cheval de charge qu’on ne l’ait d’abord disputé par l’épée. » Ganelon répond : « Vous dites vrai, je le sais bien. »

LX  
Quand Roland entend qu’il sera à l’arrière-garde, il dit, irrité, à son parâtre : « Ah ! truand, méchant homme de vile souche, l’avais-tu donc cru, que je laisserais choir le gant par terre, comme toi le bâton, devant Charles ?

LXI  
Droit empereur, » dit Roland le baron, « donnez-moi l’arc que vous tenez au poing. Nul ne me reprochera, je crois, de l’avoir laissé choir, comme fit Ganelon du bâton qu’avait reçu sa main droite. » L’empereur tient la tête baissée. Il lisse sa barbe, tord sa moustache. Il pleure, il ne peut s’en tenir.

LXII  
Alors vint Naimes : en la cour il n’y a pas meilleur vassal. Il dit au roi : « Vous l’avez entendu, le comte Roland est rempli de colère. Le voilà marqué pour l’arrière-garde : vous n’avez pas un baron qui puisse rien y changer. Donnez-lui l’arc que vous avez tendu, et trouvez-lui qui bien l’assiste. » Le roi donne l’arc et Roland l’a reçu.
