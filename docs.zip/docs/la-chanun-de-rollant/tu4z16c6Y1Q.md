---
id: tu4z16c6Y1Q
title: "La Chançun de Rollant 5"
sidebar_label: "La Chançun de Rollant 5"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/tu4z16c6Y1Q"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La Chançun de Rollant 5

[XII]  
Li empereres s’en vait desuz un pin,  
Ses baruns mandet pur sun cunseill fenir,  
Le duc Oger e l’arcevesque Turpin,  
Richard li velz e sun nevold Henri  
E de Gascuigne li proz quens Acelin,  
Tedbald de Reins e Milun sun cusin,  
E si i furent e Gerers e Gerin ;  
Ensembl’ od els li quens Rollant i vint  
E Oliver, li proz e li gentilz ;  
Des Francs de France en i ad plus de mil ;  
Guenes i vint, ki la traïsun fist.  
Des ore cumencet le cunseill que mal prist. 

[Instrumental]  
[XIII]  
« Seignurs barons, » dist li emperere Carles,  
« Li reis Marsilie m’ad tramis ses messages.  
De sun aveir me voelt duner grant masse,  
Urs e leuns e veltres caeignables,  
Set cenz cameilz e mil hosturs muables,  
Quatre cenz muls cargez de l’or d’Arabe,  
Avoec iço plus de cinquante care.  
Mais il me mandet que en France m’en alge :  
Il me sivrat ad Ais, a mun estage,  
Si recevrat la nostre lei plus salve ;  
Chrestiens ert, de mei tendrat ses marches ;  
Mais jo ne sai quels en est sis curages. »  
Dient Franceis : « Il nus i cuvent guarde ! »

[Instrumental]  
[XIV]  
Li empereres out sa raisun fenie.  
Li quens Rollant, ki ne l’otriet mie,  
En piez se drecet, si li vint cuntredire.  
Il dist al rei : « Ja mar crerez Marsilie !  
Set anz ad pleins qu’en Espaigne venimes ;  
Jo vos cunquis e Noples e Commibles,  
Pris ai Valterne e la tere de Pine  
E Balasgued e Tuele e Sezilie :  
Li reis Marsilie i fist mult que traïtre.  
De ses paiens enveiat quinze,  
Chascuns portout une branche d’olive,  
Nuncerent vos cez paroles meïsme.  
A voz Franceis un cunseill en presistes,  
Loerent vos alques de legerie ;  
Dous de voz cuntes al paien tramesistes,  
L’un fut Basan e li altres Basilies ;  
Les chef en prist es puis desuz Haltilie.  
Faites la guer cum vos l’avez enprise,  
En Sarraguce menez vostre ost banie,  
Metez le sege a tute vostre vie,  
Si vengez cels que li fels fist ocire ! » 

  
XII  
L’empereur s’en va sous un pin ; pour tenir son conseil il mande ses barons : le duc Ogier et l’archevêque Turpin, Richard le Vieux et son neveu Henri, et le preux comte de Gascogne Acelin, Thibaud de Reims et son cousin Milon, Vinrent aussi et Gerier et Gerin ; et avec eux le comte Roland y vint, et Olivier, le preux et le noble ; des Francs de France ils sont plus d’un millier ; Ganelon y vint, qui fit la trahison. Alors commence le conseil qui prit male fin.

XIII  
« Seigneurs barons, » dit l’empereur Charles, « le roi Marsile m’a envoyé ses messagers. De ses richesses il veut me donner à foison, ours et lions, et lévriers bons à mettre en laisse, sept cents chameaux et mille autours mués, quatre cents mulets chargés d’or d’Arabie, et en outre plus de cinquante chars. Mais il me mande que je m’en aille en France : il me suivra à Aix, en mon palais, et recevra notre loi, qu’il avoue la plus sainte ; il sera chrétien, c’est de moi qu’il tiendra ses marches. Mais je ne sais quel est le fond de son cœur. » Les Français disent : « Méfions-nous ! »

XIV  
L’empereur a dit sa pensée. Le comte Roland, qui ne s’y accorde point, tout droit se dresse et vient y contredire. Il dit au roi « Malheur si vous en croyez Marsile ! Voilà sept ans tout pleins que nous vînmes en Espagne. Je vous ai conquis et Noples et Commibles ; j’ai pris Valterne et la terre de Pine et Balaguer et Tuele et Sezille. Alors le roi Marsile fit une grande trahison : de ses païens il en envoya quinze, et chacun portait une branche d’olivier, et ils vous disaient toutes ces mêmes paroles. Vous prîtes le conseil de vos Français. Ils vous conseillèrent assez follement : vous fîtes partir vers le païen deux de vos comtes, l’un était Basan et l’autre  Basille ; dans la montagne, sous Haltilie, il prit leurs têtes. Faites la guerre comme vous l’avez commencée ! Menez à Saragosse le ban de votre armée ; mettez-y le siège, dût-il durer toute votre vie, et vengez ceux que le félon fit tuer. »
