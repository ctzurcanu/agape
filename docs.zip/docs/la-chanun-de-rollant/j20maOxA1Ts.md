---
id: j20maOxA1Ts
title: "La Chançun de Rollant 16"
sidebar_label: "La Chançun de Rollant 16"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/j20maOxA1Ts"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La Chançun de Rollant 16

[LIV-2]  
Einz qu’il oüssent 4 liues siglet,  
Sis aquillit e tempeste e ored :  
La sunt neiez, jamais nes en verrez ;  
Se il fust vis, jo l’oüsse amenet.  
Del rei paien, sire, par veir creez  
Ja ne verrez cest premer meis passet  
Qu’il vos sivrat en France le regnet,  
Si recevrat la lei que vos tenez,  
Jointes ses mains iert vostre comandet ;  
De vos tendrat Espaigne le regnet. »  
Ço dist li reis : « Graciet en seit Deus !  
Ben l’avez fait ; mult grant prod i avrez. »  
Par mi cel ost funt mil grailles suner.  
Franc desherbergent, funt lur sumers trosser,  
Vers dulce France tuit sunt achiminez.

[LV]  
Carles li magnes ad Espaigne guastede,  
Les castels pris, les citez violees.  
Ço dit li reis que sa guere out finee.  
Vers dulce France chevalchet l’emperere…  
. . . . . . . . . . . . . . . . . . . . .  
Li quens Rollant ad l’enseigne fermee,  
En sum un tertre contre le ciel levee.  
Franc se herbergent par tute la cuntree.  
Paien chevalchent par cez greignurs valees,  
Halbercs vestuz e trés bien. . . . . . .  
Healmes lacez e ceintes lur espees,  
Escuz as cols e lances adubees.  
En un bruill par sum les puis remestrent.  
400 milie atendent l’ajurnee.  
Deus ! quel dulur que li Franceis nel sevent !

[LVI]  
Tresvait le jur, la noit est aserie.  
Carles se dort, li empereres riches.  
Sunjat qu’il eret as greignurs porz de Sizer,  
Entre ses poinz teneit sa hanste fraisnine.  
Guenes li quens l’ad sur lui saisie.  
Par tel aïr l’at estrussee e brandie  
Qu’envers le cel en volent les escicles.  
Carles se dort, qu’il ne s’esveillet mie.

[LVII]  
Après iceste altre avisiun sunjat :  
Qu’il ert en France, a sa capele, ad Ais.  
El destre braz li morst uns uers si mals.  
Devers Ardene vit venir uns leuparz,  
Sun cors demenie mult fierement asalt.  
D’enz de sale uns veltres avalat,  
Que vint a Carles lé galops e les salz.  
La destre oreille al premer uer trenchat,  
Ireement se cumbat al lepart.  
Dient Franceis que grant bataille i ad ;  
Il ne sevent liquels d’els la veintrat.  
Carles se dort, mie ne s’esveillat.

Contemporary:

LIV-2  
Ils n’avaient pas cinglé à quatre lieues au large, quand la tempête et l’orage les saisirent : ils furent noyés, jamais vous n’en verrez un seul. Si l’Algalife était en vie, je vous l’eusse amené. Quant au roi païen, sire, tenez pour vrai que vous ne verrez point ce premier mois passer sans qu’il vous suive au royaume de France : il recevra la loi que vous gardez ; à mains jointes, il deviendra votre homme ; c’est de vous qu’il tiendra le royaume d’Espagne. » Le roi dit : « Que Dieu soit remercié ! Vous m’avez bien servi, vous en aurez grande récompense. » Par l’armée on fait sonner mille clairons. Les Francs lèvent le camp, troussent les bêtes de somme. Vers douce France tous s’acheminent.

LV  
Charlemagne a ravagé l’Espagne, pris les châteaux, violé les cités. Sa guerre, dit-il, est achevée. Vers douce France l’empereur chevauche, [Au soir…] le comte Roland attache à sa lance le gonfanon ; du haut d’un tertre, il l’élève vers le ciel : à ce signe, les Francs dressent leurs campements par toute la contrée. Or, par les larges vallées, les païens chevauchent, le haubert endossé, […] le heaume lacé, l’épée ceinte, l’écu au col, la lance appareillée. Dans une forêt, au sommet des monts, ils ont fait halte. Ils sont quatre cent mille, qui attendent l’aube. Dieu ! quelle douleur que les Français ne le sachent pas !

LVI  
Le jour s’en va, la nuit s’est faite noire. Charles dort, l’empereur puissant. Il eut un songe : il était aux plus grands ports de Cize ; entre ses poings il tenait sa lance de frêne. Ganelon le comte l’a saisie ; si rudement il la secoue que vers le ciel en volent des éclisses. Charles dort ; il ne s’éveille pas.

LVII  
Après cette vision, une autre lui vint. Il songea qu’il était en France, en sa chapelle, à Aix. Un ours très cruel le mordait au bras droit. Devers l’Ardenne il vit venir un léopard, qui, très hardiment, s’attaque à son corps même. Du fond de la salle dévale un lévrier ; il court vers Charles au galop et par bonds, tranche à l’ours l’oreille droite et furieusement combat le léopard. Les Français disent : « Voilà une grande bataille ! » Lequel des deux vaincra ? Ils ne savent. Charles dort, il ne s’est pas réveillé.
