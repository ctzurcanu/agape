---
id: c2GBfHW7DU0
title: "La Chançun de Rollant 2"
sidebar_label: "La Chançun de Rollant 2"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/c2GBfHW7DU0"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La Chançun de Rollant 2

[IV]  
Dist Blancandrins : « Pa ceste meie destre  
E par la barbe ki al piz me ventelet,  
L’ost des Franceis verrez sempres desfere.  
Francs s’en irunt en France, la lur tere.  
Quant cascuns ert a sun meillor repaire,  
Carles serat ad Ais, a sa capele,  
A seint Michel tendrat mult halte feste.  
Vendrat li jurz, si passerat li termes,  
N’orrat de nos paroles ne nuveles.  
Li reis est fiers e sis curages pesmes :  
De nos ostages ferat trecher les testes.  
Asez est mielz qu’il i perdent les testes  
Que nus perduns clere Espaigne, la bele,  
Ne nus aiuns les mals ne les suffraites !  »  
Dient paien : « Issi poet il ben estre ! »

[V]  
Li reis Marsilie out sun cunseill finet,  
Sin apelat Clarin de Balaguet,  
Estamarin e Eudropin, sun per,  
E Priamun e Guarlan le barbet  
E Machiner e sun uncle, Maheu,  
E Joüner e Malbien d’ultremer  
E Blancandrins, por la raisun cunter.  
Des plus feluns dis en ad apelez :  
« Seignurs baruns, a Carlemagnes irez.  
Il est al siege a Cordres la citet.  
Branches d’olives en voz mains porterez,  
Ço senefiet pais e humilitet.  
Par voz saveirs sem puez acorder,  
Jo vos durrai or e argent asez,  
Teres e fiez tant cum vos en vuldrez. »  
Dient paien : « De ço avun nus asez ! » 

[VI]  
Li reis Marsilie out finet sun cunseill,  
Dist a ses humes : « Seignurs, vos en ireiz.  
Branches d’olive en voz mains portereiz,  
Si me direz a Carlemagne le rei  
Pur le soen Deu qu’il ait mercit de mei.  
Ja einz ne verrat passer cest premer meis  
Que jel sivrai od mil de mes fedeilz,  
Si recevrai la chrestiene lei,  
Serai ses hom par amur e par feid.  
S’il voelt ostages, il en avrat par veir. »  
Dist Blancandrins : « Mult bon plait en avreiz. »

Contemporary French:

IV  
Blancandrin dit : « Par cette mienne dextre, et par la barbe qui flotte au vent sur ma poitrine, sur l’heure vous verrez l’armée des Français se défaire. Les Francs s’en iront en France : c’est leur pays. Quand ils seront rentrés chacun dans son plus cher domaine, et Charles dans Aix, sa chapelle, il tiendra, à la Saint-Michel, une très haute cour. La fête viendra, le terme passera : le roi n’entendra de nous sonner mot ni nouvelle. Il est orgueilleux et son cœur est cruel : de nos otages il fera trancher les têtes. Bien mieux vaut qu’ils y perdent leurs têtes, et que nous ne perdions pas, nous, claire Espagne la belle, et que nous n’endurions pas les maux et la détresse ! » Les païens disent : « Peut-être il dit vrai ! »

V  
Le roi Marsile a tenu son conseil. Il appela Clarin de Balaguer, Estamarin et son pair Eudropin, et Priamon et Guarlan le barbu, et Machiner et son oncle Maheu, et Joüner et Malbien d’outre-mer, et Blancandrin, pour leur dire sa pensée ; des plus félons, il en a pris dix à part : « Vers Charlemagne, seigneurs barons, vous irez. Il est devant la cité de Cordres, qu’il assiège. Vous porterez en vos mains des branches d’olivier, ce qui signifie paix et humilité. Si par adresse vous pouvez trouver pour moi un accord, je vous donnerai de l’or et de l’argent en masse, des terres et des fiefs tant que vous en voudrez. » Les païens disent : « C’est nous combler ! »

VI  
Le roi Marsile a tenu son conseil. Il dit à ses hommes : « Seigneurs, vous irez. Vous porterez des branches d’olivier en vos mains, et vous me direz au roi Charlemagne qu’au nom de son Dieu il me fasse merci ; qu’il ne verra point ce premier mois passer que je ne l’aie rejoint avec mille de mes fidèles ; que je recevrai la loi chrétienne et deviendrai son homme en tout amour et toute foi. Veut-il des otages, en vérité, il en aura. » Blancandrin dit : « Par là vous obtiendrez un bon accord. »
