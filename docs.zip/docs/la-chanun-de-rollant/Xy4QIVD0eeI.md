---
id: Xy4QIVD0eeI
title: "La Chançun de Rollant 4"
sidebar_label: "La Chançun de Rollant 4"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Xy4QIVD0eeI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La Chançun de Rollant 4

[IX]  
Blancandrins ad tut premereins parled  
E dist al rei : « Salvet seiez de Deu,  
Le glorius que devuns aürer !  
Iço vus mandet reis Marsilies li bers :  
Enquis ad mult la lei de salvetet.  
De sun aveir vos voelt asez duner,  
Urs e leuns e veltres enchaignez,  
Set cenz cameilz e mil hosturs muez,  
D’or e d’argent .IIII. cenz muls trussez,  
Cinquante care que carier en ferez ;  
Tant i avrat de besanz esmerez  
Dunt bien purrez voz soldeiers luer.  
En cest païs avez estet asez ;  
En France ad Ais devez bien repairer.  
La vos sivrat, ço dit, mis avoez. »  
Li empereres tent ses mains vers Deu,  
Baisset sun chef, si cumencet a penser. 

[X]  
Li empereres en tint sun chef enclin.  
De sa parole ne fut mie hastifs,  
Sa custume est qu’il parolet a leisir.  
Quant se redrecet, mult par out fier lu vis ;  
Dist as messages : « Vus avez mult ben dit.  
Li reis Marsilies est mult mis enemis :  
De cez paroles que vos avez ci dit,  
En quel mesure en purrai estre fiz ?  
— Vos par hostages », ço dist li Sarrazins,  
« Dunt vos avrez u dis u quinze u vint.  
Pa num d’ocire i metrai un mien filz  
E sin avrez, ço quid, de plus gentilz.  
Quant vus serez el palais seignurill,  
A la grant feste seint Michel del Peril,  
Mis avoez la vos sivrat, ço dit.  
Enz en voz bainz que Deus pur vos i fist,  
La vuldrat il chrestiens devenir. »  
Charles respunt : « Uncore purrat guarir. »

[XI]  
Bels fut li vespres e li soleilz fut cler.  
Les dis mulez fait Charles establer.  
El grant verger fait li reis tendre un tref,  
Les dis messages ad fait enz hosteler ;  
Douze serjanz les unt ben cunreez ;  
La noit demurent tresque vint al jur cler.  
Li empereres est par matin levet,  
Messe e matines ad li reis escultet.  
Desuz un pin en est li reis alez,  
Ses baruns mandet pur sun cunseill finer :  
Par cels de France voelt il del tut errer.

Contemporary French:

IX  
Blancandrin parle, lui le premier. Il dit au roi : « Salut au nom de Dieu, le Glorieux, que nous devons adorer ! Entendez ce que vous mande le roi Marsile, le preux. Il s’est bien enquis de la loi qui sauve, aussi vous veut-il donner de ses richesses à foison, ours, et lions, et lévriers enchaînés, sept cents chameaux et mille autours sortis de mue, quatre cents mulets, d’or et d’argent troussés, cinquante chars dont vous ferez un charroi, comblés de tant de besants d’or fin que vous en pourrez largement payer vos soudoyers. En ce pays vous avez fait un assez long séjour. En France, à Aix, il vous sied de retourner. Là vous suivra, il vous l’assure, mon seigneur. » L’empereur tend ses mains vers Dieu, baisse la tête et se prend à songer.

X  
L’empereur garde la tête baissée. Sa parole jamais ne fut hâtive. Telle est sa coutume, il ne parle qu’à son loisir. Quand enfin il se redressa, son visage était plein de fierté. Il dit aux messagers : « Vous avez très bien parlé. Mais le roi Marsile est mon grand ennemi. De ces paroles que vous venez de dire, comment pourrai-je avoir garantie ? — Par des otages, » dit le Sarrasin, « dont vous aurez ou dix, ou quinze ou vingt. Dût-il périr, j’y mettrai un mien fils, et vous en recevrez, je crois, de mieux nés encore. Quand vous serez en votre palais souverain, à la haute fête de saint Michel du Péril, là vous suivra, il vous l’assure, mon seigneur. Là, en vos bains, que Dieu fit pour vous, il veut devenir chrétien. » Charles répond : « Il peut encore parvenir au salut. »

XI  
La vêprée était belle et le soleil clair. Charles fait établer les dix mules. Dans le grand verger il fait dresser une tente. C’est là qu’il héberge les dix messagers ; douze sergents prennent grand soin de leur service. Ils y restent cette nuit tant que vint le jour clair. De grand matin l’empereur s’est levé : il a écouté messe et matines. Il s’en est allé sous un pin ; il mande ses barons pour tenir son conseil : en toutes ses voies il veut pour guides ceux de France.
