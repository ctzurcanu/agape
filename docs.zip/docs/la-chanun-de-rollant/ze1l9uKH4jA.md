---
id: ze1l9uKH4jA
title: "La Chançun de Rollant 9"
sidebar_label: "La Chançun de Rollant 9"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/ze1l9uKH4jA"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La Chançun de Rollant 9

[XXIX]  
Dist Blancandrins : « Francs sunt mult gentilz home  
Mult grant mal funt e cil duc e cil cunte  
A lur seignur, ki tel cunseill li dunent :  
Lui e altrui travaillent e cunfundent. »  
Guenes respunt : « Jo ne sai veirs nul hume,  
Ne mès Rollant, ki uncore en avrat hunte.  
Er matin sedeit li emperere suz l’umbre,  
Vint i ses niés, out vestue sa brunie,  
E out predet dejuste Carcasonie ;  
En sa main tint une vermeille pume :  
Tenez, bel sire, dist Rollant a sun uncle,  
De trestuz reis vos present les curunes.  
Li soens orgoilz le devreit ben cunfundre,  
Kar chascun jur de mort s’abandunet.  
Seit ki l’ociet, tute pais puis avriumes. »

  
[Instrumental]

[XXX]  
Dist Blancandrins : « Mult est pesmes Rollant,  
Ki tute gent voelt faire recreant  
E tutes teres met en chalengement !  
Par quele gent quiet il espleiter tant ? »  
Guenes respunt : « Par la franceise gent.  
Il l’aiment tant ne li faldrunt nient ;  
Or e argent lur met tant en present,  
Muls e destrers e palies e guarnemenz ;  
L’emperere meïsmes ad tut a sun talent :  
Cunquerrat li les teres d’ici qu’en Orient. » 

[XXXI]  
Tant chevalcherent Guenes e Blancandrins  
Que l’un a l’altre la sue feit plevit  
Que il querreient que Rollant fust ocis.  
Tant chevalcherent e veies e chemins  
Qu’en Sarraguce descendent suz un if.  
Un faldestoet out suz l’umbre d’un pin ;  
Envolupet fut d’un palie alexandrin :  
La fut li reis ki tute Espaigne tint ;  
Tut entur lui vint milie Sarrazins,  
N’i ad celoi ki mot sunt ne mot tint,  
Pur les nuveles qu’il vuldreient oïr.  
Atant as vos Guenes e Blanchandrins.

  
[XXXII]  
Blancandrins vint devant Marsiliun,  
Par le puign tint le cunte Guenelun,  
E dist al rei : « Salvez seiez de Mahum  
E d’Apollin, qui seintes leis tenuns !  
Vostre message fesime a Charlun.  
Ambes ses mains en levat cuntremunt,  
Loat sun Deu, ne fist altre respuns.  
Ci vos enveiet un sun noble barun  
Ki est de France, si est mult riches hom :  
Par lui orrez si avrez pais u nun. »  
Respunt Marsilie : « Or diet, nus l’orrum ! » 

Contemporary:

XXIX  
Blancandrin dit : « Les Francs sont gens très nobles. Mais ils font grand mal à leur seigneur, ces ducs et ces comtes qui le conseillent comme ils font : ils l’épuisent et le perdent, lui et d’autres avec lui. » Ganelon répond : « Ce n’est vrai, que je sache, de personne, sinon de Roland, lequel, un jour, en pâtira. L’autre matin, l’empereur était assis à l’ombre. Survint son neveu, la brogne endossée, qui des abords de Carcasoine ramenait du butin. À la main il tenait une pomme vermeille : « Prenez, beau sire, dit-il à son oncle : de tous les rois je vous donne en présent les couronnes. » Son orgueil est bien fait pour le perdre, car chaque jour il s’abandonne à la mort. Vienne qui le tue : nous aurions paix plénière ! »

XXX  
Blancandrin dit : « Roland est bien digne de haine, qui veut réduire à merci toute nation et qui prétend sur toutes les terres. Pour tant faire, sur qui donc compte-t-il ? » Ganelon répond : « Sur les Français ! Ils l’aiment tant qu’ils ne lui feront jamais faute. Il leur donne à profusion or et argent, mulets et destriers, draps de soie, armures. À l’empereur même il donne tout ce qu’il veut [?] : il lui conquerra les terres d’ici jusqu’en Orient. »

XXXI  
Tant chevauchèrent Ganelon et Blancandrin qu’ils ont échangé sur leur foi une promesse : ils chercheront comment faire tuer Roland. Tant chevauchèrent-ils par voies et par chemins qu’à Saragosse ils mettent pied à terre, sous un if. A l’ombre d’un pin un trône était dressé, enveloppé de soie d’Alexandrie. Là est le roi qui tient toute l’Espagne. Autour de lui vingt mille Sarrasins. Pas un qui sonne mot, pour les nouvelles qu’ils voudraient ouïr. Voici que viennent Ganelon et Blancandrin.

XXXII  
Blancandrin est venu devant Marsile ; il tient par le poing le comte Ganelon. Il dit au roi : « Salut, au nom de Mahomet et d’Apollin, de qui nous gardons les saintes lois ! Nous avons fait votre message à Charles. Vers le ciel il éleva ses deux mains, loua son Dieu, ne fit autre réponse. Il vous envoie, le voici, un sien noble baron, qui est de France et très haut homme. Par lui vous apprendrez si vous aurez la paix ou non. » Marsile répond : « Qu’il parle, nous l’entendrons ! »
