---
id: IMzRhc3X-XY
title: "La Chançun de Rollant 3"
sidebar_label: "La Chançun de Rollant 3"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/IMzRhc3X-XY"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La Chançun de Rollant 3

[VII]  
Dis blanches mules fist amener Marsilies,  
Que li tramist li reis de Suatilie.  
Li frein sunt d’or, les seles d’argent mises.  
Cil sunt muntez ki le message firent,  
Enz en lur mains portent branches d’olive.  
Vindrent a Charles, ki France ad en baillie :  
Nes poet guarder que alques ne l’engignent.

[VIII]  
Li empereres se fait e balz e liez :  
Cordres ad prise e les murs peceiez,  
Od ses cadables les turs en abatied ;  
Mult grant eschech en unt si chevaler  
D’or e d’argent e de guarnemenz chers.  
En la citet nen ad remés paien  
Ne seit ocis u devient chrestien.

Li empereres est en un grant verger,  
Ensembl’ od lui Rollant e Oliver,  
Sansun li dux e Anseïs li fiers,  
Gefreid d’Anjou, le rei gunfanuner,  
E si i furent e Gerin e Gerers ;  
La u cist furent, des altres i out bien :  
De dulce France i ad quinze milliers.

Sur palies blancs siedent cil cevaler,  
As tables juent pur els esbaneier  
E as eschecs li plus saive e li veill,  
E escremissent cil bacheler leger.  
Desuz un pin, delez un eglenter,  
Un faldestoed i unt fait fut d’or mer :  
La siet li reis ki dulce France tient.  
Blanche ad la barbe e tut flurit le chef,  
Gent ad le cors e le cuntenant fier :  
S’est kil demandet, ne l’estoet enseigner.  
E li message descendirent a pied,  
Sil saluerent par amur e par bien.

Contemporary French:

VII  
Marsile fit amener dix mules blanches, que lui avait envoyées le roi de Suatille. Leurs freins sont d’or ; les selles serties d’argent. Les messagers montent ; en leurs mains ils portent des branches d’olivier. Ils s’en vinrent vers Charles, qui tient France en sa baillie. Charles ne peut s’en garder : ils le tromperont.

VIII  
L’empereur s’est fait joyeux ; il est en belle humeur : Cordres, il l’a prise. Il en a broyé les murailles, et de ses pierrières abattu les tours. Grand est le butin qu’ont fait ses chevaliers, or, argent, précieuses armures. Dans la cité plus un païen n’est resté : tous furent occis ou faits chrétiens. L’empereur est dans un grand verger : près de lui, Roland et Olivier, le duc Samson et Anseïs le fier, Geoffroi d’Anjou, gonfalonier du roi, et là furent encore et Gerin et Gerier, et avec eux tant d’autres : de douce France, ils sont quinze milliers. Sur de blancs tapis de soie sont assis les chevaliers ; pour se divertir, les plus sages et les vieux jouent aux tables et aux échecs, et les légers bacheliers s’escriment de l’épée. Sous un pin, près d’un églantier, un trône est dressé, tout d’or pur : là est assis le roi qui tient douce France. Sa barbe est blanche et tout fleuri son chef ; son corps est beau, son maintien fier : à qui le cherche, pas n’est besoin qu’on le désigne. Et les messagers mirent pied à terre et le saluèrent en tout amour et tout bien.
