---
id: ZaJ9YGkPsLU
title: "La Chançun de Rollant 1"
sidebar_label: "La Chançun de Rollant 1"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/ZaJ9YGkPsLU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La Chançun de Rollant 1

[I]  
Carles li reis, nostre emperere magnes,  
Set anz tuz pleins ad estet en Espaigne :  
Tresqu’en la mer cunquist la tere altaigne.  
N’i ad castel ki devant lui remaigne ;  
Mur ne citet n’i est remés a fraindre,  
Fors Sarraguce, ki est en une muntaigne.  
Li reis Marsilie la tient, ki Deu nen aimet.  
Mahumet sert e Apollin recleimet :  
Nes poet guarder que mals ne l’i ateignet.

[II]  
Li reis Marsilie esteit en Sarraguce.  
Alez en est en un verger suz l’umbre.  
Sur un perrun de marbre bloi se culchet ;  
Envirun lui plus de vint milie humes.  
Il en apelet e ses dux e ses cuntes :  
« Oez, seignurs, quel pecchet nus encumbret.  
Li empereres Carles de France dulce  
En cest païs nos est venuz cunfundre.  
Jo nen ai ost qui bataille li dunne,  
Ne n’ai tel gent ki la sue derumpet.  
Cunseilez mei cume mi savie hume,  
Si me guarisez e de mort et de hunte ! »  
N’i ad paien ki un sul mot respundet,  
Fors Blancandrins de Castel de Valfunde.

[III]  
Blancandrins fut des plus saives paiens ;  
De vasselage fut asez chevaler,  
Prozdom i out pur sun seignur aider,  
E dist al rei : « Ore ne vus esmaiez !  
Mandez Carlun, a l’orguillus e al fier,  
Fedeilz servises e mult granz amistez.  
Vos li durrez urs e leons e chens,  
Set cenz camelz e mil hosturs muers,  
D’or e d’argent .IIII.C. muls cargez,  
Cinquante carre qu’en ferat carier :  
Ben en purrat luer ses soldeiers.  
En ceste tere ad asez osteiet ;  
En France, ad Ais, s’en deit ben repairer.  
Vos le sivrez a la feste seint Michel,  
Si recevrez la lei de chrestiens,  
Serez ses hom par honur e par ben.  
S’en volt ostages, e vos l’en enveiez,  
U dis u vint, pur lui afiancer.  
Enveiuns i les filz de noz muillers :  
Par num d’ocire i enveierai le men.  
Asez est melz qu’il i perdent lé chefs  
Que nus perduns l’onur ne la deintet,  
Ne nus seiuns cunduiz a mendeier !  »

Contemporary French:

I  
Le roi Charles, notre empereur, le Grand, sept ans tout pleins est resté dans l’Espagne : jusqu’à la mer il a conquis la terre hautaine. Plus un château qui devant lui résiste, plus une muraille à forcer, plus une cité, hormis Saragosse, qui est dans une montagne. Le roi Marsile la tient, qui n’aime pas Dieu. C’est Mahomet qu’il sert, Apollin qu’il prie. Il ne peut pas s’en garder : le malheur l’atteindra.

II  
Le roi Marsile est à Saragosse. Il s’en est allé dans un verger, sous l’ombre. Sur un perron de marbre bleu il se couche ; autour de lui, ils sont plus de vingt mille. Il appelle et ses ducs et ses comtes : « Entendez, seigneurs, quel fléau  nous frappe. L’empereur Charles de douce France est venu dans ce pays pour nous confondre. Je n’ai point d’armée qui lui donne la bataille ; ma gent n’est pas de force à rompre la sienne. Conseillez-moi, vous, mes hommes sages, et gardez-moi et de mort et de honte ! » Il n’est païen qui réponde un seul mot, sinon Blancandrin, du château de Val-Fonde.

III  
Entre les païens Blancandrin était sage : par sa vaillance, bon chevalier ; par sa prudhomie, bon conseiller de son seigneur. Il dit au roi : « Ne vous effrayez pas ! Mandez à Charles, à l’orgueilleux, au fier, des paroles de fidèle service et de très grande amitié. Vous lui donnerez des ours et des lions et des chiens, sept cents chameaux et mille autours sortis de mue, quatre cents mulets d’or et d’argent chargés, cinquante chars dont on formera un charroi : il en pourra largement payer ses soudoyers. Mandez-lui qu’en cette terre assez longtemps il guerroya ; qu’en France, à Aix, il devrait bien s’en retourner ; que vous l’y suivrez à la fête de saint Michel ; que vous y recevrez la loi des chrétiens ; que vous deviendrez son vassal en tout honneur et tout bien. Veut-il des otages, or bien, envoyez-en, ou dix ou vingt, pour le mettre en confiance. Envoyons-y les fils de nos femmes : dût-il périr, j’y enverrai le mien. Bien mieux vaut qu’ils y perdent leurs têtes et que nous ne perdions pas, nous, franchise et seigneurie, et ne soyons pas conduits à mendier. »
