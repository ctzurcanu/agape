---
id: FeY9GiwPA4s
title: "La Chançun de Rollant 7"
sidebar_label: "La Chançun de Rollant 7"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/FeY9GiwPA4s"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La Chançun de Rollant 7

[XX]  
« Francs chevalers, » dist li emperere Carles,  
« Car m’eslisez un barun de ma marche,  
Qu’a Marsiliun me portast mun message. »  
Ço dist Rollant : « Ço ert Guenes, mis parastre. »  
Dient Franceis : « Car il le poet ben faire.  
Se lui lessez, n’i trametrez plus saive. »  
E li quens Guenes en fut mult anguisables.  
De sun col getet ses grandes pels de martre  
E est remés en sun blialt de palie.  
Vairs out les oeilz e mult fier lu visage ;  
Gent out le cors e les costez out larges ;  
Tant par fut bels tuit si per l’en esguardent.  
Dist a Rollant : « Tut fol, pur quei t’esrages ?  
Ço set hom ben que jo sui tis parastres,  
Si as juget qu’a Marsiliun en alge.  
Se Deus ço dunet que jo de la repaire,  
Jo t’en muvra un si grant contraire  
Ki durerat a trestut tun edage. »  
Respunt Rollant : « Orgoill oi e folage.  
Ço set hom ben n’ai cure de manace.  
Mai saives hom il deit faire message :  
Si li reis voelt, prez sui por vus le face ! »

[XXI]  
Guenes respunt : « Pur mei n’iras tu mie !  
Tu n’ies mes hom ne jo ne sui tis sire.  
Carles comandet que face sun servise :  
En Sarraguce en irai a Marsilie.  
Einz i frai un poi de legerie  
Que jo n’esclair ceste meie grant ire. »  
Quant l’ot Rollant, si cumençat a rire.

[XXII]  
Quant ço veit Guenes qu’ore s’en rit Rollant,  
Dunc ad tel doel pur poi d’ire ne fent ;  
A ben petit que il ne pert le sens,  
E dit al cunte : « Jo ne vus aim nient :  
Sur mei avez turnet fals jugement.  
Dreiz emperere, veiz me ci en present :  
Ademplir voeill vostre comandement..

[XXIII]  
En Sarraguce sai ben qu’aler m’estoet.   
Hom ki la vait repairer ne s’en poet.  
Ensur que tut si ai jo vostre soer,  
Sin ai un filz, ja plus bels n’en estoet.  
Ço est Baldewin, » ço dit, « ki ert prozdoem.  
A lui lais jo mes honurs e mes fieus.  
Guadez le ben, ja nel verrai des oilz. »  
Carles respunt : « Tro avez tendre coer.  
Puis quel comant, aler vus en estoet. »

[XXIV]  
Ço dist li reis : « Guenes, venez avant,   
Si recevez le bastun e lu guant.  
Oït l’avez, sur vos le jugent Franc.  
— Sire, » dist Guenes, « ço ad tut fait Rollant !  
Ne l’amerai a trestut mun vivant,  
Ne Oliver, por ço qu’il est si cumpainz,  
Li duze per, por ço qu’il l’aiment tant.  
Desfi les en, sire, vostre veiant. »  
Ço dist li reis : « Trop avez mal talant.  
Or irez vos certes, quant jol cumant.  
— Jo i puis aler, mais n’i avrai guarant.   
Nu l’out Basilies ne sis freres Basant. »

Contemporary:

XX  
« Francs chevaliers, » dit l’empereur Charles, « élisez-moi un baron de ma terre, qui puisse porter à Marsile mon message. » Roland dit : « Ce sera Ganelon, mon parâtre. » Les Français disent : « Certes il est homme à le faire ; lui écarté, vous n’enverrez pas un plus sage. » Et le comte Ganelon en fut pénétré d’angoisse. De son col il rejette ses grandes peaux de martre ; il reste en son bliaut de soie. Il a les yeux vairs, le visage très fier ; son corps est noble, sa poitrine large : il est si beau que tous ses pairs le contemplent. Il dit à Roland : « Fou ! Pourquoi ta frénésie ? On le sait bien que je suis ton parâtre et voici que tu m’as marqué pour aller vers Marsile. Si Dieu donne que je revienne de là-bas, je te ferai tel dommage qui durera aussi longtemps que tu vivras ! » Roland répond : « Ce sont propos d’orgueil et de folie. On le sait bien, je n’ai cure d’une menace ; mais pour un message il faut un homme de sens : si le roi veut, je suis prêt : je le ferai à votre place. »

XXI  
Ganelon répond : « Tu n’iras pas à ma place ! Tu n’es pas mon vassal, je ne suis pas ton seigneur. Charles commande que je fasse son service : j’irai à Saragosse, vers Marsile ; mais avant que j’apaise ce grand courroux où tu me vois, j’aurai joué quelque jeu de ma façon. » Quand Roland l’entend, il se prend à rire.

XXII  
Quand Ganelon voit que Roland s’en rit, il en a si grand deuil qu’il pense éclater de courroux ; peu s’en faut qu’il ne perde le sens. Et il dit au comte : « Je ne vous aime pas, vous qui avez fait tourner sur moi cet injuste choix. Droit empereur, me voici devant vous : je veux accomplir votre commandement.

XXIII  
J’irai à Saragosse ! Il le faut, je le sais bien. Qui va là-bas n’en peut revenir. Sur toutes choses, rappelez-vous que j’ai pour femme votre sœur. J’ai d’elle un fils, le plus beau qui soit. C’est Baudoin, dit-il, qui sera un preux. C’est à lui que je lègue mes terres et mes fiefs. Prenez-le bien sous votre garde, je ne le reverrai de mes yeux. » Charles répond : « Vous avez le cœur trop tendre. Puisque je le commande, il vous faut aller. »

XXIV  
Le roi dit : « Ganelon, approchez et recevez le bâton et le gant. Vous l’avez bien entendu : les Francs vous ont choisi. — Sire, » dit Ganelon, « c’est Roland qui a tout fait ! Je ne l’aimerai de ma vie, ni Olivier, parce qu’il est son compagnon, ni les pairs, parce qu’ils l’aiment tant. Je les défie, sire, sous votre regard ! » Le roi dit : « Vous avez trop de courroux. Vous irez certes, puisque je le commande. — J’y puis aller, mais sans nulle sauvegarde, tout comme Basille et son frère Basant. »
