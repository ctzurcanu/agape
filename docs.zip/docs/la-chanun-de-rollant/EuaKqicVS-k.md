---
id: EuaKqicVS-k
title: "La Chançun de Rollant 13"
sidebar_label: "La Chançun de Rollant 13"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/EuaKqicVS-k"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La Chançun de Rollant 13

[XLII]  
Dist li Sarrazins : « Merveille en ai grant  
De Carlemagne, ki est canuz e blancs !  
Mien escientre plus ad de. II.C. anz.  
Par tantes teres est alet cunquerant,  
Tanz colps ad pris de bons espiez trenchanz,  
Tanz riches reis morz e vencuz en champ :  
Quant ier il mais d’osteier recreant ?  
— Ço n’iert, » dist Guenes, « tant cum vivet Rollant :  
N’ad tel vassal d’ici qu’en Orient.  
Mult par est proz Oliver, sis cumpainz ;  
Li douze per, que Carles aimet tant,  
Funt les enguardes a vingt milie de Francs.  
Soürs est Carles, ne crent hume vivant. » 

[XLIII]  
« Bel sire Guenes, » dist Marsilies li reis,  
« Jo ai tel gent, plus bele ne verreiz ;  
Quatre cenz milie chevalers puis aveir.  
Puis m’en cumbatre a Carle e a Franceis ? »  
Guenes respunt : « Ne vus a ceste feiz !  
De voz paiens mult grant perte i avreiz.  
Lessez la folie, tenez vos al saveir.  
L’empereür tant li dunez aveir  
N’i ait Franceis ki tot ne s’en merveilt.  
Par vingt hostages que li enveiereiz  
En dulce France s’en repairerat li reis ;  
Sa rereguarde lerrat derere sei.  
Iert i sis niés. li quens Rollant, ço crei,  
E Oliver, li proz e li curteis.  
Mort sunt li cunte, se est ki mei en creit.  
Carles verrat sun grant orguill cadeir ;  
N’avrat talent que ja mais vus guerreit. » 

[XLIV]  
« Bel sire Guenes. . . . . . . . .  
Cum faitement purrai Rollant ocire ? »  
Guenes respont : « Ço vos sai jo ben dire.  
Li reis serat as meillors porz de Sizer ;  
Sa rereguarde avrat detrés sei mise ;  
Iert i sis niés, li quens Rollant, li riches,  
E Oliver, en qui il tant se fiet.  
vingt milie Francs unt en lur cumpaignie.  
De voz paiens lur enveiez .C. milie :  
Une bataille lur i rendent cil primes ;  
La gent de France iert blecee e blesmie ;  
Nel di por ço, des voz iert la martirie.  
Altre bataille lur livrez de meïsme :  
De quel que seit Rollant n’estoerdrat mie.  
Dunc avrez faite gente chevalerie ;  
N’avrez mais guere en tute vostre vie. 

Contemporary:

XLII  
Le Sarrasin dit : « Je m’émerveille grandement. Charlemagne est chenu et blanc ; à mon escient il a deux cents ans et plus ; par tant de terres il a passé en les conquérant, il a pris tant de coups de bonnes lances tranchantes, il a tué et vaincu en bataille tant de riches rois : quand sera-t-il recru de guerroyer ? — Jamais », dit Ganelon, « tant que Roland vivra. Il n’y a pas si vaillant d’ici jusqu’en Orient. Il est très preux aussi, son compagnon Olivier. Et les douze pairs, que Charles aime tant, forment son avant-garde avec vingt mille Français. Charles est en sûreté ; il ne craint homme vivant. »

XLIII  
« Beau sire Ganelon, » dit le roi Marsile, « j’ai une armée, jamais vous ne verrez plus belle ; j’y puis avoir quatre cent mille chevaliers : puis-je combattre Charles et les Français ? « Ganelon répond : « Pas de si tôt ! Vous y perdriez de vos païens en masse. Laissez la folie ; tenez-vous à la sagesse ! Donnez à l’empereur tant de vos biens qu’il n’y ait Français qui ne s’en émerveille. Pour vingt otages que vous lui enverrez, vers douce France le roi repartira. Derrière lui il laissera son arrière-garde. Son neveu en sera, je crois, le comte Roland, et aussi Olivier, le preux et le courtois : ils sont morts, les deux comtes, si je trouve qui m’écoute. Charles verra son grand orgueil choir ; l’envie lui passera de jamais guerroyer contre vous. »

XLIV  
« Beau sire Ganelon, [...] comment pourrai-je faire périr Roland ? » Ganelon répond : « Je sais bien vous le dire. Le roi viendra aux meilleurs Ports de Cize : derrière lui il aura laissé son arrière-garde. Son neveu en sera, le puissant comte Roland, et Olivier, en qui tant il se fie, et en leur compagnie vingt mille Français. De vos païens envoyez-leur cent mille, et qu’ils leur livrent une première bataille. La gent de France y sera meurtrie et mise à mal, et il y aura aussi, je ne dis pas, grande tuerie des vôtres. Mais livrez-leur de même une seconde bataille : qu’il tombe dans l’une ou dans l’autre, Roland n’échappera pas. Alors vous aurez accompli une belle chevalerie, et de toute votre vie vous n’aurez plus la guerre.
