---
id: vZqMz2ywlIM
title: "La Chançun de Rollant 15"
sidebar_label: "La Chançun de Rollant 15"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/vZqMz2ywlIM"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La Chançun de Rollant 15

[LI]  
Li reis apelet Malduit, sun tresorer :  
« L’aveir Carlun est il apareilliez ? »  
E cil respunt : « Oïl, sire, asez bien :  
700 cameilz, d’or e argent cargiez,  
E 20 hostages, des plus gentilz desuz cel. »

[LII]  
Marsilies tint Guenelun par l’espalle,  
Si li ad dit : « Mult par ies ber e sage.  
Par cele lei que vos tenez plus salve,  
Guardez de nos ne turnez le curage.  
De mun aveir vos voeill dunner grant masse,  
10 muls cargez del plus fin or d’Arabe ;  
Ja mais n’iert an altretel ne vos face.  
Tenez les clefs de ceste citet large ;  
Le grant aveir en presentez al rei Carles :  
Pois me jugez Rollant a rereguarde.  
Sel pois trover a port ne a passage,  
Liverrai lui une mortel bataille. »  
Guenes respunt : « Mei est vis que trop targe ! »  
Pois est munted, entret en sun veiage.

[LIII]  
Li empereres aproismet sun repaire.  
Venuz en est a la citet de Galne :  
Li quens Rollant, il l’ad e prise e fraite ;  
Puis icel jur en fut cent anz deserte.  
De Guenelun atent li reis nuveles  
E le treüd d’Espaigne, la grant tere.  
Par main en l’albe, si cum li jurz esclairet,  
Guenes li quens est venuz as herberges.

[LIV]  
Li empereres est par matin levet ;  
Messe e matines ad li reis escultet.  
Sur l’erbe verte estut devant sun tref.  
Rollant i fut e Oliver li ber,  
Neimes li dux e des altres asez.  
Guenes i vint, li fels, li parjurez.  
Par grant veisdie cumencet a parler  
E dist al rei : « Salvez seiez de Deu !  
De Sarraguce ci vos aport les clefs ;  
Mult grant aveir vos en faz amener  
E .XX. hostages, faites les ben guarder,  
E si vos mandet reis Marsilies li ber  
De l’algalifes nel devez pas blasmer,  
Kar a mes oilz vi 400 milie armez,  
Halbers vestuz, alquanz healmes fermez,  
Ceintes espees as punz d’or neielez,  
Ki l’en cunduistrent tresqu’en la mer :  
De Marcilie s’en fuient por la chrestientet  
Que il ne voelent ne tenir ne guarder.

Contemporary:

LI  
Le roi appelle Malduit son trésorier : « Le trésor de Charles est-il apprêté ? — Oui, sire, pour le mieux : sept cents chameaux, d’or et d’argent chargés, et vingt otages, des plus nobles qui soient sous le ciel. »

LII  
Marsile prit Ganelon par l’épaule. Il lui dit : « Vous êtes très preux et sage. Par cette loi que vous tenez pour la plus sainte, ne retirez plus de nous votre cœur ! Je veux vous donner de mes richesses en masse, dix mulets chargés de l’or le plus fin d’Arabie ; il ne passera pas d’année que je ne vous en fasse autant. Tenez, voici les clés de cette large cité ; ses grands trésors, présentez-les au roi Charles ; puis faites-moi mettre Roland à l’arrière-garde. Si je le puis trouver en quelque port ou passage, je lui livrerai une bataille à mort. » Ganelon répond : « Je m’attarde trop, je crois. » Il monte à cheval, entre en sa route.

LIII  
L’empereur regagne ses quartiers. Il est venu à la cité de Galne : le comte Roland l’avait prise et détruite ; de ce jour elle resta cent ans déserte. Le roi attend des nouvelles de Ganelon et le tribut d’Espagne, la grand’terre. À l’aube, comme le jour se lève, Ganelon le comte arrive au camp.

LIV  
L’empereur s’est tôt levé. Il a écouté messe et matines. Devant sa tente, il se tient debout sur l’herbe verte. Roland est là, et Olivier le preux, Naimes le duc, et beaucoup des autres. Arrive Ganelon, le félon, le parjure. Avec toute sa ruse il se met à parler : « Salut de par Dieu ! » dit-il au roi. « De Saragosse je vous apporte les clés, les voici ; et voici un grand trésor que je vous amène, et vingt otages : faites-les mettre sous bonne garde. Et le roi Marsile, le vaillant, vous mande que, s’il ne vous livre pas l’Algalife, vous ne l’en devez pas blâmer, car de mes yeux j’ai vu quatre cent mille hommes en armes, revêtus du haubert, beaucoup portant lacé le heaume et ceints de leurs épées aux pommeaux d’or niellé, qui ont accompagné l’Algalife jusque sur la mer. Il fuyaient Marsile, à cause de la loi chrétienne, qu’ils ne voulaient pas recevoir et garder.
