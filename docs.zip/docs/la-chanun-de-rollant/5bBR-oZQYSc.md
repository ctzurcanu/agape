---
id: 5bBR-oZQYSc
title: "La Chançun de Rollant 11"
sidebar_label: "La Chançun de Rollant 11"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/5bBR-oZQYSc"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La Chançun de Rollant 11

[XXXVI]  
Envers le rei s’est Guenes aproismet,  
Si li ad dit : « A tort vos curuciez,  
Quar ço vos mandet Carles, ki France tient,  
Que recevez la lei de chrestiens ;  
Demi Espaigne vus durat il en fiet,  
L’altre meitet avrat Rollant, sis niés :  
Mult orguillos parçuner i avrez !  
Si ceste acorde ne volez otrier,  
En Sarraguce vus vendrat aseger.  
Par poestet serez pris e liez ;  
Menet serez dreit ad Ais le siet.  
Vus n’i avrez palefreid ne destrer,  
Ne mul ne mule que puissez chevalcher ;  
Getet serez sur un malvais sumer.  
Par jugement iloec perdrez le chef.  
Nostre emperere vus enveiet cest bref. »  
El destre poign al paien l’ad livret.

[XXXVII]  
Marsilies fut esculurez de l’ire,  
Freint le seel, getet en ad la cire,  
Guardet al bref, vit la raisun escrite :  
« Carle me mandet, ki France ad en baillie,  
Que me remembre de la dolur e de l’ire,  
Ço est de Basan e de sun frere Basilie  
Dunt pris les chefs as puis de Haltoïe ;  
Se de mun cors voeil aquiter la vie,  
Dunc li envei mun uncle l’algalife ;  
Altrement ne m’amerat il mie. »  
Après parlat ses filz envers Marsilies  
E dist al rei : « Guenes ad dit folie.  
Tant ad erret nen est dreiz que plus vivet.  
Livrez le mei, jo en ferai la justise. »  
Quant l’oït Guenes, l’espee en ad branlie ;  
Vait s’apuier suz le pin a la tige.

[XXXVIII]  
Enz el verger s’en est alez li reis,  
Ses meillors humes en meinet ensembl’od sei,  
E Blancandrins i vint, al canud peil,  
E Jurfaret, ki est ses filz e ses heirs,  
E l’algalifes, sun uncle e sis fedeilz.  
Dist Blancandrins : « Apelez le Franceis :  
De nostre prod m’ad plevie sa feid. »  
Ço dist li reis : « E vos l’i ameneiz. »  
Guenelun prist par la main destre ad deiz,  
Enz el verger l’en meinet josqu’al rei.  
La purparolent la traïsun seinz dreit.

Contemporary French:

XXXVI  
Ganelon s’est avancé vers le roi. Il lui dit : « Vous vous irritez à tort, puisque Charles, qui règne sur la France, vous mande ceci : recevez la loi des chrétiens, il vous donnera en fief la moitié de l’Espagne. L’autre moitié, Roland l’aura, son neveu : vous partagerez avec un très orgueilleux voisin. Si vous ne voulez pas accepter cet accord, le roi viendra vous assiéger dans Saragosse : de vive force vous serez pris et lié : vous serez mené droit à la cité d’Aix ; vous n’aurez pour la route palefroi ni destrier, mulet ni mule, que vous puissiez chevaucher ; vous serez jeté sur une mauvaise bête de somme ; là, par jugement, vous aurez la tête tranchée. Notre empereur vous envoie ce bref. » Il l’a remis au païen, dans sa main droite.

XXXVII  
Marsile a blêmi de courroux. Il rompt le sceau, en jette la cire, regarde le bref, voit ce qui est écrit : « Charles me mande, le roi qui tient la France en sa baillie, qu’il me souvienne de sa douleur et de sa colère pour Basan et son frère Basille de qui j’ai pris les têtes aux monts de Haltoïe ; si je veux racheter ma vie, que je lui envoie mon oncle l’Algalife ; sans quoi, jamais il ne m’aimera. » Alors le fils de Marsile prit la parole. Il dit au roi : « Ganelon a parlé en fou. Il en a trop fait : il n’a plus droit à vivre. Livrez-le moi, je ferai justice. » Quand Ganelon l’entend, il brandit son épée, va sous le pin, s’adosse au tronc.

XXXVIII  
Marsile s’est retiré dans le verger. Il a emmené avec lui ses meilleurs vassaux. Et Blancandrin y vint, au poil chenu, et Jurfaret, qui est son fils et son héritier, et l’Algalife, son oncle et son fidèle. Blancandrin dit : « Appelez le Français : il nous servira, il me l’a juré sur sa foi. » Le roi dit : « Amenez-le-donc. » Et Blancandrin l’a pris par la main droite et le conduit par le verger jusqu’au roi. Là ils débattent la laide trahison.
