---
id: EyOMJFepbK0
title: "La Chançun de Rollant 6"
sidebar_label: "La Chançun de Rollant 6"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/EyOMJFepbK0"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La Chançun de Rollant 6

[XV]  
Li emperere en tint sun chef enbrunc,  
Si duist sa barbe, afaitad sun gernun,  
Ne ben ne mal ne respunt sun nevuld.  
Franceis se taisent, ne mais que Guenelun.  
En piez se drecet, si vint devant Carlun,  
Mult fierement cumencet sa raisun  
E dist al rei : « Ja mar crerez bricun,  
Ne mei ne altre, se de vostre prod nun !  
Quant ço vos mandet li reis Marsiliun  
Qu’il devendrat jointes ses mains tis hom  
E tute Espaigne tendrat par vostre dun,  
Puis recevrat la lei que nus tenum,  
Qui ço vos lodet que cest plait degetuns,  
Ne li chalt, sire, de quel mort nus muriuns.  
Cunseill d’orguill n’est dreiz que a plus munt ;  
Laissum les fols, as sages nus tenuns ! »

[XVI]  
Après iço i est Neimes venud,  
Meillor vassal n’aveit en la curt nul,  
E dist al rei : « Ben l’avez entendud :  
Guenes li quens ço vus ad respondud ;  
Saveir i ad, mais qu’il seit entendud.  
Li reis Marsilie est de guere vencud :  
Vos li avez tuz ses castels toluz,  
Od voz caables avez fruiset ses murs,  
Ses citez arses e ses humes vencuz.  
Quant il vos mandet qu’aiez mercit de lui,  
Pecchet fereit ki dunc li fesist plus.  
U par ostage vos en voelt faire soürs,  
Ceste grant guerre ne deit munter a plus. »  
Dient Franceis : « Ben ad parlet li dux. »

[XVII]  
« Seignurs baruns, qui i enveieruns,  
En Sarraguce, al rei Marsiliuns ? »  
Respunt dux Neimes : « Jo irai, par vostre dun !  
Livrez m’en ore le guant e le bastun. »  
Respunt li reis : « Vos estes saives hom.  
Par ceste barbe e par cest men gernun,  
Vos n’irez pas uan de mei si luign.  
Alez sedeir, quant nuls ne vos sumunt !

[XVIII]  
Seignurs baruns, qui i purruns enveier,  
Al Sarrazin ki Sarraguce tient ? »  
Respunt Rollant : « Jo i puis aler mult ben !  
— Nu ferez certes, » dist li quens Oliver.  
« Vostre curages est mult pesmes e fiers :  
Jo me crendreie que vos vos meslisez.  
Se li reis voelt, jo i puis aler ben. ».  
Respunt li reis : « Ambdui vos en taisez !  
Ne vos ne il n’i porterez les piez.  
Par ceste barbe que veez blancheier,  
Li duze per mar i serunt jugez ! »  
Franceis se taisent, as les vus aquisez.

[XIX]  
Turpins de Reins en est levet del renc  
E dist al rei : « Laisez ester voz Francs !  
En cest païs avez estet set anz,  
Mult unt oüd e peines e ahans.  
Dunez m’en, sire, le bastun e le guant  
E jo irai al Sarazin espan,  
Sin vois vedeir alques de sun semblant. »  
Li empereres respunt par maltalant :  
« Alez sedeir desur cel palie blanc !  
N’en parlez mais, se jo nel vos cumant ! »

Contemporary French:

XV  
L’empereur tient la tête baissée. Il lisse sa barbe, arrange sa moustache, ne fait à son neveu, bonne ou mauvaise, nulle réponse. Les Français se taisent, hormis Ganelon. Il se dresse droit sur ses pieds, vient devant Charles. Très fièrement il commence. Il dit au roi : « Malheur, si vous en croyez le truand, moi ou tout autre, qui ne parlerait pas pour votre bien ! Quand le roi Marsile vous mande que, mains jointes, il deviendra votre homme, et qu’il tiendra toute l’Espagne comme un don de votre grâce, et qu’il recevra la loi que nous gardons, celui-là qui vous conseille que nous rejetions un tel accord, peu lui chaut, sire, de quelle mort nous mourrons. Un conseil d’orgueil ne doit pas prévaloir. Laissons les fous, tenons-nous aux sages ! »

XVI  
Alors Naimes s’avança ; il n’y avait en la cour nul meilleur vassal. Il dit au roi : « Vous l’avez bien entendue, la réponse que vous fit Ganelon ; elle a du sens, il n’y a qu’à la suivre. Le roi Marsile est vaincu dans sa guerre ; tous ses châteaux, vous les lui avez ravis ; de vos pierrières vous avez brisé ses murailles ; vous avez brûlé ses cités, vaincu ses hommes. Aujourd’hui qu’il vous mande que vous le receviez à merci, lui en faire pis, ce serait péché. Puisqu’il veut vous donner en garantie des otages, cette grande guerre ne doit pas aller plus avant. » Les Français disent : « Le duc a bien parlé ! »

XVII  
« Seigneurs barons, qui y enverrons-nous, à Saragosse, vers le roi Marsile ? » Le duc Naimes répond : « J’irai, par votre congé : livrez-m’en sur l’heure le gant et le bâton. » Le roi dit : « Vous êtes homme de grand conseil ; par cette mienne barbe, vous n’irez pas de si tôt si loin de moi. Retournez vous asseoir, car nul ne vous a requis !

XVIII  
Seigneurs barons, qui pourrons-nous envoyer au Sarrasin qui tient Saragosse ? » Roland répond : « J’y puis aller très bien. — Vous n’irez certes pas, » dit le comte Olivier. « Votre cœur est âpre et orgueilleux, vous en viendriez aux prises, j’en ai peur. Si le roi veut, j’y puis aller très bien. » Le roi répond : « Tous deux, taisez-vous ! Ni vous ni lui n’y porterez les pieds. Par cette barbe que vous voyez toute blanche, malheur à qui me nommerait l’un des douze pairs ! » Les Français se taisent, restent tout interdits.  
...
