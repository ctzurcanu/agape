---
id: 05kVsTOYI70
title: "La Chançun de Rollant 8"
sidebar_label: "La Chançun de Rollant 8"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/05kVsTOYI70"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La Chançun de Rollant 8

[XXV]  
Li empereres li tent sun guant, le destre ;  
Mais li quens Guenes iloec ne volsist estre :  
Quant le dut prendre, si li caït a tere.  
Dient Franceis : « Deus, que purrat ço estre ?  
De cest message nos avendrat grant perte.  
— Seignurs, » dist Guenes, « vos en orrez noveles ! »

[XXVI]

« Sire, » dist Guenes, « dunez mei le cungied.  
Quant aler dei, n’i ai plus que targer. »  
Ço dist li reis : « Al Jhesu e al mien ! »  
De sa main destre l’ad asols e seignet,  
Puis li livrat le bastun e le bref. 

[XXVII]  
Guenes li quens s’en vait a sun ostel,  
De garnemenz se prent a cunreer,  
De ses meillors que il pout recuvrer :  
Esperuns d’or ad en ses piez fermez,  
Ceint Murglies, s’espee, a sun costed ;  
En Tachebrun, sun destrer, est munted ;  
L’estreu li tint sun uncle Guinemer.  
La veïsez tant chevaler plorer,  
Ki tuit li dient : « Tant mare fustes ber !  
En la cort al rei mult i avez ested,  
Noble vassal vos i solt hom clamer.  
Ki ço jugat que doüsez aler  
Par Charlemagne n’ert guariz ne tensez.  
Li quens Rollant nel se doüst penser,  
Que estrait estes de mult grant parented. »  
Enprès li dient : « Sire, car nos menez ! »  
Ço respunt Guenes : « Ne placet Damnedeu !  
Mielz est que sul moerge que tant bon chevaler.  
En dulce France, seignurs, vos en irez :  
De meie part ma muiller saluez,  
E Pinabel, mun ami e mun per,  
E Baldewin, mun filz que vos savez ;  
E lui aidez e pur seignur le tenez. »  
Entret en sa veie, si s’est achiminez.

[XXVIII]  
Guenes chevalchet suz une olive halte,  
Asemblet s’est as sarrazins messages,  
Mais Blancandrins ki envers lu s’atarget ;  
Par grant saveir parolet li uns a l’altre.  
Dist Blancandrins : « Merveilus hom est Charles,  
Ki cunquist Puille e trestute Calabre !  
Vers Engletere passat il la mer salse,  
Ad oes seint Perre en cunquist le chevage :  
Que nus requert ça en la nostre marche ? »  
Guenes respunt : « Itels est sis curages.  
Jamais n’ert hume ki encuntre lui vaille. »

Contemporary:

XXV  
L’empereur lui tend son gant, celui de sa main droite. Mais le comte Ganelon eût voulu n’être pas là. Quand il pensa le prendre, le gant tomba par terre. Les Français disent : « Dieu ! quel signe est-ce là ? De ce message nous viendra une grande perte. — Seigneurs, » dit Ganelon, « vous en entendrez des nouvelles ! »

XXVI  
« Sire, » dit Ganelon, donnez-moi votre congé. Puisqu’il me faut aller, je n’ai que faire de plus m’attarder. » Et le roi dit : « Allez, par le congé de Jésus et par le mien ! » De sa dextre il l’a absous et signé du signe de la croix. Puis il lui délivra le bâton et le bref.

XXVII  
Le comte Ganelon s’en va à son campement. Il se pare des équipements les meilleurs qu’il peut trouver. À ses pieds il a fixé des éperons d’or, il ceint à ses flancs Murgleis, son épée. Sur Tachebrun, son destrier, il monte ; son oncle, Guinemer, lui a tenu l’étrier. Là vous eussiez vu tant de chevaliers pleurer, qui tous lui disent : « C’est grand’pitié de votre prouesse ! En la cour du roi vous fûtes un long temps, et l’on vous y tenait pour un noble vassal. Qui vous marqua pour aller là-bas, Charles lui-même ne pourra le protéger ni le sauver. Non, le comte Roland n’eût pas dû songer à vous : vous êtes issu d’un trop grand lignage. » Puis ils lui disent : « Sire, emmenez-nous ! » Ganelon répond : « Ne plaise au Seigneur Dieu ! Mieux vaut que je meure seul et que vivent tant de bons chevaliers. En douce France, seigneurs, vous rentrerez. De ma part saluez ma femme, et Pinabel, mon ami et mon pair, et Baudoin, mon fils… Donnez-lui votre aide et le tenez pour votre seigneur. » Il entre en sa route et s’achemine.

XXVIII  
Ganelon chevauche sous de hauts oliviers. Il a rejoint les messagers sarrasins et Blancandrin, qui s’attarde avec lui. Tous deux conversent par grande ruse. Blancandrin dit : « C’est un homme merveilleux que Charles ! Il a conquis la Pouille et toute la Calabre ; il a passé la mer salée et gagné à saint Pierre le tribut de l’Angleterre : que vient-il encore chercher ici, dans notre pays ? » Ganelon répond : « Tel est son plaisir. Jamais homme ne le vaudra. »
