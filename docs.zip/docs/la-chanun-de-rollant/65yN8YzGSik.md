---
id: 65yN8YzGSik
title: "La Chançun de Rollant 21"
sidebar_label: "La Chançun de Rollant 21"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/65yN8YzGSik"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La Chançun de Rollant 21

Playlist: https://youtube.com/playlist?list=PLrZFPVQM38MfqznQd5vPrezccjR2_cDcH&si=Qw9EacvwBdnLHt7v

[LXXIV-2]  
A Durendal jo la metrai encuntre ;  
Asez orrez laquele irat desure.  
Françeis murrunt, si a nus s’abandunent ;  
Carles li velz avrat e deol e hunte.  
Jamais en tere ne porterat curone. »

[LXXV]  
De l’altre part est Escremiz de Valterne.  
Sarrazins est, si est sue la tere.   
Devant Marsilie s’escriet en la presse :  
« En Rencesvals irai l’orgoill desfaire.  
Se trois Rollant, n’en porterat la teste,  
Ne Oliver, ki les altres cadelet.  
Li .XII. per tuit sunt jugez a perdre.  
Franceis murrunt e France en ert deserte.  
De bons vassals avrat Carles suffraite. »

[LXXVI]  
D’altre part est uns paiens, Esturganz ;  
Estramariz i est, un soens cumpainz :  
Cil sunt felun, traïtur suduiant.  
Ço dist Marsilie : « Seignurs, venez avant !  
En Rencesvals irez as porz passant,  
Si aiderez a cunduire ma gent. »  
E cil respundent : « A vostre comandement !  
Nus asaldrum Oliver e Rollant ;  
Li 12 per n’avrunt de mort guarant.  
Noz espees sunt bones e trenchant ;  
Nus les feruns vermeilles de chald sanc.  
Franceis murrunt, Carles en ert dolent.  
Tere Majur vos metrum en present.  
Venez i, reis, sil verrez veirement :  
L’empereor vos metrum en present. »

[LXXVII]  
Curant i vint Margariz de Sibilie ;  
Cil tient la tere entre qu’as Cazmarine.  
Pur sa beltet dames li sunt amies :  
Cele nel veit vers lui ne s’esclargisset ;  
Quant ele le veit, ne poet muer ne riet ;  
N’i ad paien de tel chevalerie.  
Vint en la presse, sur les altres s’escriet  
E dist al rei : « Ne vos esmaiez mie !  
En Rencesvals irai Rollant ocire,  
Ne Oliver n’en porterat la vie.  
Li 12 per sunt remés en martirie.  
Veez m’espee, ki d’or est enheldie,  
Si la tramist li amiralz de Primes.  
Jo vos plevis qu’en vermeill sanc ert mise.  
Franceis murrunt e France en ert hunie.  
Carles li velz, a la barbe flurie,  
Jamais n’ert jurn qu’il n’en ait doel e ire.  
Jusqu’a un an avrum France saisie ;  
Gesir porrum el burc de seint Denise. »  
Li reis paiens parfundement l’enclinet.

[LXXIV-2]  
A Durendal jo la metrai encuntre ;  
Asez orrez laquele irat desure.  
Françeis murrunt, si a nus s’abandunent ;  
Carles li velz avrat e deol e hunte.  
Jamais en tere ne porterat curone. »

Contemporary:

[LXXIV-2]  
Contre Durendal je veux l’essayer. Laquelle aura le dessus ? Vous l’entendrez bien dire. Les Français périront, si contre nous ils s’aventurent. Charles le Vieux en aura douleur et honte. Jamais plus sur terre il ne portera la couronne. »

LXXV  
D’autre part voici Escremiz de Valterne. Il est Sarrasin et Valterne est son fief. Devant Marsile il s’écrie dans la foule : « A Roncevaux j’irai, pour abattre l’orgueil. Si j’y trouve Roland, il n’en remportera pas sa tête, ni Olivier, celui qui commande les autres. Les douze pairs sont tous marqués pour périr. Les Français mourront, la France en sera vidée. Charles aura disette de bons vassaux. »

LXXVI  
D’autre part voici un païen, Esturgant ; avec lui Estramariz, un sien compagnon : tous deux félons, traîtres prouvés. Marsile dit : « Seigneurs, avancez ! À Roncevaux vous irez au passage des ports, et vous aiderez à conduire ma gent. » Ils répondent : « Sire, à votre commandement ! Nous attaquerons Olivier et Roland ; contre la mort les douze pairs n’auront pas de garant. Nos épées sont bonnes et tranchantes ; nous les ferons vermeilles de sang chaud. Les Français mourront, Charles en pleurera ; la Terre des Aïeux, nous vous la donnerons. Venez-y, roi ; en vérité, vous le verrez : nous vous donnerons l’empereur lui-même. »

LXXVII  
Tout courant vient Margariz de Séville. Celui-là tient la terre jusqu’aux Cazmarines. Pour sa beauté les dames lui sont amies : pas une qui, à le voir, ne s’épanouisse et ne lui rie. Nul païen n’est si bon chevalier. Il vient dans la foule et par-dessus les autres crie au roi : « N’ayez nulle crainte ! À Roncevaux j’irai tuer Roland ; non plus que lui Olivier ne sauvera sa vie ; les douze pairs sont restés pour leur martyre. Voyez mon épée dont la garde est d’or : c’est l’émir de Primes qui me l’envoya. En un sang vermeil, je vous le jure, elle plongera. Les Français mourront, France en sera honnie. Charles le Vieux, à la barbe fleurie, à chaque jour qu’il vivra, en aura deuil et courroux. Avant un an, nous aurons la France pour butin, nous pourrons coucher au bourg de Saint-Denis. » Le roi païen s’incline devant lui profondément.

[LXXIV-2]  
Contre Durendal je veux l’essayer. Laquelle aura le dessus ? Vous l’entendrez bien dire. Les Français périront, si contre nous ils s’aventurent. Charles le Vieux en aura douleur et honte. Jamais plus sur terre il ne portera la couronne. »
