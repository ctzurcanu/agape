---
id: 5gkzpVQsV3E
title: "Imn morţilor - Hymn to the Dead"
sidebar_label: "Imn morţilor - Hymn to the Dead"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/5gkzpVQsV3E"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Imn morţilor - Hymn to the Dead

Lyrics: Radu Gyr

Morminte dragi, lumină vie,  
sporite-ntruna an de an,  
noi v-auzim curgând sub glie  
ca un şuvoi subpământean.

Ați luminat cu jertfe sfinte  
pământul până-n temelii,  
că țara arde de morminte  
cum arde cerul de făclii.

Ascunse-n lut ca o comoară,  
morminte vechi, morminte noi,  
de vi se pierde urma-n țară,  
v-o regăsim mereu în noi.

De vi s-au smuls şi flori, şi cruce,  
şi dacă locul nu vi-l ştim,  
tot gândul nostru-n veac v-aduce  
îngenunchieri de heruvim.

Morți sfinți în temniți şi prigoane,  
morți sfinți în lupte şi furtuni,  
noi ne-am făcut din voi icoane  
şi vă purtăm pe frunți cununi.

Nu plângem lacrimă de sânge,  
ci ne mândrim cu-atâți eroi.  
Nu, neamul nostru nu vă plânge,  
ci se cuminecă prin voi.

English:

Dear graves, living light,  
increasing year by year,  
we hear you flowing under the grove  
like an underground stream.

You have illuminated the earth   
to its foundations with holy sacrifices,  
that the land burns with graves  
as the sky burns with torches.

Hidden in clay like a treasure,  
old graves, new graves,  
if your trace is lost in the land,  
we will always find you in us.

Even if your flowers and cross have been torn away,  
and if we do not know your place,  
all our thoughts forever bring you  
cherubic kneeling.

Holy dead in dungeons and persecutions,  
holy dead in battles and storms,  
we have made you our icons  
and we wear you as wreaths on our foreheads.

We do not cry tears of blood,  
but we are proud of so many heroes.  
No, our nation does not mourn for you,  
but is comforted by you.
