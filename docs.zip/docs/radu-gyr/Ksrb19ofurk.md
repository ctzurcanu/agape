---
id: Ksrb19ofurk
title: "Avem o țară - We have a country"
sidebar_label: "Avem o țară - We have a country"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Ksrb19ofurk"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Avem o țară - We have a country

Lyrics: Radu Gyr

Avem o ţară unde au stăpânit odată  
Vitejii Daci, bărbaţi nemuritori.  
Şi unde stau de veacuri laolaltă,  
Izvoare, văi şi munţi cu fruntea-n zări.  
   
Avem troiţe sfinte, altare şi icoane  
Şi candeli ard cu mii de pâlpâiri;  
Avem atâtea lacrimi şi prigoane  
Că ne e plin pământul de martiri.  
   
Avem la Putna, Sfânt şi viu cu duhul  
Pe cel ce-a stat Ortodoxiei scut;  
Şi azi de-l vom chema să-nfrâng-apusul,  
Va răsturna cinci veacuri de pământ.  
   
Avem pe Brâncoveanu pildă tare,  
Căci pruncii lui sub sabie-au căzut;  
Ca să păzească fără de schimbare  
Credinţa dreaptă-n care s-au născut.  
   
Avem Ardealul sfânt, pământul răstignirii,  
Cu tunuri sfârtecat de cel viclean;  
Avem ierarhii sfinţi, pe Iancu şi martirii,  
Pe Horia tras pe roată pentru neam.  
   
Azi iaraşi te-au suit vrăjmaşii tăi pe cruce,  
Ardeal cu trei culori împodobit;  
Scriind deasupra vina ta cu sânge,  
Aceea că, Ortodoxia ai iubit.  
   
Avem un Rai de sfinţi în temniţi daţi la moarte  
Şi aruncaţi în groapă neştiuţi;  
Dar astăzi dând pământul la o parte  
Ies moaşte sfinte-n zeghe grea de deţinuţi.  
   
E jertfa lor de veacuri mărturia  
Ce strigă din morminte pân' la noi:  
Să apărăm cu râvnă Ortodoxia  
Şi-acest pământ, de Sfinţi şi de eroi!

English:

We Have a Country  
We have a country that was once  
Populated by the brave Dacians, undying men.1  
And here are plenty of centuries-old  
Springs, hills, and mountains peaking over the clouds.  
   
We have holy crosses, shrines, and icons,  
Candles that burn flickering a thousand times;  
We endured so many tears and oppression  
That beneath our land lie countless Martyrs.  
   
Buried at Putna, lies the great and holy one  
Who stood up, defending the Orthodox faith, like a shield. 2  
Even today, if we were to call him to face the darkness,  
He'll dig his way out from under five centuries-old soil.  
   
We have Brâncoveanu, for us, he's like a parable   
'Cause his sons were all beheaded;  
While defending the unchanged  
Righteous faith in which they were born into.  
   
We have the holy Transylvania, the land of crucifixion,  
Shredded by the cannons of the cunning ones;  
We have the Holy Hierarchs, Iancu and his Martyrs,   
And Horea died a slow, painful, death for the sake of his people.  
   
Today, your enemies have placed you once again on the cross,  
You, beautifully tricolour Transylvanian land;  
Writing your sin in blood, above the cross:  
You're guilty of defending the Orthodoxy.  
   
We have a Haven full of imprisoned Saints, sent to their death,  
Tossed into unmarked graves;  
But today, while digging the soil,  
Holy remains, wearing heavy prison chains, come to light.  
   
Their sacrifice and testimony  
Is the voice that's shouting at us from beyond the grave:  
Let's feverishly defend the Orthodox faith  
And this land that is full of Saints and heroes!
