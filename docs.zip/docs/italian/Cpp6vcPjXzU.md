---
id: Cpp6vcPjXzU
title: "Inno e Marcia Pontificale - Papal Anthem"
sidebar_label: "Inno e Marcia Pontificale - Papal Anthem"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Cpp6vcPjXzU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Inno e Marcia Pontificale - Papal Anthem

Lyrics: Antonio Allegra, 1949  
https://en.wikipedia.org/wiki/Pontifical_Anthem

Roma immortale di Martiri e di Santi,  
Roma immortale accogli i nostri canti:  
Gloria nei cieli a Dio nostro Signore,  
Pace ai Fedeli, di Cristo nell'amore.

A Te veniamo, Angelico Pastore,  
In Te vediamo il mite Redentore,  
Erede Santo di vera e santa Fede;  
Conforto e vanto a chi combatte e crede,

Non prevarranno la forza ed il terrore,  
Ma regneranno la Verità, l'Amore.

Salve Salve Roma, patria eterna di memorie  
Cantano le tue glorie, mille palme e mille altari  
Roma degli Apostoli, Madre guida dei redenti  
Roma luce delle genti, il mondo spera te!

Salve Salve Roma la tue luce non tramonta  
Vince l'odio e l'onta lo splendor di tua beltà  
Roma degli Apostoli, madre guida dei redenti  
Roma luce delle genti, il mondo spera te!

Latin:

O felix Roma – o Roma nobilis:  
Sedes es Petri, qui Romae effudit sanguinem,  
Petri cui claves datae sunt regni caelorum.  
Pontifex, Tu successor es Petri;  
Pontifex, Tu magister es tuos confirmans fratres;  
Pontifex, Tu qui Servus servorum Dei,  
hominumque piscator, pastor es gregis,  
ligans caelum et terram.  
Petre, Tu Christi es Vicarius super terram,  
rupes inter fluctus, Tu es pharus in tenebris;  
Tu pacis es vindex, Tu es unitatis custos,  
vigil libertatis defensor; in Te potestas.

Tu Pontifex, firma es petra, et super petram  
hanc aedificata est Ecclesia Dei.

Petre, Tu Christi es Vicarius super terram,  
rupes inter fluctus, Tu es pharus in tenebris;  
Tu pacis es vindex, Tu es unitatis custos,  
vigil libertatis defensor; in Te potestas.

O felix Roma – O Roma nobilis.  
O felix Roma – O Roma nobilis.

English:

O happy Rome - O noble Rome  
O happy Rome - O noble Rome

You are the seat of Peter, who shed his blood in Rome,  
Peter, to whom the keys of the kingdom of heaven were given.  
Pontiff, You are the successor of Peter;

Pontiff, You are the teacher, you confirm your brethren;  
Pontiff, You who are the Servant of the servants of God,  
and fisher of men, are the shepherd of the flock,  
linking heaven and earth.

Pontiff, You are the vicar of Christ on earth,  
a rock amidst the waves, You are a beacon in the darkness;  
You are the defender of peace, You are the guardian of unity,  
watchful defender of liberty; in You is the authority.

Pontiff, you are the unshakable rock, and on this rock  
was built the Church of God.

Pontiff, You are the vicar of Christ on earth,  
a rock amidst the waves, You are a beacon in the darkness;  
You are the defender of peace, You are the guardian of unity,  
watchful defender of liberty; in You is the authority.

O happy Rome - O noble Rome  
O happy Rome - O noble Rome
