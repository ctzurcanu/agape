---
id: MGfWQD-MH_w
title: "Salmo svizzero - Swiss Psalm"
sidebar_label: "Salmo svizzero - Swiss Psalm"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/MGfWQD-MH_w"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Salmo svizzero - Swiss Psalm

Lyrics: https://en.wikipedia.org/wiki/Swiss_Psalm

Quando bionda aurora  
il mattin c'indora  
l'alma mia t'adora re del ciel!  
Quando l'alpe già rosseggia  
a pregare allor t'atteggia;  
in favor del patrio suol,  
in favor del patrio suol,  
cittadino Dio lo vuol,  
cittadino Dio, si Dio lo vuol.

Se di stelle è un giubilo  
la celeste sfera  
Te ritrovo a sera o Signor!  
Nella notte silenziosa  
l'alma mia in Te riposa:  
libertà, concordia, amor,  
libertà, concordia, amor,  
all'Elvezia serba ognor,  
all'Elvezia serba ognor.

Se di nubi un velo  
m'asconde il tuo cielo  
pel tuo raggio anelo Dio d'amore!  
Fuga o sole quei vapori  
e mi rendi i tuoi favori:  
di mia patria deh! Pietà  
di mia patria deh! Pietà  
brilla, o sol di verità,  
brilla sol, o sol di verità!

Quando rugge e strepita  
impetuoso il nembo  
m'è ostel tuo grembo o Signor!  
In te fido Onnipossente  
deh, proteggi nostra gente;  
Libertà, concordia, amor,  
Libertà, concordia, amor,  
all'Elvezia serba ognor  
all'Elvezia serba ognor.

English:

When the blond dawn  
gilds the morning  
my soul adores you, king of heaven!  
When the Alps are already red  
then you set yourself to pray;  
in favor of the native land,  
in favor of the native land,  
God wants you to be a citizen,  
God wants you to be a citizen, yes God wants you to be.

If the stars are a jubilation  
the celestial sphere  
I find you again in the evening, O Lord!  
In the silent night  
my soul rests in you:  
freedom, harmony, love,  
freedom, harmony, love,  
for Helvetia it always keeps,  
for Helvetia it always keeps.

If a veil of clouds  
hides your sky from me  
for your ray I yearn, God of love!  
Flee, O sun, those vapors  
and give me back your favors:  
of my country, oh! Have mercy  
on my country, oh! Mercy  
shines, oh sun of truth,  
shines, oh sun of truth!

When the storm roars and thunders  
the impetuous storm  
is my shelter, oh Lord!  
In you, faithful Almighty  
ah, protect our people;  
Freedom, harmony, love,  
Freedom, harmony, love,  
for Helvetia always  
for Helvetia always.
