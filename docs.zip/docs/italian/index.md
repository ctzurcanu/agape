---
id: PLrZFPVQM38MfMRlzqhfm6Qrgrt4KDE7b1
title: "Italian"
sidebar_label: "Italian"
---

# Italian

This is the landing page for the playlist "Italian".

## Videos in this Playlist

- [Paradiso - Heaven 01](/agape/italian/dex7_B89JtM)
- [Inno e Marcia Pontificale - Papal Anthem](/agape/italian/Cpp6vcPjXzU)
- [Salmo svizzero - Swiss Psalm](/agape/italian/MGfWQD-MH_w)

