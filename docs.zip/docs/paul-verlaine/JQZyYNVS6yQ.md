---
id: JQZyYNVS6yQ
title: "Chanson d’automne - Autumn Song"
sidebar_label: "Chanson d’automne - Autumn Song"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/JQZyYNVS6yQ"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Chanson d’automne - Autumn Song

Paroles: Paul Verlaine

Les sanglots longs  
Des violons  
De l’automne  
Blessent mon coeur  
D’une langueur  
Monotone.

Tout suffocant  
Et blême, quand  
Sonne l’heure,  
Je me souviens  
Des jours anciens  
Et je pleure

Et je m’en vais  
Au vent mauvais  
Qui m’emporte  
Deçà, delà,  
Pareil à la  
Feuille morte.

English:

The long sobs  
of the violins  
of autumn  
wound my heart  
with a  
monotonous languor.

All suffocating  
and pale, when  
the hour strikes,  
I remember  
the old days  
and I cry

And I go away  
In the bad wind  
Which carries me  
here and there,  
Like a  
dead leaf.
