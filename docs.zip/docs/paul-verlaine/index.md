---
id: PLrZFPVQM38Mcc4jmEt6ZVYIGe0w9Zh-M8
title: "Paul Verlaine"
sidebar_label: "Paul Verlaine"
---

# Paul Verlaine

This is the landing page for the playlist "Paul Verlaine".

## Videos in this Playlist

- [Chanson d’automne - Autumn Song](/agape/paul-verlaine/JQZyYNVS6yQ)

