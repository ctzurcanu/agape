---
id: QkKXgbepHMU
title: "Scene 17"
sidebar_label: "Scene 17"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/QkKXgbepHMU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 17

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

However, it was a question of deciding how this attack which had so happily begun would be continued against the English.  
The chiefs, unconcerned about letting themselves be led by a country girl or sharing with her the glory of success, met in secret to discuss the plan to adopt.  
Joan presented herself to the council; and as the chancellor of the Duke of Orléans sought to conceal from her the decisions that had been taken:  
“Say what you have concluded and said,” she cried, indignant at these subterfuges; “I can conceal something greater!” she added:  
"You have been in your counsel and I have been in mine, and believe that the counsel of God will be fulfilled and will stand firm, and that yours will perish. Get up early tomorrow morning, for I will have much to do, more than I ever had."
