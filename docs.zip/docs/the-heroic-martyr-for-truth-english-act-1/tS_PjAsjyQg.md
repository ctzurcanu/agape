---
id: tS_PjAsjyQg
title: "Scene 29"
sidebar_label: "Scene 29"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/tS_PjAsjyQg"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 29

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

This retreat imposed by the cowardice of Charles VII and the jealousy of the courtiers was a terrible attack on Joan's prestige.  
From now on, in everyone's eyes, she ceased to be invincible.  
The holy girl seems to have understood this, because, before leaving Paris, she went to place as an offering, on the altar of Saint-Denis, her hitherto victorious weapons. She prayed for a long time. Perhaps at that moment, she had a presentiment that her glorious mission was over, and that painful trials were ahead for her. Nevertheless, she submitted and, with death in her soul, followed the King to Gien. The army was disbanded. The people of the court thought that we had fought enough. It was important, moreover, for their jealousy to put an end to Joan's success.
