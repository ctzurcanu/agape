---
id: qsm5GOy4xHY
title: "Scene 40"
sidebar_label: "Scene 40"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/qsm5GOy4xHY"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 40

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

On May 30, Joan confessed and received communion. Then she was taken to the place of execution. When she was at the foot of the scaffold, she knelt, invoking God, the Virgin, and the Saints; then, turning to the bishop, to the judges, to her enemies, she devoutly begged them to have masses said for her soul. She climbed the stake, asked for a cross, and died in the flames while pronouncing the name of Jesus. Everyone was crying, the executioners themselves and the judges.  
“We are lost, we have burned a saint!” cried the English as they dispersed.

  
O JOAN, WITHOUT SEPULCHER AND WITHOUT PORTRAIT,   
YOU WHO KNEW THAT THE TOMB OF HEROES   
IS THE HEART OF THE LIVING...  
André MALRAUX

  
ONLY PROVABLE VOLUNTEERS CAN RAISE JOAN  
AND OTHER HEROES BACK FROM THEIR GRAVES  
Anon
