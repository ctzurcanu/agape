---
id: 8xu-VjJEf60
title: "Scene 25"
sidebar_label: "Scene 25"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/8xu-VjJEf60"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 25

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

On July 16, the King entered the city of Reims at the head of his troops. The next day, the coronation ceremony took place in the cathedral, amid a great concourse of lords and people. Joan stood behind the King, her standard in her hand; "this standard had suffered, it was right that it should be in the spotlight."

When Charles VII had received the sacred anointing and the crown from the archbishop, Regnault of Chartres, Joan threw herself at his feet, kissing his knees and weeping hot tears.  
“O kind Sire,” she said, “now is fulfilled the pleasure of God who wanted me to bring you to your city of Reims to receive your holy coronation, showing that you are true king, and that the kingdom of France must belong to you !”  
“All those who saw it at that moment,” says the old chronicle, “believed better than ever that it was something from God.”  
“O good and devout people,” cried the holy girl, seeing the enthusiasm of the crowd around the King, “if I must die, I would be very happy if they buried me here!”
