---
id: eEtkuxif6dE
title: "Scene 13"
sidebar_label: "Scene 13"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/eEtkuxif6dE"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 13

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

However, we received no news from Blois. Dunois, worried, left to hasten the arrival of help. It was time. The Archbishop of Reims, Regnault de Chartres, Chancellor of the King, reconsidering the decisions taken, was going to send the troops back to their garrisons. Dunois obtained to take them to Orléans.  
On Wednesday, May 4, in the morning, Joan, surrounded by all the clergy of the city and followed by a large part of the population, left Orléans; through the English bastilles, she advanced in a grand procession to meet the small army of Dunois, which passed under the protection of the priests and a girl, without the English daring to attack it.
