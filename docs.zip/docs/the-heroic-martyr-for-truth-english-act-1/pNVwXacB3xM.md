---
id: pNVwXacB3xM
title: "Scene 3"
sidebar_label: "Scene 3"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/pNVwXacB3xM"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 3

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

From that day on, Joan's piety became even more ardent; The child willingly separated herself from her companions to meditate, and heavenly voices were heard, speaking to her of her mission. They were, she said, the voices of her Saints. Often these voices were accompanied by visions; Saint Catherine and Saint Marguerite appeared to her.  
“I saw them with the eyes of my body,” she later told her judges, “and when they left me I cried; I would have liked them to take me with them.”  
The child grew up, his spirit exalted by his visions and keeping deep in her heart the secret of his celestial conversations. No one suspected what was happening inside her, not even the priest who heard her confession.

At the beginning of the year 1428, Joan was eighteen years old, and the voices became more urgent.  
“The danger is great, Joan has to leave to help the King and save the kingdom.”  
Her Saints ordered her to go find the Lord of Baudricourt, Lord of Vaucouleurs, and to ask him for an escort who would take her to the Dauphin.  
Not daring to share her plan with her parents, Joan went to Burey to find her uncle Laxart and begged him to take her to Vaucouleurs. The ardor of his prayer shook the timidity of the fearful peasant; he promised to accompany her.
