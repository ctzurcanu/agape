---
id: VTwasT4-zHE
title: "Scene 20"
sidebar_label: "Scene 20"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/VTwasT4-zHE"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 20

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

The news of the deliverance of Orléans spread far and wide, attesting to all the divinity of Joan's mission.  
The holy girl, avoiding the recognition of the Orléanais, returned hastily to Chinon. She wanted, taking advantage of the enthusiasm raised around her, to leave immediately for Reims, taking the King with her in order to have him crowned. The King welcomed her with great honors, but refused to follow her. He accepted the devotion of this heroic girl, but he understood that her generous efforts would in no way disturb the cowardly inertia of her royal existence.  
It was decided that Joan would attack the places that the English still held on the banks of the Loire.
