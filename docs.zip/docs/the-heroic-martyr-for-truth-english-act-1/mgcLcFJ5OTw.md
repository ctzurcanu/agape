---
id: mgcLcFJ5OTw
title: "Scene 22"
sidebar_label: "Scene 22"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/mgcLcFJ5OTw"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 22

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

On June 18, Joan reached, near Patay, the English army led by Talbot and Fastolf.  
“In the name of God we must fight them,” she said; "even if they hang by the clouds, we will have them, because God sends them to us so that we can punish them. Our kind King will have today the greatest victory that he ever had."  
She wanted to go to the vanguard, but she was held back, and La Hire was charged with attacking the English to force them to turn around, in order to give the French troops time to arrive. But La Hire's attack was so impetuous that everything gave way before him. When Joan ran with her men-at-arms, the English were retreating in disorder. Their retreat became a rout.   
Talbot was taken prisoner.  
"You didn’t think this morning that this would happen to you," said the Duke of Alençon.  
"It is the fortune of war," replied Talbot.
