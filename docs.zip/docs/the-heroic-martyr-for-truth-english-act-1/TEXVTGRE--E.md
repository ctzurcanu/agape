---
id: TEXVTGRE--E
title: "Scene 24"
sidebar_label: "Scene 24"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/TEXVTGRE--E"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 24

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

The soldiers, English and Burgundians, who were garrisoning Troyes were able to leave the city with everything they owned. What they had were mainly prisoners, French people. When drawing up the capitulation, nothing had been stipulated in favor of these unfortunate people. But when the English left the city with their garroted prisoners, Joan threw herself across the road.  
“In God’s name, you will not take them!” she cried.  
She demanded that the prisoners be handed over to her, and that their ransom be paid by the King.
