---
id: PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv
title: "The Heroic Martyr for Truth. English. Act 1"
sidebar_label: "The Heroic Martyr for Truth. English. Act 1"
---

# The Heroic Martyr for Truth. English. Act 1

This is the landing page for the playlist "The Heroic Martyr for Truth. English. Act 1".

## Videos in this Playlist

- [Foreword](/agape/the-heroic-martyr-for-truth-english-act-1/vVMf3Y-GOXk)
- [Scene 1](/agape/the-heroic-martyr-for-truth-english-act-1/l3FFl5gJy1Y)
- [Scene 2](/agape/the-heroic-martyr-for-truth-english-act-1/-0pezS17Glg)
- [Scene 3](/agape/the-heroic-martyr-for-truth-english-act-1/pNVwXacB3xM)
- [Scene 4](/agape/the-heroic-martyr-for-truth-english-act-1/RfnNWnD1LM8)
- [Scene 5](/agape/the-heroic-martyr-for-truth-english-act-1/7vm1PO_uYMA)
- [Scene 6](/agape/the-heroic-martyr-for-truth-english-act-1/XArMWCtn2kA)
- [Scene 7](/agape/the-heroic-martyr-for-truth-english-act-1/MUnnCL3jIcE)
- [Scene 8](/agape/the-heroic-martyr-for-truth-english-act-1/EQV8cwhIptU)
- [Scene 9](/agape/the-heroic-martyr-for-truth-english-act-1/5e3Q_zKzxxA)
- [Scene 10](/agape/the-heroic-martyr-for-truth-english-act-1/CbkAbiCMCJU)
- [Scene 11](/agape/the-heroic-martyr-for-truth-english-act-1/Sbw7FrLUHhw)
- [Scene 12](/agape/the-heroic-martyr-for-truth-english-act-1/0G9vSdPYH8c)
- [Scene 13](/agape/the-heroic-martyr-for-truth-english-act-1/eEtkuxif6dE)
- [Scene 14](/agape/the-heroic-martyr-for-truth-english-act-1/1_3-mHLA00)
- [Scene 15](/agape/the-heroic-martyr-for-truth-english-act-1/2WUCPdro0Ok)
- [Scene 16](/agape/the-heroic-martyr-for-truth-english-act-1/BNE5u-AN_JU)
- [Scene 17](/agape/the-heroic-martyr-for-truth-english-act-1/QkKXgbepHMU)
- [Scene 18](/agape/the-heroic-martyr-for-truth-english-act-1/q-_yEWwtDZk)
- [Scene 19](/agape/the-heroic-martyr-for-truth-english-act-1/j7bklw76ayM)
- [Scene 20](/agape/the-heroic-martyr-for-truth-english-act-1/VTwasT4-zHE)
- [Scene 21](/agape/the-heroic-martyr-for-truth-english-act-1/aQk9mJBFErY)
- [Scene 22](/agape/the-heroic-martyr-for-truth-english-act-1/mgcLcFJ5OTw)
- [Scene 23](/agape/the-heroic-martyr-for-truth-english-act-1/dLged6qgbsU)
- [Scene 24](/agape/the-heroic-martyr-for-truth-english-act-1/TEXVTGRE--E)
- [Scene 25](/agape/the-heroic-martyr-for-truth-english-act-1/8xu-VjJEf60)
- [Scene 27](/agape/the-heroic-martyr-for-truth-english-act-1/-76Kz0YkISs)
- [Scene 28](/agape/the-heroic-martyr-for-truth-english-act-1/eXou5ixeGLI)
- [Scene 29](/agape/the-heroic-martyr-for-truth-english-act-1/tS_PjAsjyQg)
- [Scene 30](/agape/the-heroic-martyr-for-truth-english-act-1/W1sIBUdOS7Y)
- [Scene 31](/agape/the-heroic-martyr-for-truth-english-act-1/Oj8WkEsW2oo)
- [Scene 32](/agape/the-heroic-martyr-for-truth-english-act-1/-GDwm1Up3GE)
- [Scene 33](/agape/the-heroic-martyr-for-truth-english-act-1/v5FC8-6uYs0)
- [Scene 34](/agape/the-heroic-martyr-for-truth-english-act-1/c9rpNTSs09g)
- [Scene 35](/agape/the-heroic-martyr-for-truth-english-act-1/MyblAFZB6kM)
- [Scene 36](/agape/the-heroic-martyr-for-truth-english-act-1/HQzWAoBckrU)
- [Scene 37](/agape/the-heroic-martyr-for-truth-english-act-1/0nKYIV8Xuv0)
- [Scene 38](/agape/the-heroic-martyr-for-truth-english-act-1/SD8wJSrxs2g)
- [Scene 39](/agape/the-heroic-martyr-for-truth-english-act-1/leTNrj42slQ)
- [Scene 40](/agape/the-heroic-martyr-for-truth-english-act-1/qsm5GOy4xHY)
- [Joan's Holocaust](/agape/the-heroic-martyr-for-truth-english-act-1/3dWOd__ZJNM)

