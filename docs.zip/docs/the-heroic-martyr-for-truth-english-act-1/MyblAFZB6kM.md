---
id: MyblAFZB6kM
title: "Scene 35"
sidebar_label: "Scene 35"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/MyblAFZB6kM"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 35

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

Locked in the prison of Rouen Castle, she was guarded day and night by soldiers, from whom she had to endure insults and even brutality, her chains not allowing her to defend herself.   
Meanwhile, a tribunal, at the discretion of the English party and chaired by Cauchon, bishop of Beauvais, was investigating her trial. To the insidious questions of her judges, the poor and holy girl, without support and without advice, could only oppose the righteousness and simplicity of her heart, only the purity of her intentions.  
“I come from God,” she said; “I have no use here; send me back to God from whom I came.”
