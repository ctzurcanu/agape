---
id: HQzWAoBckrU
title: "Scene 36"
sidebar_label: "Scene 36"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/HQzWAoBckrU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 36

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

However, there remained one help for her: that of her saints. They alone had not abandoned her. Joan always received advice from her celestial voices; Saint Marguerite and Saint Catherine appeared to her in the silence of the night, comforting her with good words. And as Bishop Cauchon asked Joan what they said to her:  
“They woke me up,” she replied, “I folded my hands and asked them to give me advice; they said to me: ‘Ask Our Lord.’”  
“And what else did they say?”  
“To answer you boldly.”  
And as the bishop pressed her with questions:  
"I can't say everything; I'm more afraid of saying something that displeases them than I am of not responding to you."
