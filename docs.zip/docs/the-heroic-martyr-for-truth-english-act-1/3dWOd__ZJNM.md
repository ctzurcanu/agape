---
id: 3dWOd__ZJNM
title: "Joan's Holocaust"
sidebar_label: "Joan's Holocaust"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/3dWOd__ZJNM"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Joan's Holocaust

Joan's Holocaust

[Verse 1]  
Flames licking my armor  
Iron will howling defiance  
Tied to a stake for glory  
My faith won’t be silenced

[Verse 2]  
Vision in the smoke dancing  
Voices guiding me higher  
Swords clashing in memories  
Feet burning on sacred pyre

[Chorus]  
Blaze of faith consumed me whole  
Saint and soldier heart of gold  
Martyr’s fire crucible bold  
For Christ for kingdom burning soul

[Verse 3]  
Judges sneering in shadow  
Laughing at my falling tears  
Their chains won't break my spirit  
Flames are whispers to my ears

[Verse 4]  
Symbols of the holy shining  
Pain like thunder in tune  
Eternal light is calling  
Ashes lift toward the moon

[Chorus]  
Blaze of faith consumed me whole  
Saint and soldier heart of gold  
Martyr’s fire crucible bold  
For Christ for kingdom burning soul

[Verse 4 bis]  
Symbols of the holy shining  
Pain like thunder in tune  
Eternal light is calling  
Ashes lift toward the moon

[Chorus]  
Blaze of faith consumed me whole  
Saint and soldier heart of gold  
Martyr’s fire crucible bold  
For Christ for kingdom burning soul
