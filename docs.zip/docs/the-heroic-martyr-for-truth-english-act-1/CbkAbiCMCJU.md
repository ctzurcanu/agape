---
id: CbkAbiCMCJU
title: "Scene 10"
sidebar_label: "Scene 10"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/CbkAbiCMCJU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 10

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

The army and the convoy arrived in front of Chécy, two leagues above Orléans.  
It was a matter of crossing the Loire; the boats were missing. Joan was transported to the other bank with part of her escort and the convoy of supplies. The rest of the troops had to return to Blois, to return to Orléans via Beauce.
