---
id: W1sIBUdOS7Y
title: "Scene 30"
sidebar_label: "Scene 30"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/W1sIBUdOS7Y"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 30

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

But Joan could not resign herself to the inaction that they wanted to impose on her. Abandoned without help during the siege of La Charité, she understood that she now had no hope of help from Charles VII. At the end of March (1430), without taking leave of the King, she left to join the French partisans who were skirmishing against the English at Lagny.  
Now, during Easter week, as she had just heard mass and taken communion in the church Saint-Jacques de Compiègne, she withdrew against a pillar of the church and began to cry. The townspeople and children were surrounding her - she said to them:  
"My children and dear friends, I tell you that I have been sold and betrayed, and that soon I will be delivered to death. I beg you to pray for me, because I will never again have the power to do any service to the King and the Kingdom of France."
