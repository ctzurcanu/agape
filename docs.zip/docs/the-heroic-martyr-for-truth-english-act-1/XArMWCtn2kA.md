---
id: XArMWCtn2kA
title: "Scene 6"
sidebar_label: "Scene 6"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/XArMWCtn2kA"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 6

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

Chinon was far away and the journey perilous. The English and Burgundian partisans held the country, and the small troop was obliged to pass through certain bridges which the enemy occupied. You had to walk at night and hide during the day. Joan's companions, frightened, talked of returning to Vaucouleurs.  
"Fear nothing, she told them, God gives me my way, my brothers in paradise tell me what I have to do."  
On the twelfth day, Joan arrived in Chinon with her companions. From the hamlet of Saint Catherine, she had sent a letter to the King announcing her arrival.  
The court of Charles VII was far from unanimous on the reception which should be given to her. La Trémouille, the favorite of the day, jealous of the ascendancy she had gained over his master, was determined to remove any influence capable of tearing Charles from his torpor. For two days, the council discussed whether the Dauphin would receive the inspired young woman.
