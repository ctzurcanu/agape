---
id: Sbw7FrLUHhw
title: "Scene 11"
sidebar_label: "Scene 11"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Sbw7FrLUHhw"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 11

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

Joan had said to Dunois, who had come to meet her:  
"I bring you the best help, the help of the King of Heaven; it does not come from me, but from God himself, who, at the request of Saint Louis and Charlemagne, had pity on the city of Orléans."  
At eight o'clock in the evening, Joan entered Orléans. The people rushed to meet her. By the light of the torches, she crossed the town in the middle of a crowd so dense that she had difficulty making her way. Everyone, men, women, and children, wanted to approach her or at least touch her horse, showing "such great joy as if they had seen God descend among them."  
"They felt, says the headquarters diary, comforted and as if relieved by the divine virtue of this simple girl."   
Joan spoke to them gently, promising to deliver them.
