---
id: v5FC8-6uYs0
title: "Scene 33"
sidebar_label: "Scene 33"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/v5FC8-6uYs0"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 33

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

Joan was taken to Margny amid the cries of joy of her enemies. The English and Burgundian chiefs and the Duke of Burgundy himself came running to see the witch. They found themselves face to face with an eighteen-year-old girl. Joan was the prisoner of John of Luxembourg, a gentleman without fortune, who only wanted to profit from her capture. The king of France made no offer to ransom the captive.
