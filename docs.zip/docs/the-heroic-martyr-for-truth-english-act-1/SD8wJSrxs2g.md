---
id: SD8wJSrxs2g
title: "Scene 38"
sidebar_label: "Scene 38"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/SD8wJSrxs2g"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 38

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

Joan, treated as a heretic, was deprived of the aid of religion. The sacraments were forbidden to her.  
Returning from the interrogation and passing with her escort in front of a chapel whose door was closed, she asked the monk who accompanied her if the body of Jesus Christ was there, requesting that she be allowed to kneel for a moment in front of the door to pray. Which she did. Now, Cauchon, having known this, threatened the monk with the most rigorous punishments if such a thing happened again.
