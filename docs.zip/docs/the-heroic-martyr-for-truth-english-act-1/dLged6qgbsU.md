---
id: dLged6qgbsU
title: "Scene 23"
sidebar_label: "Scene 23"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/dLged6qgbsU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 23

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

The English lost four thousand dead. Two hundred prisoners were taken from them. Only those who could pay a ransom were kept at mercy; the others were killed mercilessly.  
One of them was beaten so brutally in front of Joan that she jumped from her horse to help him. She lifted the poor man's head, brought a priest to him, consoled him, and helped him die.  
Her heart was as pitiful for the wounded English as for those of his party  
Besides, she defied blows, and was often wounded, but never wanted to use her sword; her standard was her only weapon.
