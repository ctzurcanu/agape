---
id: 7vm1PO_uYMA
title: "Scene 5"
sidebar_label: "Scene 5"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/7vm1PO_uYMA"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 5

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

But this time she stayed in Vaucouleurs.  
Soon the only noise in the country was about this young girl, who was going around saying loudly that she would save the kingdom, that she must be taken to the Dauphin, that God wanted it.  
“I will go,” she said, “even if I wear out my legs up to my knees.”  
The people, of simple hearts, moved by her faith, believed in her. A squire, Jean de Metz, won by the confidence of the crowd, offered to take her to Chinon, where Charles VII was. The poor people, uniting their miseries, joined together to clothe and arm the little peasant girl. They bought her a horse, and on the appointed day she set out with her weak escort.  
“Go. And come what may!” Baudricourt threw her.  
"God bless you!" cried the poor people, and the women wept as they saw her go away.
