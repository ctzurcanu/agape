---
id: MUnnCL3jIcE
title: "Scene 7"
sidebar_label: "Scene 7"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/MUnnCL3jIcE"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 7

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

At that moment, news arrived from Orléans so disturbing that Joan's supporters managed to ensure that this supreme chance of salvation was not ruled out. In the evening, by the light of fifty torches, in the great hall of the castle, where all the lords of the court crowded together, Joan was introduced. She had never seen the King. Charles VII, in order not to attract her attention, wore a less luxurious costume than those of his courtiers. At first glance, she distinguished him among all, and kneeling before him:  
“God bless you, kind Dauphin!” she says  
"I am not the King," he replied, “this is the King.” And he designated a lord for him.  
"You are, kind prince, and no other; the King of Heaven sends you word through me that you will be crowned."  
And approaching the object of her mission, she told him that God had sent her to help and succor; she asked that he give her an army, promising to lift the siege of Orléans and take him to Reims.  
The Dauphin remained hesitant. This girl could be a witch. He sent her to Poitiers to submit to the examination of doctors and ecclesiastics.
