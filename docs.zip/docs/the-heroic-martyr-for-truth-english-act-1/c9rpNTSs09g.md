---
id: c9rpNTSs09g
title: "Scene 34"
sidebar_label: "Scene 34"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/c9rpNTSs09g"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 34

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

Joan was locked up in the Château de Beaurevoir. But knowing that the English wanted to buy her from the Lord of Luxembourg and also that the siege of Compiègne was advancing and that the city was going to succumb, one night she let herself slide from the top of the keep, using straps that broke. She fell at the foot of the wall and remained there as if dead.   
Joan, however, recovers from her fall. A crueler end was in store for her.  
At the end of November, she was handed over to the English for a sum of ten thousand pounds.
