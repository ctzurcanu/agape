---
id: leTNrj42slQ
title: "Scene 39"
sidebar_label: "Scene 39"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/leTNrj42slQ"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 39

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

However, the trial moved too slowly for the English.  
“Judges, you don’t earn your money!” they shouted to the members of the court.  
“I have come to the King of France,” said Joan, “from God, from the Virgin Mary, the saints and the victorious Church above; to that Church I submit myself, my works, what I have done or to do. You say that you are my judges, be careful about what you do, because truly I am sent from God and you are putting yourself in great danger!”  
The holy heroine was condemned, as a heretic, relapse, apostate, and idolater, to be burned alive on the Place du Vieux-Marché in Rouen.  
“Bishop, I die because of you!” she said, addressing Cauchon.
