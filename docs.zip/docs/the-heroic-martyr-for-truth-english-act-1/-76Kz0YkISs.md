---
id: -76Kz0YkISs
title: "Scene 27"
sidebar_label: "Scene 27"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/-76Kz0YkISs"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 27

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

There was nothing like the eagerness of the people to touch Joan. It was about who would kiss her hands or her clothes, who would touch her. The little children were presented to her so that she could bless them, the rosaries, the holy images so that she could sanctify them by touching them with her hand. And the humble girl gracefully rejected these signs of adoration, gently joking with the poor people about their credulity in her power. But she asked on what day and at what time the children of the poor received communion, to go and commune with them.  
Her pity was for all those who suffered, but her tenderness was all for the small and humble. She felt like their sister, knowing that she was born to one of them. When later she was criticized for having tolerated this adoration of the crowd, Joan will simply respond:  
"Many people saw me willingly, and they kissed my hands without my permission, but the poor people came willingly to me because I did not displease them."
