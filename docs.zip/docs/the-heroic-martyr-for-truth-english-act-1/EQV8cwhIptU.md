---
id: EQV8cwhIptU
title: "Scene 8"
sidebar_label: "Scene 8"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/EQV8cwhIptU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 8

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

For three weeks she was tortured with insidious questions.  
“There is more in God's book than in yours,” she replied; “I know neither A nor B, but I come from the King of Heaven.”  
As it was objected to her that God, to deliver France, did not need armed men, she stood up suddenly:  
“The men will fight, God will give the victory.”  
There as in Vaucouleurs, the people declared themselves in her favor, they considered her holy and inspired. The doctors and the powerful had to give in to the enthusiasm of the crowd.
