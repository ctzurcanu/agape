---
id: RfnNWnD1LM8
title: "Scene 4"
sidebar_label: "Scene 4"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/RfnNWnD1LM8"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 4

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

Baudricourt's reception was brutal. Joan told him "that a message came from God, that God would command the Dauphin to behave well because the Lord would give him help before the middle of Lent"; she added  
"that God wanted the Dauphin to become King; that he would do so in spite of his enemies, and that she herself would lead him to the coronation".  
"This girl is crazy, said Baudricourt, let’s take her back to her father to give her a good pair of slaps."  
Joan returned to Domrémy. But pressed again by her voices, she returned to Vaucouleurs and saw the Lord of Baudricourt again without obtaining a better welcome.
