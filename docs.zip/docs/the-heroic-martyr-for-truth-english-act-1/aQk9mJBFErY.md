---
id: aQk9mJBFErY
title: "Scene 21"
sidebar_label: "Scene 21"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/aQk9mJBFErY"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 21

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

On June 11, the French occupied the suburbs of Jargeau. The next day, first thing in the morning, Joan gave the signal for combat. The Duke of Alençon wanted to delay the assault:  
"Forward, kind duke, to the attack! Do not doubt, it is the hour when it pleases God; work, and God will work."  
She herself climbed the ladder; she was knocked down by a stone which hit her on the head. But she got up, shouting to her people:  
"Friends, up! up! Our sire has condemned the English; they are ours at this hour; have good courage!"  
The ramparts were scaled. The English, pursued as far as the town bridge, were caught and killed. Suffolk was taken prisoner.   
On the 15th, the French took control of the Meung bridge;   
on the 16th, they laid siege to Beaugency;   
on the 17th, the city capitulated.
