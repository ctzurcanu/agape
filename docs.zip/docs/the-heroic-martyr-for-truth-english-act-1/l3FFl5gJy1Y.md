---
id: l3FFl5gJy1Y
title: "Scene 1"
sidebar_label: "Scene 1"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/l3FFl5gJy1Y"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 1

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

Joan was born on January 6, 1412, in Domrémy, a small village in Lorraine, dependent on the bailiwick of Chaumont, which came under the crown of France.  
Her father's name was Jacques d'Arc, and her mother was Isabelle Romée; they were honest people, simple laborers living from their work.  
Joan was raised with her brothers and her sister in a small house that can still be seen in Domrémy, so close to the church that its garden touches the cemetery.  
The child grows up there under the eye of God.  
She was sweet, simple, and straight. Everyone loved her because they knew she was charitable and the best girl in her village. Diligent at work, she helped her family in their tasks, during the day leading the animals to pasture, or taking part in her father's hard work, in the evening spending time with her mother and assisting her in the care of the household.
