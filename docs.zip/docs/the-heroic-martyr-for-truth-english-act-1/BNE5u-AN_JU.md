---
id: BNE5u-AN_JU
title: "Scene 16"
sidebar_label: "Scene 16"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/BNE5u-AN_JU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 16

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

Joan returned victorious to Orléans. But as, in the joy of her success, she returned towards the city, crossing the battlefield, she felt her poor heart melt with pity at the sight of the wounded and the killed, and she began to cry, thinking that they had died without confession. And she said  
“that she had never seen the blood of France being spilled before. her hair stood on end.”
