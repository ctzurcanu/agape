---
id: -0pezS17Glg
title: "Scene 2"
sidebar_label: "Scene 2"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/-0pezS17Glg"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Scene 2

The Heroic Martyr for Truth: Act 1   
https://www.youtube.com/playlist?list=PLrZFPVQM38MeC-ecXR6xoUe730yGpoLlv 

One summer day, when she was thirteen years old, as it was noon, she heard a voice in her father's garden; a great light broke out, and the archangel Saint Michael appeared to her. He told her to be good and to attend church. Then, telling her of the great pity that was in the kingdom of France, he announced to her that she would go to the aid of the Dauphin and that she would take him to Reims for coronation.  
"Sir, I am only a poor girl, I cannot ride or lead men-at-arms."  
"God will help you", replied the archangel.  
And the upset child remained crying.
