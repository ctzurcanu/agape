---
id: HDJgnDDreHE
title: "Szene 12"
sidebar_label: "Szene 12"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/HDJgnDDreHE"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 12

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Sie bat darum, in eine Kirche gebracht zu werden, denn sie wollte vor allem Gott danken.

Wie ein alter Mann zu Johanna sagte, als er über die Engländer sprach:

„Meine Tochter, sie sind stark und sehr beständig, und es wird eine große Herausforderung sein, sie zu vertreiben“, antwortete sie: „Für die Macht Gottes ist nichts unmöglich.“

Und tatsächlich überzeugte ihr Selbstvertrauen alle um sie herum. Die Einwohner von Orléans, die am Vortag noch so ängstlich und entmutigt waren, waren nun fanatisiert und wollten sich auf den Feind stürzen und ihre Bastillen beseitigen. Dunois fürchtete einen Misserfolg und beschloss, auf die Ankunft der Entsatzarmee zu warten, um den Angiff zu beginnen. In der Zwischenzeit forderte Johanna die Engländer auf, sich zurückzuziehen und in ihr Land zurückzukehren. Sie reagierten mit Beleidigungen.
