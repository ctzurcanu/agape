---
id: KCxHgviRccE
title: "Szene 24"
sidebar_label: "Szene 24"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/KCxHgviRccE"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 24

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Die Soldaten, Engländer und Burgunder, die Troyes besetzt hielten, konnten die Stadt mit allem verlassen, was sie besaßen. Was sie mitnahmen, waren vor allem Gefangene, Franzosen. Bei der Ausarbeitung der Kapitulation war nichts zugunsten dieser Unglücklichen vereinbart worden. Doch als die Engländer mit ihren garrottierten Gefangenen die Stadt verließen, warf sich Johanna auf die andere Straßenseite.

„Im Namen Gottes, Sie werden sie nicht nehmen!“, rief sie.

Sie verlangte die Auslieferung der Gefangenen und die Zahlung eines Lösegeldes durch den König.
