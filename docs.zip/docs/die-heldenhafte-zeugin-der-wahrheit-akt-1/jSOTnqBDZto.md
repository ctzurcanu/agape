---
id: jSOTnqBDZto
title: "Szene 3"
sidebar_label: "Szene 3"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/jSOTnqBDZto"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 3

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Von diesem Tag an wurde Johannas Frömmigkeit noch glühender. Das Kind trennte sich gern von seinen Gefährtinnen, um zu meditieren, und man hörte himmlische Stimmen, die ihr von ihrer Mission erzählten. Es waren, sagte sie, die Stimmen ihrer Heiligen. Oft wurden diese Stimmen von Visionen begleitet; die heilige Katharina und die heilige Margarete erschienen ihr.

„Ich habe sie mit den Augen meines Körpers gesehen“, sagte sie später den Richtern, „und als sie mich verließen, habe ich geweint; ich hätte mir gewünscht, dass sie mich mitgenommen hätten.“

Das Kind wuchs heran, sein Geist war durch seine Visionen erhaben und sie bewahrte tief in ihrem Herzen das Geheimnis ihrer himmlischen Gespräche. Niemand ahnte, was in ihr vorging, nicht einmal der Priester, der ihr die Beichte abnahm.

Zu Beginn des Jahres 1428 war Johanna achtzehn Jahre alt und die Stimmen wurden dringlicher.

„Die Gefahr ist groß. Johanna muss gehen, um dem König zu helfen und das Königreich zu retten.“

Ihre Heiligen befahlen ihr, den Herrn von Baudricourt, Herrn von Vaucouleurs, aufzusuchen und ihn um eine Eskorte zu bitten, die sie zum Dauphin bringen würde.

Da sie es nicht wagte, ihren Eltern von ihrem Plan zu erzählen, ging Johanna nach Burey, um ihren Onkel Laxart zu suchen, und bat ihn, sie nach Vaucouleurs zu bringen. Die Inbrunst ihres Gebets erschütterte die Schüchternheit des ängstlichen Bauern; er versprach, sie zu begleiten.
