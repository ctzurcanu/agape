---
id: btCGISE3Img
title: "Zuletzt"
sidebar_label: "Zuletzt"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/btCGISE3Img"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Zuletzt

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Am 30. Mai beichtete Johanna und empfing die Kommunion. Dann wurde sie zum Hinrichtungsort gebracht. Am Fuße des Schafotts kniete sie nieder und rief zu Gott, der Jungfrau Maria und den Heiligen. Dann wandte sie sich an den Bischof, die Richter und ihre Feinde und bat sie inbrünstig, Messen für ihre Seele lesen zu lassen. Sie stieg auf den Pfahl, bat um ein Kreuz und starb in den Flammen, während sie den Namen Jesu aussprach. Alle weinten, die Henker selbst und die Richter.

„Wir sind verloren, wir haben eine Heilige verbrannt!“, riefen die Engländer, als sie auseinandergingen.

Schluss  
Herrgott, vergib Rouen. Sie wissen nicht, was sie tun …

Jesus, Jesus, warum hast du mich vergessen?

Herr, in deine Hände lege ich meinen Geist.

O JOHANNA, OHNE GRAB UND OHNE PORTRÄT, DIE DU WUSSTEST, DASS DAS GRAB DER HELDEN DAS HERZ DER LEBENDEN IST… - André MALRAUX

NUR NACHWEISBARE FREIWILLIGE KÖNNEN JOHANNA UND ANDERE HELDEN AUS IHREN GRÄBERN WIEDER ERWECKEN - Anon
