---
id: WlczYNzu09Y
title: "Szene 23"
sidebar_label: "Szene 23"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/WlczYNzu09Y"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 23

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Die Engländer verloren viertausend Tote. Zweihundert Gefangene wurden ihnen genommen. Nur diejenigen, die ein Lösegeld zahlen konnten, wurden auf Gedeih und Verderb festgehalten; die anderen wurden gnadenlos getötet.

Einer von ihnen wurde vor den Augen von Johanna so brutal geschlagen, dass sie vom Pferd sprang, um ihm zu helfen. Sie hob den Kopf des armen Mannes, brachte einen Priester zu ihm, tröstete ihn und half ihm beim Sterben.

Ihr Herz war ebenso mitleidig für die verwundeten Engländer wie für die ihrer Gesellschaft.

Außerdem widerstand sie Schlägen und wurde oft verwundet, wollte jedoch ihr Schwert nie benutzen; ihre weiße Standarte war ihre einzige Waffe.
