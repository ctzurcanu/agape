---
id: esAbFgqsGVs
title: "Szene 34"
sidebar_label: "Szene 34"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/esAbFgqsGVs"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 34

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Johanna wurde im Schloss Beaurevoir eingesperrt. Da sie jedoch wusste, dass die Engländer sie vom Herrn von Luxemburg kaufen wollten und dass die Belagerung von Compiègne immer weiter fortschritt und die Stadt bald untergehen würde, ließ sie sich eines Nachts von der Spitze des Bergfrieds gleiten. Dabei benutzte sie Riemen, die jedoch rissen. Sie stürzte am Fuß der Mauer und blieb dort wie tot liegen.

Johanna erholte sich jedoch von ihrem Sturz. Ihr stand ein grausameres Ende bevor.

Ende November wurde sie für eine Summe von zehntausend Tournois Pfund an die Engländer übergeben.
