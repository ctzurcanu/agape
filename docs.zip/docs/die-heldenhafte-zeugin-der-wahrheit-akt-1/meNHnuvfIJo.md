---
id: meNHnuvfIJo
title: "Szene 38"
sidebar_label: "Szene 38"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/meNHnuvfIJo"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 38

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Johanna wurde als Ketzerin behandelt und ihr wurde jeglicher religiöser Beistand verwehrt. Die Sakramente wurden ihr verboten.

Als sie vom Verhör zurückkam und mit ihrer Begleitung an einer Kapelle vorbeikam, deren Tür verschlossen war, fragte sie den Mönch, der sie begleitete, ob der Leichnam Jesu Christi dort sei, und bat darum, ihr zu erlauben, einen Moment vor der Tür niederzuknien und zu beten. Was sie auch tat. Da Cauchon dies wusste, drohte er dem Mönch mit den strengsten Strafen, falls so etwas noch einmal passieren sollte.
