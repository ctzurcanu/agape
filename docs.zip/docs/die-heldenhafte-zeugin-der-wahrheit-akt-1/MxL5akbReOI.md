---
id: MxL5akbReOI
title: "Szene 15"
sidebar_label: "Szene 15"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/MxL5akbReOI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 15

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Tatsächlich wurde die Bastille von Saint-Loup ohne Vorwarnung angegriffen. Der Angriff war gescheitert; die Franzosen zogen sich ungeordnet zurück. Johanna eilte ihnen zur Hilfe, brachte sie zum Feind zurück und begann den Angriff erneut. Vergeblich versuchte Talbot, seinem Volk zu helfen. Johanna stand am Fuß der Wälle und ermutigte ihr Volk. Drei Stunden lang leisteten die Engländer Widerstand. Trotz ihrer verzweifelten Verteidigung wurde die Bastille eingenommen.
