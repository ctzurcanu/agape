---
id: 7qussWJQ4Jg
title: "Szene 25"
sidebar_label: "Szene 25"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/7qussWJQ4Jg"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 25

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Am 16. Juli marschierte der König an der Spitze seiner Truppen in die Stadt Reims ein. Am nächsten Tag fand in der Kathedrale inmitten einer großen Menschenmenge von Adligen und Bürgern die Krönungszeremonie statt. Johanna stand mit ihrer Standarte in der Hand hinter dem König.

„Diese Standarte hat gelitten, es war richtig, dass sie im Rampenlicht stand.“

Als Karl VII. die heilige Salbung und die Krone vom Erzbischof Regnault von Chartres erhalten hatte, warf sich Johanna ihm zu Füßen, küsste seine Knie und weinte heiße Tränen.

„Oh gütiger Herr“, sagte sie, „nun ist der Wunsch Gottes erfüllt, der wollte, dass ich Sie in Ihre Stadt Reims bringe, um Ihre heilige Krönung zu empfangen und zu zeigen, dass Sie der wahre König sind und dass das Königreich Frankreich Ihnen gehören muss!“

„Alle, die es in diesem Moment sahen“, heißt es in der alten Chronik, „glaubten mehr denn je, dass es etwas von Gott war.“

„Oh, ihr guten und frommen Leute“, rief das heilige Mädchen, als sie die Begeisterung der Menge um den König sah, „wenn ich sterben muss, wäre ich sehr glücklich, wenn sie mich hier begraben würden!“
