---
id: PTHw_wVfQpU
title: "Szene 29"
sidebar_label: "Szene 29"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/PTHw_wVfQpU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 29

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Dieser Rückzug, der durch die Feigheit Karls VII. und die Eifersucht der Höflinge erzwungen wurde, war ein schrecklicher Angriff auf Johannas Ansehen.

Von nun an war sie in jedermanns Augen nicht mehr unbesiegbar.

Das heilige Mädchen schien das verstanden zu haben, denn bevor sie Paris verließ, legte sie ihre bis dahin siegreichen Waffen als Opfergabe auf den Altar von Saint-Denis. Sie betete lange. Vielleicht hatte sie in diesem Moment eine Ahnung, dass ihre glorreiche Mission beendet war und schmerzhafte Verhandlungen auf sie warteten. Trotzdem unterwarf sie sich und folgte dem König mit dem Tod in der Seele nach Gien. Die Armee wurde aufgelöst. Die Leute am Hof dachten, wir hätten genug gekämpft. Außerdem war es wichtig, dass ihre Eifersucht Johannas Erfolg ein Ende setzte.
