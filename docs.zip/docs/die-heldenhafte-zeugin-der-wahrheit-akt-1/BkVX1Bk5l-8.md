---
id: BkVX1Bk5l-8
title: "Szene 11"
sidebar_label: "Szene 11"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/BkVX1Bk5l-8"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 11

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Johanna hatte zu Dunois, der zu ihr gekommen war, gesagt:

„Ich bringe euch die beste Hilfe, die Hilfe des Königs des Himmels; sie kommt nicht von mir, sondern von Gott selbst, der auf die Bitte des Heiligen Ludwig und Karl des Großen hin Mitleid mit der Stadt Orléans hatte.“

Um acht Uhr abends kam Johanna in Orléans an. Die Menschen eilten ihr entgegen. Im Licht der Fackeln durchquerte sie die Stadt inmitten einer Menschenmenge, die so dicht war, dass sie kaum vorankam. Alle, Männer, Frauen und Kinder, wollten sich ihr nähern oder zumindest ihr Pferd berühren und zeigten „eine so große Freude, als hätten sie Gott zu sich herabsteigen sehen“.

„Sie fühlten sich“, heißt es im Tagebuch des Hauptquartiers, „getröstet und wie erleichtert durch die göttliche Tugend dieses einfachen Mädchens.“

Johanna sprach sanft mit ihnen und versprach, sie zu befreien.
