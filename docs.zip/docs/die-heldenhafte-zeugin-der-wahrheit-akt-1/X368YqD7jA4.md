---
id: X368YqD7jA4
title: "Szene 21"
sidebar_label: "Szene 21"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/X368YqD7jA4"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 21

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Am 11. Juni besetzten die Franzosen die Vororte von Jargeau. Am nächsten Tag gab Johanna gleich am Morgen das Signal zum Kampf. Der Herzog von Alençon wollte den Angriff verzögern:

„Vorwärts, gütiger Herzog, zum Angriff! Zweifle nicht, es ist die Stunde, in der es Gott gefällig ist; arbeite, und Gott wird arbeiten.“

Sie selbst kletterte die Leiter hinauf. Sie wurde von einem Stein am Kopf niedergerissen. Aber sie stand auf und rief ihren Leuten zu:

„Freunde, auf, auf! Unser Vater hat die Engländer verurteilt, in dieser Stunde gehören sie uns, seid tapfer!“

Die Wälle wurden erklommen. Die Engländer wurden bis zur Stadtbrücke verfolgt, gefangen genommen und getötet. Suffolk wurde gefangen genommen.

Am 15. übernahmen die Franzosen die Kontrolle über die Meung-Brücke;

am 16. belagerten sie Beaugency;

am 17. kapitulierte die Stadt;
