---
id: 1IWC9AqMz1c
title: "Szene 13"
sidebar_label: "Szene 13"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/1IWC9AqMz1c"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 13

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Aus Blois kam jedoch keine Nachricht. Dunois machte sich besorgt auf den Weg, um die Ankunft von Hilfe zu beschleunigen. Es war an der Zeit. Der Erzbischof von Reims, Regnault de Chartres, Kanzler des Königs, überdachte die getroffenen Entscheidungen und wollte die Truppen in ihre Garnisonen zurückschicken. Dunois gelang es, sie nach Orléans zu bringen.

Am Mittwochmorgen, dem 4. Mai, verließ Johanna, umgeben von der gesamten Geistlichkeit der Stadt und gefolgt von einem großen Teil der Bevölkerung, Orléans; durch die englischen Bastillen rückte sie in einer großen Prozession vor, um der kleinen Armee von Dunois entgegenzutreten, die unter dem Schutz der Priester und eines Mädchens vorbeizog, ohne dass die Engländer es wagten, sie anzugreifen.
