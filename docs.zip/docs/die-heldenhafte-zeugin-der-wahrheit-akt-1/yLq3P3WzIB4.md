---
id: yLq3P3WzIB4
title: "Szene 5"
sidebar_label: "Szene 5"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/yLq3P3WzIB4"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 5

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Aber dieses Mal blieb sie in Vaucouleurs.

Bald drehte sich im ganzen Land alles um das junge Mädchen, das überall herumlief und laut verkündete, sie würde das Königreich retten, man müsse sie zum Dauphin bringen, Gott wolle das.

„Ich werde gehen“, sagte sie, „selbst wenn meine Beine bis zu den Knien abgenutzt werden.“

Das einfache Volk glaubte an sie und war von ihrem Glauben bewegt. Ein Gutsherr, Jean de Metz, der durch das Vertrauen der Menge überzeugt war, bot an, sie nach Chinon zu bringen, wo Karl VII. weilte. Die armen Leute vereinten ihr Elend und taten sich zusammen, um das kleine Bauernmädchen zu kleiden und zu bewaffnen. Sie kauften ihr ein Pferd, und am festgesetzten Tag brach sie mit ihrer schwachen Eskorte auf.

„Geh. Und komme, was wolle!“, warf Baudricourt ihr zu.

„Gott segne euch!“, riefen die armen Leute, und die Frauen weinten, als sie sie weggehen sahen.
