---
id: 3e37gZBrHPg
title: "Szene 1"
sidebar_label: "Szene 1"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/3e37gZBrHPg"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 1

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Johanna wurde am 6. Januar 1412 in Domrémy geboren, einem kleinen Dorf in Lothringen, das zur Vogtei Chaumont gehörte, die wiederum unter die französische Krone fiel.

Ihr Vater hieß Jacques d’Arc und ihre Mutter Isabelle Romée; sie waren ehrliche Leute, einfache Arbeiter, die von ihrer Arbeit lebten.

Johanna wuchs mit ihren Brüdern und ihrer Schwester in einem kleinen Haus auf, das noch heute in Domrémy zu sehen ist, so nah an der Kirche, dass sein Garten an den Friedhof grenzt.

Dort wächst das Kind unter den Augen Gottes auf.

Sie war süß, einfach und ehrlich. Alle liebten sie, weil sie wusste, dass sie wohltätig und das beste Mädchen in ihrem Dorf war. Fleißig bei der Arbeit half sie ihrer Familie bei ihren Aufgaben. Tagsüber führte sie die Tiere auf die Weide oder half ihrem Vater bei der harten Arbeit. Abends verbrachte sie Zeit mit ihrer Mutter und half ihr bei der Versorgung des Haushalts.

Sie liebte Gott und betete oft zu ihm.
