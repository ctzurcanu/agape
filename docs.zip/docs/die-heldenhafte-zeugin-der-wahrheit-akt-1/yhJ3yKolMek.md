---
id: yhJ3yKolMek
title: "Szene 2"
sidebar_label: "Szene 2"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/yhJ3yKolMek"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 2

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

An einem Sommertag, als sie dreizehn Jahre alt war, hörte sie am Mittag eine Stimme im Garten ihres Vaters; ein großes Licht brach aus und der Erzengel Sankt Michael erschien ihr. Er sagte ihr, sie solle brav sein und in die Kirche gehen. Dann erzählte er ihr von dem großen Elend, das im Königreich Frankreich herrschte, und verkündete ihr, sie werde dem Dauphin zu Hilfe kommen und ihn zur Krönung nach Reims bringen.

„Herr, ich bin nur ein armes Mädchen, ich kann weder reiten noch Soldaten führen.“

„Gott wird dir helfen“, antwortete der Erzengel.

Und das verstörte Kind weinte weiter.
