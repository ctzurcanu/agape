---
id: kUPUBqqRxIc
title: "Szene 22"
sidebar_label: "Szene 22"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/kUPUBqqRxIc"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 22

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Am 18. Juni erreichte Johanna in der Nähe von Patay die englische Armee unter Talbot und Fastolf.

„Im Namen Gottes müssen wir sie bekämpfen“, sagte sie. „Selbst wenn sie in den Wolken hängen, werden wir sie haben, denn Gott schickt sie zu uns, damit wir sie bestrafen können. Unser gütiger König wird heute den größten Sieg erringen, den er jemals errungen hat.“

Sie wollte die Vorhut übernehmen, wurde jedoch zurückgehalten, und La Hire wurde beauftragt, die Engländer anzugreifen, um sie zur Umkehr zu zwingen und den französischen Truppen Zeit zum Eintreffen zu geben. Doch La Hires Angriff war so ungestüm, dass alles vor ihm nachgab. Als Johanna mit ihren Soldaten startete, zogen sich die Engländer in Unordnung zurück. Ihr Rückzug wurde zu einer Flucht.

Talbot wurde gefangen genommen.

„Sie hätten heute Morgen nicht gedacht, dass Ihnen das passieren würde“, sagte der Herzog von Alençon.

„Das ist das Glück des Krieges“, antwortete Talbot.
