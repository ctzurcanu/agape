---
id: SYFRc1pihnA
title: "Szene 32"
sidebar_label: "Szene 32"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/SYFRc1pihnA"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 32

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Eine Truppe hatte sie angegriffen.

„Ergib dich!“, riefen sie ihr zu. „Ich habe jemand anderem als euch meine Treue geschworen und versprochen“, antwortete das tapfere Mädchen, „und ich werde meinen Eid halten!“

Aber sie wehrte sich vergebens. An ihren langen Kleidern gezogen, wurde sie vom Pferd geworfen und gefangen genommen. Von der Stadtmauer aus beobachtete der Herr von Flavy, Gouverneur von Compiègne, ihre Gefangennahme. Er unternahm nichts, um ihr zu helfen.
