---
id: TjCbIP3IMsY
title: "Szene 6"
sidebar_label: "Szene 6"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/TjCbIP3IMsY"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 6

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Chinon war weit weg und die Reise gefährlich. Die englischen und burgundischen Partisanen hielten das Land, und die kleine Truppe war gezwungen, bestimmte Brücken zu überqueren, die der Feind besetzt hatte. Man musste nachts wandern und sich tagsüber verstecken. Johannas Gefährten sprachen voller Angst davon, nach Vaucouleurs zurückzukehren.

„Fürchtet euch nicht, sagte sie ihnen, Gott zeigt mir meinen Weg, meine Brüder im Paradies sagen mir, was ich tun muss.“

Am zwölften Tag traf Johanna mit ihren Gefährten in Chinon ein. Aus dem kleinen Dorf Sainte-Catherine hatte sie dem König einen Brief geschickt, in dem sie ihre Ankunft ankündigte.

Am Hof Karls VII. herrschte keine Einigkeit darüber, wie sie empfangen werden sollte. La Trémouille, der Günstling der damaligen Zeit, war eifersüchtig auf die Macht, die sie über seinen Herrn erlangt hatte, und war entschlossen, jeden Einfluss zu beseitigen, der Karl aus seiner Trägheit reißen konnte. Zwei Tage lang diskutierte der Rat, ob der Dauphin die beseelte junge Frau empfangen würde.
