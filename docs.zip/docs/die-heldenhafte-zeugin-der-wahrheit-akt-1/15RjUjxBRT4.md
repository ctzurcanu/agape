---
id: 15RjUjxBRT4
title: "Szene 9"
sidebar_label: "Szene 9"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/15RjUjxBRT4"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 9

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Die Truppen versammelten sich in Blois. Johanna traf dort ein, gefolgt vom Herzog von Alençon, Marschall von Boussac, dem Herrn von Rais, La Hire und Xaintrailles.

Auf ihre weiße Standarte ließ sie das Bild Gottes und die Namen Jesus und Maria sticken. Sie riet ihren Soldaten, ihr Gewissen zu klären und zu beichten, bevor sie in den Kampf zogen. Am Donnerstag, dem 28. April, brach die kleine Armee auf. Johanna führte den Weg an, ihre Standarte im Wind wehte, und sang „Komm, Schöpfer“.

Sie wollte direkt auf Orléans zumarschieren; die Führung hielt es für klüger, über das linke Loire-Ufer zu marschieren.
