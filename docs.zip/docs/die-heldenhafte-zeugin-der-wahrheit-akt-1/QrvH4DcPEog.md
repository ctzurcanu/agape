---
id: QrvH4DcPEog
title: "Szene 20"
sidebar_label: "Szene 20"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/QrvH4DcPEog"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 20

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Die Nachricht von der Befreiung Orléans verbreitete sich weit und breit und zeugte von der Göttlichkeit von Johannas Mission.

Das heilige Mädchen, das die Anerkennung der Orléanais vermeiden wollte, kehrte hastig nach Chinon zurück. Sie wollte die Begeisterung, die um sie herum entfacht wurde, ausnutzen und sofort nach Reims aufbrechen und den König mitnehmen, um ihn krönen zu lassen. Der König empfing sie mit großen Ehren, weigerte sich jedoch, ihr zu folgen. Er akzeptierte die Hingabe dieses heldenhaften Mädchens, verstand jedoch, dass ihre großzügigen Bemühungen die feige Trägheit ihres königlichen Daseins in keiner Weise stören würden.

Es wurde beschlossen, dass Johanna die Orte angreifen würde, die die Engländer noch an den Ufern der Loire belagerten.
