---
id: pKk0TAzoklo
title: "Szene 35"
sidebar_label: "Szene 35"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/pKk0TAzoklo"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 35

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Im Gefängnis des Schlosses von Rouen wurde sie Tag und Nacht von Soldaten bewacht, von welchen sie Beleidigungen und sogar Brutalität ertragen musste, da sie aufgrund ihrer Ketten keine Möglichkeit hatte, sich zu verteidigen.

Inzwischen untersuchte ein Gericht, das nach dem Ermessen der englischen Partei unter dem Vorsitz von Cauchon, dem Bischof von Beauvais, stand, ihren Prozess. Den heimtückischen Fragen ihrer Richter konnte das arme und heilige Mädchen, ohne Unterstützung und ohne Rat, nur die Rechtschaffenheit und Einfachheit ihres Herzens, nur die Reinheit ihrer Absichten entgegensetzen.

„Ich komme von Gott“, sagte sie. „Ich bin hier nutzlos. Schickt mich zurück zu Gott, von dem ich gekommen bin.“
