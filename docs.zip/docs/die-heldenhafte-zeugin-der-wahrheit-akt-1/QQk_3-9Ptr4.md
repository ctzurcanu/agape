---
id: QQk_3-9Ptr4
title: "Szene 30"
sidebar_label: "Szene 30"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/QQk_3-9Ptr4"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 30

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Doch Johanna konnte sich nicht mit der Untätigkeit abfinden, die man ihr aufzwingen wollte. Während der Belagerung der Charité ohne Hilfe zurückgelassen, erkannte sie, dass sie nun keine Hoffnung mehr auf Hilfe von Karl VII. hatte. Ende März (1430) brach sie, ohne sich vom König zu verabschieden, auf, um sich den französischen Partisanen anzuschließen, die bei Lagny gegen die Engländer kämpften.

Jetzt, in der Osterwoche, als sie gerade in der Kirche Saint-Jacques de Compiègne die Messe gehört und die Kommunion empfangen hatte, zog sie sich an einer Säule der Kirche zurück und begann zu weinen. Die Stadtbewohner und Kinder umringten sie – sie sagte zu ihnen: „Meine Kinder und lieben Freunde, ich sage euch, dass ich verkauft und verraten wurde und dass ich bald dem Tod ausgeliefert werde. Ich bitte euch, für mich zu beten, denn ich werde nie wieder die Macht haben, dem König und dem Königreich Frankreich irgendeinen Dienst zu erweisen.“
