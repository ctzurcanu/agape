---
id: rMUt3iYomEg
title: "Szene 4"
sidebar_label: "Szene 4"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/rMUt3iYomEg"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 4

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Baudricourts Empfang war brutal. Johanna sagte ihm, „dass eine Botschaft von Gott gekommen sei, dass Gott dem Dauphin befehlen werde, sich gut zu benehmen, weil der Herr ihm vor der Fastenzeit helfen werde“; sie fügte hinzu, „dass Gott wolle, dass der Dauphin König werde; dass er dies trotz seiner Feinde tun werde und dass sie ihn selbst zur Krönung führen werde“.

„Dieses Mädchen ist verrückt“, sagte Baudricourt, „bringen wir sie zurück zu ihrem Vater, damit er ihr ein paar ordentliche Ohrfeigen verpasst.“

Johanna kehrte nach Domrémy zurück. Doch von ihren Stimmen erneut bedrängt, kehrte sie nach Vaucouleurs zurück und traf den Herrn von Baudricourt erneut, ohne einen besseren Empfang zu erfahren.
