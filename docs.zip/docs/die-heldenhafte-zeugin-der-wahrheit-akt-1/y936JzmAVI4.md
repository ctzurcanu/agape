---
id: y936JzmAVI4
title: "Szene 33"
sidebar_label: "Szene 33"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/y936JzmAVI4"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 33

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Unter dem Jubelschrei ihrer Feinde wurde Johanna nach Margny gebracht. Die englischen und burgundischen Häuptlinge und der Herzog von Burgund selbst eilten herbei, um die Hexe zu sehen. Sie standen einem achtzehnjährigen Mädchen Auge in Auge gegenüber. Johanna war die Gefangene von Johann von Luxemburg, einem vermögenden Herrn, der nur aus ihrer Gefangennahme Profit schlagen wollte. Der König von Frankreich bot der Gefangenen kein Lösegeld an.
