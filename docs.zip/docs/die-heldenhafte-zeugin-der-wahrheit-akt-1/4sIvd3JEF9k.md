---
id: 4sIvd3JEF9k
title: "Szene 16"
sidebar_label: "Szene 16"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/4sIvd3JEF9k"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 16

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Johanna kehrte siegreich nach Orléans zurück. Doch als sie in der Freude ihres Erfolgs über das Schlachtfeld in Richtung Stadt zurückkehrte, fühlte sie, wie ihr armes Herz beim Anblick der Verwundeten und Toten vor Mitleid zerfloss, und sie begann zu weinen, weil sie dachte, sie seien ohne Beichte gestorben. Und sie sagte, „sie habe noch nie zuvor gesehen, wie das Blut Frankreichs vergossen wurde. Ihr standen die Haare zu Berge.“
