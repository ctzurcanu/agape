---
id: xQLH9IzowgE
title: "Vorwort"
sidebar_label: "Vorwort"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/xQLH9IzowgE"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Vorwort

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Am 22. Oktober 1422 starb Karl VI. und vermachte mit dem Vertrag von Troyes sein Königreich durch die Hand seiner Tochter an Heinrich V., dem König von England.

In dem Jahrhundert, seit der Krieg unser Land verwüstete, war unsere Unabhängigkeit noch nie so bedroht.

Als Herren von Guyenne, auf der einen Seite vereint mit dem Herzog von Burgund, auf der anderen unterstützt vom Herzog der Bretagne, belagerten die Engländer den Norden und die Mitte Frankreichs bis zur Loire.

Die Belagerung von Orléans stellte ein letztes Hindernis auf ihrem Vormarsch nach Süden dar. Doch ohne Hilfe war die Stadt dem Untergang geweiht.

Der Dauphin Karl VII. hatte in Bourges Zuflucht gesucht: ein trauriger König, ohne Armee, ohne Geld, ohne Kraft. Ein paar Höflinge wetteiferten noch um die letzten Gunstbeweise dieser untergehenden Monarchie, aber keiner von ihnen war in der Lage, sie zu verteidigen, und in der hungrigen Gegend zogen sich die Überreste der königlichen Armee, Banden von Straßenkämpfern aller Herkunft, geschwächt und demoralisiert durch ihre jüngsten Niederlagen bei Cravant und Verneuil, zurück, unfähig zu einem neuen Versuch.

Es fehlte an allem: an Männern, an Ressourcen, ja sogar an der Willenskraft zum Widerstand. Karl VI., der an seiner Veranlassung verzweifelte, dachte daran, ins Dauphiné oder vielleicht sogar über die Berge hinaus nach Kastilien zu fliehen und sein Königreich, seine Rechte und seine Pflichten aufzugeben.

Nachdem der Wahnsinn Karls VI., die Trägheit des Dauphins und der Egoismus und die Unfähigkeit des Adels den Ruin des Landes vollendet hatten, stand auch unser Volk davor, seine Nationalität zu verlieren.

Dann kam es an der Grenze Lothringens in einem abgelegenen Dorf zum Austand eines kleinen Bauernmädchens. Von Mitleid bewegt durch das Elend der armen Menschen in Frankreich, hatte sie in der Tiefe ihres Herzens die erste Sehnsucht nach der Heimat gespürt. Mit ihrer schwachen Hand ergriff sie das große Schwert des besiegten Frankreichs, und mit ihrer schwachen Brust, die einen Wall gegen so viel Elend bildete, schöpfte sie aus der Energie ihres Glaubens die Kraft, den verlorenen Mut wiederzuerlangen und unser Land den siegreichen Engländern zu übergeben.

„Ich komme von meinem Herrn Gott“, sagte sie, „um das Königreich Frankreich zu retten.“

Und sie fügte hinzu: „Dafür wurde ich geboren.“

Aus diesem Grund wurde sie, das heilige Mädchen, geboren. Aus diesem Grund wurde sie feige ihren Feinden ausgeliefert und starb unter den Schrecken grausamster Folter, im Stich gelassen von dem König, den sie gekrönt hatte, und dem Volk, das sie gerettet hatte.

Öffnet dieses Buch, meine lieben Kinder, mit Hingabe im Gedenken an diese bescheidene Bäuerin, die die Schutzpatronin Frankreichs ist, die Heilige des Vaterlandes, weil sie dessen Märtyrerin war. Diese Geschichte wird euch sagen, dass man, um zu siegen, an den Sieg glauben muss. Denkt daran, an den Tag, an dem das Land all euren Mut brauchen wird.
