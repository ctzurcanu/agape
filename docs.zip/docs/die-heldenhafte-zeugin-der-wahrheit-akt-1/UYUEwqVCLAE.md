---
id: UYUEwqVCLAE
title: "Szene 27"
sidebar_label: "Szene 27"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/UYUEwqVCLAE"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 27

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Die Menschen waren so begierig, Johanna zu berühren, wie nichts anderes. Es ging darum, wer ihre Hände oder ihre Kleider küssen und sie berühren würde. Man brachte ihr die kleinen Kinder, damit sie sie segnen konnte, die Rosenkränze und die Heiligenbilder, damit sie sie durch Berühren mit der Hand heiligen konnte. Und das demütige Mädchen lehnte diese Zeichen der Anbetung anmutig ab und scherzte sanft mit den Armen über ihre Leichtgläubigkeit in ihre Macht. Aber sie fragte, an welchem Tag und zu welcher Zeit die Kinder der Armen die Kommunion empfingen, um sie mit ihnen gemeinsam zu empfangen.

Ihr Mitleid galt allen, die litten, aber ihre Zärtlichkeit galt den Kleinen und Bescheidenen. Sie fühlte sich wie deren Schwester, da sie wusste, dass sie als eine von ihnen geboren war. Als sie später dafür kritisiert wurde, dass sie diese Verehrung der Menge toleriert hatte, antwortete Johanna einfach:

„Viele Leute sahen mich freiwillig und küssten mir ohne meine Erlaubnis die Hände, aber die Armen kamen freiwillig zu mir, weil ich ihnen nicht missfiel.“
