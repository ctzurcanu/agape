---
id: XgIRoGYO7tI
title: "Szene 37"
sidebar_label: "Szene 37"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/XgIRoGYO7tI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 37

Eines Tages kamen Stafford und Warwick mit Jean de Luxembourg zu ihr. Und als er ihr spöttisch sagte, dass er kommen würde, um sie zurückzukaufen, wenn sie verspreche, sich nicht wieder gegen England zu bewaffnen:

„Im Namen Gottes“, antwortete sie, „Sie machen sich über mich lustig, denn ich weiß genau, dass Sie weder den Willen noch die Macht dazu haben. Ich weiß genau, dass die Engländer mich hinrichten werden, weil sie glauben, nach meinem Tod das Königreich Frankreich zu erlangen. Aber selbst wenn sie hunderttausend Mann mehr wären, würden sie das Königreich nicht bekommen.“

Wütend stürzte sich der Earl of Stafford auf sie.

Ohne das Eingreifen der Assistenten hätte er sie getötet.
