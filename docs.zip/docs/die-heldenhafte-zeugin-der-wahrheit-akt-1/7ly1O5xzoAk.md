---
id: 7ly1O5xzoAk
title: "Szene 18"
sidebar_label: "Szene 18"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/7ly1O5xzoAk"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 18

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Am nächsten Tag, dem 6. Mai, eroberte sie die Augustiner-Bastille. Am Samstag, dem 7., begann frühmorgens der Angriff auf die Bastille von Tournelles. Johanna, die in den Graben hinabgelassen worden war, stellte gerade eine Leiter gegen die Brustwehr, als sie ein Armbrustbolzen zwischen Hals und Schulter durchbohrte. Sie riss das Eisen aus der Wunde; man bot ihr dann an, die Wunde zu beschwören, doch sie lehnte ab und sagte, „sie würde lieber sterben, als etwas zu tun, das gegen den Willen Gottes sei“. Sie beichtete und betete lange, während ihre Truppen sich ausruhten. Dann gab sie den Befehl, den Angriff wiederaufzunehmen, stürzte sich in die Hitze des Gefechts und rief den Angreifern zu:

„Es gehört alles euch, kommt rein!“

Die Bastille wurde eingenommen und alle Verteidiger kamen um. Am linken Loire-Ufer war kein einziger Engländer mehr zu finden.
