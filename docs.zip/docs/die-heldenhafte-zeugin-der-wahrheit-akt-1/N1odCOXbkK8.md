---
id: N1odCOXbkK8
title: "Szene 19"
sidebar_label: "Szene 19"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/N1odCOXbkK8"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 19

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Am Sonntag stellten sich die Engländer am rechten Ufer der Loire zum Kampf auf. Johanna verbot, sie anzugreifen. Sie ließ einen Altar errichten und las im Beisein der versammelten Armee eine Messe. Am Ende der Zeremonie sagte sie zu den Umstehenden:

„Sehen Sie nach, ob die Engländer uns zugewandt oder mit dem Rücken zu uns stehen!“ Und als man ihr sagte, dass sie sich in Richtung Meung zurückzogen:

„Im Namen Gottes, wenn sie gehen, lasst sie gehen; es gefällt dem Herrn Gott nicht, dass wir heute gegen sie kämpfen, ihr werdet sie ein anderes Mal haben.“

Orléans wurde nach acht Monaten Belagerung in vier Tagen befreit.
