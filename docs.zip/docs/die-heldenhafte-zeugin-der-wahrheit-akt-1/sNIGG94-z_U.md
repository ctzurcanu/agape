---
id: sNIGG94-z_U
title: "Szene 8"
sidebar_label: "Szene 8"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/sNIGG94-z_U"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 8

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Drei Wochen lang wurde sie mit heimtückischen Fragen gequält.

„In Gottes Buch steht mehr als in deinem“, antwortete sie. „Ich kenne weder A noch B, aber ich komme vom König des Himmels.“

Als man ihr vorwarf, Gott brauche keine bewaffneten Männer, um Frankreich zu befreien, stand sie plötzlich auf:

„Die Männer werden kämpfen, Gott wird den Sieg erteilen.“

Dort wie in Vaucouleurs war das Volk ihr wohlgesonnen und betrachtete sie als heilig und beseelt. Die Ärzte und die Mächtigen mussten der Begeisterung der Menge nachgeben.
