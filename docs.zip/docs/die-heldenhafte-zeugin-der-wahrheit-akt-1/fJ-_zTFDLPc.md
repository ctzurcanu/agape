---
id: fJ-_zTFDLPc
title: "Szene 28"
sidebar_label: "Szene 28"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/fJ-_zTFDLPc"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 28

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Nach der Krönung von Reims wollte Johanna energisch auf Paris vorrücken und die Hauptstadt des Königreichs zurückerobern. Die Unentschlossenheit des Königs gab den Engländern Zeit, ihre Verteidigungsvorbereitungen zu treffen. Der Angriff wurde zurückgeschlagen; Johanna wurde durch einen Armbrustbolzen am Oberschenkel verletzt.

Sie musste mit Gewalt vom Fuß der Wälle weggebracht werden, um sie zu zwingen, den Kampf abzubrechen. Am nächsten Tag widersetzte sich der König der Wiederaufnahme des Angriffs; Johanna war jedoch für den Misserfolg verantwortlich.

Karl VII war lange Zeit auf den Straßen herumgeschleift worden; er konnte es kaum erwarten, sein träges Leben in seinen Schlössern in der Touraine wieder aufzunehmen.
