---
id: NlT01c9AnEI
title: "Szene 31"
sidebar_label: "Szene 31"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/NlT01c9AnEI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 31

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Am 23. Mai erfuhr sie in Crespy, dass die Stadt Compiègne von den Engländern und Burgundern schwer belagert wurde.

Sie zog mit vierhundert Kämpfern dorthin und betrat die Stadt am 24. bei Tagesanbruch. Dann griff sie mit einem Teil der Garnison die Burgunder an. Aber die Engländer kamen, um sie anzugreifen. Die Franzosen zogen sich zurück.

„Denkt an nichts anderes, als auf sie zu schießen“, rief Johanna. „Es liegt an euch, sie nervös zu machen!“

Doch Johanna wurde vom Rückzug ihres Volkes mitgerissen. Als die Franzosen unter die Stadtmauern von Compiègne zurückgebracht wurden, fanden sie die Brücke hochgezogen und das Fallgitter heruntergelassen vor. Doch Johanna, die in die Gräben gedrängt wurde, verteidigte sich noch immer.
