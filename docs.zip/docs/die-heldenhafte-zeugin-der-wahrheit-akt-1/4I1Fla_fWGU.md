---
id: 4I1Fla_fWGU
title: "Szene 7"
sidebar_label: "Szene 7"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/4I1Fla_fWGU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 7

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

In diesem Moment trafen Nachrichten aus Orléans ein, die so beunruhigend waren, dass es Johannas Anhängern gelang, diese letzte Chance auf Rettung nicht zunichte zu machen. Am Abend wurde Johanna im Licht von fünfzig Fackeln in der großen Halle des Schlosses vorgestellt, wo sich alle Hofherren drängten. Sie hatte den König noch nie gesehen. Karl VII. trug, um ihre Aufmerksamkeit nicht zu erregen, ein weniger luxuriöses Kostüm als seine Höflinge. Auf den ersten Blick erkannte sie ihn unter allen und kniete vor ihm nieder:

„Gott segne dich, lieber Dauphin!“, sagt sie

„Ich bin nicht der König“, antwortete er, „das ist der König.“ Und er bestimmte ihr einen Herrn.

„Das bist du, gütiger Prinz, und kein anderer. Der König des Himmels lässt dir durch mich ausrichten, dass du gekrönt wirst.“

Und als sie sich dem Ziel ihrer Mission näherte, erzählte sie ihm, dass Gott sie gesandt habe, um ihm zu helfen und Beistand zu leisten. Sie bat ihn, ihr ein Heer zu schicken, und versprach, die Belagerung von Orléans aufzuheben und ihn nach Reims zu bringen.

Der Dauphin zögerte. Dieses Mädchen könnte eine Hexe sein. Er schickte sie nach Poitiers, um sie dort einer Untersuchung durch Ärzte und Geistliche zu unterziehen.
