---
id: QDZnVjqMGts
title: "Szene 14"
sidebar_label: "Szene 14"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/QDZnVjqMGts"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 14

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Am selben Tag schreckte Johanna hoch, als sie sich ausruhte.

„Ach! Mein Gott“, rief sie, „das Blut unseres Volkes wird auf dem Boden vergossen! … Das ist falsch! Warum wurde ich nicht geweckt? Schnell, meine Waffen, mein Pferd!“

Mit Hilfe der Frauen des Hauses bewaffnete sie sich rasch, sprang in den Sattel und galoppierte mit ihrer Standarte in der Hand direkt auf die Porte de Bourgogne zu, und zwar so schnell, dass Funken vom Bürgersteig sprühten.
