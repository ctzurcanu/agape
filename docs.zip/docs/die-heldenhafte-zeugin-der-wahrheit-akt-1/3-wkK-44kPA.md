---
id: 3-wkK-44kPA
title: "Szene 39"
sidebar_label: "Szene 39"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/3-wkK-44kPA"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 39

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Den Engländern ging der Prozess allerdings zu langsam voran.

„Richter, Sie verdienen Ihr Geld nicht!“, riefen sie den Mitgliedern des Gerichts zu.

„Ich bin zum König von Frankreich gekommen“, sagte Johanna, „von Gott, von der Jungfrau Maria, den Heiligen und der siegreichen Kirche da oben; dieser Kirche unterwerfe ich mich, meine Werke, was ich getan habe oder tun werde. Ihr sagt, ihr seid meine Richter, seid vorsichtig mit dem, was ihr tut, denn ich bin wirklich von Gott gesandt und ihr begebt euch in große Gefahr!“

Die heilige Heldin wurde als Ketzerin, Rückfällige, Abtrünnige und Götzendienerin dazu verurteilt, auf dem Place du Vieux-Marché in Rouen lebendig verbrannt zu werden.

„Bischof, ich sterbe Ihretwegen!“, sagte sie zu Cauchon.
