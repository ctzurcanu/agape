---
id: lW-hKhFdg3U
title: "Szene 36"
sidebar_label: "Szene 36"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/lW-hKhFdg3U"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 36

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Eine Hilfe blieb ihr jedoch: die ihrer Heiligen. Nur sie hatten sie nicht im Stich gelassen. Johanna erhielt immer Rat von ihren himmlischen Stimmen; die heilige Margarete und die heilige Katharina erschienen ihr in der Stille der Nacht und trösteten sie mit guten Worten. Und als Bischof Cauchon Johanna fragte, was sie ihr gesagt hätten:

„Sie weckten mich“, antwortete sie. „Ich faltete die Hände und bat sie um einen Rat. Sie sagten zu mir: ‚Frag unseren Herrn.‘“

„Und was haben sie sonst noch gesagt?“

„Um Ihnen mutig zu antworten.“

Und als der Bischof sie mit Fragen bedrängte:

„Ich kann nicht alles sagen. Ich habe mehr Angst davor, etwas zu sagen, was Ihnen missfällt, als davor, Ihnen nicht zu antworten.“
