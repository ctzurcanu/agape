---
id: pU0ILiKX4k8
title: "Szene 10"
sidebar_label: "Szene 10"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/pU0ILiKX4k8"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Szene 10

Die heldenhafte Zeugin der Wahrheit. Akt 1.   
Playlist: https://www.youtube.com/playlist?list=PLrZFPVQM38McvejkNVeU5UTyPEMhzOnjn 

Die Armee und der Konvoi erreichten Chécy, zwei Meilen oberhalb von Orléans.

Es ging darum, die Loire zu überqueren; die Boote fehlten. Johanna wurde mit einem Teil ihrer Eskorte und dem Versorgungskonvoi an das andere Ufer gebracht. Der Rest der Truppen musste nach Blois zurückkehren, um über das rechte Loireufer, über Beauce, nach Orléans zurückzukehren.
