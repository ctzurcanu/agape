---
id: AL7tsCU1Cgg
title: "Home on the Range (Kansas)"
sidebar_label: "Home on the Range (Kansas)"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/AL7tsCU1Cgg"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Home on the Range (Kansas)

Lyrics: Dr. Brewster M. Higley, 1874

Oh, give me a home where the buffalo roam,  
Where the deer and the antelope play,  
Where seldom is heard a discouraging word  
And the sky is not clouded all day.  
   
A home, a home (on the range)  
Where the deer and the antelope play,  
Where seldom is heard a discouraging word  
And the sky is not clouded all day.  
   
Oh, give me a land where the bright diamond sand  
Throws its light from the glittering stream  
Where glideth along the graceful white swan  
Like a maid in her heavenly dream.  
   
A home, a home (on the range)  
Where the deer and the antelope play,  
Where seldom is heard a discouraging word  
And the sky is not clouded all day.  
   
Oh, give me the gale of the Solomon Vale,  
Where life streams with buoyancy flow,  
On the banks of the Beaver, where seldom if ever  
Any poisonous herbage doth grow.  
   
A home, a home (on the range)  
Where the deer and the antelope play,  
Where seldom is heard a discouraging word  
And the sky is not clouded all day.  
   
How often at night, when the heavens were bright  
With the light of the glittering stars,  
Have I stood here amazed and asked as I gazed  
If their glory exceeds that of ours.  
   
A home, a home (on the range)  
Where the deer and the antelope play,  
Where seldom is heard a discouraging word  
And the sky is not clouded all day.  
   
I love the wild flowers in this bright land of ours;  
I love the wild curlew's shrill scream;  
The bluffs and white rocks and antelope flocks  
That graze on the mountains so green.  
   
A home, a home (on the range)  
Where the deer and the antelope play,  
Where seldom is heard a discouraging word  
And the sky is not clouded all day.  
   
The air is so pure, the breeze is so fine,  
The zephyrs so balmy and light,  
I would not exchange my home here to range  
Forever in azures so bright.

A home, a home (on the range)  
Where the deer and the antelope play,  
Where seldom is heard a discouraging word  
And the sky is not clouded all day.
