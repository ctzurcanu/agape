---
id: e74JxA-bt6A
title: "Imnul neamului - National anthem"
sidebar_label: "Imnul neamului - National anthem"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/e74JxA-bt6A"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Imnul neamului - National anthem

Lyrics: Vasile Militaru

Veniţi, români din larga zare,  
Mereu să fim uniţi, mereu,  
Să făurim o ţară mare,  
Să placă şi lui Dumnezeu!

Şi când spre noi veni-vor iară  
Vrăjmaşii care vin şi pier,  
Noi să fim trăznet ce doboară  
Stejari cu fruntea pân-la cer!

Să ştie cei ce pradă vor  
Că-aici va fi mormântul lor.

Că noi prin munţi şi văi mănoase,  
Pe care ard făclii de maci,  
Avem comori de sfinte oase:  
Avem strămoşi romani şi daci!

Trăit-am veacuri de robie;  
Strămoşii ne-au fost traşi pe roţi,  
Dar am păstrat a noastră glie  
Şi vom păstra-o-n viaţă toţi!

Să ştie cei ce pradă vor  
Că-aici va fi mormântul lor!

Aici va fi mormântul lor!

English:

Come, Romanians from the wide horizon,  
Let us always be united, always,  
Let us build a great country,  
May God be pleased too!

And when the enemies who come and perish will come to us again,  
Let us be the thunderbolt that knocks down  
Oak trees with their heads reaching to the sky!

Let those who want to plunder know  
That here will be their grave.

That we, through the mountains and valleys,  
On which poppy torches burn,  
We have treasures of holy bones:  
We have Roman and Dacian ancestors!

We have lived centuries of slavery;  
Our ancestors were dragged on wheels,  
But we have kept ours  
And we will all keep it alive!

Let those who want to plunder know  
That here will be their grave!

This will be their grave!
