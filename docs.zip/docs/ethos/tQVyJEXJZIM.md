---
id: tQVyJEXJZIM
title: "We are Singapore, 1987"
sidebar_label: "We are Singapore, 1987"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/tQVyJEXJZIM"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## We are Singapore, 1987

Lyrics: Hugh Harrison, 1987

There was a time when people said  
That Singapore won't make it, but we did  
There was a time when troubles seemed too much  
For us to take, but we did  
We built a nation, strong and free, reaching out together  
For peace and harmony!

This is my country, this is my flag  
This is my future, this is my life  
This is my family, these are my friends  
We are Singapore, Singaporeans!  
   
Singapore our homeland, it's here that we belong  
All of us united, one people marching on  
We've come so far together, our common destiny  
Singapore forever, a nation strong and free!  
   
This is my country, this is my flag  
This is my future, this is my life  
This is my family, these are my friends  
We are Singapore, Singaporeans!  
   
We, the citizens of Singapore  
Pledge ourselves as one united people  
Regardless of race, language or religion  
To build a democratic society  
Based on justice and equality  
So as to achieve happiness  
Prosperity and progress for our nation

We are Singapore, we are Singapore  
We will stand together, hear the lion roar  
We are Singapore, we are Singapore  
We're a nation strong and free forevermore!

This is my country, this is my flag  
This is my future, this is my life  
This is my family, these are my friends  
We are Singapore, Singaporeans!  
   
We are Singapore, we are Singapore  
We will stand together, hear the lion roar  
We are Singapore, we are Singapore  
We're a nation strong and free forevermore!  
   
We are Singapore, Singaporeans!  
We are Singapore, Singaporeans!
