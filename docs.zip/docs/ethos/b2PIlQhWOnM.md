---
id: b2PIlQhWOnM
title: "Победна песма - Victorious song (The Terrifying Judgement)"
sidebar_label: "Победна песма - Victorious song (The Terrifying Judgement)"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/b2PIlQhWOnM"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Победна песма - Victorious song (The Terrifying Judgement)

Lyrics: Св. владике Николаја Велимировића

"Ево долазим ускоро, и плата моја самном, да дам свакоме по делима његовим.  
Ја сам алфа и омега, први и последњи, почетак и свршетак" [(Oтк. 22, 12-13)]

Ево Господа са Војскама иде, душмани наши нека се застиде!  
Нека се застиде, нека се покају, погледај Војску Неба како блистају!  
Kако блистају, како се оре, слежу се пред њима високе горе.  
Високе горе и горди цари, погледај, иде Господ да се зацари.

Серафими напред па Херувими, сва земља гори сав свет се дими!  
Сав свет се дими, тешко се дише, радост и ужас ко да опише?!

Ко да опише чудо чудеса кад земљу грешну стегну Небеса!?  
Стегну Небеса својом близином, тад земља плоду слична је гњилом!  
Војске за Војском из Неба ничу, Ангели трубе, праведни кличу!  
Праведни кличу: "Ево Господа!", нека ишчезне земља и вода!

Земља и вода нашто нам више? Погледај, сад се збива што Писмо пише!  
Што Писмо пише све се догађа, ново се Небо и Земља рађа!

Ево Господа, устајте људи, ево Га иде свету да суди!  
Свету да суди, стадо да лучи, од стопа свемир тутњи и хучи!  
Тутњи и хучи земља и небо шта ће нам сада злато и сребро?  
Злато и сребро нека почине, а Ти нам блистај Божији Сине!  
   
"Ево долазим ускоро, и плата моја самном, да дам свакоме по делима његовим.  
Ја сам алфа и омега, први и последњи, почетак и свршетак"

English: Victorious song (The Terrifying Judgement)

"And, behold, I come quickly; and my reward is with me, to give every man according as his work shall be.  
I am Alpha and Omega, the beginning and the end, the first and the last." (Rev. 22, 12-13)  
   
Here comes the Lord with His Heavenly Host, let our enemies be ashamed!  
Let them be ashamed, let them repent, look how the Heavenly Host shines!  
How they shine, how loud they are, tall mountains crumble before them  
Tall mountains and prideful emperors, look, the Lord is coming to be enthroned  
Seraphims forward, Cherubims after them, the whole earth is burning, the whole world is in smoke!  
The whole world is in smoke, it's hard to breathe, such joy and horror, who could describe!?  
Who can describe the miracle of miracles when the sinful earth is clenched by Heaven!?  
Clenched by the closeness of Heaven, then the fruits of earth are like rotten fruit!  
Armies after Armies arrive from Heaven, Angels blow their trumpets, the righteous cry out!  
The righteous cry out: "Here comes the Lord!", let earth and water evaporate!  
Earth and water, what's their use to us anymore? Look, everything is happening as the Scripture foretold!  
What was written in Scripture is happening, a new Heaven and Earth are being born!  
Here comes the Lord, arise people, here He comes to judge the world!  
To judge the world, to tend to His flock, the universe rumbles and roars from His footsteps!  
Earth and sky rumble and roar, of what use are gold and silver to us now?  
Let gold and silver be put to rest, and may You shine for us, Son of God!

"And, behold, I come quickly; and my reward is with me, to give every man according as his work shall be.  
I am Alpha and Omega, the beginning and the end, the first and the last."
