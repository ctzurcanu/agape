---
id: yk_p45uQ5lk
title: "Canto dei Sanfedisti - Song of the Sanfedisti"
sidebar_label: "Canto dei Sanfedisti - Song of the Sanfedisti"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/yk_p45uQ5lk"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Canto dei Sanfedisti - Song of the Sanfedisti

Lyrics: Anon, 1799

A lu suono de la grancascia  
Viva lu populo bascio  
A lu suono de tamburrielli  
So' risurte li puverielli

A lu suono de campane  
Viva viva li pupulane  
A lu suono de viuline  
Morte alli Giacubbine  
   
Sona sona  
Sona Carmagnola  
Sona li cunzigli  
Viva 'o rre cu la famiglia  
Sona sona  
Sona Carmagnola  
Sona li cunziglie  
Viva 'o rre cu la famiglia

  
A sant'Eremo tanto forte  
L'hanno fatto comme 'a ricotta  
A 'stu curnuto sbrevognato  
L'hanno miso 'a mitria 'ncapo.

Maistà chi t'ha traruto  
Chistu stommaco chi ha avuto,  
'E signure 'o cavaliere  
Te vulevano priggiuniere.

Sona sona  
Sona Carmagnola  
Sona li cunzigli  
Viva 'o rre cu la famiglia  
Sona sona  
Sona Carmagnola  
Sona li cunziglie  
Viva 'o rre cu la famiglia

  
Alli tridece de giugno  
Sant'Antonio gluriuso  
'e signure 'sti birbante  
'e facettero 'o mazzo tanto  
   
So' venute li Francise  
Aute tasse 'nce hanno mise  
"Liberté, Egalité"  
Tu arrobbe a me, io arrobbo a te.  
   
Sona sona  
Sona Carmagnola  
Sona li cunzigli  
Viva 'o rre cu la famiglia  
Sona sona  
Sona Carmagnola  
Sona li cunziglie  
Viva 'o rre cu la famiglia

   
Li Francise so' arrivate  
'nce hanno bbuono carusate  
E vualà e vualà  
Cavece 'nculo alla libertà  
   
A lu ponte 'a Maddalena  
'onna Luisa è asciuta prena  
E tre miedece che banno  
Nun la ponno fa sgrava'  
   
Sona sona  
Sona Carmagnola  
Sona li cunzigli  
Viva 'o rre cu la famiglia  
Sona sona  
Sona Carmagnola  
Sona li cunziglie  
Viva 'o rre cu la famiglia

   
A lu muolo senza guerra  
Se tiraje l'albero 'nterra  
Afferrajeno 'e giacubbine  
'e facettero 'na mappina  
   
E' fernuta l'uguaglianza  
È fernuta la libertà  
Pe' vuje sò dulure 'e panza  
Signo' jateve a cucca'  
   
Sona sona  
Sona Carmagnola  
Sona li cunziglie  
Viva 'o rre cu la famiglia  
Sona sona  
Sona Carmagnola  
Sona li cunziglie  
Viva 'o rre cu la famiglia

  
Passaje lu mese chiuvuso,  
lu ventuso e l'addiruso;  
a lu mese ca se mete  
hanno avuto l'aglio arrete!

Viva Tata Maccarone  
ca rispetta la Religgione.  
Giacubine jate a mare  
mò v'abbrucia lu panaro!

Sona sona  
Sona Carmagnola  
Sona li cunziglie  
Viva 'o rre cu la famiglia  
Sona sona  
Sona Carmagnola  
Sona li cunziglie  
Viva 'o rre cu la famiglia

English:

At the sound of the drum  
Long live the bascio people  
At the sound of the tambourines  
The peasants have risen

At the sound of the bells  
Long live the pupulane  
At the sound of the violins  
Death to the Giacubbine

The bell rings  
The Carmagnola rings  
The cunziglie rings  
Long live the king with his family  
The bell rings  
The Carmagnola rings  
The cunziglie rings  
Long live the king with his family

At Sant'Eremo so strong  
They made him like ricotta cheese  
A curnuto frabognato  
They put a mitre on his head.

Majesty who took you away  
Who had this stomach,  
And lord the knight  
They wanted you prisoner.

Sona sona  
Sona Carmagnola  
Sound them cunzigli  
Long live your family  
Sona sona  
Sona Carmagnola  
Sound them cunziglie  
Long live your family

  
Alli tridece de June  
Saint Anthony Gluriuso  
'and signure this rascal  
'and they did a lot

Francise came there  
Aute taxes 'nce they have mise  
"Liberté, Egalité"  
You get angry at me, I'll get angry at you.

The bell rings  
The bell rings Carmagnola  
The bell rings the cunziglie  
Long live the king with his family  
The bell rings  
The bell rings Carmagnola  
The bell rings the cunziglie  
Long live the king with his family

The Francises have arrived  
They have good carusate  
And up and down  
They've got to fuck freedom

On the Maddalena bridge  
Lady Luisa is dry and ready  
And three men who want to leave  
They can't free her

The bell rings  
The bell rings Carmagnola  
The bell rings the cunziglie  
Long live the king with his family  
The bell rings  
The bell rings Carmagnola  
The bell rings the cunziglie  
Long live the king with his family

A lu muolo senza guerra  
If you pull the tree down  
They grab it jacubbine  
'e facettero 'na map

Equality is over  
Freedom is over  
For you to see how sweet your belly is  
Signo' go to bed

Soon soon  
Soon Carmagnola  
Soon the little ones  
Long live the king with his family  
Soon soon  
Soon Carmagnola  
Soon the little ones  
Long live the king with his family

We're spending the month closed,  
the windy and the hot;  
to the month that you put  
they had garlic stop!

Long live Tata Maccarone  
who respects Religion.  
Giacubine go to sea  
now your basket is burning!

Sona sona  
Sona Carmagnola  
Sound them cunziglie  
Long live your family  
Sounds sound  
Sona Carmagnola  
Sound them cunziglie  
Long live your family
