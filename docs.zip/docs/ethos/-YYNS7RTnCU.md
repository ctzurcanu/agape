---
id: -YYNS7RTnCU
title: "Invocaţie - Summoning"
sidebar_label: "Invocaţie - Summoning"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/-YYNS7RTnCU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Invocaţie - Summoning

Lyrics: Şerban Foarţă / Andrei Ujică (Phoenix)  
Original: https://www.youtube.com/watch?v=f65skE-alEA&list=PLJ2I_U9XF3oDbVnzt8NnLkFAz4dmVHFsf&index=1

Vouă, celor din hronici, pecetii şi herburi,   
fiarelor nepăscătoare de ierburi,   
nepăsătoare de carne de fiară, neumbrite de nour,   
nearse de soare: Pajură, Bour,   
cu schiptru şi tiară, -  
mă rog, să vă iviţi!   
să vă iviţi!

Pre voi, fiare heralde:  
alde Pardosu', alde  
Irog-inorogu'vă rog, să vă iviţi!   
să vă iviţi!

Fiarelor de bună şi de rea priinţă,   
pe cari vânătorul dac-o să le prindză,   
n-o să mi-se-aleagă cu pleavă şi abure,   
cu niscai sfarog: Fiarelor din fabule,   
din eticeşti şi de zăbavă cărţi,   
mă rog, să se ivească!   
să se ivească!

Vouă, cinstitelor, ţie, sperjure,   
şarpe sân-pomului jur-împrejure,   
fiarelor omului semiasemine:  
alde Sirenei, celui Chentaur  
cu gură de aur, ca a Hrisostomului,   
mă rog, să se ivească!   
să se ivească!

Fiare cuminţi, cu-o mie de dinţi,   
cu coadă de peşte, cu gheare la deşte,   
cu unghie de ţap, cu cap, făr-de-cap,   
cu blana ca sfecla, cu ochii ca stecla,   
cu ochii de vâlc, fiare cu tâlc,   
cu duhori suave, fiare filozoafe... Ave! 

... A psevdofiarelor cânt viaţa-neviaţa  
care nu se trece ca topită gheaţa,   
nu se risipeşte în văzduh ca ceaţa,   
nice nu se rumpe ca subţire aţa,   
au se ovileşte ca bătrână faţa;  
căci de zboară-mi zboară altfel decât raţa,   
se ivesc pe lume nu din ou ca raţa,   
nici nu-mi pasc fâneaţa-n toată dimineaţa,   
ci-şi păstrează pururi harul şi verdeaţa,   
taina şi dulceaţa, -  
fiindcă nici viaţă nu le e viaţa! 

  
Eu vă cânt şi vă descânt,   
vă invoc şi vă evoc,   
de noroc, de nenoroc,   
Vasilisc şi Inorog,   
Aspidă şi Zgripţor-Roc. 

Eu vă agrăiesc, vă isc,   
Inorog şi Vasilisc,   
frate Dulf cu ochi de sulf,   
dimpreună cu Adelfă,   
soru-ta, eu v-aduc jertfă. 

Şi tot eu îi ţin ison,   
Păsării Calandrinon,   
Păsării de da sau ba,   
ca şi ţie, dumneata,   
Scarabee, scara mea... 

Eu vă cânt,   
eu vă trec pragul,   
eu vă strig la ceasul fix  
şi tot eu vă uit de dragul  
împăratului Finics! 

Fie să renască numai cel ce har  
are de-a renaşte, curăţit prin jar,   
din cenuşa-i proprie şi din propriu-i scrum,   
astăzi, ca şi mâine, pururi şi acum.

English:

To you, those from chronics, seals and herbs,  
beasts who don't eat herbs,  
who don't mind beasts' meat, with no shadows from clouds  
unscorched by the sun: Griffon, Auroch,  
with scepter and tiara, -  
I beg you to show yourself!  
To you, herald beasts,  
like Pardos, like Irog-the unicorn, please, show yourself!  
   
Beasts of good and bad kind,  
which the hunter, if he's to catch them  
won't get only husks and steam,  
with something dry: Beasts from the fables,  
from moral and necessary books,  
I beg them to show themselves!  
   
To you, honest ones, to you, perjurer,  
snake of the saint tree around  
beasts of human halflike  
like mermaids, the Centaur  
with golden mouth, like the Chrysostom  
I beg them to show themselves!  
   
Gentle beasts, with a thousand teeth,  
with fishtails, with claws at their fingers  
with goat's nails, with head, no head  
with the fur like beetroot, with eyes like glass,  
with eyes of werewolves, beasts with moral  
with suave scents, philosophic beasts... Ave!  
   
....Of the false beasts I sing life - no life  
which doesn't go like the ice that's melted  
doesn't vanish like the fog in the sky  
nor breaks like the thread that's thin  
or wilts like the old face,  
cause if it flies other way than the duck  
they come into the world not from eggs like the duck  
nor they graze the pasture the whole morning,  
but they keep their gift forever and the greenness,  
secret and sweetness,  
cause neither life is their life!  
   
I sing to you and I enchant you  
I invoke you and I evoke you  
for luck, for bad luck  
Basilisk and Unicorn,  
Aspid and Evil-Roc  
   
I'm atalking, I'm starting you  
Unicorn and Basilisk  
brother Dulf with sulfur eyes  
together with Adelphe, your sister,  
I bring you sacrifice  
   
And still I'm the one keeping the rhythm  
To the Calandrinon bird,  
The bird of yes or no,  
like you, like yours,  
Scarabee, my ladder...  
   
I'm singing to you,  
I'm crossing your doorstep,  
I'm calling you at the fixed hour  
and still I forget you for the sake  
of emperor Phoenix!  
   
May it reborn only the one that gift  
Has to reborn, cleansed by ashes,  
from it's own ashes and own remains  
today, as tomorrow, forever and now.
