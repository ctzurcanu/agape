---
id: U6dqWlJsSck
title: "Blestem - Damnation 1"
sidebar_label: "Blestem - Damnation 1"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/U6dqWlJsSck"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Blestem - Damnation 1

Lyrics: Nicolae Labiş

Nicicînd durerea-n timp nu se îngroapă.  
La Mărășești, sub ploaia ca un plîns,  
În șanțul plin cu sînge și cu apă,  
Bunicul meu privirile și-a stins.  
Vestit-au surda-i trecere în moarte  
Obuzele nemțești cu foc păgîn,  
Și foc păgîn și schije iuți și sparte  
I-au înfundat obuzele-n plămîn.

Cînd peste nepăsarea gropii voastre  
Uitarea-și va așterne sur zăbun,  
Abia atunci au să se ostoiască  
Mîniile blestemului ce-l spun!

Pe cîmpul Turzii, pîrjolit de sete,  
Reînverzit de trupuri de soldați,  
Lăsat-a tata-n sunet de trompetă  
Puterea bărbătească-a unui braț.  
Eu n-am să uit scrisoarea lui vreodată,  
Parcă și-acum în palme o mai strîng -  
Scrisoarea lui cu slova tremurată,  
Ce-a scris-o în spital cu brațul stîng!

Cînd peste nepăsarea gropii voastre  
Uitarea-și va așterne sur zăbun,  
Abia atunci au să se ostoiască  
Mîniile blestemului ce-l spun!

Sînge la fel cu sîngele ce bate  
În tîmpla mea, pe cîmp de luptă-a curs -  
A curs prin brațul zdrențuit al tatii,  
Prin inima bunicului a curs,  
Și-a fumegat apoi sub bolți de zare  
Fum alb, bogat, cu pîlpîit contur,  
Ce s-a-mpletit pe cer cu fumul mare  
Zbucnit din Maidanek și Oradour.

Cînd peste nepăsarea gropii voastre  
Uitarea-și va așterne sur zăbun,  
Abia atunci au să se ostoiască  
Mîniile blestemului ce-l spun!

Cînd peste nepăsarea gropii voastre  
Uitarea-și va așterne sur zăbun,  
Abia atunci au să se ostoiască  
Mîniile blestemului ce-l spun!

English:

Pain is never buried by time.  
In Mărășești, under the rain like a cry,  
In the ditch full of blood and water,  
My grandfather looked away.  
The deaf announced his death  
German shells with heathen fire,  
And heathen fire and quick and broken shrapnel  
The shells stuck in his lung.

When over the carelessness of your pit  
His oblivion will lie on the ground,  
Only then will they be able to rest  
The rage of the curse that I pronounce!

On the Turzii field, parched with thirst,  
Overgrown with soldiers' bodies,  
Father left in a trumpet blast  
The manly power of one arm.  
I shall never forget his letter,  
It's as if I'm still holding it in my hands -  
His letter in shaky letters,  
What he wrote in the hospital with his left arm!

When over the indifference of your pit  
His oblivion will lie on the ground,  
Only then will they be able to rest  
The rage of the curse that I pronounce!

It bleeds like beating blood  
In my temple, on the battlefield, flowed -  
Flowed through father's ragged arm,  
Through the grandfather's heart flowed,  
He then smoked under vaults of buttermilk  
White smoke, rich, with flickering outline,  
What was woven into the sky with the big smoke  
Burst from Maidanek and Oradour.

When over the carelessness of your pit  
His oblivion will lie on the ground,  
Only then will they be able to rest  
The rage of the curse that I pronounce!

When over the indifference of your pit  
His oblivion will lie on the ground,  
Only then will they be able to rest  
The rage of the curse that I pronounce!
