---
id: Z8x2z3ZA3uI
title: "To France"
sidebar_label: "To France"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Z8x2z3ZA3uI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## To France

Lyrics: Mike Oldfield

Taking on water,  
Sailing a restless sea  
From a memory,  
A fantasy.  
The wind carries  
Into white water,  
Far from the islands.  
Don't you know you're

Never going to get to France.  
Mary, Queen of Chance, will they find you?  
Never going to get to France.  
Could a new romance ever bind you?

Walking on foreign ground,  
Like a shadow,  
Roaming in far off  
Territory.  
Over your shoulder,  
Stories unfold, you're  
Searching for sanctuary.  
You know you're

Never going to get to France.  
Mary, Queen of Chance, will they find you?  
Never going to get to France.  
Could a new romance ever bind you?

I see a picture  
By the lamp's flicker.  
Isn't it strange how  
Dreams fade and shimmer?

Never going to get to France.  
Mary, Queen of Chance, will they find you?  
Never going to get to France.  
Could a new romance ever bind you?

I see a picture  
By the lamp's flicker.  
Isn't it strange how  
Dreams fade and shimmer?

Never going to get to France.  
Mary, Queen of Chance, will they find you?  
Never going to get to France.  
Could a new romance ever bind you?

Never going to get to France.  
Never going to....

Never going to get to France.  
Never going to....
