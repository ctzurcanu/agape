---
id: FRCwiE2QAV8
title: "Morning Song שיר בוקר"
sidebar_label: "Morning Song שיר בוקר"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/FRCwiE2QAV8"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Morning Song שיר בוקר

Lyrics: Natan Alterman

בהרים כבר השמש מלהטת  
ובעמק עוד נוצץ הטל,  
אנו אוהבים אותך, מולדת,  
בשמחה, בשיר ובעמל.  
   
ממורדות הלבנון עד ים המלח  
נעבור אותך במחרשות,  
אנו עוד ניטע לך ונבנה לך,  
אנו ניפה אותך מאד.  
   
נלבישך שלמת בטון ומלט  
ונפרוש לך מרבדי גנים,  
על אדמת שדותייך הנגאלת  
הדגן ירנין פעמונים.  
   
המדבר, אנו דרך בו נחצובה,  
הביצות, אנחנו ניבשן,  
מה ניתן לך עוד להוד ושובע,  
מה עוד לא נתנו וניתן.

בהרים, בהרים זרח אורנו,  
אנו נעפילה אל ההר,  
האתמול נשאר מאחורינו  
אך רבה הדרך למחר.  
   
אם קשה היא הדרך ובוגדת,  
אם גם לא אחד יפול חלל,  
עד עולם נאהב אותך מולדת,  
אנו לך בקרב ובעמל!

English: Morning Song

Upon the mountains the sun is already scorching  
And in the valley the dew still glistens,  
We love thee, homeland,  
In joy, in song and in labor.  
   
From the slopes of Lebanon to the Dead Sea  
We shall cross thee with plows,  
We shall plant seeds and build over thee,  
We shall make thee oh so beautiful.  
   
We shall clothe thee with a dress of concrete and cement  
And spread garden carpets over thee,  
Upon the redeemed land of thy fields  
The grains shall ring like bells.  
   
The desert, we shall make a path in it,  
The swamps, we shall dry them  
What else should we give thee for thy glory and satisfaction,  
What else we haven't given and shall give.  
   
In the mountains, in the mountains our light has shone,  
We shall climb up the mountain,  
The yesterday is behind us  
But long is the way for tomorrow.  
   
If the road is hard and treacherous,  
If not only one shall drop dead,  
Forevermore we shall love thee, homeland,  
We are yours in battle and in labor!
