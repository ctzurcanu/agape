---
id: 6b4cMmF7O-o
title: "Poltava"
sidebar_label: "Poltava"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/6b4cMmF7O-o"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Poltava

Lyrics: Sabaton

Time has worn the soldiers down  
Marched for many miles  
In the eastern lands so cursed  
Time to make a stand

Tsar has scorched his nation’s land  
Nothing to be found  
Hunger grasps the soldiers’ heart  
20 000 strong  
   
Listen, excuse for a king  
Trust me, this fight you can’t win

Poltava  
Rode to certain death and pain  
Poltava  
Swedish soldiers met their bane  
Poltava  
Sacrificed their lives in vain  
Poltava

In the shade of morning mist  
Advancing on their foe  
Bullets break the silent air  
Wasted battleplan

Swedish forces stand alone  
King has left command  
Rule is left to lesser men  
Waiting for their chance

Listen, obey my command  
Hear me, or die by my hand

Poltava  
Rode to certain death and pain  
Poltava  
Swedish soldiers met their bane  
Poltava  
Sacrificed their lives in vain  
Poltava

Russian armies blocked their way  
20 000 lost that day  
They bled the ground  
Peace they found  
There’s no sign of victory  
King Carolus had to flee  
And leave the land  
Leave command

Madness, curse your feeble horde  
Fear me or you’ll die by my sword
