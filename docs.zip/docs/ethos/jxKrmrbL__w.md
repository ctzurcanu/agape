---
id: jxKrmrbL__w
title: "Deșteaptă-te, române! 02"
sidebar_label: "Deșteaptă-te, române! 02"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/jxKrmrbL__w"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Deșteaptă-te, române! 02

Deșteaptă-te, române! 02

Deșteaptă-te, române, din somnul cel de moarte,  
În care te-adânciră barbarii de tirani!  
barbarii de tirani!  
Acum ori niciodată, croiește-ți altă soartă,  
La care să se-nchine și cruzii tăi dușmani   
Acum ori niciodată, croiește-ți altă soartă,  
La care să se-nchine și cruzii tăi dușmani   
și cruzii tăi dușmani 

Acum ori niciodată să dăm dovezi la lume  
Că-n aste mâni mai curge un sânge de roman,  
un sânge de roman,  
Și că-n a noastre piepturi păstrăm cu fală-un nume  
Triumfător în lupte, un nume de Traian!   
Și că-n a noastre piepturi păstrăm cu fală-un nume  
Triumfător în lupte, un nume de Traian!   
un nume de Traian!  
       
Priviți, mărețe umbre, Mihai, Ștefan, Corvine,  
Româna națiune, ai voștri strănepoți,  
ai voștri strănepoți,  
Cu brațele armate, cu focul vostru-n vine,  
„Viața-n libertate ori moarte!” strigă toți  
Cu brațele armate, cu focul vostru-n vine,  
„Viața-n libertate ori moarte!” strigă toți  
"ori moarte!" strigă toți

Preoți, cu crucea-n frunte căci oastea e creștină,  
Deviza-i libertate și scopul ei preasfânt.  
și scopul ei preasfânt.  
Murim mai bine-n luptă, cu glorie deplină,  
Decât să fim sclavi iarăși în vechiul nost' pământ  
Murim mai bine-n luptă, cu glorie deplină,  
Decât să fim sclavi iarăși în vechiul nost' pământ   
în vechiul nost' pământ

Români din patru unghiuri, acum ori niciodată  
Uniți-vă în cuget, uniți-vă-n simțiri!  
uniți-vă-n simțiri!  
Strigați în lumea largă că Dacia-i furată  
Prin intrigă și silă, viclene uneltiri  
Strigați în lumea largă că Dacia-i furată  
Prin intrigă și silă, viclene uneltiri  
viclene uneltiri
