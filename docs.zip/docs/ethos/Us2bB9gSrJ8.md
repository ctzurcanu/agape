---
id: Us2bB9gSrJ8
title: "Ons Heemecht - Our Homeland"
sidebar_label: "Ons Heemecht - Our Homeland"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Us2bB9gSrJ8"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Ons Heemecht - Our Homeland

Lyrics: Michel Lentz, 1859  
https://en.wikipedia.org/wiki/Ons_Heemecht

Wou d'Uelzecht durech d'Wisen zéit,  
Duerch d'Fielsen d'Sauer brécht,  
Wou d'Rief laanscht d'Musel dofteg bléit,  
Den Himmel Wäin ons mécht:  
Dat as onst Land, fir dat mir géif  
Hei nidden alles won,  
Ons Heemechtsland dat mir sou déif  
An onsen Hierzer dron.  
Ons Heemechtsland dat mir sou déif  
An onsen Hierzer dron.

An sengem donkle Bëscherkranz,  
Vum Fridde stëll bewaacht,  
Sou ouni Pronk an deire Glanz  
Gemittlech léif et laacht;  
Säi Vollek frou sech soë kann,  
An 't si keng eidel Dreem:  
Wéi wunnt et sech sou heemlech dran,  
Wéi as 't sou gutt doheem!  
Wéi wunnt et sech sou heemlech dran,  
Wéi as 't sou gutt doheem!

Gesank, Gesank vu Bierg an Dall  
Der Äärd, déi äis gedron;  
D'Léift huet en treie Widderhall  
A jidder Broschts gedon;  
Fir, d'Hemecht ass keng Weis ze schéin;  
All Wuert, dat vun er klénkt,  
Gräift äis an d' Séil wéi Himmelstéin  
An d'A wéi Feier blénkt.  
Gräift äis an d' Séil wéi Himmelstéin  
An d'A wéi Feier blénkt.

O Du do uewen, deen seng Hand  
Duerch d'Welt d'Natioune leet,  
Behitt Du d'Lëtzebuerger Land  
Vru friemem Joch a Leed;  
Du hues ons all als Kanner schon  
De fräie Geescht jo ginn,  
Looss viru blénken d'Fräiheetssonn,  
Déi mir sou laang gesinn!  
Looss viru blénken d'Fräiheetssonn,  
Déi mir sou laang gesinn!

English:

Where the Alzette slowly flows,  
The Sauer plays wild pranks,  
Where fragrant vineyards amply grow  
On the Mosella's banks;  
There lies the land for which we would  
Dare everything down here,  
Our own, our native land which ranks  
Deeply in our hearts.   
Our own, our native land which ranks  
Deeply in our hearts. 

In her shady woodland of trees,  
Guarded stilly by peace,  
Without splendor nor pageantries,  
With warmth and love she laughes!  
Her folks with glee say to themselves,  
And they aren't void dreams:  
How homely 'tis to live therein,  
How great 'tis to be home.  
How homely 'tis to live therein,  
How great 'tis to be home.

Singing, chanting, from mount and vale,  
The earth who bore our births,  
Love has echoed a loyal gale,  
In each and every breast!  
For her, no song's too beautiful,  
Every word that rings from her,  
Our soul moves like sounds ethereal,  
And the eye shines like fire.  
Our soul moves like sounds ethereal,  
And the eye shines like fire.

O Thou above whose powerful hand  
Makes States or lays them low,  
Protect this Luxembourger land  
From foreign yoke and woe.  
Your spirit of liberty bestow  
On us now as of yore.  
Let Freedom's sun in glory glow  
For now and evermore.   
Let Freedom's sun in glory glow  
For now and evermore.
