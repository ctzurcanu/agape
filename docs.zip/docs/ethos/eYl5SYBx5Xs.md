---
id: eYl5SYBx5Xs
title: "Altaylardan Tunaya"
sidebar_label: "Altaylardan Tunaya"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/eYl5SYBx5Xs"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Altaylardan Tunaya

Lyrics: Ali Aksoy

Altaylardan Tuna’ya  
Kızıl Çin’le arası var.

Düştük kara sevdaya, loy loy   
Gönül güzel yarası var.  
Düştük kara sevdaya, loy loy   
Gönül güzel yarası var.

Al bizi de sürü sen,  
Bayrak olak bürü sen,

Hele durma yürü sen, loy loy  
Daha yolun yarısı var.  
Hele durma yürü sen, loy loy  
Daha yolun yarısı var.

Ölüm bize ar gelmez,  
Kara toprak dar gelmez,

Zındanları zor gelmez, loy loy  
Gözlerinin karası var…  
Zındanları zor gelmez, loy loy  
Gözlerinin karası var…

Başka nizam istemem,  
Yurtta tasa istemem,

Yasa masa istemem, loy loy  
Milletimin töresi var…  
Yasa masa istemem, loy loy  
Ulu Türk'ün töresi var…

Bir ülkedir uzakta,  
Yaralıdır tuzakta,

Uzağında kalsakta, loy loy  
Gönlümüzde orası var…  
Uzağında kalsakta, loy loy  
Gönlümüzde orası var…

Ele surat asacak,  
Zalime kan kusacak,

Sanma böyle susacak, loy loy  
Fırtınası, borası var…  
Sanma böyle susacak, loy loy  
Fırtınası, borası var…  
Sanma böyle susacak, loy loy  
Fırtınası, borası var…

Sanma böyle susacak, loy loy  
Her şeyin bir sırası var….
