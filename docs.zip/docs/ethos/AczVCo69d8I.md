---
id: AczVCo69d8I
title: "Rossiya - Russia"
sidebar_label: "Rossiya - Russia"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/AczVCo69d8I"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Rossiya - Russia

Lyrics: Ivan Novak, Laibach

United forever in vast, endless space  
Created in struggle by unhappy race  
We're sunrise of freedom  
We're frozen in ice  
United forever in great Russia's embrace.

From the Arctic Circle  
To the southern seas  
Deserted forests  
Neverending steps  
The unbreakable union  
Of fraternal states  
United forever in Great Russia's embrace

Славься, Отечество  
наше свободное,  
Славься, страна моя!  
Мы гордимся тобой!

Let's rise - as prisoners of starvation  
Let's rise - as damned of the Earth  
Let's get all together  
Let's break us free  
The world is changing  
At it's core

Long live great Russia's motherland  
Built by the people and their mighty hands  
Long live the young nation  
United and free  
Shining in glory  
For all men to see

Славься, Отечество  
наше свободное,  
Славься, страна моя!  
Мы гордимся тобой!

Славься, Отечество  
наше свободное,  
Славься, страна моя!  
Мы гордимся тобой!
