---
id: lXkLD6KVlwU
title: "Say It Loud: I'm Black And I'm Proud"
sidebar_label: "Say It Loud: I'm Black And I'm Proud"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/lXkLD6KVlwU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Say It Loud: I'm Black And I'm Proud

Lyrics: James Brown

Uh, with your bad self  
Say it louder (I got a mouth)  
Say it louder (I got a mouth)

Look a'here, some people say we got a lot of malice  
Some say it's a lotta nerve  
I say we won't quit moving  
Til we get what we deserve  
We've been buked and we've been scourned  
We've been treated bad, talked about  
As just as sure as you're born  
But just as sure as it take  
Two eyes to make a pair, huh  
Brother, we can't quit until we get our share

Say it loud,  
I'm black and I'm proud  
Say it loud,  
I'm black and I'm proud, one more time  
Say it loud,  
I'm black and I'm proud, huh

I've worked on jobs with my feet and my hands  
But all the work I did was for the other man  
And now we demands a chance  
To do things for ourselves  
we tired of beating our heads against the wall  
And working for someone else

Say it loud,  
I'm black and I'm proud  
Say it loud,  
I'm black and I'm proud  
Say it loud,  
I'm black and I'm proud  
Say it loud,  
I'm black and I'm proud, oowee

  
Ooowee, ou're killing me  
Alright uh, you're out of sight  
Alright, so tough, you're tough enough  
Ooowee uh, you're killing me, oow

Say it loud,  
I'm black and I'm proud  
Say it louder,  
I'm black and I'm proud

  
Now we demand a chance to do things for ourselves  
We tired of beating our heads against the wall  
And working for someone else  
A look a'here,  
One thing more I got to say right here  
Now, we're people like the birds and the bees  
We rather die on our feet,  
Than keep living on our knees

Say it loud,  
I'm black and I'm proud, hu  
Say it loud,  
I'm black and I'm proud, hu  
Say it loud,  
I'm black and I'm proud, Lord'a Lord'a Lord'a  
Say it loud,  
I'm black and I'm proud, ooooh

[Instrumental]

Uh, alright now, good Lord  
You know we can do the boog-a-loo  
Now we can say we do the Funky Broadway!  
Now we can do, hu  
Sometimes we dance, we sing and we talk  
You know I do like to do the camel walk  
Alright now, hu alright,  
Alright now, ha

Say it loud,  
I'm black and I'm proud  
Say it louder,  
I'm black and I'm proud, let me hear ya  
Say it louder,  
I'm black and I'm proud  
Say it louder,  
I'm black and I'm proud

[Instrumental]  
[Instrumental]

Now we's demands a chance to do things for ourselves  
We're tired of beating our heads against the wall  
And working for someone else, hu  
Now we're our people, too  
We're like the birds and the bees,  
But we'd rather die on our feet,  
Than keep a'living on our knees

Say it louder,  
I'm black and I'm proud  
Say it louder,  
I'm black and I'm proud, let me hear ha', huh  
Say it loud,  
I'm black and I'm proud, hu  
Say it louder,  
I'm black and I'm proud  
Say it louder,  
I'm black and I'm proud

Oooow, oowee, you're killing me, alright  
Uh, outa sight, alright you're outa sight  
Ooowee, oh Lord,  
Ooowee, you're killing me  
Ooowee, ooowee, ooowee, ooowee, ow
