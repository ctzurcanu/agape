---
id: Q92s_gaMF6Q
title: "Daniil Sihastrul - Daniel the Hesychast"
sidebar_label: "Daniil Sihastrul - Daniel the Hesychast"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Q92s_gaMF6Q"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Daniil Sihastrul - Daniel the Hesychast

Lyrics: Dimitrie Bolintineanu  
https://en.wikipedia.org/wiki/Daniil_Sihastrul

Sub o râpă stearpă, pe un râu în spume,  
Unde un sihastru a fugit de lume,  
Cu vărsarea serii un străin sosi.  
— „Ștefan al Moldovei vine a-ți vorbi!”

— „Ștefan al Moldovei, Daniil îi spune,  
Să aștepte-afară!  
Sunt în rugăciune.”

— „Bunule părinte!  
Sunt rănit și-nvins;  
Însăși a mea mumă astăzi m-a respins!

Viu sa-ți cer povața dacă nu-i mai bine  
Turcilor Moldova d-astăzi să se-nchine?”

Daniel Sihastru domnului a zis:  
— „Ma înșeală-auzul ori eu am un vis?  
Capul ce se pleacă paloșul nu-l taie,  
Dar cu umilință lanțu-l încovoaie!

Ce e oare traiul, dacă e robit?  
Sărbătoare-n care nimeni n-a zâmbit?  
Viața și robia nu pot sta-mpreună,  
Nu e tot d-odată pace și furtună.

Doamne! tu ai dreptul a schimba-n mormânturi  
Pentru neatârnare, oameni și pământuri;  
Dar nu ai p-acela ca să-i umilești!  
Poți ca să îi sfarâmi; dar nu să-i robești!

Dacă mâna-ți slabă sceptrul ți-o apasă,  
Altuia mai harnic locul tău îl lasă!  
Căci mai bine este supus lăudat,  
Decât cu rușine domn și atârnat!”

Căci mai bine este supus lăudat,  
Decât cu rușine domn și atârnat!”  
După-aceste vorbe, Ștefan strânge-oștire  
Și-nvingând păgânii 'nalță-o mânăstire.”

Și-nvingând păgânii 'nalță-o mânăstire.”

English:

Under a barren ravine, on a foaming river,  
Where a hermit fled from the world,  
With evening falling a stranger arrived.  
— “Stephen of Moldavia comes to speak to you!”

— “Stephen of Moldavia, Daniil tells him,  
Let him wait outside!  
I am in prayer.”

— “Good father!  
I am wounded and defeated;  
My own mother has rejected me today!

I live to ask your advice if it is not better  
For the Moldavian Turks to bow today?”

Daniel the Hermit said to the lord:  
— “Do my ears deceive me, or do I have a dream?  
The head that bows down is not cut off by the sword,  
But with humility the chain bends it!

What is life, if it is enslaved?  
A holiday where no one smiled?  
Life and slavery cannot coexist,  
It is not peace and storm at the same time.

Lord! you have the right to change into graves  
For disobedience, people and lands;  
But you do not have the right to humiliate them!  
You can crush them; but not to enslave them!

If your weak hand presses your scepter,  
To another more diligent your place leaves!  
For it is better to be praised,  
Than to be lord and hanged with shame!”

For it is better to be praised,  
Than to be lord and hanged with shame!”  
After these words, Stephen gathers an army  
And, defeating the pagans, 'raises a monastery.'

And defeating the pagans, he built a monastery.”
