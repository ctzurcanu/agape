---
id: kKLZ9FkLWtY
title: "Ballade des dames du temps jadis - Ballad of the Ladies of Times Past"
sidebar_label: "Ballade des dames du temps jadis - Ballad of the Ladies of Times Past"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/kKLZ9FkLWtY"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Ballade des dames du temps jadis - Ballad of the Ladies of Times Past

Lyrics: François Villon, 15th century

Dictes-moy où, n'en quel pays,  
Est Flora, la belle Romaine;  
Archipiada, ne Thaïs,  
Qui fut sa cousine germaine;  
Echo, parlant quand bruyt on maine  
Dessus rivière ou sus estan,  
Qui beauté eut trop plus qu'humaine?  
Mais où sont les neiges d'antan!

Où est la très sage Heloïs,  
Pour qui fut chastré et puis moyne  
Pierre Esbaillart à Sainct-Denys?  
Pour son amour eut cest essoyne.  
Semblablement, où est la royne  
Qui commanda que Buridan  
Fust jetté en ung sac en Seine?  
Mais où sont les neiges d'antan!

La royne Blanche comme ung lys,  
Qui chantoit à voix de sereine;  
Berthe au grand pied, Bietris, Allys;  
Harembourges, qui tint le Mayne,  
Et Jehanne, la bonne Lorraine,  
Qu'Anglois bruslèrent à Rouen;  
Où sont-ilz, Vierge souveraine?...  
Mais où sont les neiges d'antan!

Prince, n'enquerez de sepmaine  
Où elles sont, ne de cest an,  
Que ce refrain ne vous remaine:  
Mais où sont les neiges d'antan!

où sont   
les neiges   
d'antan?

English: 

Tell me where, in which country,  
Is Flora, the beautiful Roman;  
Archipiada, or Thaïs,  
Who was her close cousin;  
Echo, speaking when one makes a noise  
Over a river or on a pond,  
Who had beauty beyond the human?  
But where are the snows of yesteryear!

Where is the very wise Heloise,  
For whom Peter Abélard was castrated   
and then became a monk at Saint-Denis?  
He suffered this for her love.  
Similarly, where is the queen  
Who commanded that Buridan  
Be thrown in a sack into the Seine?  
But where are the snows of yesteryear!

Where is the very wise Heloise,  
For whom Peter Abélard was castrated   
and then became a monk at Saint-Denis?  
He suffered this for her love.  
Similarly, where is the queen  
Who commanded that Buridan  
Be thrown in a sack into the Seine?  
But where are the snows of yesteryear!

The Queen Blanche, as white as a lily,  
Who sang with a voice like a siren;  
Bertha Broadfoot, Beatrice, Alice;  
Haremburgis, who held the Maine,  
And Joan, the good Lorraine,  
Whom the English burned in Rouen;  
Where are they, Sovereign Virgin?...  
But where are the snows of yesteryear!

Prince, do not ask, in a week  
Where they are, nor of this year,  
Lest this refrain remain with you:  
But where are the snows of yesteryear!

Where are the snows of yesteryear!
