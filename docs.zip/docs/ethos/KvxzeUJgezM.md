---
id: KvxzeUJgezM
title: "Zurgălăul - The Carol Bell"
sidebar_label: "Zurgălăul - The Carol Bell"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/KvxzeUJgezM"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Zurgălăul - The Carol Bell

Lyrics: Nicolae Labiş

E Anul Nou. Ştiam noi ce mâine fi-va  
Şi ce-o să mai aducă anul nou?  
Un zurgălău stingher din nou porni-va  
Prin sate durerosul lui ecou?

Voi, oameni ai pământului, uitarea  
S-a aşternut pe sânge, scrum şi fier?  
N-aţi cunoscut ce-nseamnă aşteptarea  
Şi ce înseamnă-un zurgălău stingher?

Sculaţi, voi, boieri mari, s-arată zorii,  
Voci tragice pe vânturi se aprind.  
Treziţi-vă, vă vin colindătorii,  
Acuzatorii, asprul lor colind.

Am cunoscut cu toţi durerea ce e.  
Avem la masă câte-un scaun gol.  
Să n-aibă somn şi-n tihnă să nu steie  
Ei, alchimiştii noului pârjol!

Nicicând noi nu vom îngrăşa ogoare  
Aşa cum ei ne văd în visul lor,  
Prin bălării de foc, nimicitoare,  
Sub pălării de foc, nimicitor.

Sculaţi, voi, boieri mari, s-arată zorii,  
Voci tragice pe vânturi se aprind.  
Treziţi-vă, vă vin colindătorii,  
Acuzatorii, asprul lor colind.

Fulgi uriaşi deasupra ţării cad,  
Pe bărăgane vânturile ţipă,  
Somn neclintit de iarbă şi de brad  
Învăluieşte munţii sub aripă.

Sculaţi, voi, boieri mari, s-arată zorii,  
Voci tragice pe vânturi se aprind.  
Treziţi-vă, vă vin colindătorii,  
Acuzatorii, asprul lor colind.

English:

It's the New Year. We knew what tomorrow would be  
And what else will the new year bring?  
A strange tinkling will start again  
Through the villages its painful echo?

You, people of the earth, oblivion  
Has it spread over blood, ash and iron?  
Have you not known what waiting means  
And what does a strange tinkling mean?

Arise, you great boyars, dawn is breaking,  
Tragic voices on the winds are burning.  
Awake, the carolers are coming to you,  
The accusers, their harsh caroling.

We have all known the pain that is.  
We each have an empty chair at the table.  
May they not sleep and may they not rest in peace  
Oh, the alchemists of the new scorching!

We will never fatten the fields  
As they see us in their dream,  
Through the fiery flames, destroying,  
Under the fiery hats, destroying.

Awake, you great boyars, the dawn is breaking,  
Tragic voices on the winds are burning.  
Wake up, the carolers are coming to you,  
The accusers, their harsh caroling.

Giant flakes above the country are falling,  
On the stilts the winds are screaming,  
The unshakable sleep of grass and fir  
Envelops the mountains under their wing.

Awake, you great boyars, the dawn is breaking,  
Tragic voices on the winds are burning.  
Wake up, the carolers are coming to you,  
The accusers, their harsh caroling.
