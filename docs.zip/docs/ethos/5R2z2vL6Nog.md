---
id: 5R2z2vL6Nog
title: "Pecador, Contempla - O Sinner, Behold"
sidebar_label: "Pecador, Contempla - O Sinner, Behold"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/5R2z2vL6Nog"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Pecador, Contempla - O Sinner, Behold

Lyrics: Joaquín Díaz González  
https://es.wikipedia.org/wiki/Joaqu%C3%ADn_D%C3%ADaz_Gonz%C3%A1lez

Pecador contempla el día final  
en que han de dar cuenta los hijos de Adán.

En un verde valle que es de Josefat  
envuelto en pavesas, el mundo verás.

Acabado el mundo, debes contemplar  
que el cuerpo y el alma su unión buscarán.

Llamará Dios a Juicio a todo ser racional  
para que den cuenta del modo de obrar.

Dime, pecador si en gracia no estás  
cuando Dios te llama a su tribunal.

Tu seno de culpas allí se verá  
y aun las más ocultas, patentes serán.

Tu ángel de la guarda, allí te acusará  
y María Santísima no te amparará.

Allí el Juez severo gran cargo te hará  
de tu mala vida, tú responderás.

No habrá allí disculpas, ni se admitirán  
descargos a nadie de su mal obrar.

Dime, miserable, ¿de quién te valdrás  
si allí al más justo, temblar le verás?

Llorad vuestras faltas gemid y clamad  
que si grave es la culpa el infierno es más.

Es píldora amarga, dorado disfraz  
que se vende como azúcar siendo rejalgar.

Es serpiente astuta, dragón infernal  
basilisco que mata con solo mirar.

English: O Sinner Behold

O Sinner behold: the final day  
In which the children of Adam must give account  
   
In a green valley that belongs to Josefat  
Wrapped in cinders. The world you will see.  
   
Once the world is finished, You must contemplate  
That the body and soul will seek their union.  
   
Every rational being to judgment God shall call   
To give an account of the way they behaved.  
   
Tell me. Sinner. If in grace you are not  
When God shall call you to his court.  
   
Your sinful guilt shall be seen there and   
even the most hidden ones, Clear shall be.  
   
Your guardian angel there shall accuse you  
And Mary most holy will not protect you.  
   
There the severe judge shall charge you  
of your bad life. You will respond.  
   
There will be no apologies. Nor will there be admitted  
Blames onto anyone for their wrongdoing.  
   
Tell me. Miserable. Who will you call?  
If there the most just, Tremble you will see?  
   
Weep your sins. Groan and cry that if the guilt is serious.   
Even more, Hell is.  
   
It's a bitter pill. A golden disguise Which is sold as sugar being realgar.  
   
It is a cunning snake, a hellish dragon a basilisk that kills just by sight.
