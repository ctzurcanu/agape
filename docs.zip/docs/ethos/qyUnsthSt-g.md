---
id: qyUnsthSt-g
title: "Ceddin deden sözleri"
sidebar_label: "Ceddin deden sözleri"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/qyUnsthSt-g"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Ceddin deden sözleri

Ceddin deden, neslin baban  
Ceddin deden, neslin baban  
Hep kahraman Türk milleti  
Orduların pek çok zaman  
Vermiştiler Dünya'ya şan  
Orduların pek çok zaman  
Vermiştiler Dünya'ya şan  
   
Türk milleti, Türk milleti  
Türk milleti, Türk milleti  
Aşk ile sev milliyeti  
Kahret vatan, düşmanını  
Çeksin o mel'un zilleti  
Kahret vatan, düşmanını  
Çeksin o mel'un zilleti
