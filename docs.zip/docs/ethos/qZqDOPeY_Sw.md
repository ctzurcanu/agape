---
id: qZqDOPeY_Sw
title: "The Foggy Dew"
sidebar_label: "The Foggy Dew"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/qZqDOPeY_Sw"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## The Foggy Dew

Lyrics: The Wolfe Tones

As down the glen one Easter morn to a city fair rode I  
There Armed lines of marching men in squadrons passed me by  
No pipe did hum, no battle drum did sound its loud tattoo  
But the Angelus Bell o'er the Liffey's swell rang out through the foggy dew  
   
Right proudly high over Dublin Town they hung out the flag of war  
'Twas better to die 'neath an Irish sky than at Suvla or Sud-El-Bar  
And from the plains of Royal Meath strong men came hurrying through  
While Britannia's Huns, with their long range guns sailed in through the foggy dew

'Twas England bade our wild geese go, that "small nations might be free";  
Their lonely graves are by Suvla's waves or the fringe of the great North Sea.  
Oh, had they died by Pearse's side or fought with Cathal Brugha  
Their graves we'd keep where the Fenians sleep, 'neath the shroud of the foggy dew.  
   
Oh the night fell black, and the rifles' crack made perfidious Albion reel  
In the leaden rain, seven tongues of flame did shine o'er the lines of steel  
By each shining blade a prayer was said, that to Ireland her sons be true  
But when morning broke, still the war flag shook out its folds in the foggy dew

Oh the bravest fell, and the Requiem bell rang mournfully and clear  
For those who died that Eastertide in the spring time of the year  
And the world did gaze, in deep amaze, at those fearless men, but few,  
Who bore the fight that freedom's light might shine through the foggy dew  
   
As back through the glen I rode again and my heart with grief was sore  
For I parted then with valiant men whom I never shall see more  
But to and fro in my dreams I go and I kneel and pray for you,  
For slavery fled, O glorious dead, when you fell in the foggy dew.
