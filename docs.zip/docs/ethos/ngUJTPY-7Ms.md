---
id: ngUJTPY-7Ms
title: "Şafaktakiler - Those in the Dawn"
sidebar_label: "Şafaktakiler - Those in the Dawn"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/ngUJTPY-7Ms"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Şafaktakiler - Those in the Dawn

Lyrics: Erdal Güney

Yağlı kurşunlar yırtıyor geceyi,  
Korku dağları sarmasın yüreğim.  
Açmasın güller yolunda göçün,  
Yurdundan uzak atmasın yüreğim.

Yar yazman işli yazgımın karası.  
Ayrılık tutmuş ellerinin kınası.

Gelse de Rumeli elveda sırası.  
Yurdundan uzak atar mı yüreğim.

Yar yazman işli yazgımın karası.  
Ayrılık tutmuş ellerinin kınası.

Gelse de Rumeli elveda sırası.  
Yurdundan uzak atar mı yüreğim.

  
Alıcı kuşlar bekliyor geceyi.  
Zincire vursan durur mu yüreğim.  
Ayrılık verme sen kadir mevlam.  
Yarinden uzak atmasın yüreğim.

Yar yazman işli yazgımın karası.  
Ayrılık tutmuş ellerinin kınası.

Gelse de Rumeli elveda sırası.  
Yurdundan uzak atar mı yüreğim.

Yar yazman işli yazgımın karası.  
Ayrılık tutmuş ellerinin kınası.

Gelse de Rumeli elveda sırası.  
Yurdundan uzak atar mı yüreğim.

English:

Greasy bullets tear the night,  
Let my heart not embrace the mountains of fear.

Let the migration not bloom on the path of roses,  
Let my heart not beat far from its homeland.

My dear clerk, the black of my embroidered fate.  
The henna of your hands gripped by separation.

Even if Rumelia comes its farewell turn.  
Would my heart beat far from its homeland.

My dear clerk, the black of my embroidered fate.  
The henna of your hands gripped by separation.

Even if Rumelia comes its farewell turn.  
Would my heart beat far from its homeland.

The birds of prey are waiting for the night.  
Would my heart stop if you chained it.  
Don't give me separation, my powerful God.  
Let my heart not beat far from its lover.

My dear clerk, the black of my embroidered fate.  
The henna of your hands gripped by separation.

Even if Rumelia comes its farewell turn.  
Would my heart beat far from its homeland.

My dear clerk, the black of my embroidered fate.

The henna of your hands, gripped by separation.

Even if it is Rumelia's turn to say goodbye.  
Would my heart beat far from its homeland?
