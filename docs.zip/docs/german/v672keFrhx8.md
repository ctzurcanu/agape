---
id: v672keFrhx8
title: "Die Gedanken sind frei - The Thoughts are Free"
sidebar_label: "Die Gedanken sind frei - The Thoughts are Free"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/v672keFrhx8"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Die Gedanken sind frei - The Thoughts are Free

Lyrics: Anonymous, Traditional

Beleget den Fuß  
Mit Banden und mit Ketten  
Daß von Verdruß  
Er sich kann nicht retten,  
So wirken die Sinnen,  
Die dennoch durchdringen.  
Es bleibet dabei:  
Die Gedanken sind frei.

Die Gedanken sind frei  
Wer kann sie erraten?  
Sie fliehen vorbei  
Wie nächtliche Schatten;  
Kein Mensch kann sie wissen,  
Kein Kerker verschließen  
Wer weiß, was es sei?  
Die Gedanken sind frei.

Ich werde gewiß  
Mich niemals beschweren,  
Will man mir bald dies,  
Bald jenes verwehren;  
Ich kann ja im Herzen  
Stets lachen und scherzen;  
Es bleibet dabei:  
Die Gedanken sind frei

Ich denk was ich will  
und was mich erquicket,  
Und das in der Still  
Und wenn es sich schicket;  
Mein Wunsch und Begehren  
Kann Niemand mir wehren;  
Wer weiß was es sei?  
Die Gedanken sind frei.

Wird gleich dem Gesicht  
Das Sehen versaget,  
So werd ich doch nicht  
Von Sorgen geplaget.  
Ich kann ja gedenken,  
Was soll ich mich kränken?  
Es bleibet dabei:  
Die Gedanken sind frei.

Ja fesselt man mich  
Im finsteren Kerker,  
So sind doch das nur  
Vergebliche Werke.  
Denn meine Gedanken  
Zerreißen die Schranken  
Und Mauern entzwei:  
Die Gedanken sind frei.

English:

Covers the foot  
With bonds and chains  
So that from annoyance  
He cannot escape,  
So work the senses,  
Which nevertheless penetrate.  
It remains this:  
Thoughts are free.

Thoughts are free  
Who can guess them?  
They flee by  
Like night shadows;  
No man can know them,  
No prison can lock  
Who knows what it is?  
Thoughts are free.

I will certainly  
Never complain,  
Even if they want to deny me now this,  
now that;  
I can indeed in my heart  
Always laugh and joke;  
It remains this:  
Thoughts are free

I think what I want  
and what refreshes me,  
And that in silence  
And when it is appropriate;  
My wish and desire  
No one can prevent me;  
Who knows what it is?  
Thoughts are free.

Even if sight is denied,  
I am not plagued by worries.  
I can think,  
Why should I be offended?  
It remains the same:  
Thoughts are free.

Yes, if they bind me  
In a dark prison,  
they are only  
vain deeds.  
For my thoughts  
Tear down the barriers  
And tear apart the walls:  
Thoughts are free.
