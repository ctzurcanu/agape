---
id: JZfrPxLtMDk
title: "Alle meine Entchen - All My Ducklings"
sidebar_label: "Alle meine Entchen - All My Ducklings"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/JZfrPxLtMDk"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Alle meine Entchen - All My Ducklings

Lyrics: Anonymous, Traditional

Alle meine Entchen  
Schwimmen auf dem See,  
Schwimmen auf dem See,  
Köpfchen in das Wasser,  
Schwänzchen in die Höh.

Alle meine Täubchen  
Sitzen auf dem Dach,  
Sitzen auf dem Dach;  
Klipper, klapper, klapp, klapp,  
Fliegen übers Dach.

Alle meine Hühner  
Scharren in dem Stroh,  
Scharren in dem Stroh,  
Finden sie ein Körnchen,  
Sind sie alle froh.

Alle meine Gänschen  
Watscheln durch den Grund,  
Watscheln durch den Grund,  
Suchen in dem Tümpel,  
Werden kugelrund.

Alle meine Täubchen  
Sitzen auf dem Dach,  
Sitzen auf dem Dach;  
fliegt eins in die Lüfte,  
fliegen alle nach.

Alle meine Entlein  
Schwimmen über'm See  
Schwimmen über'm See  
s Köpferl unter'm Wasser,  
Schwänzlein in der Höh'.

Alle meine Vögel  
Fliegen hin und her  
Fliegen hin und her  
Fliegen auf und nieder  
Und das freut sie sehr.

Alle meine Häslein  
Sitzen in dem Klee  
Sitzen in dem Klee  
Schwänzchen in dem Rasen,  
Köpfchen in der Höh'

Alle meine Fröschlein  
Hüpfen auf und ab  
Hüpfen auf und ab  
Schreien dabei recht lustig,  
Quack, quack, quack, quack, quack.

Alle meine Puppen,  
Susi und Mari  
Susi und Mari  
Schlafen in der Wiege,  
Bis ich wecke sie.

Alle meine Kinder  
Tanzen lustig heut'  
Tanzen lustig heut'  
Tanzen voller Freude  
In der Sommerzeit.

English:

All my ducklings  
Swimming on the lake,  
Swimming on the lake,  
Heads in the water,  
Little tails up in the air!

All my little doves  
Sitting on the roof,  
Sitting on the roof;  
Clipper, clapper, clap, clap,  
They fly over the roof.

All my chickens  
Scratching in the straw  
Scratching in the straw  
Find a little grain,  
They're all happy.

All my goslings  
Waddle across the ground,  
Waddle across the ground,  
Search in the pond,  
Become round like a ball.

All my doves  
Sitting on the roof  
Sitting on the roof  
One flies in the air  
They all fly after.

All my ducklings  
Swim across the lake  
Swim across the lake  
Their little heads under the water  
Their little tails up high.

All my birds  
Fly back and forth  
Fly back and forth  
Fly up and down  
It makes them very happy.

All my little hares/rabbits  
Sit in the clover  
Sit in the clover  
Their little tails in the grass  
Their little heads up high.

All my little frogs  
Bounce up and down  
Bounce up and down  
Yell very comically  
Quack, quack, quack, quack, quack.

All my dolls  
Suzy and Mary  
Suzy and Mary  
Sleep in the cradle  
Till I wake them up.

All my children  
Dance merrily today  
Dance merrily today  
Dance full of joy  
In the summertime.
