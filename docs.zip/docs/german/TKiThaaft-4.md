---
id: TKiThaaft-4
title: "Hoppe, hoppe, Reiter - Hop, Hop, Rider"
sidebar_label: "Hoppe, hoppe, Reiter - Hop, Hop, Rider"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/TKiThaaft-4"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Hoppe, hoppe, Reiter - Hop, Hop, Rider

Lyrics: Anonymous, Traditional German

Hoppe, hoppe, Reiter,  
Wenn er fällt, dann schreit er.  
Fällt er in die Hecken,  
Tut er sich erschrecken.  
Fällt er in den Sumpf  
Macht der Reiter plumps!

Hoppe, hoppe, Reiter,  
Wenn er fällt, dann schreit er.  
Fällt er auf die Steine,  
Tun ihm weh die Beine.  
Fällt er in den Sumpf  
Macht der Reiter plumps!

Hoppe, hoppe, Reiter  
Wenn er fällt, dann schreit er  
Fällt er in den Graben  
Fressen ihn die Raben  
Fällt er in den Sumpf  
Macht der Reiter plumps!

English:

Hop, hop, rider,  
If he falls, he will cry.  
If he falls into the hedges,  
He will get frightened.  
If he falls into the mud,  
The rider falls with a splash!

Hop, hop, rider,  
If he falls, he will cry.  
If he falls on the stone,  
His leg will get hurt.  
If he falls into the mud,  
The rider falls with a splash!

Hop, hop, rider  
If he falls he will cry.  
If he falls into the ditch,  
He will be eaten by the ravens.  
If he falls into the mud,  
The rider falls with a splash!
