---
id: PLrZFPVQM38MesHDwXYBKv7H-Jk6ajwnii
title: "German"
sidebar_label: "German"
---

# German

This is the landing page for the playlist "German".

## Videos in this Playlist

- [Totentanz -  Dance of Death](/agape/german/V38bg1f61Bs)
- [Unser liebe Fraue - Our Lady](/agape/german/RJ9U88lRw-M)
- [Auferstanden Aus Ruinen - Risen from the Ruins](/agape/german/0hyq9sxp67Q)
- [Gott erhalte Franz den Kaiser - God save Franz the Emperor](/agape/german/ijxzW_y6AxA)
- [Südwesterlied - Southwester song](/agape/german/kS-K_QgBD5s)
- [Fridericus Rex Grenadiermarsch - King Frederick's Grenadier March](/agape/german/6pscQpgt3bI)
- [Die Eisenfaust am Lanzenschaft - The Iron Fist on the Lance's Shaft](/agape/german/L1AX8QvLZM8)
- [Y Gododdin 01 -  The Gododdin 01](/agape/german/dCCTIzZk-GU)
- [Hoppe, hoppe, Reiter - Hop, Hop, Rider](/agape/german/TKiThaaft-4)
- [Todesfuge - Death Fugue](/agape/german/5D2bhObHPDs)
- [Alle meine Entchen - All My Ducklings](/agape/german/JZfrPxLtMDk)
- [Die Gedanken sind frei - The Thoughts are Free](/agape/german/v672keFrhx8)
- [Morgenrot, Morgenrot leuchtest mir zum frühen Tod - Dawn, dawn, does it light my way to death?](/agape/german/rix6_Oi2fLo)
- [Herbsttag - Autumn Day](/agape/german/CSh3RVrLeQE)
- [Die Loreley - The Lorelei](/agape/german/lJC4Y9zxFCg)
- [Der Panther - The Panther](/agape/german/c7zOVuUd6Zw)
- [Die Lösung - The Solution](/agape/german/lUkdNEv--I0)
- [Wandrers Nachtlied - Wanderer's Night Song](/agape/german/dJwVPnBp3xU)
- [Hundert Mann und ein Befehl - A Hundred Men and a Command](/agape/german/cDW6yBp7Aok)
- [Palästinalied - Palestine song](/agape/german/4XzCaVss_y8)
- [Märchenkönigin - Crăiasa din poveşti](/agape/german/P0xh2eqfHwo)
- [Deutsche Verzweiflung - German Despair](/agape/german/k0f4gL3PF1M)
- [TotenTanz](/agape/german/WRXN-1UBQcg)

