---
id: 0hyq9sxp67Q
title: "Auferstanden Aus Ruinen - Risen from the Ruins"
sidebar_label: "Auferstanden Aus Ruinen - Risen from the Ruins"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/0hyq9sxp67Q"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Auferstanden Aus Ruinen - Risen from the Ruins

Lyrics: Johannes R. Becher, 1949

Auferstanden aus Ruinen  
und der Zukunft zugewandt,  
laß uns dir zum Guten dienen,  
Deutschland, einig Vaterland.  
Alte Not gilt es zu zwingen,  
und wir zwingen sie vereint,  
denn es muß uns doch gelingen,  
daß die Sonne schön wie nie  
über Deutschland scheint,  
über Deutschland scheint.

Glück und Friede sei beschieden  
Deutschland, unserm Vaterland.  
Alle Welt sehnt sich nach Frieden,  
reicht den Völkern eure Hand.  
Wenn wir brüderlich uns einen,  
schlagen wir des Volkes Feind.  
Laßt das Licht des Friedens scheinen,  
daß nie eine Mutter mehr  
ihren Sohn beweint,  
ihren Sohn beweint.

Laßt uns pflügen, laßt uns bauen,  
lernt und schafft wie nie zuvor,  
und der eignen Kraft vertrauend,  
steigt ein frei Geschlecht empor.  
Deutsche Jugend, bestes Streben  
unsres Volks in dir vereint,  
wirst du Deutschlands neues Leben.  
Und die Sonne schön wie nie  
über Deutschland scheint,  
über Deutschland scheint.

English: 

From the ruins risen newly,  
To the future turned, we stand.  
Let us serve your good weal truly,  
Germany, our fatherland.  
Triumph over bygone sorrow,  
Can in unity be won.  
For we shall attain a morrow,  
When over our Germany,  
There's the shining sun!  
There's the shining sun!

May both peace and joy inspire,  
Germany, our fatherland.  
Peace is all the world's desire,  
To the peoples lend your hand.  
In fraternity united,  
We shall crush the people's foe.  
Let all paths by peace be lighted,  
That no mother shall again  
Mourn her son in woe!  
Mourn her son in woe!

Let us plow and build our nation,  
Learn and work as never yet,  
That a free new generation,  
Faith in its own strength begets!  
German youth, for whom the striving  
Of our people is at one,  
You are Germany's reviving,  
And over our Germany,  
There's the shining sun!  
There's the shining sun!
