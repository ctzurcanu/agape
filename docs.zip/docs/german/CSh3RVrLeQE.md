---
id: CSh3RVrLeQE
title: "Herbsttag - Autumn Day"
sidebar_label: "Herbsttag - Autumn Day"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/CSh3RVrLeQE"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Herbsttag - Autumn Day

Lyrics: Rainer Maria Rilke

Herr: es ist Zeit. Der Sommer war sehr groß.  
Leg deinen Schatten auf die Sonnenuhren,  
und auf den Fluren laß die Winde los.

Befiehl den letzten Früchten voll zu sein;  
gieb ihnen noch zwei südlichere Tage,  
dränge sie zur Vollendung hin und jage  
die letzte Süße in den schweren Wein.

Wer jetzt kein Haus hat, baut sich keines mehr.

Wer jetzt kein Haus hat, baut sich keines mehr.  
Wer jetzt allein ist, wird es lange bleiben,  
wird wachen, lesen, lange Briefe schreiben  
und wird in den Alleen hin und her  
unruhig wandern, wenn die Blätter treiben.

English (Paul Archer):

Lord, the time has come. The summer has been so long.  
Lay your shadows over the sundials  
and let loose the wind over the fields.

Order the last fruits to fully ripen;  
give them two more days of southern sun,  
urge them to perfection and speed  
the last sweetness into the laden vine.

Those who have no house, will not build one now.

Those who have no house, will not build one now.  
Those who are alone will long remain so,  
they will rise, and read, and write long letters  
and through the avenues go here and there  
restlessly wandering, with the leaves drifting down.
