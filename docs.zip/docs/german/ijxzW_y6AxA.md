---
id: ijxzW_y6AxA
title: "Gott erhalte Franz den Kaiser - God save Franz the Emperor"
sidebar_label: "Gott erhalte Franz den Kaiser - God save Franz the Emperor"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/ijxzW_y6AxA"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Gott erhalte Franz den Kaiser - God save Franz the Emperor

Lyrics: Lorenz Leopold Haschka, 1797

Gott erhalte Franz den Kaiser,  
Unsern guten Kaiser Franz!  
Lange lebe Franz, der Kaiser,  
In des Glückes hellstem Glanz!  
Ihm erblühen Lorbeerreiser,  
Wo er geht, zum Ehrenkranz!  
Gott erhalte Franz den Kaiser,  
Unsern guten Kaiser Franz!

Laß von seiner Fahne Spitzen  
Strahlen Sieg und Fruchtbarkeit!  
Laß in seinem Rate Sitzen  
Weisheit, Klugheit, Redlichkeit;  
Und mit Seiner Hoheit Blitzen  
Schalten nur Gerechtigkeit!  
Gott erhalte Franz den Kaiser,  
Unsern guten Kaiser Franz!

Laß von seiner Fahne Spitzen  
Strahlen Sieg und Fruchtbarkeit!  
Laß in seinem Rate Sitzen  
Weisheit, Klugheit, Redlichkeit;  
Und mit Seiner Hoheit Blitzen  
Schalten nur Gerechtigkeit!  
Gott erhalte Franz den Kaiser,  
Unsern guten Kaiser Franz!

Ströme deiner Gaben Fülle  
Über ihn, sein Haus und Reich!  
Brich der Bosheit Macht, enthülle  
Jeden Schelm- und Bubenstreich!  
Dein Gesetz sei stets sein Wille,  
Dieser uns Gesetzen gleich.  
Gott erhalte Franz den Kaiser,  
Unsern guten Kaiser Franz!

Froh erleb' er seiner Lande,  
Seiner Völker höchsten Flor!  
Seh' sie, Eins durch Bruderbande,  
Ragen allen andern vor!  
Und vernehm' noch an dem Rande  
Später Gruft der Enkel Chor.  
Gott erhalte Franz den Kaiser,  
Unsern guten Kaiser Franz!\

English:

God save Franz the Emperor,  
Our good Emperor Franz!  
Long live Franz the Emperor,  
In the brightest splendor of happiness!  
Laurel branches bloom for him,  
Wherever he goes, as a wreath of honor!  
God save Franz the Emperor,  
Our good Emperor Franz!

Let victory and fertility shine from his banner's spires!

Let wisdom, prudence, and integrity reign in his council;  
And with His Highness's lightning,  
Let only justice reign!  
God save Franz the Emperor,  
Our good Emperor Franz!

Let victory and fertility shine from his banner's spires!

Let wisdom, prudence, and integrity reign in his council;  
And with His Highness' lightning,  
Let only justice reign!  
God save Franz the Emperor,  
Our good Emperor Franz!

May the abundance of your gifts flow  
Upon him, his house, and his empire! Break the power of evil, reveal  
Every rogue and rascally prank!  
May your law always be his will,  
This is like our law.  
God preserve Franz the Emperor,  
Our good Emperor Franz!

May he joyfully experience his lands,  
His peoples' highest prosperity!  
See them, united by brotherly bonds,  
Rising above all others!  
And still hear, at the edge  
Of the later tomb, the choir of the grandchildren.  
God preserve Franz the Emperor,  
Our good Emperor Franz!
