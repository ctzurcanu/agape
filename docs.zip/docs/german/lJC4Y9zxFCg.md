---
id: lJC4Y9zxFCg
title: "Die Loreley - The Lorelei"
sidebar_label: "Die Loreley - The Lorelei"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/lJC4Y9zxFCg"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Die Loreley - The Lorelei

Lyrics: Heinrich Heine, 1824

Ich weiß nicht, was soll es bedeuten,  
Daß ich so traurig bin;  
Ein Mährchen aus alten Zeiten,  
Das kommt mir nicht aus dem Sinn.

Die Luft ist kühl und es dunkelt,  
Und ruhig fließt der Rhein;  
Der Gipfel des Berges funkelt  
Im Abendsonnenschein.

Die schönste Jungfrau sitzet  
Dort oben wunderbar;  
Ihr gold’nes Geschmeide blitzet,  
Sie kämmt ihr gold’nes Haar.

Sie kämmt es mit gold’nem Kamme,  
Und singt ein Lied dabei;  
Das hat eine wundersame,  
Gewaltige Melodei.

Den Schiffer im kleinen Schiffe  
Ergreift es mit wildem Weh;  
Er schaut nicht die Felsenriffe,  
Er schaut nur hinauf in die Höh’.

Ich glaube, die Wellen verschlingen  
Am Ende Schiffer und Kahn;  
Und das hat mit ihrem Singen  
Die Lore-Ley gethan.

English:

I don't know what it can mean  
that I am so sad,  
a fairy-tale from ancient times,  
which I can't get out of my mind.

The air is cool and it's getting dark,  
and the Rhine is flowing peacefully;  
the mountain's peak is glittering  
in the evening sunshine.  
   
The most beautiful virgin is sitting  
up there, marvellously,  
her golden jewellery is sparkling,  
she combs her golden hair.

She combs it with a golden comb  
and at the same time sings a song  
that has a wondrous  
tremendous melody.  
   
The boatman in his little ship  
is seized by a mad woe;  
he doesn't see the rocky reefs,  
he's only looking up into the heights.

I believe the waves will engulf  
boatman and boat in the end,  
and that, with her singing,  
the Lorelei has done.
