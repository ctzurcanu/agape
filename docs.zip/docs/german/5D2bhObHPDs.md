---
id: 5D2bhObHPDs
title: "Todesfuge - Death Fugue"
sidebar_label: "Todesfuge - Death Fugue"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/5D2bhObHPDs"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Todesfuge - Death Fugue

Lyrics: Paul Celan, 1945

Schwarze Milch der Frühe wir trinken sie abends  
wir trinken sie mittags und morgens wir trinken sie nachts  
wir trinken und trinken  
wir schaufeln ein Grab in den Lüften da liegt man nicht eng  
Ein Mann wohnt im Haus der spielt mit den Schlangen der schreibt  
der schreibt wenn es dunkelt nach Deutschland  
dein goldenes Haar Margarete  
   
er schreibt es und tritt vor das Haus und es blitzen die Sterne  
er pfeift seine Rüden herbei  
er pfeift seine Juden hervor läßt schaufeln ein Grab in der Erde  
er befiehlt uns spielt auf nun zum Tanz  
   
Schwarze Milch der Frühe wir trinken dich nachts  
wir trinken dich morgens und mittags wir trinken dich abends  
wir trinken und trinken  
Ein Mann wohnt im Haus der spielt mit den Schlangen der schreibt  
der schreibt wenn es dunkelt nach Deutschland  
dein goldenes Haar Margarete  
Dein aschenes Haar Sulamith  
   
wir schaufeln ein Grab in den Lüften da liegt man nicht eng  
   
Er ruft stecht tiefer ins Erdreich ihr einen ihr andern singet und spielt  
er greift nach dem Eisen im Gurt er schwingts seine Augen sind blau  
stecht tiefer die Spaten ihr einen ihr anderen spielt weiter zum Tanz auf  
   
Schwarze Milch der Frühe wir trinken dich nachts  
wir trinken dich mittags und morgens wir trinken dich abends  
wir trinken und trinken  
ein Mann wohnt im Haus dein goldenes Haar Margarete  
dein aschenes Haar Sulamith er spielt mit den Schlangen  
   
Er ruft spielt süßer den Tod der Tod ist ein Meister aus Deutschland  
er ruft streicht dunkler die Geigen dann steigt ihr als Rauch in die Luft  
dann habt ihr ein Grab in den Wolken da liegt man nicht eng  
   
Schwarze Milch der Frühe wir trinken dich nachts  
wir trinken dich mittags der Tod ist ein Meister aus Deutschland  
wir trinken dich abends und morgens wir trinken und trinken  
der Tod ist ein Meister aus Deutschland sein Auge ist blau  
er trifft dich mit bleierner Kugel er trifft dich genau  
ein Mann wohnt im Haus dein goldenes Haar Margarete  
er hetzt seine Rüden auf uns er schenkt uns ein Grab in der Luft  
er spielt mit den Schlangen und träumet der Tod ist ein Meister aus  
Deutschland  
   
dein goldenes Haar Margarete  
dein aschenes Haar Sulamith

English:

Black milk of daybreak we drink it come evening  
we drink it come midday come morning we drink it come night  
we drink it and drink it  
we spade out a grave in the air there it won't feel so tight  
A man lives at home who plays with the vipers he writes  
he writes in the German-born nightfall  
the gold of your hair Margarete  
he writes it and steps out of doors and the stars are aglitter he whistles his hounds out  
he whistles his Jews off has them spade out a grave in the ground  
he orders us play up for the dance  
   
Black milk of daybreak we drink you come night  
we drink you come midday come morning we drink you come evening  
we drink you and drink you  
A man lives at home who plays with the vipers he writes  
he writes in the German-born nightfall the gold of your hair Margarete  
the ash of your hair Shulamith we spade out a grave in the air there it won't feel so tight  
   
He yells you there dig deeper and you there sing and play  
He grabs the nightstick at his belt and swings it his eyes are so blue  
You there dig deeper and you there play loud for the dance  
   
Black milk of daybreak we drink you come night  
We drink you come midday come morning we drink you come evening  
We drink you and drink you  
a man lives at home the gold of your hair Margarete  
the ash of your hair Shulamith he plays with the vipers  
he yells play sweeter for death Death is a German-born master  
yells scrape the strings darker you'll rise through the air like smoke  
and have a grave in the clouds there it won't feel so tight  
   
Black milk of daybreak we drink you come night  
we drink you come midday Death is a German-born master  
We drink you come evening come morning we drink you and drink you  
Death is a German-born master his eye is so blue  
He shoots with lead bullets he shoots you his aim is so true  
a man lives at home the gold of your hair Margarete  
he lets his hounds loose on us grants us a grave in the air  
he plays with his vipers and dreams a dream Death is a German-born master  
   
The gold of your hair Margarete  
The ash of your hair Shulamith
