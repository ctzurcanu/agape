---
id: cDW6yBp7Aok
title: "Hundert Mann und ein Befehl - A Hundred Men and a Command"
sidebar_label: "Hundert Mann und ein Befehl - A Hundred Men and a Command"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/cDW6yBp7Aok"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Hundert Mann und ein Befehl - A Hundred Men and a Command

Lyrics: Freddy Quinn

Irgendwo im fremden Land  
ziehen wir durch Stein und Sand.  
Fern von zu Haus und vogelfrei,  
hundert Mann, und ich bin dabei. 

Hundert Mann, und ein Befehl,  
und ein Weg, den keiner will.  
Tagein tagaus, wer weiß wohin?  
Verbranntes Land, und was ist der Sinn? 

Ganz allein in dunkler Nacht  
hab’ ich oft daran gedacht,  
daß weit von hier der Vollmond scheint  
und weit von mir ein Mädchen weint. 

Und die Welt ist doch so schön,  
könnt’ ich dich noch einmal seh’n.  
Nun trennt uns schon ein langes Jahr,  
weil ein Befehl unser Schicksal war. 

Wahllos schlägt das Schicksal zu,  
heute ich und morgen du.  
Ich hör’ von fern die Krähen schrei’n  
im Morgenrot, warum muß das sein? 

Irgendwo im fremden Land  
ziehen wir durch Stein und Sand.  
Fern von zu Haus und vogelfrei,  
hundert Mann, und ich bin dabei...

English:

Somewhere in a foreign land,  
we travel through stone and sand.  
Far from home and outlawed,  
a hundred men, and I'm there.

A hundred men, and a command,  
and a path no one wants.  
Day in day out, who knows where?  
Scorched land, and what's the point?

All alone in the dark night,  
I've often thought  
that far from here the full moon is shining  
and far from me a girl is crying.

And the world is so beautiful,  
if only I could see you once more.  
Now a long year has separated us,  
because an order was our fate.

Fate strikes randomly,  
today me and tomorrow you.  
I hear the crows crying from afar  
at dawn, why does it have to be?

Somewhere in a foreign land  
we travel through stone and sand.  
Far from home and outlawed,  
a hundred men, and I'm there...
