---
id: k0f4gL3PF1M
title: "Deutsche Verzweiflung - German Despair"
sidebar_label: "Deutsche Verzweiflung - German Despair"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/k0f4gL3PF1M"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Deutsche Verzweiflung - German Despair

Lyrics: Hoffmann von Fallersleben 

In Angst und bürgerlichem Leben  
wurde nie eine Kette gesprengt.  
Hier muß man schon mehr geben,  
die Freiheit wird nicht geschenkt.

Nicht Mord, noch Brand, noch Kerker,  
nicht Standrecht obendrein;  
es muß noch kommen stärker,  
soll es von Wirkung sein!

Sie sind die glücklichen Sklaven  
der Freiheit größter Feind,  
drum sollt Ihr Unglück haben  
und spüren jedes Leid.

Nicht Mord, noch Brand, noch Kerker,  
nicht Standrecht obendrein;  
es muß noch kommen stärker,  
soll es von Wirkung sein!

Zu Bettlern sollt ihr werden,  
verhungern allesamt,  
zu Mühen und Beschwerden  
verflucht sein und verdammt.

Nicht Mord, noch Brand, noch Kerker,  
nicht Standrecht obendrein;  
es muß noch kommen stärker,  
soll es von Wirkung sein!

Euch soll das bißchen Leben  
so gründlich sein verhaßt,  
daß Ihr es weg wollt geben  
wie eine schwere Last.

Nicht Mord, noch Brand, noch Kerker,  
nicht Standrecht obendrein;  
es muß noch kommen stärker,  
soll es von Wirkung sein!

Nun dann vielleicht erwacht noch  
in Euch ein neuer Geist,  
ein Geist, der über Nacht noch  
Euch hin zur Freiheit reißt!

Nicht Mord, noch Brand, noch Kerker,  
nicht Standrecht obendrein;  
es muß noch kommen stärker,  
soll es von Wirkung sein!

English:

In fear and civil life   
a chain was never broken.  
Here you have to give more,   
freedom is not given for free.

Refrain:  
Not murder, nor fire, nor dungeon,  
nor military law on top of that;  
it still has to become worse   
if it should be effective!

They are the happy slaves,  
freedom's greatest enemy,  
that's why you should have misfortune  
and feel every suffering.

You shall become beggars   
all of you should starve to death,  
to trouble and discomfort  
be cursed and damn it.

You should this little life   
hate so thoroughly  
that you want to give it away   
like a heavy burden.

Only then maybe a new spirit   
wakes up within you,  
a ghost that carries you   
to freedom overnight!
