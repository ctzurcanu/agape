---
id: WRXN-1UBQcg
title: "TotenTanz"
sidebar_label: "TotenTanz"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/WRXN-1UBQcg"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## TotenTanz

Ir mechtiger konig groiß und rich  
Ir must nu werden den armen glich  
Wan yr süllent noch bůde  
Sterben wie ander lüde  
Daz urteill got selber gegeben hait  
uber yeglichen mentschlichen staidt.  
Daz sie mußen in der erden  
Widderumb tzü eschen werden

Her fürt dů stolizer dümherr   
Dü besitzest nü und nũmer mee  
Dyn pfrund rent güld uñ gút  
Dar vor hetrestu dich nvt behudt.  
Troist dich selbst wan du müst sterben  
Uñ magst nyt lenger tsijll erwerben  
Laiß dyn dedyng und kom herfort  
Dich hait keyn bede noch suße wort.

Her wyrt her wirdt von bingen  
An dyßen reyen must du nu springé.  
Vil boßheit hast du begangé  
Myt falscher spijse und myt wyn langen  
Du hast gehalten lüde allerley  
Dye mit flüchen und schweren hatten eyn groiß geschrey.  
Des bist dü eyn ursach gewesen  
Bit goit das dyn sele moge genesen.

Du bruder salt nů myt myr gain  
Uñ salt doch goit ym hertzen hain.  
Du hast ane sunde gefurt dyn leben  
Zů gottes dienst dich gantz ergeben  
Und hast gesuchet nyt mere  
Dan dyn heyle und goittes ere  
Du hast uber geben willen uñ eygenmudt  
Umb gottes willen das ist dyr guit

Hantverckesman und auch dů leye  
Kumme nü auch an mynen reyen.  
Du pflechst abents lang tzü wachen  
Kleyder belz und schůwe tzü machen  
Gelden verkauffen lenen borgen  
Wenig vor die sele tzu sorgen  
Bys du kommest in lybes noit  
Und dich holt der bitrer doit

O groißer meister von pariß  
Werent ir nu gewest so wüse  
Uñ hettent studeret off den doit   
Sicherlich das were uch noit.  
Ir mußene nu glych dem leyen  
Spryngen myt myr an dyßen reyen  
Uñ dar zu uweren geyst off geben  
Wy woil yr meynet noch langer zů leben.

Nu kümmet her fürt von allem staidt  
We sych hye vor dißer dantze nyt en hait  
U wer iste vijll ich bin alleyn  
Doch ůberwinden ich uch alle gemeyn  
Uwer tzijt ist kommen yr müßet sterbé  
Langer tzijt mogent ir nyt erwerbé  
Synt yr gottes frunde das ist uch güt  
Ist des nyt so fart yr in der hellen gluit.
