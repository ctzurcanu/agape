---
id: c7zOVuUd6Zw
title: "Der Panther - The Panther"
sidebar_label: "Der Panther - The Panther"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/c7zOVuUd6Zw"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Der Panther - The Panther

Lyrics: Rainer Maria Rilke, 1903

Sein Blick ist vom Vorübergehn der Stäbe  
so müd geworden, daß er nichts mehr hält.  
Ihm ist, als ob es tausend Stäbe gäbe  
und hinter tausend Stäben keine Welt.

Der weiche Gang geschmeidig starker Schritte,  
der sich im allerkleinsten Kreise dreht,  
ist wie ein Tanz von Kraft um eine Mitte,  
in der betäubt ein großer Wille steht.

Nur manchmal schiebt der Vorhang der Pupille  
sich lautlos auf –. Dann geht ein Bild hinein,  
geht durch der Glieder angespannte Stille –  
und hört im Herzen auf zu sein.

English (Stephen Mitchell):

His vision, from the constantly passing bars,  
has grown so weary that it cannot hold  
anything else. It seems to him there are  
a thousand bars; and behind the bars, no world.

As he paces in cramped circles, over and over,  
the movement of his powerful soft strides  
is like a ritual dance around a center  
in which a mighty will stands paralyzed.

Only at times, the curtain of the pupils  
lifts, quietly--. An image enters in,  
rushes down through the tensed, arrested muscles,  
plunges into the heart and is gone.
