---
id: V38bg1f61Bs
title: "Totentanz -  Dance of Death"
sidebar_label: "Totentanz -  Dance of Death"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/V38bg1f61Bs"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Totentanz -  Dance of Death

https://en.wikipedia.org/wiki/Danse_Macabre

Ir mechtiger konig groiß und rich  
Ir must nu werden den armen glich  
Wan yr süllent noch bůde  
Sterben wie ander lüde  
Daz urteill got selber gegeben hait  
uber yeglichen mentschlichen staidt.  
Daz sie mußen in der erden  
Widderumb tzü eschen werden

Her fürt dů stolizer dümherr   
Dü besitzest nü und nũmer mee  
Dyn pfrund rent güld uñ gút  
Dar vor hetrestu dich nvt behudt.  
Troist dich selbst wan du müst sterben  
Uñ magst nyt lenger tsijll erwerben  
Laiß dyn dedyng und kom herfort  
Dich hait keyn bede noch suße wort.

Her wyrt her wirdt von bingen  
An dyßen reyen must du nu springé.  
Vil boßheit hast du begangé  
Myt falscher spijse und myt wyn langen  
Du hast gehalten lüde allerley  
Dye mit flüchen und schweren hatten eyn groiß geschrey.  
Des bist dü eyn ursach gewesen  
Bit goit das dyn sele moge genesen.

Du bruder salt nů myt myr gain  
Uñ salt doch goit ym hertzen hain.  
Du hast ane sunde gefurt dyn leben  
Zů gottes dienst dich gantz ergeben  
Und hast gesuchet nyt mere  
Dan dyn heyle und goittes ere  
Du hast uber geben willen uñ eygenmudt  
Umb gottes willen das ist dyr guit

Hantverckesman und auch dů leye  
Kumme nü auch an mynen reyen.  
Du pflechst abents lang tzü wachen  
Kleyder belz und schůwe tzü machen  
Gelden verkauffen lenen borgen  
Wenig vor die sele tzu sorgen  
Bys du kommest in lybes noit  
Und dich holt der bitrer doit

O groißer meister von pariß  
Werent ir nu gewest so wüse  
Uñ hettent studeret off den doit   
Sicherlich das were uch noit.  
Ir mußene nu glych dem leyen  
Spryngen myt myr an dyßen reyen  
Uñ dar zu uweren geyst off geben  
Wy woil yr meynet noch langer zů leben.

Nu kümmet her fürt von allem staidt  
We sych hye vor dißer dantze nyt en hait  
U wer iste vijll ich bin alleyn  
Doch ůberwinden ich uch alle gemeyn  
Uwer tzijt ist kommen yr müßet sterbé  
Langer tzijt mogent ir nyt erwerbé  
Synt yr gottes frunde das ist uch güt  
Ist des nyt so fart yr in der hellen gluit.

English:

(the King)  
You mighty king, great and rich,  
you must now  
You should be like the poor  
die like the other people  
God himself will make his judgment  
On every estate  
That they will go into the soil  
To become ashes again

  
(the Canon)  
Come here, you proud canon  
You don't own anything anymore  
Your prebends, interest, gold and goods  
You haven't protected yourself against this  
Comfort yourself in your moment of death  
and may not gain longer respite  
Leave your negotiations and step forward  
No prayers will help you, nor sweet words

(the Innkeeper)  
Mr. Innkeeper, Mr. Inkeeper of Bingen.  
you must join my circle dance.  
You have done much out of malice.  
With false food and diluted wine  
you have housed various people  
who loudly cursed and swore.  
You are accountable for this  
Pray to God that he may save your soul

(the Hermit)  
You brother shall now go with me  
and shall yet have God in your heart.  
You have lead your life free from sin  
and yielded yourself entirely to God's service  
and you have sought nothing more  
than salvation and God's honour  
you have renounced your own will and mind  
for God's will and that was good (for you).

(the Craftsman)  
Craftsman, you layman,  
you shall now come and join the circle dance  
You used to stay up late  
to craft clothes, fur and shoes  
pay, sell, lend and borrow,  
You take little care of your own soul  
until you come in mortal danger  
and the bitter Death fetches you

(the Doctor)  
O big master from Paris  
Had you been so wise  
and had also studied Death  
this surely would have been what you need.  
You must now, just like the layman,  
join me in my circle dance  
and surrender your spirit,  
even if you expect to live longer.

(the Death to all estates)  
Now come forward, from every estate  
who has abstained from this dance.  
You are many, I am alone;  
But still, I have to overcome you altogether  
Your time has come, you must die  
You can't gain more time  
Are you friends of God; that's good for you  
If not, then you will descent into Hell's Embers
