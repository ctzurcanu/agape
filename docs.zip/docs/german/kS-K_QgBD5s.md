---
id: kS-K_QgBD5s
title: "Südwesterlied - Southwester song"
sidebar_label: "Südwesterlied - Southwester song"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/kS-K_QgBD5s"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Südwesterlied - Southwester song

Lyrics: Heinz Anton Klein-Werner, 1937

Hart wie Kameldornholz ist unser Land  
Und trocken sind seine Reviere.  
Die Gräser, sie sind von der Sonne verbrannt  
Und scheu sind im Busch die Tiere.

Und sollte man uns fragen:  
Was hält euch denn hier fest?  
Wir könnten nur sagen:  
Wir lieben Südwest!  
Und sollte man uns fragen:  
Was hält euch denn hier fest?  
Wir könnten nur sagen:  
Wir lieben Südwest!

Doch unsre Liebe ist teuer bezahlt  
Trotz allem, wir lassen dich nicht.  
Weil unsere Sorgen überstrahlt,  
der Sonne hell leuchtendes Licht.

Und sollte man uns fragen:  
Was hält euch denn hier fest?  
Wir könnten nur sagen:  
Wir lieben Südwest!  
Und sollte man uns fragen:  
Was hält euch denn hier fest?  
Wir könnten nur sagen:  
Wir lieben Südwest!  
   
Und kommst auch du einmal in unser Land  
Und hast seine Weiten gesehen  
Und hat unsre Sonne ins Herz dir gebrannt  
Dann kannst du nicht wieder von hier gehen.

Und sollte man dich fragen:  
Was hält dich denn hier fest?  
Du könntest nur sagen:  
Ich liebe Südwest!  
Und sollte man dich fragen:  
Was hält dich denn hier fest?  
Du könntest nur sagen:  
Ich liebe Südwest!

English:

Our land is as hard as camelthorn wood  
And its territories are dry.  
The grasses are burned by the sun  
And the animals in the bush are shy.

And should anyone ask us:  
What keeps you here?  
We could only say:  
We love the southwest!  
And should anyone ask us:  
What keeps you here?  
We could only say:  
We love the southwest!

But our love comes at a high price  
Despite everything, we won't leave you.  
Because the sun's bright light outshines our worries.

And should anyone ask us:  
What keeps you here?  
We could only say:  
We love the southwest!  
And should anyone ask us:  
What keeps you here?  
We could only say:  
We love the southwest!

And if you too come to our land once  
And have seen its vastness  
And have our sun burned into your heart  
Then you won't be able to leave here again.

And if someone asked you:  
What keeps you here?  
You could only say:  
I love the Southwest!  
And if someone asked you:  
What keeps you here?  
You could only say:  
I love the Southwest!
