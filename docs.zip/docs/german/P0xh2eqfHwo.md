---
id: P0xh2eqfHwo
title: "Märchenkönigin - Crăiasa din poveşti"
sidebar_label: "Märchenkönigin - Crăiasa din poveşti"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/P0xh2eqfHwo"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Märchenkönigin - Crăiasa din poveşti

Lyrics: Mihai Eminescu  
Translation: Carmen Sylva (Queen Elisabeth of Romania)  
https://en.wikipedia.org/wiki/Elisabeth_of_Wied

Weiße Nebel sind vom Monde  
Silberglänzend ausgeflossen,  
Aus dem Wasser aufgestiegen,  
Auf die Felder ausgegossen.

Spinngewebe zu zerreißen,  
Alle Blumen sich vereinen;  
An der Nacht Gewänder hängen  
Beeren sie von Edelsteinen.

An dem See, um den die Wolken  
Einen feinen Schatten weben,  
Der durch's Wellenspiel zerrissen,  
Wie die hellen Schollen beben,

Leis das Schilf zur Seite teilend,  
Steht ein Mägdelein vorgebeugt,  
Schüttelt lauter rote Rosen  
Sanft hin auf die Zauberwogen.

Dass ein Bild erscheine, blickt sie  
Auf der Wasserkreise Gleiten,  
Denn es ward der See besprochen  
Von der Venus Wort vor Zeiten.

Dass ein Bild zur Fläche steige,  
Lässt sie junge Rosen fliehen,  
Denn die Göttin hat den Rosen  
Einstens Zauberkraft verliehen.

Schaut und schaut ... ihr Haar ist golden,  
Ihr Gesicht im Monde scheinet,  
In den blauen Augen haben  
Alle Märchen sich vereinet.

Romanian:

Neguri albe, strălucite  
Naşte luna argintie,  
Ea le scoate peste ape,  
Le întinde pe câmpie;

S-adun flori în şezătoare  
De painjen tort să rumpă,  
Şi anină-n haina nopţii  
Boabe mari de piatră scumpă.

Lângă lac, pe care norii  
Au urzit o umbră fină,  
Ruptă de mişcări de valuri  
Ca de bulgări de lumină,

Dându-şi trestia-ntr-o parte,  
Stă copila lin plecată,  
Trandafiri aruncă roşii  
Peste unda fermecată.

Ca să vad-un chip, se uită  
Cum aleargă apa-n cercuri,  
Căci vrăjit de mult e lacul  
De-un cuvânt al sfintei Miercuri;

Ca să iasă chipu-n faţă,  
Trandafiri aruncă tineri,  
Căci vrăjiţi sunt trandafirii  
De-un cuvânt al sfintei Vineri.

Ea se uită... Păru-i galben,  
Faţa ei lucesc în lună,  
Iar în ochii ei albaştri  
Toate basmele s-adună.
