---
id: 4XzCaVss_y8
title: "Palästinalied - Palestine song"
sidebar_label: "Palästinalied - Palestine song"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/4XzCaVss_y8"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Palästinalied - Palestine song

Lyrics: Walther von der Vogelweide, 13th century

Nû alrêst lebe ich mir werde,  
sît mîn sündic ouge siht  
daz hêre lant und och die erde,  
dem man vil der êren giht.  
   Mirst geschehen, des ich ie bat,  
   ich bin komen an die stat,  
   dâ got menschlîchen trat.

Schœne lant, rîch unde hêre,  
swaz ich der noch hân gesehen,  
sô bist dûz ir aller êre,  
waz ist wunders hie geschehen:  
   Daz ein maget ein kint gebar,  
   hêre uber aller engel schar,  
   was daz niht ein wunder gar?

Hie liez er sich reine toufen,  
daz der mensche reine sî.  
dô liez er sich hie verkoufen,  
daz wir eigen wurden vrî.  
   Anders wæren wir verlorn.  
   wol dir sper, cruze unde dorn!  
   wê dir, heiden! daz ist dir zorn.

Dô er sich wolte über uns erbarmen,  
hie leit er den grimmen tôt,  
er vil rîche über uns vil armen,  
daz wir komen ûz der nôt.  
   Daz in dô des niht verdrôz,  
   daz ist ein wunder alze grôz,  
   aller wunder übergenôz.

Hinnen vuor der sun zer helle,  
von dem grabe, dâ er inne lac.  
des was ie der vater geselle,  
und der geist, den nieman mac  
   Sunder gescheiden, dêst al ein,  
   sleht unde ebener danne ein zein,  
   alse er Abrahâm erschein.

Dô er den tievel dô geschande,  
daz nie keiser baz gestreit,  
dô vuor er her wider ze lande.  
dô huob sich der juden leit,  
   Daz er hêrre huote brach,  
   und daz man in sît lebendic sach,  
   den ir hant sluoc unde stach.

Dar nâch was er in deme lande  
vierzic tage, dô fuor er dar,  
dannen in sîn vater sande.  
sînen geist er uns bewar,  
   Den sant er hin wider zehant.  
   heilic ist daz selbe lant,  
   sîn name, der ist vor got erkant.

In diz lant hât er gesprochen  
einen angeslîchen tac,  
dâ die witwe wirt gerochen  
und der arme clagen mac  
   Und der weise den gewalt,  
   der dâ wirt an ime gestalt:  
   wol ime dort, der hie vergalt.

Unserre lantrehtære tihten  
fristet dâ niemannes clage,  
wan er wil dâ zestunt rihten:  
sô ist ez an dem lesten tage.  
   Und swer deheine schulde hie hât  
   unverebenet, wie der stât  
   dort, dâ er pfant noch bürgen hât.

Juden, Cristen unde heiden  
jehent, daz diz ir erbe sî.  
got sol uns ze reht bescheiden  
dur die sîne namen drî.  
   Al diu welt, diu strîtet her:  
   wir sîn an der rehten ger,  
   reht ist, daz er uns wer.

Irlât iuch nit verdriezen,  
daz ich noch gesprochen hân.  
sô wil ich die rede entsliezen  
kurzwîlen und ouch wizzen lân,  
   Swaz got wunders hie noch lie,  
   mit der welte ie begie,  
   daz huob sich dort und endet hie.

English:  
Palestine song

Now my life has gained its meaning  
since these sinful eyes behold  
the sacred land with meadows greening  
whose renown is often told.  
This was granted me from God:  
to see the land, the holy sod,  
which in human form He trod.  
   
Splendid lands of wealth and power,  
I’ve seen many, far and near,  
yet of all are you the flower.  
What a wonder happened here!  
That a maid a child should bear,  
Lord of all the angels fair,  
was not this a wonder rare?  
   
Here was He baptized, the Holy,  
that all people might be pure.  
Here He died, betrayed and lowly,  
that our bonds should not endure.  
Else our fate had been severe.  
Hail, O cross, thorns and spear!  
Heathens, woe! Your rage is clear.  
   
Out of pity for us,  
He suffered here the cruel parting.  
Out of pity for us  
He, the Almighty, allowed cursing.  
For us to escape misery,  
it is an immeasurable prodigy,  
more than any other prodigy.  
   
Then to hell the Son descended  
from the grave in which He lay,  
by the Father still attended,  
and the Spirit whom none may give a name:  
in one are three,  
an arrowshaft in unity.  
This did Abraham once see.  
   
When He there defeated Satan,  
ne’ er has kaiser battled so,  
He returned, our ways to straighten.  
Then the Jews had fear and woe:  
watch and stone were both in vain,  
He appeared in life again,  
whom their hands had struck and slain.  
   
Thereafter he walked this land,  
for forty days: then He ascended,  
from whence His Father had him on errand.  
His Spirit, may He protect us from the wicked,  
He at once sent back down.  
Holy is this very town,  
its name, is by God known.  
   
To this land, so He has spoken,  
shall a fearful judgment come.  
Widows’ bonds shall then be broken  
and the orphans’ foe be dumb,  
and the poor no longer cower  
under sad misuse of power.  
Woe to sinners in that hour!  
   
All the judgement of an earthly court,  
will give no man respite from accusation,  
for He will want at once to sort,  
for the Last Day annunciation:  
whoever leaves a single sin,  
unatoned here, how bereft he will stand facing Him,  
where he has neither surety nor kin.  
   
Christians, heathen, Jews, contending,  
claim it as a legacy.  
May God judge with grace unending  
through his blessed Trinity.  
Strife is heard on every hand:  
ours the only just demand,  
He will have us rule the land.  
   
Now do not ignore,  
what I have recited.  
My wish was to briefly explore,  
the discourse and to you I have presented,  
all the wonder that God has unfurled,  
upon man in this world,  
they began and ended here in this emerald.
