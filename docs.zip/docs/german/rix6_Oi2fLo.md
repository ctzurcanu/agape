---
id: rix6_Oi2fLo
title: "Morgenrot, Morgenrot leuchtest mir zum frühen Tod - Dawn, dawn, does it light my way to death?"
sidebar_label: "Morgenrot, Morgenrot leuchtest mir zum frühen Tod - Dawn, dawn, does it light my way to death?"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/rix6_Oi2fLo"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Morgenrot, Morgenrot leuchtest mir zum frühen Tod - Dawn, dawn, does it light my way to death?

Lyrics: Wilhelm Hauff, 1824

Morgenrot, Morgenrot  
leuchtest mir zum frühen Tod?  
Bald wird die Trompete blasen,  
dann muß ich mein Leben lassen,  
ich und mancher Kamerad,  
ich und mancher Kamerad.

Kaum gedacht, kaum gedacht,  
wird der Lust ein End' gemacht!  
Gestern noch auf stolzen Rossen,  
heute durch die Brust geschossen,  
morgen in das kühle Grab,  
morgen in das kühle Grab!

Ach wie bald, ach wie bald  
schwindet Schönheit und Gestalt!  
Prahlst du gleich mit deinen Wangen,  
die wie Milch und Purpur prangen?  
Ach, die Rosen welken all,  
Ach, die Rosen welken all'!

Und was ist, und was ist  
aller Erden Freud' und Lüst'?  
Unter Kummer, unter Sorgen,  
sich bemühen früh am Morgen,  
bis der Tag vorüber ist,  
bis der Tag vorüber ist!

Darum still, darum still  
füg' ich mich, wie Gott es will.  
Nun, so will ich wacker streiten,  
und sollt' ich den Tod erleiden,  
stirbt ein braver Reitersmann,  
stirbt ein braver Reitersmann!

English:

Dawn, dawn,  
does it light my way to an early death?  
Soon the trumpet will sound,  
then I must give up my life,  
I and many a comrade,  
I and many a comrade.

Scarcely thought, scarcely thought,  
my joy is brought to an end!  
Yesterday still on proud steeds,  
today shot through the chest,  
tomorrow into the cold grave,  
tomorrow into the cold grave!

Ah, how soon, oh, how soon,  
beauty and form vanish!  
Do you boast of your cheeks,  
that shine like milk and purple?  
Ah, all the roses are withering,  
Ah, all the roses are withering!

And what is, and what is  
all earth's joy and pleasure?  
Amidst sorrow, amidst cares,  
striving early in the morning,  
until the day is over,  
until the day is over!

Therefore, silently, silently,  
I submit myself as God wills.  
Now, then, I will fight bravely,  
and should I suffer death,  
a brave rider dies,  
a brave rider dies!
