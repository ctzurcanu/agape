---
id: dJwVPnBp3xU
title: "Wandrers Nachtlied - Wanderer's Night Song"
sidebar_label: "Wandrers Nachtlied - Wanderer's Night Song"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/dJwVPnBp3xU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Wandrers Nachtlied - Wanderer's Night Song

Lyrics: Johann Wolfgang von Goethe, 1780

Über allen Gipfeln  
Ist Ruh',  
In allen Wipfeln  
Spürest du  
Kaum einen Hauch;  
Die Vögelein schweigen im Walde.  
Warte nur, balde  
Ruhest du auch.

Der du von dem Himmel bist,  
Alles Leid und Schmerzen stillest,  
Den, der doppelt elend ist,  
Doppelt mit Erquickung füllest,  
Ach, ich bin des Treibens müde!  
Was soll all der Schmerz und Lust?  
Süßer Friede,  
Komm, ach komm in meine Brust!

Süßer Friede,  
Komm, ach komm   
in meine Brust!

English:

Above all the peaks  
There is peace,  
In every treetop  
You can barely feel a breath;  
The little birds are silent in the forest.  
Just wait, soon  
You too will rest.

You who are from heaven,  
You calm all suffering and pain,  
You fill him who is doubly miserable  
with double refreshment,  
Ah, I am tired of this hustle and bustle!  
What is the use of all this pain and pleasure?  
Sweet peace,  
Come, ah, come into my breast!

Sweet peace,  
Come, ah, come  
into my breast!
