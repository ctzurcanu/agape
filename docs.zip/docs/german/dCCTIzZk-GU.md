---
id: dCCTIzZk-GU
title: "Y Gododdin 01 -  The Gododdin 01"
sidebar_label: "Y Gododdin 01 -  The Gododdin 01"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/dCCTIzZk-GU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Y Gododdin 01 -  The Gododdin 01

Lyrics:  Llyfr Aneirin, Wales, ~1270

[I.]  
Gredyf gwr oed gwas  
Gwrhyt am dias  
Meirch mwth myngvras  
A dan vordwyt megyrwas  
Ysgwyt ysgauyn lledan  
Ar bedrein mein vuan  
Kledyuawr glas glan  
Ethy eur aphan  
Ny bi ef a vi  
Cas e rof a thi  
Gwell gwneif a thi  
Ar wawt dy uoli  
Kynt y waet elawr  
Nogyt y neithyawr  
Kynt y vwyt y vrein  
Noc y argyurein  
Ku kyueillt ewein  
Kwl y uot a dan vrein  
Marth ym pa vro  
Llad un mab marro

[II.]  
Kayawc kynhorawc men y delhei  
Diffun ymlaen bun med a dalhei  
Twll tal y rodawr ene klywei  
Awr ny rodei nawd meint dilynei  
Ni chilyei o gamhawn eny verei  
Waet mal brwyn gomynei gwyr nyt echei  
Nys adrawd gododin ar llawr mordei  
Rac pebyll madawc pan atcoryei  
Namen un gwr o gant eny delhei

[III.]  
Kaeawc kynnivyat kywlat erwyt  
Ruthyr eryr en ebyr pan llithywyt  
E arnot a vu not a gatwyt  
Grwell a wnaeth e aruaeth ny gilywyt  
Rac bedin ododin odechwyt  
Hyder gymhell ar vreithel vanawyt  
Ny nodi nac ysgeth w nac ysgwyt  
Ny ellir anet ry vaethpwyt  
Rac ergyt catvannan catwyt

[IV.]  
Kaeawc kynhorawc bleid e maran  
Gwevrawr godrwawr torchawr am rann  
Bu gwevrawr gwerthvawr gwerth gwin vann  
Ef gwrthodes gwrys gwyar disgrein  
Ket dyffei wyned a gogled e rann  
O gussyl mab ysgyrran  
Ysgwydawr angkyuan

[V.]  
Kaeawc kynhorawc aruawc eg gawr  
Kyn no diw e gwr gwrd eg gwyawr  
Kynran en racwan rac bydinawr  
Kwydei pym pymwnt rac y lafnawr  
O wyr deivyr a brennych dychiawr  
Ugein cant eu diuant en un awr  
Kynt y gic e vleid nogyt e neithyawr  
Kynt e vud e vran nogyt e allawr  
Kyn noe argyurein e waet e lawr  
Gwerth med eg kynted gan lliwedawr  
Hyueid hir ermygir tra vo kerdawr

English:

The Gododdin

I.  
He was a man in mind, in years a youth,  
And gallant in the din of war;  
Fleet, thick-maned chargers  
Were ridden by the illustrious hero;  
A shield, light and broad,  
Hung on the flank of his swift and slender steed;  
His sword was blue and gleaming,  
His spurs were of gold, his raiment was woollen.   
It will not be my part  
To speak of thee reproachfully,  
A more choice act of mine will be  
To celebrate thy praise in song;  
Thou hast gone to a bloody bier,  
Sooner than to a nuptial feast;  
Thou hast become a meal for ravens,  
Ere thou didst reach the front of conflict.   
Alas, Owain! my beloved friend;  
It is not meet that he should be devoured by ravens!  
There is swelling sorrow in the plain,  
Where fell in death the only son of Marro.

II.  
Adorned with his wreath, leader of rustic warriors, whenever he came  
By his troop unattended, before maidens would he serve the mead;  
But the front of his shield would be pierced, if ever he heard  
The shout of war; no quarter would he give to those whom he pursued;  
Nor would he retreat from the combat until blood flowed;  
And he cut down like rushes the men who would not yield.  
The Gododin relates, that on the coast of Mordei,   
Before the tents of Madog, when he returned,  
But one man in a hundred with him came. 

III.  
Adorned with his wreath, the chief of toil, his country’s rod of power,  
Darted like an eagle to our harbours, when allured  
To the compact that had been formed; his ensign was beloved,  
More nobly was his emblazoned resolution performed, for he retreated not,  
With a shrinking mind, before the host of Gododin.  
Manawyd, with confidence and strength thou pressest upon the tumultuous fight,  
Nor dost thou regard either spear or shield;  
No habitation rich in dainties can be found,  
That has been kept out of the reach of thy warriors’ charge.

IV.  
Adorned with a wreath was the leader, the wolf of the holme,  
Amber beads in ringlets encircled his temples;  
Precious was the amber, worth a banquet of wine.   
He repelled the violence of men, as they glided along;  
For Venedotia and the North would have come to his share,  
By the advice of the son of Ysgyran,  
The hero of the broken shield.

V.  
Adorned with his wreath was the leader, and armed in the noisy conflict;  
Chief object of observation was the hero, and powerful in the gory field,  
Chief fighter in the advanced division, in front of the hosts;  
Five battalions fell before his blades;  
Even of the men of Deivyr and Bryneich, uttering groans,  
Twenty hundred perished in one short hour;  
Sooner did he feed the wolf with his carcase, than go to the nuptial feast;  
He sooner became the raven’s prey, than approached the altar;  
He had not raised the spear ere his blood streamed to the ground;  
This was the price of mead in the hall, amidst the throng;  
Hyveidd Hir shall be celebrated whilst there remains a minstrel.
