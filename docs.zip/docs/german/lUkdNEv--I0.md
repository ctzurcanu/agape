---
id: lUkdNEv--I0
title: "Die Lösung - The Solution"
sidebar_label: "Die Lösung - The Solution"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/lUkdNEv--I0"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Die Lösung - The Solution

Lyrics: Bertolt Brecht

Nach dem Aufstand des 17. Juni  
Ließ der Sekretär des Schriftstellerverbands  
In der Stalinallee Flugblätter verteilen  
Auf denen zu lesen war, daß das Volk  
Das Vertrauen der Regierung verscherzt habe  
Und es nur durch verdoppelte Arbeit  
zurückerobern könne. Wäre es da  
Nicht doch einfacher, die Regierung  
Löste das Volk auf und  
Wählte ein anderes?

English:

After the uprising of June 17,  
the secretary of the Writers' Association  
had leaflets distributed on Stalinallee  
which stated that the people  
had lost the government's trust  
and could only regain it by redoubling their efforts.  
Wouldn't it be  
simper if the government  
dissolved the people and  
elected another?
