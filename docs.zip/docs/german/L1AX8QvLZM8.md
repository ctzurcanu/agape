---
id: L1AX8QvLZM8
title: "Die Eisenfaust am Lanzenschaft - The Iron Fist on the Lance's Shaft"
sidebar_label: "Die Eisenfaust am Lanzenschaft - The Iron Fist on the Lance's Shaft"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/L1AX8QvLZM8"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Die Eisenfaust am Lanzenschaft - The Iron Fist on the Lance's Shaft

Lyrics: Willi Nufer

Die Eisenfaust am Lanzenschaft,  
Die Zügel in der Linken,  
So sprengt des Reiches Ritterschaft  
Und ihre Schwerter blinken.  
   
Heja, heja, heja! Heja! Und ihre Schwerter blinken  
Heja, heja, heja! Heja! Und ihre Schwerter blinken  
   
Das Balkenkreuz, das schwarze, fliegt  
Voran auf weißem Grunde,  
Verloren zwar, doch unbesiegt.  
So klingt uns seine Kunde.  
   
Heja, heja, heja! Heja! So klingt uns seine Kunde.  
Heja, heja, heja! Heja! So klingt uns seine Kunde.  
   
Es flattert hell im Morgenwind  
Und grüßt der Grenzen Lande,  
Grüßt die, die uns're Brüder sind,  
Trotz Schmach und Not und Schande.  
   
Heja, heja, heja! Heja! Trotz Schmach und Not und Schande.  
Heja, heja, heja! Heja! Trotz Schmach und Not und Schande.  
   
Es fliegt voraus im Ritterskleid  
Und mahnet uns zu streiten,  
Für die verlorne Herrlichkeit,  
Drum Wimpel flieg, wir reiten.  
   
Heja, heja, heja! Heja! Drum Wimpel flieg, wir reiten.  
Heja, heja, heja! Heja! Drum Wimpel flieg, wir reiten.

  
English: 

The Iron Fist on the Lance's Shaft  
The iron fist on the lance's shaft,  
The reins on the left,  
Thus explode forth the knighthood of the empire  
And their swords flash.  
   
Heya, heya, heya! Heya! And their swords flash  
   
The Balkenkreuz, the black, flies  
ahead on the white ground,  
Abandoned but undefeated.  
Thus its tidings sound to us.  
   
Heya, heya, heya! Heya! Thus its tidings sound to us.  
   
It flutters brightly in the morning wind  
and greets the borderlands,  
Greets them, who are our brothers,  
despite disgrace, misery, and shame.  
   
Heya, heya, heya! Heya! Despite disgrace, misery, and shame.  
   
It flies ahead in knight's attire  
And urges us to fight  
for lost glory,  
therefore the pennants fly, and we ride.  
   
Heya, heya, heya! Heya! Therefore the pennants fly, and we ride.
