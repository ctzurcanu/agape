---
id: RJ9U88lRw-M
title: "Unser liebe Fraue - Our Lady"
sidebar_label: "Unser liebe Fraue - Our Lady"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/RJ9U88lRw-M"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Unser liebe Fraue - Our Lady

Lyrics:  Georg Forster, 1556  
https://en.wikipedia.org/wiki/Unser_liebe_Fraue_vom_kalten_Brunnen

Unser liebe Fraue  
vom kalten Bronnen,  
Bescher uns armen Landsknecht  
ein´ warme Sonnen!  
Dass wir nit erfrieren,  
gehn in des Wirtes Haus  
wir ein mit vollem Säckel,  
mit leerem wieder aus.

Die Drummen, die Drummen,  
Lärman, lärman, lärman,  
heiridiridiran, ridiran  
Ride Landsknecht voran.

Pam-pam pam-pam pam-pam

Unser liebe Fraue  
vom kalten Bronnen,  
bescher’ uns armen Landsknecht  
ein’ warme Sonnen!  
Dass wir nit erfrieren,  
iieh’n wir dem Bauermann  
das wullen Hemd vom Leibe,  
das steht ihm übel an.

Die Drummen, die Drummen,  
Lärman, lärman, lärman,  
heiridiridiran, ridiran  
Ride Landsknecht voran.

Pam-pam pam-pam pam-pam

Wir schlucken Staub beim Wandern  
der Säckel hängt uns hohl  
der Kaiser schluckt ganz Flandern  
bekomm’s ihm ewig wohl  
Er denkt beim Länderschmause  
wie er die Welt erwürb  
mir wohnt ein Lieb zu Hause  
das weinte, wenn ich stürb

Die Drummen, die Drummen,  
Lärman, lärman, lärman,  
heiridiridiran, ridiran  
Ride Landsknecht voran.

Pam-pam pam-pam pam-pam

Trommler schlägt Parade,  
die seid’nen Fahnen weh’n,  
jetzt heißt’s auf Glück und Gnade  
ins Feld marschieren geh’n.  
Korn reift auf den Feldern,  
es schnappt der Hecht im Strom,  
heiß weht der Wind von Geldern,  
herauf gen Berg op Zoom

Die Drummen, die Drummen,  
Lärman, lärman, lärman,  
heiridiridiran, ridiran  
Ride Landsknecht voran.

Pam-pam pam-pam pam-pam

Unser liebe Fraue  
vom kalten Bronnen,  
bescher’ uns armen Landsknecht  
ein’ warme Sonnen!  
Daß wir endlich finden  
von aller Arbeit Ruh!  
Der Teufel hol das Saufen,  
das Rauben auch dazu.

Die Drummen, die Drummen,  
Lärman, lärman, lärman,  
heiridiridiran, ridiran  
Ride Landsknecht voran.

English:

Our dear Lady of the Cold Spring,  
Bless us poor mercenaries  
a warm sun!  
So that we don't freeze,  
we'll go into the innkeeper's house  
with a full bag,  
and leave with an empty one.

The drummers, the drummers,  
Noise, noise, noise,  
heiridiridiran, ridiran  
Ride mercenaries ahead.

Pam-pam pam-pam pam-pam

Our dear Lady of the Cold Spring,  
bless us poor mercenaries  
a warm sun!  
So that we don't freeze,  
we'll tear the farmer's woolen shirt off his body,  
it looks bad on him.

The drummers, the drummers,  
Noise, noise, noise, noise,  
heiridiridiran, ridiran  
Ride mercenaries ahead.

Pam-pam pam-pam pam-pam

We swallow dust as we wander  
our purses hang hollow  
the emperor swallows all of Flanders  
may he be well forever  
he thinks at the country feast  
how he will win the world  
a love lives at home  
that would cry if I died

The drummers, the drummers,  
noise, noise, noise,  
heiridiridiran, ridiran  
Ride, Landsknecht ahead.

Pam-pam pam-pam pam-pam

Drummers sound parade,  
the silken flags wave,  
now it's time, by luck and mercy,  
to march into the field. Grain ripens in the fields,  
pike snaps in the stream,  
the wind blows hot from Geldern,  
up towards Berg op Zoom

The drummers, the drummers,  
Noise, noise, noise,  
heiridiridiran, ridiran  
Ride on, Landsknecht.

Pam-pam pam-pam pam-pam

Our dear Lady  
of the cold spring,  
give us poor Landsknechts  
a warm sun!  
So that we may finally find  
rest from all our work!  
The devil take the drinking,  
and the robbery too.

The drummers, the drummers,  
Noise, noise, noise, noise,  
heiridiridiran, ridiran  
Ride on, Landsknecht.
