---
id: v8di3nnig7s
title: "Марш сибирских стрелков - March of the Siberian Riflemen"
sidebar_label: "Марш сибирских стрелков - March of the Siberian Riflemen"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/v8di3nnig7s"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Марш сибирских стрелков - March of the Siberian Riflemen

https://en.wikipedia.org/wiki/Po_dolinam_i_po_vzgoriam

Из тайги, тайги дремучей,  
От Амура, от реки,  
Молчаливо, грозной тучей  
В бой идут сибиряки  
Молчаливо, грозной тучей  
В бой идут сибиряки.  
   
Их сурово воспитала  
Молчаливая тайга,  
Бури грозные Байкала  
И сибирские снега,  
Бури грозные Байкала  
И сибирские снега.  
   
Ни усталости, ни страха;  
Бьются ночь и бьются день,  
Только серая папаха  
Лихо сбита набекрень,  
Только серая папаха  
Лихо сбита набекрень.  
   
Эх, Сибирь, Сибирь родная  
За тебя мы постоим,  
Волнам Рейна и Дуная  
Твой поклон передадим,  
Волнам Рейна и Дуная  
Твой поклон передадим!

Знай, Сибирь, в лихие годы,  
В память славной старины,  
Честь великого народа  
Отстоят твои сыны,  
Честь великого народа  
Отстоят твои сыны.  
   
Русь свободная воскреснет,  
Нашей верою горя,  
И услышат эту песню  
Стены древнего Кремля,  
И услышат эту песню  
Стены древнего Кремля.

English:

From the taiga, the dense taiga,  
From the Amur, from the river,  
Silently, like a menacing cloud  
The Siberians go into battle  
Silently, like a menacing cloud  
The Siberians go into battle.

They were harshly brought up by  
The silent taiga,  
The menacing storms of Baikal  
And Siberian snows,  
The menacing storms of Baikal  
And Siberian snows.

No fatigue, no fear;  
The night fights and the day fights,  
Only the gray papakha  
Dashingly knocked down askew,  
Only the gray papakha  
Dashingly knocked down askew.

Eh, Siberia, native Siberia  
We will stand up for you,  
We will convey your bow to the waves of the Rhine and the Danube,  
We will convey your bow to the waves of the Rhine and the Danube!

Know, Siberia, in hard times,  
In memory of the glorious past,  
The honor of the great people  
Your sons will defend,  
The honor of the great people  
Your sons will defend.

Free Rus' will rise again,  
Burning with our faith,  
And the walls of the ancient Kremlin will hear this song,  
And the walls of the ancient Kremlin will hear this song.
