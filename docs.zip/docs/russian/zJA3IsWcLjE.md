---
id: zJA3IsWcLjE
title: "Полюшко-поле - Song of the Plains"
sidebar_label: "Полюшко-поле - Song of the Plains"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/zJA3IsWcLjE"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Полюшко-поле - Song of the Plains

Lyrics: Viktor Gusev, 1933  
https://en.wikipedia.org/wiki/Polyushko-pole

Полюшко, поле,  
Полюшко, широко поле,  
Едут ли по полю герои,  
Эх, да Красной Армии герои.   
   
Девушки плачут, и  
Девушкам сегодня грустно.  
Милый ли надолго уехал,  
Эх, да милый в армию уехал.  
   
Девушки, гляньте,  
Гляньте на дорогу нашу,  
Вьется дальняя дорога,  
Эх, да развеселая дорога.   
   
Едем мы, едем,  
Едем - а кругом колхозы,  
Наши, девушки, колхозы.  
Эх, да молодые наши села.  
   
Только мы видим,  
Видим мы седую тучу,  
Вражья злоба из-за леса,  
Эх, да вражья злоба, словно туча.  
   
Девушки, гляньте,  
Мы врага принять готовы,  
Наши кони быстроноги,  
Эх, да наши танки быстроходны.  
   
В небе за тучей  
Грозные следят пилоты.  
Быстро плавают подлодки.  
Эх, да корабли стоят в дозоре.

Пусть же в колхозе  
Дружная кипит работа,  
Мы - дозорные сегодня,  
Эх, да мы сегодня часовые.   
   
Девушки, гляньте,  
Девушки, утрите слезы.  
Пусть сильнее грянет песня,  
Эх, да наша песня боевая!  
   
Полюшко, поле,  
Полюшко, зелено поле!  
Едут-ли по полю герои,  
Эх, да Красной Армии герои.

English:

Polyushko, field,  
Polyushko, wide field,  
Are heroes riding across the field,  
Oh, yes, the heroes of the Red Army.

Girls are crying, and  
Girls are sad today.  
Has my dear one left for a long time,  
Oh, yes, my dear one has left for the army.

Girls, look,  
Look at our road,  
The long road winds,  
Oh, yes, the cheerful road.

We are riding, riding,  
Riding - and around are collective farms,  
Our collective farms, girls.  
Oh, yes, our young villages.

Only we see,  
We see a gray cloud,  
The enemy's malice from behind the forest,  
Oh, yes, the enemy's malice, like a cloud.

Girls, look,  
We are ready to meet the enemy,  
Our horses are swift-footed,  
Oh, yes, our tanks are fast.

In the sky, behind the cloud,  
Formidable pilots are watching.  
Submarines are sailing fast.  
Oh, yes, the ships are on patrol.

Let the collective farm  
Work be in full swing,  
We are the lookouts today,  
Oh, yes, we are the sentries today.

Girls, look,  
Girls, wipe away your tears.  
Let the song ring out louder,  
Oh, yes, our battle song!

Polyushka, field,  
Polyushka, green field!  
Heroes are riding across the field,  
Oh, yes, the heroes of the Red Army.
