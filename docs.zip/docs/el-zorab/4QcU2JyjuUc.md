---
id: 4QcU2JyjuUc
title: "El-Zorab (Romanian)"
sidebar_label: "El-Zorab (Romanian)"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/4QcU2JyjuUc"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## El-Zorab (Romanian)

Lyrics: George Coşbuc

La paşa vine un arab,  
Cu ochii stinşi, cu graiul slab.  
- "Sunt, paşă, neam de beduin,  
Şi de la Bab-el-Manteb vin  
Să vând pe El-Zorab.

Arabii toţi răsar din cort,  
Să-mi vadă roibul, când îl port  
Şi-l joc în frâu şi-l las în trap!  
Mi-e drag ca ochii mei din cap  
Şi nu l-aş da nici mort.

Dar trei copii de foame-mi mor!  
Uscat e cerul gurii lor;  
Şi de amar îndelungat,  
Nevestei mele i-a secat  
Al laptelui izvor!

Ai mei pierduţi sunt, paşă, toţi:  
O, mântuie-i, de vrei, că poţi!  
Dă-mi bani pe cal! Că sunt sărac!  
Dă-mi bani! Dacă-l găseşti pe plac,  
Dă-mi numai cât socoţi!

El poartă calul, dând ocol,  
În trap grăbit, în pas domol,  
Şi ochii paşei mari s-aprind;  
Cărunta-i barbă netezind  
Stă mut, de suflet gol.

- "O mie de ţechini primeşti?  
- "O, paşă, cât de darnic eşti!  
Mai mult decât în visul meu!  
Să-ţi răsplătească Dumnezeu,  
Aşa cum îmi plăteşti!

Arabul ia, cu ochii plini  
De zâmbet, mia de ţechini -  
De-acum, de-acum ei sunt scăpaţi,  
De-acum vor fi şi ei bogaţi,  
N-or cere la străini!

Nu vor trăi sub cort în fum,  
Nu-i vor cerşi copiii-n drum,  
Nevasta lui se va-ntrema;  
Şi vor avea şi ei ce da  
Săracilor de-acum! -

El strânge banii mai cu foc,  
Şi pleacă, beat de mult noroc,  
Şi-aleargă dus d-un singur gând,  
Deodată însă, tremurând,  
Se-ntoarce, stă pe loc.

Se uită lung la bani, şi pal  
Se clatină, ca dus de-un val,  
Apoi la cal priveşte drept;  
Cu paşii rari, cu fruntea-n piept,  
S-apropie de cal.

Cuprinde gâtul lui plângând  
Şi-n aspra-i coamă îngropând  
Obrajii palizi: - "Pui de leu,  
Suspină trist. Odorul meu,  
Tu ştii că eu te vând!

Copiii mei nu s-or juca  
Mai mult cu frunze-n coama ta,  
Nu te-or petrece la izvor:  
De-acum smochini, din mâna lor,  
Ei n-or avea cui da!

Ei nu vor mai ieşi cu drag  
Să-ntindă mâinile din prag,  
Să-i iau cu mine-n şea pe rând!  
Ei nu vor mai ieşi râzând  
În calea mea şirag!

Copiii mei cum să-i îmbun  
Nevestei mele ce să-i spun,  
Când va-ntreba de El-Zorab  
Va râde-ntregul neam arab  
De bietul Ben-Ardun!

Raira, tu, nevasta mea,  
Pe El-Zorab nu-l vei vedea  
De-acum, urmându-te la pas,  
Nici în genunchi la al tău glas  
El nu va mai cădea!

Pe-Ardun al tău, pe Ben-Ardun,  
N-ai să-l mai vezi în zbor nebun  
Pe urma unui şoim uşor  
Ca să-ţi împuşte şoimu-n zbor;  
Nu-i vei pofti: Drum bun!

Nu vei zâmbi, cum saltă-n vânt  
Ardun al tău în alb vestmânt;  
Şi ca să simţi sosirea lui  
Mai mult de-acum tu n-o să pui  
Urechea la pământ!

O, calul meu! Tu, fala mea,  
De-acum eu nu te voi vedea  
Cum ţii tu nările-n pământ  
Şi coada ta fuior în vânt,  
În zbor de rândunea!

Cum mesteci spuma albă-n frâu,  
Cum joci al coamei galben râu.  
Cum iei pământul în galop  
Şi cum te-aşterni ca un potop  
De trăsnete-n pustiu!

Ştia pustiul de noi doi  
Şi zarea se-ngrozea de noi -  
Şi tu de-acum al cui vei fi?  
Şi cine te va mai scuti  
De vânturi şi de ploi?

Nu vor grăi cu tine blând,  
Te-or înjura cu toţi pe rând  
Şi te vor bate,-odorul meu,  
Şi te-or purta şi mult, şi greu;  
Lăsa-te-vor flămând!

Şi te vor bate,-odorul meu,  
Să mori tu, cel crescut de noi!...  
Ia-ţi banii, paşă! Sunt sărac,  
Dar fără cal eu ce să fac:  
Dă-mi calul înapoi!

Se-ncruntă paşa: - "Eşti nebun?  
Voieşti pe ianiceri să-i pun  
Să te de-a câinilor? Aşa!  
E calul meu, şi n-aştepta  
De două ori să-ţi spun!

- Al tău? Acel care-l crescu  
Iubindu-l, cine-i: eu ori tu?  
De dreapta cui ascultă el,  
Din leu turbat făcându-l miel?  
Al tău? O, paşă, nu!

Al meu e! Pentru calul meu  
Mă prind de piept cu Dumnezeu -  
Ai inimă! Tu poţi să ai  
Mai vrednici şi mai mândri cai,  
Dar eu, stăpâne, eu?

Întreagă mila ta o cer!  
Alah e drept şi-Alah din cer  
Va judeca ce-i între noi,  
Că mă răpeşti şi mă despoi,  
M-arunci pe drum să pier.

Şi lumea te va blestema,  
Că-i blestem făptuirea ta!  
Voi merge, paşă, să cerşesc,  
Dar mila voastră n-o primesc -  
Ce bine-mi poţi tu da?

Dă paşa semn. - "Să-l dezbrăcaţi  
Şi binele în vergi i-l daţi!  
Sar eunucii, vin, îl prind -  
Se-ntoarce-arabul răsărind  
Cu ochii îngheţaţi...

El scoate grabnic un pumnal,  
Şi-un val de sânge, roşu val  
De sânge cald a izvorât  
Din nobil-încomatul gât,  
Şi cade mortul cal.

Stă paşa beat, cu ochi topiţi,  
Se trag spahiii-ncremeniţi.  
Şi-arabul, în genunchi plecat,  
Sărută sângele-nchegat  
Pe ochii-nţepeniţi.

Să-ntoarce-apoi cu ochi păgâni  
Şi-aruncă fierul crunt din mâini:  
- "Te-or răzbuna copiii mei!  
Şi-acum mă taie, dacă vrei,  
Şi-aruncă-mă la câini!
