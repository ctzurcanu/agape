---
id: m0m9G-zv2Nw
title: "El-Zorab (French)"
sidebar_label: "El-Zorab (French)"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/m0m9G-zv2Nw"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## El-Zorab (French)

Lyrics: George Coşbuc

Devant le pacha, vient un arabe,  
Les yeux cernés, la voix en rade:  
« - Pacha, je suis un bédouin,  
Et de Bab-el-Mandeb je viens  
Pour vendre El-Zorab.»

Les arabes tous, de leurs tentes sortent,  
Voir le pur sang comme il s' comporte.  
Il trotte, il frein, galope joyeux!  
Je l’aime autant que j’aime mes yeux,  
Je l’donnerais pas même mort.

Mais, j'ai trois enfants tous affamés!  
Ils sont très sèches leurs palais  
Ma femme, de par trop long chagrin,  
Elle vient de perdre ce matin,  
La source de son lait !

Nous sommes perdus, mais si tu veux  
Pacha, délivre nous, car tu le peux!  
Paye mon cheval, je suis un mendiant!  
Paye mon cheval si tu le trouves bien!  
Paye, ce que tu veux!

Il fait tourner en rond comme ca  
Tantôt au trop, tantôt au pas.  
Pacha le fixe les yeux brillants,  
Sa barbe grise en caressant  
Son âme vide, il ne bouge pas.

«-Une bourse de mille tzekins te va ? »  
«-Ô, bon et généreux pacha !  
-C’est plus que je n’avais rêvé !  
-Allah va te récompenser,  
Tel que tu me donneras! »

L’arabe, les yeux de joie remplis,  
Prends dans sa main les milles tzekins.  
Maintenant, oui ils sont sauvés,  
N’ont plus besoin de mendier,  
La quête aux étrangers - finie!

Finie la vie dans la fumée,  
Et ses enfants de mendier,  
Sa femme, va certainement guérir;  
Et ils auront de quoi offrir  
A ceux, dont le besoin y est !

Il serre l’argent avec ardeur,  
Et il s’en va, plein de bonheur,  
Il court, porté d’une seule pensée,  
Mais frissonnant, soudain, va s'arrêter,  
Figé sur place pris de frayeur.

Longuement fixant l'argent royal,  
il trébucha et il devient pâle,  
Vers son cheval il regarda;  
Des rares pas, la tête en bas,  
S'approche de son cheval.

Il prend son cou en pleurant,  
Sa crinière en caressant :  
Lui dit en soupirant, il le serre  
« - Ô mon enfant ! Prince du désert,  
Tu as a senti que je te vends »

Mes enfants ne s'amuseront guère  
Ne caresseront plus ta crinière..  
Ni vers la source t'accompagner  
Des figues de leurs mains te donner,  
Ce geste, ne vont plus le faire!

Ils n’en sortiront plus joyeux,  
Tendre les mains depuis l'préau,  
A cheval les prendre un par un,  
Comme ils sortaient toujours d'antan  
Tous, à la queue leu leu.

Ça sera le pire pour mes enfants  
Et que pourrais-je dire à ma femme  
Quand el demandera El Zorab?  
Je vais être la honte de tout arabe  
Moi, pauvre Ben Ardun.

Raira, ma femme, ma douce aimée  
El-Zorab tu ne verras plus jamais  
Dorénavant suivre tes pas,  
Ou à genoux au son de ta voix  
Comme il tombait!

Ton Ben Ardun tu ne verras plus  
En course folle comme tu l'a vu  
A la poursuite d'un aigle en vol  
Qui fusillé il tombe à sol,  
Ni la Bonne route- comme salut

Tu ne souriras plus quand dans le vent  
Vol ton Ardun en blancs vêtements  
Et pour sentir son arrivée,  
L'oreille au sol, tu ne vas plus coller  
Dorénavant

Oh mon cheval, o ma fierté!  
Je ne te reverrais plus jamais,  
Comment tu prends ton allure  
Au vent ta tête et chevelure  
Comme une l’hirondelle, voler!

Et la mousse blanche sur tes mors  
Ton jeu de crinière en jaune d’or  
Comment la terre au trop tu frappes  
Et comme tu t’étales comme une nappe  
Des foudres du désert sortent.

Le désert tout nous craignait  
Même l’horizon fut effrayé  
Et maintenant qui t’aura  
Et qui encore te défendra  
De vent et de pluies mouillés?

Ils ne vont pas te chouchouter.  
Chacun va plutôt jurer!  
Ils vont te battre, mon trésor,  
Ils vont te fatiguer d’abord,  
Et te laisser affamer!

Et à la guerre vont t’emmener  
Toi, que ma famille t’a élevé  
Pacha, prends ton argent : Tiens!  
Sans lui, moi que je deviens ?  
-Tu dois me le retourner!

-Tu es fou ? Crie pacha d’une acère voix  
Que mes janissaires ils doivent, tu crois  
Te jeter aux chiens ? Bien !  
Ce cheval est le mien  
-Je ne dirais pas deux fois

Le tiens ? Celui qui l’a élevé  
C’est moi ou toi ? qui l’a aimé ?  
Suite à quel ordre il faisait le beau  
Du lion enragé en doux agneau ?  
-Le tiens ? O pacha, non, tu peux rêver!

C’est le mien ! Pour mon cheval  
J’en prends Allah pour un rival  
Aie un bon cœur ! Tu peux avoir  
Des chevaux dignes de ta gloire  
Mais moi ? Maître royal ?

Je demande toute ta pitié  
Allah est droit, Allah va juger,  
Le différent car tu m’embrouilles  
Tu me kidnappes et me dépouilles  
Au mauvais sort suis-je jeté.

Le monde entier va te maudire  
-Maudit et ton geste on va le dire.  
-Je préfère pacha aller mendier  
-Je ne veux plus ta pitié  
-Tu me fais choisir le pire!

Pacha d’un signe : "Qu’il soit déshabillé  
Des coups des tiges vous lui donnez!"  
Les eunuques arrivent, attrapent l’arabe  
Mais lui esquive et puis très grave,  
Il va se retourner.

Les yeux glacés, il sort une dague  
Et rouge vague de sang, la vague  
De sang rouge et chaud elle jaillit  
D’une noble crinière, de sang salie  
Et il tombe mort le cheval swag!

Pacha se bloque, ivre, anéanti,  
Ainsi que tous les ébaillis spahis.  
Alors l’arabe agenouillé,  
Embrasse le sang coagulé  
Sur les yeux meurtris.

Il se retourne les yeux d'un Payen  
Il jette l'arme féroce de mains  
-Mes enfants vont te venger!  
Et maintenant tu peux me découper  
Et me jeter aux chiens!
