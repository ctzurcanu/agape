---
id: 5adb1hDbWQ0
title: "El-Zorab (English)"
sidebar_label: "El-Zorab (English)"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/5adb1hDbWQ0"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## El-Zorab (English)

Lyrics: George Coşbuc  
Translator (from Romanian): Octavian Cocoş

An Arab comes, looking like hell,  
His voice is weak, he can't speak well,  
– O, pasha, please, don't be severe,  
From Bab-el-Mandeb I've come here  
My EL-Zorab to sell.

All Arabs then approach with care  
To see my horse with reddish hair.  
I pull the reins, he trots a while  
I love him for his graceful style,  
I'd die to leave him there.

But my three kids do starve in pain  
Their mouth is dry, I go insane,  
And my wife's misery is great,  
Because her breasts are in such state  
They can't give milk again!

My dearest ones are cold as ice,  
But you, O, pasha, you are nice!  
Now buy the horse! I'm poor, indeed!  
Give me some money on the steed,  
Be good and name a price!

He takes the horse and rides about  
Slowly and fast, to clear his doubt;  
Then pasha's eyes begin to glow  
Touches his beard and his thoughts flow,  
His soul is somewhere out.

– One thousand sequins, you agree?  
– How noble, pasha, you can be!  
It's more than ever crossed my mind!  
May God be good to you and kind  
For how you're paying me!

The Arab takes with smiling eyes  
The golden sequins, his dear prize –  
From now on they will not be sad,  
From now on they'll be rich and glad  
Won't beg from foreign guys!

Won't live in tent and breathe the smoke  
His kids won't beg from other folk,  
His wife will be as was before  
And they themselves will give the poor  
Some money when they're broke! –

He grabs the money on a whim  
And leaves; the fate is good to him.  
Runs like a drunkard, out of mind,  
But suddenly he looks behind,  
Then stops, his sight is dim.

Gazes the money from the sale,  
Then falters and his face turns pale,  
Looks at the horse, into his eyes;  
And walking slowly, deeply sighs,  
Comes back along the trail.

He grabs his neck, he's crying, too,  
Caresses him, feeling so blue,  
And tells him: O, my lion dear,  
I know for you it's very clear  
That I am selling you.

My children will not play again  
By putting leaves on your thick mane,  
And will not lead you to the spring  
And figs from now to you won't bring,  
They'll wait for you in vain!

They won't come out day after day  
To reach out from the place they stay,  
To lift them on the horse's back!  
I will not see them on the track  
How laugh and keep my way!

How shall I still my children's yell,  
To my sweet wife what shall I tell  
When El-Zorab she will not see,  
The Arabs all will mock at me,  
My life will be like hell!

My wife, Raira, it is true  
Now, El-Zorab won't come to you  
To walk together, feel the breeze,  
He will not fall down on his knees  
The way he used to do!

And Ben-Ardun, your husband dear,  
Won't fly again, having no fear,  
To chase a hawk in its swift fly  
And shoot it down from the blue sky,  
You will not laugh and cheer!

You will not stare with happy face  
His clothes, which flutter in the race,  
And on the ground won't put your ear  
To hear the trot so loud and clear  
When comes back to his place!

O, my dear horse! You are my core,  
But I'll not see you anymore,  
How with your nose you sniff the ground  
How your thick tail you move around  
And in the sky you soar!

How every time you chew your foam,  
How jumps your mane when we two roam.  
How when you gallop people scream  
And how you rush like a big stream  
When we're away from home!

The desert knew us, I maintain,  
And the horizon was in pain –  
From now on who'll take care of you?  
Who will protect you, as I do,  
From winds and heavy rain?

They won't speak gently to you, dear,  
They'll curse you often around here  
And they will beat you with the whip  
And you'll endure their brutal grip;  
And you will starve in fear!

They'll treat you badly on the track  
And you will die like a poor hack!...  
O, pasha, I don't need your pay  
Without my horse I'll go astray  
I want to have him back.

The pasha frowns: “Are you insane?”  
My janissaries, it is plain,  
Can throw you to the dogs by force  
Because right now he is my horse,  
So stop pleading in vain!

– Your horse? Come on, then tell me who  
Has raised him, pasha: I or you?  
Whose arm obeys, when he's a ram,  
To turn him into a good lamb?  
Not yours, but mine, it's true!

He is my horse! And on a whim,  
I would fight God, for I'm not slim,  
Be nice, that's all I do request,  
Because your horses are the best,  
But I have only him!

Therefore, I ask you to be fair!  
Allah is just and from up there  
He'll judge and see how you behave  
And how you treat me like a slave,  
But you don't really care!

The world will curse you, you will see,  
With what you do, they disagree!  
I'll go to beg from other guys  
But from your coins I turn my eyes  
What good can give to me?

Then pasha orders, once, not twice,  
„Strip him and beat him as a price!”  
The eunucks quickly leave their place –  
The Arab turns with pallid face  
His sight is cold as ice...

Pulls out a dagger, looks ahead,  
And blood is flowing, thick and red,  
When cuts the throat wearing a mane  
And in a blink, without much pain,  
The noble horse falls dead.
