---
id: gLTfHohGSVE
title: "Joan of Arc, Supermaid - Joan's Light"
sidebar_label: "Joan of Arc, Supermaid - Joan's Light"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/gLTfHohGSVE"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Joan of Arc, Supermaid - Joan's Light

Joan of Arc, Supermaid - Joan's Light

Music:  Luca Turilli  
Original: Black Dragon https://www.youtube.com/watch?v=coM3Ahz6XEo  
Lyrics:  ChatGPT4  
             Christian Tzurcanu  
AI Voice Editor: Christian Tzurcanu
