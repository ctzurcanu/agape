---
id: ujWAriq0FT4
title: "Joan of Arc, Supermaid - Act 2: Joan's Soul"
sidebar_label: "Joan of Arc, Supermaid - Act 2: Joan's Soul"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/ujWAriq0FT4"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Joan of Arc, Supermaid - Act 2: Joan's Soul

Joan of Arc, Supermaid - Act 2: Joan's Soul

Music:  Andrew Lloyd Webber   
Lyrics:  Tim Rice  
             ChatGPT4  
             Christian Tzurcanu  
AI Voice Editor: Christian Tzurcanu
