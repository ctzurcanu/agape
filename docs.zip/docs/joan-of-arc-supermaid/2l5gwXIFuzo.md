---
id: 2l5gwXIFuzo
title: "Jeanne d'Arc Romée riding into Eternity"
sidebar_label: "Jeanne d'Arc Romée riding into Eternity"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/2l5gwXIFuzo"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Jeanne d'Arc Romée riding into Eternity

Jeanne d'Arc Romée riding into Eternity  
3D printed statue

Music: from Joan of Arc, Supermaid opera: https://youtu.be/180abRJwjdM?si=dInhYadOczC2RpI-&t=1721
