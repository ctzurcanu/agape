---
id: errU9nx02eQ
title: "Blaze of Faith"
sidebar_label: "Blaze of Faith"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/errU9nx02eQ"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Blaze of Faith

Blaze of Faith

Heroic rock for Jeanne d'Arc Romée

Additional material for https://youtube.com/playlist?list=PLrZFPVQM38MfDoCUSwVUyTPQlHmpw-oO8&si=VznYNNIHg-ECmWIs

[Verse 1]  
Flames licking my armor  
Iron will howling defiance  
Tied to a stake for glory  
My faith won’t be silenced

[Verse 2]  
Vision in the smoke dancing  
Voices guiding me higher  
Swords clashing in memories  
Feet burning on sacred pyre

[Chorus]  
Blaze of faith consume me whole  
Saint and soldier heart of gold  
Martyr’s fire crucible bold  
For Christ for kingdom burning soul

[Verse 3]  
Judges sneering in shadow  
Laughing at my falling tears  
Their chains won't break my spirit  
Flames are whispers to my ears

[Verse 4]  
Symbols of the holy shining  
Pain like thunder in tune  
Eternal light is calling  
Ashes lift toward the moon

[Chorus]  
Blaze of faith consume me whole  
Saint and soldier heart of gold  
Martyr’s fire crucible bold  
For Christ for kingdom burning soul

[Verse 4 bis]  
Symbols of the holy shining  
Pain like thunder in tune  
Eternal light is calling  
Ashes lift toward the moon

[Chorus]  
Blaze of faith consume me whole  
Saint and soldier heart of gold  
Martyr’s fire crucible bold  
For Christ for kingdom burning soul
