---
id: y2FsuJL7OjY
title: "À Jeanne D’Arc 03 - To Joan of Arc 03"
sidebar_label: "À Jeanne D’Arc 03 - To Joan of Arc 03"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/y2FsuJL7OjY"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## À Jeanne D’Arc 03 - To Joan of Arc 03

Lyrics: Alexandre Soumet, 1846

Dès l'âge de treize ans, du côté de l'Église  
Gentil Dauphin, j'avais entendu maintes fois  
A travers les rameaux venir de saintes voix  
Et ces voix me disaient, - souvenir adorable !  
Que pour garder toujours la paix inaltérable  
Il fallait rester pure, et de grandes clartés  
Venaient à la même heure et des mêmes côtés.

J'attendais ce moment avec beaucoup de joie  
On aime à voir venir ce que Dieu nous envoie !  
Quelquefois de ces voix j'étais intimidée ;  
Mais leurs sages conseils m'ont toujours bien guidée.

Un jour - j'en tremble encore et d'extase et d'effroi !...  
Un jour que priant Dieu pour la France et le roi  
J'ornais de frais rameaux l'Église du village  
Me croirez-vous ?... Je vis resplendir le feuillage  
Et dans l'air s'avancer à travers le vieux mur  
Monseigneur Saint Michel sous un manteau d'azur.

Du glaive flamboyant sa main était chargée  
Son aile blanche et grande et d'or toute frangée  
Se déployait en arc et sur son front béni  
Reposait le rayon d'un bonheur infini.

Son vol tout lumineux qui m'apparut sans voiles  
Faisait naître en passant des nuages d'étoiles  
Il brillait à mes yeux pleins de ravissement  
Comme un saphir tombé du haut du firmament.

Les lys que Salomon admirait dans leur gloire  
Ont un éclat moins pur que sa robe de moire ;   
Les airs sont moins légers que ses cheveux flottants  
Et sa voix ressemblait au souffle du printemps  
Lorsqu'il passe au matin, sous les branches fleuries  
Des tendres amandiers, bouquets de nos prairies...

L'archange qui venait de la part du Seigneur  
Et quand je le vis fuir aux voûtes éternelles  
Je lui dis en pleurant :   
- Prenez-moi sous vos ailes !... 

English:

From the age of thirteen, on the side of the Church  
Gentil Dauphin, I had heard many times  
Through the branches come holy voices  
And these voices told me, - adorable memory!  
That to always keep the unalterable peace  
It was necessary to remain pure, and great clarities  
Would come at the same time and from the same sides.

I awaited this moment with great joy  
We like to see what God sends us come!  
Sometimes I was intimidated by these voices;  
But their wise advice has always guided me well.

One day - I still tremble with ecstasy and fear!...  
One day when praying to God for France and the king  
I adorned the village Church with fresh branches  
Would you believe me?... I saw the foliage shine  
And in the air advance through the old wall  
Monsignor Saint Michel under a cloak of azure.

His hand was loaded with the flaming sword  
His white wing, large and fringed with gold  
Spread out in an arc and on his blessed brow  
Rested the ray of infinite happiness.

His luminous flight that appeared to me without veils  
Created clouds of stars as it passed  
He shone in my eyes full of delight  
Like a sapphire fallen from the heights of the firmament.

The lilies that Solomon admired in their glory  
Have a brilliance less pure than his moire robe;

The airs are less light than his floating hair  
And his voice resembled the breath of spring  
When he passes in the morning, under the flowering branches  
Of the tender almond trees, bouquets of our meadows...

The archangel who came from the Lord  
And when I saw him flee to the eternal vaults  
I said to him, weeping:  
- Take me under your wings!...
