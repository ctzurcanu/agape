---
id: GGqyoc1CA44
title: "Jésus, Jésus, je vais brûler !"
sidebar_label: "Jésus, Jésus, je vais brûler !"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/GGqyoc1CA44"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Jésus, Jésus, je vais brûler !

Je veux juste dire,  
S'il y a un moyen,  
Éloignez les flammes de moi,  
Car je suis plus faible que ce tourment.  
Je sens la brûlure, j'ai changé.

Une fois, j'entendais des voix, claires et étincelantes.  
Alors, j'étais choisie.  
Maintenant, je suis piégée et empoisonnée.  
Écoutez, j'ai sûrement rencontré les attentes du Ciel,  
Combattu une longue année, semblant vingt.  
Jésus a-t-il demandé autant à une autre âme ?

Mais si je brûle,  
Suis mon chemin et garde mon étendard fidèle,  
Qu'ils me moquent, me méprisent, me chaînent, me lient aux flammes.

Je veux savoir, je veux savoir, cher Jésus,  
Je veux savoir, je veux savoir, bon Jésus,  
Je veux voir, je veux voir, chers Saints,  
Je veux voir, je veux voir, bons Saints,  
Pourquoi dois-je brûler ?

Mon nom brillera-t-il plus qu'il ne l'a jamais fait auparavant ?  
Tous les cœurs qui ont bougé battront-ils le même tambour pour toujours ?

J'ai besoin de savoir, j'ai besoin de savoir, cher Jésus,  
J'ai besoin de savoir, j'ai besoin de savoir, bon Jésus,  
J'ai besoin de voir, j'ai besoin de voir, chers Saints,  
J'ai besoin de voir, j'ai besoin de voir, bons Saints,

Si je suis cendre, quelle sera ma couronne ?  
Si je suis cendre, quelle sera ma couronne ?  
J'ai besoin de savoir, j'ai besoin de savoir, cher Jésus,  
J'ai besoin de savoir, j'ai besoin de savoir, bon Jésus,  
Pourquoi dois-je brûler ? Oh, pourquoi dois-je brûler ?

Peux-tu me dire maintenant que ma poussière ne sera pas oubliée ?  
Montre-moi juste un fragment de ton grand plan céleste.  
Montre-moi qu'il y a une raison pour mes efforts et ma douleur.

Tu m'as choisie pour griller et chargé Rouen de braises.  
D'accord, je brûlerai !  
Regarde-moi brûler !  
Vois comment je brûle !  
Oh oh oh oh  
Oui  
Vois comment je brûle !

  
À l'époque, j'étais choisie,  
Maintenant, je suis piégée et empoisonnée.  
Après tout, j'ai essayé pendant un an, cela semble toujours.  
Archange Michel, pour le Trône, ton étendard blanc j'ai brandi  
À l'aube ardente de Rouen, je brûlerai pour Christ, seule.

Ciel, ton but est vaste,  
Mais en toi, ma confiance est placée.  
Je porterai tes vêtements, j'accepte mon passé.  
Emmène-moi à ton bûcher, Rouen.

Brûle-moi, allume-moi,  
Achève-moi.  
Prends-moi, maintenant !

Avant que mon cœur n'abandonne...
