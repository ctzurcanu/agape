---
id: 0eUx9mY0zqY
title: "À Jeanne D’Arc - To Joan of Arc 01"
sidebar_label: "À Jeanne D’Arc - To Joan of Arc 01"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/0eUx9mY0zqY"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## À Jeanne D’Arc - To Joan of Arc 01

Lyrics: St. Thérèse de Lisieux

Quand le Dieu des armées te donnant la victoire  
Tu chassas l'étranger et fis sacrer le roi  
Jeanne, ton nom devint célèbre dans l'histoire  
Nos plus grands conquérants pâlirent devant toi.

Mais ce n'était encor qu'une gloire éphémère  
Il fallait à ton nom l'auréole des Saints  
Aussi le Bien-Aimé t'offrit sa coupe amère  
Et tu fus comme Lui rejetée des humains.

Au fond d'un noir cachot, chargée de lourdes chaînes  
Le cruel étranger t'abreuva de douleurs  
Pas un de tes amis ne prit part à tes peines  
Pas un ne s'avança pour essuyer tes pleurs.

Jeanne tu m'apparais plus brillante et plus belle  
Qu'au sacre de ton roi, dans ta sombre prison.  
Ce céleste reflet de la gloire éternelle  
Qui donc te l'apporta ? Ce fut la trahison.

Ah ! si le Dieu d'amour en la vallée des larmes  
N'était venu chercher la trahison, la mort  
La souffrance pour nous aurait été sans charmes  
Maintenant nous l'aimons, elle est notre trésor.

English:

When the God of armies gave you victory  
You chased away the foreigner and had the king crowned  
Jeanne, your name became famous in history  
Our greatest conquerors paled before you.

But it was still only an ephemeral glory  
Your name needed the halo of the Saints  
So the Beloved offered you his bitter cup  
And you were like Him rejected by humans.

In the depths of a dark dungeon, burdened with heavy chains  
The cruel foreigner drenched you with pain  
Not one of your friends took part in your sorrows  
Not one came forward to wipe away your tears.

Jeanne, you appear to me more brilliant and more beautiful  
Than at the coronation of your king, in your dark prison.  
This celestial reflection of eternal glory  
Who then brought it to you? It was treason.

Ah! if the God of love in the valley of tears  
Had not come to seek betrayal, death  
Suffering for us would have been without charms  
Now we love her, she is our treasure.
