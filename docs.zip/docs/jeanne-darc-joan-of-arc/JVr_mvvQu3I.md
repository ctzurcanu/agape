---
id: JVr_mvvQu3I
title: "Rouen"
sidebar_label: "Rouen"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/JVr_mvvQu3I"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Rouen

Rouen

Part of Joan of Arc, Supermaid rock opera: https://youtu.be/ujWAriq0FT4?si=8SHeorogsDdJ9uif&t=2419

[Merchants]

Roll on up old faire Rouen  
Come on in old faire Rouen

Sunday here we go again,  
Live in me old faire Rouen

Here you live old faire Rouen  
Here you breathe old faire Rouen

While Joan's saga still survives,  
You at least are still alive.

I got things you won't believe,  
Name your pleasure I will sell.

I can fix your wildest needs,  
I got heaven and I got hell

Roll on up, for my price is down.

Come on in for the best in town.

Take your pick of the finest wine.

Lay your bets on this bird of mine.

What you see is what you get.

No one's been disappointed yet.

Don't be scared give me a try,  
There is nothing you can't buy.

Name your price, I got everything.

Hurry it's going fast.

Borrow cash on the finest terms.

Hurry now while stocks still last.

Roll on up old faire Rouen  
Come on in old faire Rouen

Sunday here we go again,  
Live in me old faire Rouen

Here you live old faire Rouen  
Here you breathe old faire Rouen

[Joan]

My death place should be a house of good deeds,  
But you have made it a den of thieves.

Get out!  
Get out!

Get out!!!
