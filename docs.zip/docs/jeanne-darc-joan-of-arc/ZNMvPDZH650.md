---
id: ZNMvPDZH650
title: "Vive Jeanne!"
sidebar_label: "Vive Jeanne!"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/ZNMvPDZH650"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Vive Jeanne!

[SUIVEURS]

Vive Jeanne !  
Hé, Jeanne, Jeanne, Jeanne, Vive Jeanne !  
Hé, Jeanne, Vive Jeanne !  
Hé, Jeanne, Jeanne, ne nous mèneras-tu pas ?  
Jeanne, Vive Jeanne !  
Vive la Pucelle d'Orléans !

Vive Jeanne !  
Hé, Jeanne, Jeanne, Jeanne, brave Jeanne !  
Hé, Jeanne, brave Jeanne !  
Hé, Jeanne, Jeanne, tu es notre force, notre courage en devenir !  
Jeanne, brave Jeanne !  
Hé, la Pucelle d'Orléans !

[Cauchon]

Dites au tribunal de se taire, nous prévoyons une menace violente.  
Cette hôte commune a beaucoup à vanter.  
Dites à ces hommes qui chantent vos louanges qu'ils sont des fous et hors de propos.  
Ils ne sont pas dans le droit chemin, l'Église approuvera probablement.

[SUIVEURS]

Vive Jeanne !  
Hé, Jeanne, Jeanne, Jeanne, Vive Jeanne !  
Hé, Jeanne, Vive Jeanne !  
Hé, Jeanne, Jeanne, tu es une Sainte, notre Sainte en devenir !  
Jeanne, Vive Jeanne !  
Hé, la Pucelle d'Orléans !

[Jeanne d'Arc]

Pourquoi gaspiller des mots à réprimander cette foule ?  
Rien ne peut faire taire leurs voix, fortes.  
Si chaque homme ici était réduit au silence,  
Le ciel et la terre eux-mêmes acclameraient.

[SUIVEURS, Jeanne d'Arc]

Vive Jeanne !  
Hé, Jeanne, Jeanne, Jeanne, Vive Jeanne !  
Hé, Jeanne, Vive Jeanne !

[SUIVEURS]

Hé, Jeanne, Jeanne, ne te battras-tu pas pour la France ?  
Jeanne, Vive Jeanne, Hé, la Pucelle d'Orléans !

[Jeanne d'Arc]

Chantez-moi vos hymnes,  
Mais pas seulement pour moi, chantez.  
Chantez pour la France,  
Car vous êtes bénis.  
Il n'y en a pas un ici  
Qui ne peut gagner une âme.  
Les doux, les courageux,  
Les vivants et les sauvés.

[SUIVEURS, Jeanne d'Arc]  
Vive Jeanne !  
Hé, Jeanne, Jeanne, Jeanne, sainte Jeanne !  
Hé, Jeanne, sainte Jeanne !  
Hé, Jeanne, Jeanne, tu es notre fierté, notre sainteté en devenir !  
Jeanne, sainte Jeanne !  
Hé, la Pucelle d'Orléans !

Vive Jeanne !  
Hé, Jeanne, Jeanne, Jeanne, Vive Jeanne !  
Hé, Jeanne, Vive Jeanne !

[SUIVEURS]

Jeanne ! Jeanne ! Jeanne !

[SUIVEURS]

Hé, Jeanne, Jeanne, ne brûleras-tu pas pour moi ?  
Jeanne, Vive Jeanne,  
Hé, la Pucelle d'Orléans !
