---
id: 5oetaYSaZDA
title: "Joan of Arc: Bells for France"
sidebar_label: "Joan of Arc: Bells for France"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/5oetaYSaZDA"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Joan of Arc: Bells for France

Music from the well-known Ukrainian song of Shchedryk (later the Carol of the Bells).

Lyrics:

My France, my France!   
If you cannot laugh in Orleans,   
weep in Paris and in Rouen,   
laugh even more as Parisien   
Then you can't know how my heart beats   
For your own glorious good

As in the past glorious France   
In the lands of King Charlemagne   
And the days of Napoleon   
The victorious   
beautiful Marianne   
Then you can not know   
How their hearts are still   
Beating bells for France  
Then you can not know   
How their hearts are still   
beating bells for France
