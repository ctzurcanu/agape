---
id: 9osjhlcWN7A
title: "Pour la France - For France"
sidebar_label: "Pour la France - For France"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/9osjhlcWN7A"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Pour la France - For France

Lyrics: St Thérèse de Lisieux

« Rappelle-toi, Jeanne, de ta patrie !  
Rappelle-toi de tes vallons en fleurs !  
Rappelle-toi la riante prairie  
Que tu quittas pour essuyer mes pleurs !

Ô Jeanne ! Souviens-toi que tu sauvas la France  
Comme un ange des Cieux tu guéris ma souffrance  
Écoute dans la nuit  
La France qui gémit

Rappelle-toi !

Rappelle-toi, Jeanne de tes victoires  
Rappelle-toi de Reims et d’Orléans  
Rappelle-toi que tu couvris de gloire  
Au nom de Dieu, le royaume des Francs !

Maintenant, loin de toi, je souffre et je soupire  
Daigne encor me sauver ! Jeanne, douce Martyre !  
Oh ! Viens briser mes fers !  
Des maux que j’ai soufferts

Rappelle-toi ! »

« Ô France !   
Ô ma belle Patrie !  
Il faut t’élever jusqu’aux Cieux  
Si tu veux retrouver la vie  
Et que ton nom soit glorieux.

Le Dieu des Francs dans sa clémence  
A résolu de te sauver  
Mais c’est par moi, Jeanne de France  
Qu’il veut encor te racheter

Viens à moi

Patrie si belle  
Je prie pour toi  
Ma voix t’appelle  
Reviens à moi ».

Reviens à moi !

English:

"Remember, Joan, your homeland!  
Remember your valleys in bloom!  
Remember the smiling meadow  
That you left to wipe away my tears!

Oh Joan! Remember that you saved France  
Like an angel from Heaven you heal my suffering  
Listen in the night  
France that moans

Remember!

Remember, Joan, your victories  
Remember Reims and Orléans  
Remember that you covered with glory  
In the name of God, the kingdom of the Franks!

Now, far from you, I suffer and I sigh  
Deign to save me again! Joan, sweet Martyr!  
Oh! Come break my chains!  
Of the evils that I have suffered

Remember!"

"Oh France!  
Oh my beautiful Homeland!  
You must rise to the Heavens  
If you want to find life again  
And may your name be glorious.

The God of the Franks in his clemency  
Has resolved to save you  
But it is through me, Joan of France  
That he still wants to redeem you

Come to me

Homeland so beautiful  
I pray for you  
My voice calls you  
Come back to me".

Come back to me!
