---
id: 96MD08ReHmI
title: "A Follower’s Death"
sidebar_label: "A Follower’s Death"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/96MD08ReHmI"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## A Follower’s Death

For Joan of Arc, Supermaid rock opera https://youtu.be/ujWAriq0FT4

[FOLLOWER] 

My God, I saw her  
She looked three-quarters dead  
and she was so bad, I had to turn my head  
You poisoned her  
and she was almost broken  
And I know who everybody's gonna blame  
I don't believe she knows I acted for our good  
I'd save her all this suffering if I could  
Don't believe our good  
And I'd save her if I could

[POLITICIANS] 

Cut the confessions, forget the excuses  
I don't understand why  
You're filled with remorse  
All that you've said  
has come true with a vengeance  
Her other followers turned against her  
You backed the right horse  
What you have done  
will be the saving of everyone  
You'll be remembered forever for this  
And not only that  
You've been paid for your efforts  
Pretty good wages for one little girl

[FOLLOWER] 

Joan, I know you can't hear me  
But I thought I did what your mission needed me to  
Joan, I'd sell out the nation  
For I have been saddled  
with the murder of you  
I have been spattered with innocent blood  
I shall be dragged  
through the slime and the mud  
I have been spattered with innocent blood  
I shall be dragged  
through the slime and the slime and the  
Slime and the mud  
I  
Don't know how to thank her  
I don't know why she made me lead

She's a girl  
She's just a girl  
She is not a Christ  
She's just the same  
As any other hero  
She scares me so  
While she's scattered ashes  
Will she let me free?  
Will she forgive  
Will she forgive me too?  
Does she still care for her Followers?  
My mind is  
It's in darkness

God.  
God, I'm sick!  
I've been used!  
And you knew all the time!  
God! God, I will never know  
Why did you choose me  
for your crime!  
For your bloody crime!  
You have crowned me!  
Crowned me!  
Crowned me! Elevated me!  
Crowned me! Elevated me!  
Crowned me, Joan!

[FOLLOWERS]

So long, Follower  
Poor old Follower  
So long, Follower
