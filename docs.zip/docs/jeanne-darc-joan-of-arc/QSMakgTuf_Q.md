---
id: QSMakgTuf_Q
title: "Too much Sainthood on their Minds"
sidebar_label: "Too much Sainthood on their Minds"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/QSMakgTuf_Q"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Too much Sainthood on their Minds

Too much Sainthood on their Minds

Part of Joan of Arc, Supermaid rock opera:  
https://youtu.be/180abRJwjdM?si=36VkrFv2-YXycJzg&t=1035

  
[KING CHARLES VII]

My mind is clearer now,  
At last   
all too well  
I can see   
where our France   
will soon be.

If you strip away   
the myth   
from the maid,  
You will see   
where we all   
soon will be. 

Joan!  
You've started to believe  
The things they say of you.  
You really do believe  
This voice of Saints is true.

And all the good you've done  
Will soon get swept away.  
You've begun to matter more  
Than voices you obey.

[Instrumental]

[KING CHARLES VII]

Listen, Joan, I don't like what I see.  
All I ask is that you listen to me.  
And remember, I've been your rightful king all along.  
You have kindled their zeitgeist.  
They think they've found a Jesus Christ.  
And they'll hurt you when they find they're wrong.

I remember when this whole thing began.  
No talk of saints then, we called you a gal.  
And believe me, my support for you hasn't unfurled.  
But every word you say today  
Gets twisted 'round some other way.  
And they'll hurt you if they think you've lied.

Domrémy, your famous daughter should have stayed a shepherdess  
Like her father tending sheep, she'd have made good.  
Fields, farms, and rural charms would have suited Joan best.  
She'd have caused nobody harm; no one would have been distressed.

Listen, Joan, do you care for our France?  
Bestow to peace a diplomatic chance.  
We are English-occupied;   
Our logistics are under-supplied!

I am frightened by your clout.  
Peasants are getting much too flout.  
And they'll crush us if they win the war.  
If they win any war...

Listen, Joan, to the warning I give.  
Please know that I want us to convive.

[Instrumental]

[KING CHARLES VII]

But it's sad to see our chances depart.  
With every city that you bombard  
All your followers are blind,  
Too much sainthood on their minds.  
It was beautiful, but now it's dangerous.  
Yes, it's all gone serious.

Listen, Joan, to the warning I give.  
Please know that I want you to live.

oh oh oh oh oh oh oh oh oh oh oh oh oh oh oh oh oh oh  
oh oh oh oh oh oh oh oh oh oh oh oh oh oh oh oh oh oh  
C'mon, c'mon,  
She won't listen to me...  
C'mon, c'mon,  
She won't listen to me...

oh oh oh oh oh oh oh oh oh oh oh oh oh oh oh oh oh oh  
oh oh oh oh oh oh oh oh oh oh oh oh oh oh oh oh oh oh  
She won't listen to me...  
She won't listen to me...
