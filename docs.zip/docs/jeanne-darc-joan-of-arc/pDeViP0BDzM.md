---
id: pDeViP0BDzM
title: "A Jeanne d'Arc - To Joan of Arc"
sidebar_label: "A Jeanne d'Arc - To Joan of Arc"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/pDeViP0BDzM"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## A Jeanne d'Arc - To Joan of Arc

Lyrics: Chanoine Ferdinand Berger, 1924

Pour le salut de la Patrie  
Prions, Français, d’un même cœur ;  
Quand un pays espère et prie,  
C’est le réveil de sa grandeur.

Un jour, hélas ! Au cœur frappé,  
La belle France allait mourir  
Sur les débris de son épée ;  
Mais le ciel vint la secourir.

Jeanne d’Arc, ô Vierge bénie  
Par qui la France à l’agonie  
Fut arrachée à l’oppresseur,  
Ne laisse pas dans la tempête,  
Périr le fruit de ta conquête  
Périr le fruit de ta conquête  
Garde la France,  
Garde la France,  
Garde la France,  
Ô noble sœur !

Des voix d’en haut, Jeanne inspirée  
Quitte sa mère et son troupeau,  
Et la victoire inespérée  
Suit désormais son blanc drapeau.

Tout se relève en la patrie,  
Comme la fleur au beau soleil,  
Et Jeanne alors, l’âme attendrie,  
Rend gloire à Dieu de ce réveil.

Jeanne d’Arc, ô Vierge bénie  
Par qui la France à l’agonie  
Fut arrachée à l’oppresseur,  
Ne laisse pas dans la tempête,  
Périr le fruit de ta conquête  
Périr le fruit de ta conquête  
Garde la France,  
Garde la France,  
Garde la France,  
Ô noble sœur !

Pour couronner sa foi sublime,  
La France, hélas, avait trop peu :  
Sur le bûcher, pure victime,  
Jeanne rendra son âme à Dieu.

Lorsque le Christ, aux Francs qu’il aime  
A prodigué tant de faveurs,  
Le désespoir est un blasphème :  
Non, non, Français en haut les cœurs !

Jeanne d’Arc, ô Vierge bénie  
Par qui la France à l’agonie  
Fut arrachée à l’oppresseur,  
Ne laisse pas dans la tempête,  
Périr le fruit de ta conquête  
Périr le fruit de ta conquête  
Garde la France,  
Garde la France...

  
Autour de nous si tout chancelle,  
Gardons encore le souvenir ;  
Sous l’étendard de la Pucelle  
Est abrité notre avenir.

Autour de nous si tout chancelle,  
Gardons encore le souvenir ;  
Sous l’étendard de la Pucelle  
Est abrité notre avenir.

Jeanne d’Arc, ô Vierge bénie  
Par qui la France à l’agonie  
Fut arrachée à l’oppresseur,  
Ne laisse pas dans la tempête,  
Périr le fruit de ta conquête  
Garde la France,  
Garde la France,  
Garde la France,  
Ô noble sœur !

English:

For the salvation of the Fatherland  
Let us pray, French, with one heart;  
When a country hopes and prays,  
It is the awakening of its greatness.

One day, alas! With its heart struck,  
Beautiful France was going to die  
On the debris of its sword;  
But heaven came to its rescue.

Joan of Arc, O blessed Virgin  
By whom France in agony  
Was snatched from the oppressor,  
Do not let in the storm,  
Perish the fruit of your conquest  
Perish the fruit of your conquest  
Guard France,  
Guard France,  
Guard France,  
O noble sister!

Voices from above, inspired Joan  
Leaves her mother and her flock,  
And the unexpected victory  
Now follows its white flag.

Everything rises again in the homeland,  
Like the flower in the beautiful sun,  
And Joan then, her soul softened,  
Gives glory to God for this awakening.

Joan of Arc, oh blessed Virgin  
By whom France in agony  
Was snatched from the oppressor,  
Do not let in the storm,  
Perish the fruit of your conquest  
Perish the fruit of your conquest  
Guard France,  
Guard France,  
Guard France,  
Oh noble sister!

To crown her sublime faith,  
France, alas, had too little:  
On the stake, a pure victim,  
Joan will give her soul to God.

When Christ, to the Franks he loves  
Has lavished so many favors,  
Despair is blasphemy:  
No, no, French, take heart!

Joan of Arc, O blessed Virgin  
By whom France in agony  
Was snatched from the oppressor,  
Do not let in the storm,  
Perish the fruit of your conquest  
Perish the fruit of your conquest  
Guard France,  
Guard France...

Around us if everything falters,  
Let us still keep the memory;  
Under the banner of the Maid  
Is sheltered our future.

Around us if everything falters,  
Let us still keep the memory;  
Under the banner of the Maid  
Is sheltered our future.

Joan of Arc, O blessed Virgin  
By whom France in agony  
Was snatched from the oppressor,  
Do not let in the storm,  
Perish the fruit of your conquest  
Guard France,  
Guard France,  
Guard France,  
O noble sister!
