---
id: Cg0k9rsoXcE
title: "À Jeanne D’Arc - To Joan of Arc 02"
sidebar_label: "À Jeanne D’Arc - To Joan of Arc 02"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/Cg0k9rsoXcE"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## À Jeanne D’Arc - To Joan of Arc 02

Lyrics: St. Thérèse de Lisieux

Moi, Jeanne la bergère  
Je chéris mon troupeau  
Ma houlette est légère  
Et j'aime mon fuseau. 

J'aime la solitude   
De ce joli bosquet   
J'ai la douce habitude   
D'y venir en secret. 

J'y tresse une couronne   
De belles fleurs des champs   
A Marie je la donne   
Avec mes plus doux chants. 

J'admire la nature  
Les fleurs et les oiseaux   
Du ruisseau qui murmure  
Je contemple les eaux. 

Les vallons, les campagnes   
Réjouissent mes yeux   
Les sommets des montagnes   
Me rapprochent des Cieux !... 

Souvent des voix étranges  
Viennent me visiter  
Je crois bien que les anges  
Doivent ainsi parler. 

J'interroge l'espace   
Je contemple les Cieux   
Je ne vois nulle trace   
D'êtres mystérieux.

Franchissant le nuage  
Qui doit me les cacher  
Au Céleste rivage  
Que ne puis-je voler ! ! !... 

English:

I, Joan the shepherdess  
I cherish my flock  
My crook is light  
And I love my spindle.

I love the solitude  
Of this pretty grove  
I have the sweet habit  
To come there in secret.

I weave a crown  
Of beautiful wild flowers  
To Mary I give it  
With my sweetest songs.

I admire nature  
The flowers and the birds  
Of the murmuring stream  
I contemplate the waters.

The valleys, the countryside  
Delight my eyes  
The mountain peaks  
Bring me closer to the Heavens!...

Often strange voices  
Come to visit me  
I believe that angels  
Must speak thus.

I question space  
I contemplate the Heavens  
I see no trace  
Of mysterious beings.

Crossing the cloud  
Who must hide them from me  
On the Celestial shore  
Why can't I fly!!!...
