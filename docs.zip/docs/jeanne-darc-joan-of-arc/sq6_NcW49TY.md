---
id: sq6_NcW49TY
title: "Serment à Rouen - Oath at Rouen"
sidebar_label: "Serment à Rouen - Oath at Rouen"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/sq6_NcW49TY"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Serment à Rouen - Oath at Rouen

Prenez dans vos bras les enfants, armes de notre combat,  
Venez tous à Rouen, où vibre leur grande épopée.  
“Reine de toute la France, nous n’avons pas trahi ta flamme,  
Notre âme te supplie : ranime en nous ton âme !”

Lève-toi, Jeanne, entends tes fils,  
Le monde est plongé dans l’effroi.  
Fidélité à la France éternelle,  
Nous te le jurons, ô Sainte, à toi !

  
Encerclant ta mémoire ardente, Jeanne, Jeanne la guerrière,  
Ressuscite en nos cœurs, reçois notre prière.  
Tout ce que tu rêvas surgira, comme ta voix l’a chanté :  
La maison des libres restera, et la France vivra à jamais !

Lève-toi, Jeanne, entends tes fils,  
Le monde est plongé dans l’effroi.  
Fidélité à la France éternelle,  
Nous te le jurons, ô Sainte, à toi !

  
Nous voici, tes soldats, tandis qu’un poète murmure,  
Du clocher de Rouen s’élève un chant pur.  
D’une force redoublée, que le peuple entier s’éveille,  
Autour de ton esprit, Jeanne, nous marcherons en bataille !

Lève-toi, Jeanne, entends tes fils,  
Le monde est plongé dans l’effroi.  
Fidélité à la France éternelle,  
Nous te le jurons, ô Sainte, à toi !

  
Notre Sainte, nous jurons, près du fleuve où ton âme erre,  
De garder à jamais notre patrie fière.  
Prenez les enfants, racontez-leur l’histoire sacrée :  
La flamme de Jeanne est le berceau de notre gloire !

Lève-toi, Jeanne, entends tes fils,  
Le monde est plongé dans l’effroi.  
Fidélité à la France éternelle,  
Nous te le jurons, ô Sainte, à toi !

Notre Sainte, nous jurons, près du fleuve où ton âme erre,  
De garder à jamais notre patrie fière.  
Prenez les enfants, racontez-leur l’histoire sacrée :  
La flamme de Jeanne est le berceau de notre gloire !

Lève-toi, Jeanne, entends tes fils,  
Le monde est plongé dans l’effroi.  
Fidélité à la France éternelle,  
Nous te le jurons, ô Sainte, à toi !

Nous te le jurons, ô Sainte, à toi !

English:

Take in your arms the children, weapons of our fight,  
Come all to Rouen, where their great epic vibrates.  
“Queen of all France, we have not betrayed your flame,  
Our soul begs you: rekindle your soul in us!”

Rise, Joan, hear your sons,  
The world is plunged into fear.  
Fidelity to eternal France,  
We swear it to you, O Saint, to you!

Encircling your ardent memory, Joan, Joan the warrior,  
Resurrect in our hearts, receive our prayer.  
All that you dreamed will arise, as your voice sang:  
The house of the free will remain, and France will live forever!

Rise, Joan, hear your sons,  
The world is plunged into fear.  
Loyalty to eternal France,  
We swear it to you, O Saint, to you!

Here we are, your soldiers, while a poet murmurs,  
From the bell tower of Rouen rises a pure song.  
With redoubled force, let the whole people awaken,  
Around your spirit, Joan, we will march into battle!

Rise, Joan, hear your sons,  
The world is plunged into terror.  
Loyalty to eternal France,  
We swear it to you, O Saint, to you!

Our Saint, we swear, near the river where your soul wanders,  
To keep our homeland proud forever.  
Take the children, tell them the sacred story:  
Joan's flame is the cradle of our glory!

Rise, Joan, hear your sons,  
The world is plunged into terror.  
Loyalty to eternal France,  
We swear to you, O Saint, to you!

Our Saint, we swear, near the river where your soul wanders,  
To keep our homeland proud forever.

Take the children, tell them the sacred story:  
The flame of Joan is the cradle of our glory!

Rise, Joan, hear your sons,  
The world is plunged into fear.  
Loyalty to eternal France,  
We swear to you, oh Saint, to you!

We swear to you, oh Saint, to you!
