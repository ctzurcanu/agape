---
id: XsabgyPmSGg
title: "Oath at Rouen"
sidebar_label: "Oath at Rouen"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/XsabgyPmSGg"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Oath at Rouen

Take the children in your arms, our struggle’s might,  
Come to Rouen where their epic tales take flight.  
“Queen of all France, we’ve kept your flame alight,  
Our souls implore you: reignite them with light!”

Arise, Jeanne, hear your children’s cry,  
Their world is drowning in the tide of the lie!  
To a France eternal, our oath stands now true—  
We swear to you, Saint, our pledge we renew!

  
Encircling your blazing memory, Jeanne, warrior-queen,  
Resurrect our soul, invest our efforts with mean.  
All you dreamed will rise as your voice once foretold:  
The home of the free endures, and France won’t grow old!

Arise, Jeanne, hear your children’s cry,  
Their world is drowning in the tide of the lie!  
To a France eternal, our oath stands now true—  
We swear to you, Saint, our pledge we renew!

  
We stand your soldiers, as a poet’s whispers soar,  
From Rouen’s spires, in pure chant we adore.  
With doubled strength, let all the people be wake:  
Around your spirit, Jeanne, for a France that is not fake!

Arise, Jeanne, hear your children’s cry,  
Their world is drowning in the tide of the lie!  
To a France eternal, our oath stands now true—  
We swear to you, Saint, our pledge we renew!

  
Our Saint, we swear by the river where your soul still strays,  
To guard our proud homeland through unending days.  
Take the children, tell the sacred flame’s birth:  
Jeanne’s fire cradles France, and the glory of the Earth!

Arise, Jeanne, hear your children’s cry,  
Their world is drowning in the tide of the lie!  
To a France eternal, our oath stands now true—  
We swear to you, Saint, our pledge we renew!

  
Our Saint, we swear by the river where your soul still strays,  
To guard our proud homeland through unending days.  
Take the children, tell the sacred flame’s birth:  
Jeanne’s fire cradles France, and the glory of the Earth!

Arise, Jeanne, hear your children’s cry,  
Their world is drowning in the tide of the lie!  
To a France eternal, our oath stands now true—  
We swear to you, Saint, our pledge we renew!

We swear to you, Saint, our pledge we renew!

We swear to you, Saint, our pledge we renew!
