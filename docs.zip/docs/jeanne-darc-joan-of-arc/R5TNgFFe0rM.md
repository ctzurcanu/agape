---
id: R5TNgFFe0rM
title: "Rappelle-toi Jeanne - Remember Joan"
sidebar_label: "Rappelle-toi Jeanne - Remember Joan"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/R5TNgFFe0rM"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Rappelle-toi Jeanne - Remember Joan

Lyrics: St Thérèse de Lisieux

Rappelle-toi, rappelle-toi…  
Rappelle-toi, rappelle-toi…

Rappelle-toi Jeanne Domrémy, Chinon,  
Orléans, Reims, et Rouen où ton cœur fut pure hostie.  
Fille de Dieu, Sainte Pucelle, viens au secours  
De la France au nom de Jésus et Marie  
   
France ô ma France, Il faut élever  
Jusqu’aux Cieux, ta Patrie  
Si tu veux retrouver la vie  
Et que ton nom soit glorieux  
Le Dieu vainqueur et clément  
A résolu de te sauver  
   
Mais c’est par moi, qu’il veut te racheter  
Viens à moi, je prie pour toi je t'appelle, reviens à moi.  
Fille de Dieu, Sainte Pucelle, viens au secours  
De la France au nom de Jésus et Marie.  
   
France ô ma France,  
Il faut élever Jusqu’aux Cieux,  
Ta Patrie Si tu veux retrouver la vie  
Et que ton nom soit glorieux  
Le Dieu vainqueur et clément  
A résolu de te sauver

Rappelle-toi, rappelle-toi…  
Rappelle-toi, rappelle-toi…

English:

Remember, remember…  
Remember, remember…

Remember Jeanne Domrémy, Chinon,  
Orléans, Reims, and Rouen where your heart was pure host.  
Daughter of God, Saint Maid, come to the aid  
Of France in the name of Jesus and Mary

France, oh my France, You must raise  
Up to the Heavens, your Homeland  
If you want to find life again  
And may your name be glorious  
The victorious and merciful God  
Has resolved to save you

But it is through me that he wants to redeem you  
Come to me, I pray for you, I call you, come back to me.  
Daughter of God, Saint Maid, come to the aid  
Of France in the name of Jesus and Mary.

France, oh my France,  
You must raise up to the Heavens,  
Your homeland If you want to find life again  
And may your name be glorious  
The victorious and merciful God  
Has resolved to save you

Remember, remember…  
Remember, remember…
