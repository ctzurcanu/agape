---
id: 5z9hFiW2x7g
title: "La lumière de Jeanne - The Light of Joan"
sidebar_label: "La lumière de Jeanne - The Light of Joan"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/5z9hFiW2x7g"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La lumière de Jeanne - The Light of Joan

[Jeanne]

Étendard blanc, porteur de lumière, preuve de la puissance divine du soleil  
Tu donnes aux héros le droit de connaître leur raison de se battre  
Tu as survécu aux révolutions, renaissant des bûchers  
Tissé de faits et de devoirs, mû par les tremblements cosmiques  
Quelle grandeur est ce voyage hors de mes propres axes

Hauts cieux roulant mon cœur d'un seul tonnerre  
Qui suis-je ? Je vis la fièvre de la tempête ni l'un ni l'autre

Je suis au centre de maintenant. Né pour être ici.  
Je suis née pour faire cela pour l'éternité de l'éternité.  
J'ai tissé l'étendard de l'espoir. Brillant de sa lumière plus blanche que blanche.  
Dans le sublime cristallin de Dieu, à travers les corridors du temps, les plans célestes assemblés

  
J'ai maintenant engendré la puissance et la lumière de la cause de la raison de se battre  
Je reste seule dans le droit d'être ma propre mère vierge  
l'œil du je

  
Mon cher Christ, j'ai autrefois brûlé pour ton Église  
Mais en ton nom, bon Christ,  
Pour ta lumière, j'ai oublié comment mourir.

  
J'ai maintenant engendré la puissance et la lumière de la cause de la raison de se battre  
Je reste seule dans le droit d'être ma propre mère vierge  
l'œil du je
