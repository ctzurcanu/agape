---
id: TvJvKs60-80
title: "Could We Start It Again?"
sidebar_label: "Could We Start It Again?"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/TvJvKs60-80"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Could We Start It Again?

Could We Start It Again?

From Joan of Arc, Supermaid rock opera https://youtu.be/ujWAriq0FT4?si=7TZRNR68FK0JT454&t=2715

[JESUS CHRIST]

I've been waiting to see you.  
You've been burning to see me, but it shouldn't be like this.  
You have over-performed,  
Ready to be anew Joan of Arc Romee?  
You are my only hope.  
Papalis Infallibilitas too much.  
Now for the first time, I think The Pope was wrong.  
Awake him ex cathedra,  
Make his judgment pro tempore.  
Joan, could we start la nouvelle guerre spirituelle?

[THE POPE]

I think you've made your point now.  
You've even gone a bit too far to get the message home.  
Before it gets too far,  
We ought to call a vote,  
Joan, could we start la nouvelle guerre spirituelle?

[ALL SPIRITUAL FIGURES]

I've been waiting to see you.  
You've been burning to see me, but it shouldn't be like this.  
You have over-performed,  
Ready to be anew Joan of Arc Romee?  
You are my only hope.  
I think you've made your point now.  
You've even gone a bit too far to get the message home.  
Before it gets too far,  
We ought to call a vote,  
Joan, could we together start again la guerre?  
Could we start la nouvelle guerre spirituelle?   
Could we start la nouvelle guerre spirituelle?   
Could we start la nouvelle guerre spirituelle?   
Could we start la nouvelle guerre spirituelle?   
Could we start la nouvelle guerre spirituelle? 

[JESUS CHRIST]

Joan, could we start la nouvelle guerre spirituelle?
