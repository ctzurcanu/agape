---
id: 9QZJ_DAYAEU
title: "Sonet CLXX"
sidebar_label: "Sonet CLXX"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/9QZJ_DAYAEU"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Sonet CLXX

Versuri: Vasile Voiculescu, 1955

Sămânţa nemuririi, iubite, e cuvântul,  
Eternul se ascunde sub coaja unei clipe,  
Ca-n oul ce păstreaza un zbor înalt de-aripe,  
Pân' ce-i soseşte timpul în slavi să-şi ia avântul;  
A fost de-ajuns un nume, al tău, sol dezrobirii,  
S-au spart şi veac, şi lume; ţinut prizonier  
A izbucnit din ţăndări, viu, vulturul iubirii,  
Cu ghearele-i de aur să ne răpească-n cer.  
Cine ne puse-n suflet aceste magici chei?  
Egali în frumuseţe şi-n genii de o seamă,  
Am descuiat tărâmul eternelor idei;  
Supremelor matriţe redaţi, care ne cheamă  
Din formele căderii, la pura-ntâietate,  
Să ne topim în alba, zeiasca voluptate...

English:

The seed of immortality, beloved, is the word,  
The Eternal hides under the shell of a moment,  
Like in the egg that keeps a high flight of wings,  
Until its time arrives in glory to take flight;  
A name was enough, yours, messenger of liberation,  
The century and the world were broken; held prisoner  
The eagle of love burst out of the rubble, alive,  
With its golden claws to snatch us into the sky.  
Who put these magical keys in our souls?  
Equal in beauty and in genius of equal worth,  
We have unlocked the realm of eternal ideas;  
To the supreme molds rendered, which call us  
From the forms of the fall, to the purest primacy,  
To melt in the white, divine voluptuousness...
