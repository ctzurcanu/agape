---
id: PLrZFPVQM38MeCUpIzyS7l9rescRS3Rozw
title: "Vasile Voiculescu"
sidebar_label: "Vasile Voiculescu"
---

# Vasile Voiculescu

This is the landing page for the playlist "Vasile Voiculescu".

## Videos in this Playlist

- [Sonet CLXX](/agape/vasile-voiculescu/9QZJ_DAYAEU)
- [În Grădina Ghetsimani - In the Garden of Gethsemane](/agape/vasile-voiculescu/AQYdwiWtllY)

