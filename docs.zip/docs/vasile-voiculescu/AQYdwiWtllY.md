---
id: AQYdwiWtllY
title: "În Grădina Ghetsimani - In the Garden of Gethsemane"
sidebar_label: "În Grădina Ghetsimani - In the Garden of Gethsemane"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/AQYdwiWtllY"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## În Grădina Ghetsimani - In the Garden of Gethsemane

Versuri: Vasile Voiculescu

Iisus lupta cu soarta şi nu primea paharul...  
Căzut pe brânci în iarbă, se-mpotrivea întruna.  
Curgeau sudori de sânge pe chipu-i alb ca varul  
Şi-amarnica-i strigare stârnea în slăvi furtuna. 

O mâna nendurată, ţinând grozava cupă,  
Se coboara-mbiindu-l şi i-o ducea la gură...  
Şi-o sete uriaşă sta sufletul să-i rupă...  
Dar nu voia s-atingă infama băutură. 

În apa ei verzuie jucau sterlici de miere  
Şi sub veninul groaznic simţea că e dulceaţă...  
Dar fălcile-ncleştându-şi, cu ultima putere  
Bătându-se cu moartea, uitase de viaţă! 

Deasupra fără tihnă, se frământau măslinii,  
Păreau că vor să fugă din loc, să nu-l mai vadă...  
Treceau bătăi de aripi prin vraiştea grădinii  
Şi uliii de seară dau roate dupa pradă.

English:

Jesus fought with fate and did not receive the cup...  
Falling on his face in the grass, he kept resisting.  
Bloody sweat flowed down his face as white as lime  
And his bitter cry stirred up the storm in glory.

A merciless hand, holding the terrible cup,  
It descended-drinking it and brought it to his mouth...  
And a huge thirst stood to break his soul...  
But he did not want to touch the infamous drink.

In its greenish water, sterlets of honey played  
And under the terrible venom he felt that it was sweetness...  
But clenching his jaws, with his last strength  
Fighting with death, he had forgotten about life!

Above, restlessly, the olive trees were struggling,  
They seemed to want to flee from the place, to never see him again...  
Wings beat through the garden's thicket  
And the evening hawks circle after their prey.
