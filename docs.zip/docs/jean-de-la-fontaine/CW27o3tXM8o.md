---
id: CW27o3tXM8o
title: "La Cigale et la Fourmi - The Cicada and the Ant"
sidebar_label: "La Cigale et la Fourmi - The Cicada and the Ant"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/CW27o3tXM8o"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## La Cigale et la Fourmi - The Cicada and the Ant

Author : Jean de la Fontaine  
Lyrics: Pierre Perret

La Cigale reine du hit parade  
Gazouilla durant tout l’été  
Mais un jour ce fût la panade  
Elle n’avait plus rien à becqueter  
Quand se pointa l’horrible hiver  
Elle n’avait pas même un sandwich  
A fair’ la manche dans l’courant d’air  
La pauvre se caillait les miches

[Choir]  
A gla gla A gla gli  
Si t’es rich’ t’auras des amis  
A gla gla A gla gli  
C’est la Cigale et la Fourmi

La Fourmi qui était sa voisine  
Avait de tout, même du caviar  
Malheureusement cette radine  
Lui offrit même pas un carambar  
Je vous paierai dit la Cigale  
J’ai du blé sur un compte en Suisse  
L’autre lui dit : “Z’aurez peau d’balle”  
Tout en grignotant un’ saucisse

[Choir]  
A gla gla A gla gli  
Si t’es rich’ t’auras des amis  
A gla gla A gla gli  
C’est la Cigale et la Fourmi

“Que faisiez-vous l’été dernier ?”  
– Je chantais sans penser au pèze  
“Vous chantiez grattos pauvre niaise  
A présent vous pouvez guincher !”  
Si tu veux vivre de chansons  
Avec moins de bas que de haut  
N’oublie jamais cette leçon :  
Il vaut mieux être imprésario

[Choir]  
A gla gla A gla gli  
Si t’es rich’ t’auras des amis  
A gla gla A gla gli  
C’est la Cigale et la Fourmi

[Choir]  
A gla gla A gla gli  
Si t’es rich’ t’auras des amis

English:

The Cicada, queen of the hit parade  
Chirped all summer long  
But one day it was a mess  
She had nothing left to peck at  
When the horrible winter arrived  
She didn't even have a sandwich  
Begging in the draft  
The poor thing was freezing her ass off

[Choir]  
A gla gla A gla gli  
If you're rich you'll have friends  
A gla gla A gla gli  
It's the Cicada and the Ant

The Ant, who was her neighbor  
Had everything, even caviar  
Unfortunately, that stingy girl  
Didn't even offer her a Carambar  
I'll pay you, said the Cicada  
I have money in a Swiss account  
The other said to her: "You'll be skint"  
While nibbling on a sausage

[Choir]  
A gla gla A gla gli  
If If you're rich, you'll have friends  
A gla gla A gla gli  
It's The Ant and the Grasshopper

"What were you doing last summer?"  
– I sang without thinking about the money  
"You were singing grattos, poor fool  
Now you can dance!"  
If you want to live from songs  
With fewer lows than highs  
Never forget this lesson:  
It's better to be an impresario

[Choir]  
A gla gla A gla gli  
If you're rich, you'll have friends  
A gla gla A gla gli  
It's The Ant and the Grasshopper

[Choir]  
A gla gla A gla gli  
If you're rich, you'll have friends
