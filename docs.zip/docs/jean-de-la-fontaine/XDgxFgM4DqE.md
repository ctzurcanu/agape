---
id: XDgxFgM4DqE
title: "Le Chêne et le Roseau - The Oak and the Reed"
sidebar_label: "Le Chêne et le Roseau - The Oak and the Reed"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/XDgxFgM4DqE"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Le Chêne et le Roseau - The Oak and the Reed

Lyrics: Jean de La Fontaine, Pierre Perret

Un chêne baraqué comme l’Himalaya  
Pour qui la tour Eiffel en jetait pas bésef  
Se fendait la tirelire en biglant tout en bas  
Un roseau agité prosterné par le zef

Gros chêne frêle roseau  
Si beaux dans la lumière  
Un’ mauvais’ météo  
Peut vous foutre par terre

Il dit à ce roseau : “mon grand t’es pas chanceux  
Si seulement tu pouvais faire face à la tempête  
Elle qui se casse le blair sur mon buffet noueux  
Alors que tu te couches quand une fourmi pète”

Gros chêne frêle roseau  
Si beaux dans la lumière  
Un’ mauvais’ météo  
Peut vous foutre par terre

Si encore tu poussais à l’ombre de mes tifs  
Tu craindrais pas la pluie le vent les cataclysmes  
Mais c’est dans les marais que tu balanc’ ton pif  
En haut t’as le mistral, en bas les rhumatismes !

Gros chêne frêle roseau  
Si beaux dans la lumière  
Un’ mauvais’ météo  
Peut vous foutre par terre

Le roseau dit au chêne : “espèc’ de gros tocard  
Moi j’ piqu’ du nez partout pour sentir les violettes  
Tandis que toi mon pote, s’il passe un p’tit clébard  
Tu vas où quand il lèv’ la patt’ sur tes chaussett’s ?”

Gros chêne frêle roseau  
Si beaux dans la lumière  
Un’ mauvais’ météo  
Peut vous foutre par terre

Oui t’as vraiment tout faux lui dit le gringalet  
Quand y a un ouragan, moi je ploie les arêtes  
Mais si le vent ne peut me rompre les oss’lets  
A toi il pourrait bien t’arracher les côt’lettes

Gros chêne frêle roseau  
Si beaux dans la lumière  
Un’ mauvais’ météo  
Peut vous foutre par terre

Mais soudain à ces mots la tempête écartèl’  
Cette masse empotée d’orgueil démesuré  
Dont la tête sans doute était proche du ciel  
Mais dont les pieds déjà se trouvaient enterrés

Gros chêne frêle roseau  
Si beaux dans la lumière  
Un’ mauvais’ météo  
Peut vous foutre par terre

English:

A stout oak like the Himalayas  
For whom the Eiffel Tower didn't look good  
Split his piggy bank while squinting at the bottom  
A restless reed prostrated by the wind

Big oak frail reed  
So beautiful in the light  
A bad weather  
Can knock you down

He said to this reed: "my big one you're not lucky  
If only you could face the storm  
She who breaks her hair on my gnarled sideboard  
While you lie down when an ant farts"

Big oak frail reed  
So beautiful in the light  
A bad weather  
Can knock you down

If only you grew in the shade of my hair  
You wouldn't fear the rain the wind the cataclysms  
But it's in the marshes that you swing your nose  
Up there you have the mistral, down there rheumatism!

Big oak frail reed  
So beautiful in the light  
A bad weather  
Can knock you down

The reed said to the oak: “you big loser  
I poke my nose everywhere to smell the violets  
While you my friend, if a little dog passes by  
Where do you go when he lifts his paw on your socks?”

Big oak frail reed  
So beautiful in the light  
A bad weather  
Can knock you down

Yes you're really all wrong the skinny guy told him  
When there's a hurricane, I bend my bones  
But if the wind can't break my bones  
It could well tear your chops off

Big oak frail reed  
So beautiful in the light  
A bad weather  
Can knock you down

But suddenly at these words the storm tore apart  
This clumsy mass of excessive pride  
Whose head was doubtless close to the sky  
But whose feet were already buried

Big oak frail reed  
So beautiful in the light  
A bad weather  
Can knock you down
