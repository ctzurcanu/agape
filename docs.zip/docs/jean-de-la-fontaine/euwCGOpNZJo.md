---
id: euwCGOpNZJo
title: "Le Corbeau et le Renard - The Crow and the Fox"
sidebar_label: "Le Corbeau et le Renard - The Crow and the Fox"
---

<div class="video-float-container">
  <iframe
    width="560"
    height="315"
    src="https://www.youtube.com/embed/euwCGOpNZJo"
    title="YouTube video player"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    referrerpolicy="strict-origin-when-cross-origin"
    allowfullscreen
  ></iframe>
</div>

## Le Corbeau et le Renard - The Crow and the Fox

Lyrics: Jean de La Fontaine, Pierre Perret

Maître Corbeau sur un chêne mastard  
Tenait un fromton dans l’ clapoir  
Maître Renard reniflait qu’au balcon  
Quelque sombre zonard débouchait les flacons  
Il dit : Salut Corbac, c’est vous que je cherchais  
Pour vous dir’ que sans vous fair’ mousser le bréchet  
A côté du costard que vous portez mon cher  
La robe du soir du Paon est une serpillière

Pauvre corbeau  
Tu t’es bien fait avoir  
Mais quelle idée de becqueter sur un chêne  
Et vu qu’ tu chant’s comm’ la rein’ des passoir’s  
C’est bien coton d’en vouloir au renard

Quand vous chantez il paraîtrait sans charre  
Que les merles en ont des cauch’mards  
Lors à ces mots plus fier que sa crémièr’  
Le corbeau ouvrit grand son piège à vers de terre  
Pour montrer qu’il pouvait chanter Rigoletto  
Cette grain’ de patat’ lâcha son calendo  
Le renard l’engloutit en disant c’est navrant  
Il est pas fait à cœur je l’ préfèr’ plus coulant

Pauvre corbeau  
Tu t’es bien fait avoir  
Mais quelle idée de becqueter sur un chêne  
Et vu qu’ tu chant’s comm’ la rein’ des passoir’s  
C’est bien coton d’en vouloir au renard

Pauvre corbeau  
Tu t’es bien fait avoir  
Mais quelle idée de becqueter sur un chêne  
Et vu qu’ tu chant’s comm’ la rein’ des passoir’s  
C’est bien coton d’en vouloir au renard  
On est forcés de r’connaîtr’ en tout cas  
Que cett’ histoir’ de Monsieur d’ la Fontaine  
Rendit prudents les chanteurs d’opéra  
Et c’est depuis qu’ils chantent la bouch’ pleine

English:

Master Crow on a mastard oak  
He was holding a cheese in the clapoir  
Master Fox was sniffing only on the balcony  
Some dark zonard was uncorking the bottles  
He said: Hi Crow, it's you I was looking for  
To tell you that without making your breastplate foam  
Compared to the suit you're wearing my dear  
The Peacock's evening dress is a mop

Poor crow  
You've been had  
But what an idea to peck on an oak  
And since you sing like the queen of the sieves  
It's really cotton to want to blame the fox

When you sing he would seem without a cart  
That blackbirds have nightmares  
Then at these words prouder than his dairy  
The crow opened wide his earthworm trap  
To show that he could sing Rigoletto  
This grain of potato dropped his calendo  
The fox swallowed it saying it's pitiful  
It's not made to the heart I prefer it more flowing

Poor crow  
You really got had  
But what a great idea to peck at an oak tree  
And since you sing like the queen of the sieves  
It's really tough to blame the fox

Poor crow  
You really got had  
But what a great idea to peck at an oak tree  
And since you sing like the queen of the sieves  
It's really tough to blame the fox  
We're forced to recognize in any case  
That this story of Monsieur d' la Fontaine  
Made opera singers cautious  
And it's since they've been singing with their mouths full
